// Portions derived from FoundationDB Record Layer (MetaDataException.java,
// RecordCoreException.java, SplitHelper.java, RecordCoreStorageException.java,
// and others),
// Copyright 2015-2018 Apple Inc. and the FoundationDB project authors
// Licensed under the Apache License, Version 2.0; translated to Go and modified.

package recordlayer

import (
	"fmt"
	"reflect"

	"github.com/google/uuid"

	"fdb.dev/gen"
	"fdb.dev/pkg/fdbgo/fdb/tuple"
	"fdb.dev/pkg/recordlayer/protoname"
)

// Phase 1: Store existence errors (replace sentinels from store.go)

// RecordStoreAlreadyExistsError is returned when attempting to create a store that already exists.
// Matches Java's com.apple.foundationdb.record.provider.foundationdb.RecordStoreAlreadyExistsException.
type RecordStoreAlreadyExistsError struct{}

func (e *RecordStoreAlreadyExistsError) Error() string {
	return "record store already exists"
}

func (*RecordStoreAlreadyExistsError) JavaRecordCoreException() {}

// RecordStoreDoesNotExistError is returned when attempting to open a store that does not exist.
// Matches Java's com.apple.foundationdb.record.provider.foundationdb.RecordStoreDoesNotExistException.
type RecordStoreDoesNotExistError struct{}

func (e *RecordStoreDoesNotExistError) Error() string {
	return "record store does not exist"
}

func (*RecordStoreDoesNotExistError) JavaRecordCoreException() {}

// RecordStoreNoInfoButNotEmptyError is returned when a store subspace has data
// but no valid store header (StoreInfoKey).
// Matches Java's com.apple.foundationdb.record.provider.foundationdb.RecordStoreNoInfoAndNotEmptyException.
type RecordStoreNoInfoButNotEmptyError struct {
	FirstKey []byte // First key found in the subspace (Java's LogMessageKeys.KEY)
}

func (e *RecordStoreNoInfoButNotEmptyError) Error() string {
	if e.FirstKey != nil {
		return fmt.Sprintf("record store has no info but is not empty (first key: %x)", e.FirstKey)
	}
	return "record store has no info but is not empty"
}

func (*RecordStoreNoInfoButNotEmptyError) JavaRecordCoreException() {}

// RecordStoreStateNotLoadedError is returned when store operations are called
// before the store state has been loaded via Create/Open/CreateOrOpen.
// Matches Java's com.apple.foundationdb.record.provider.foundationdb.UninitializedRecordStoreException.
type RecordStoreStateNotLoadedError struct{}

func (e *RecordStoreStateNotLoadedError) Error() string {
	return "record store state not loaded"
}

func (*RecordStoreStateNotLoadedError) JavaRecordCoreException() {}

// Phase 1: Index errors (replace sentinels from index_state.go)

// IndexNotReadableError is returned when trying to scan an index that is not in a readable state.
// Matches Java's com.apple.foundationdb.record.ScanNonReadableIndexException.
type IndexNotReadableError struct {
	IndexName    string
	CurrentState IndexState
}

func (e *IndexNotReadableError) Error() string {
	return fmt.Sprintf("index is not readable: %s is %s", e.IndexName, e.CurrentState)
}

func (*IndexNotReadableError) JavaRecordCoreException() {}

// IndexNotFoundError is returned when an index name is not found in the metadata.
// Matches Java's MetaDataException for missing indexes.
type IndexNotFoundError struct {
	IndexName string
}

func (e *IndexNotFoundError) Error() string {
	return fmt.Sprintf("index not found in metadata: %s", e.IndexName)
}

func (*IndexNotFoundError) JavaRecordCoreException() {}

// IndexNotBuiltError is returned when trying to mark an index as readable but it has
// unbuilt ranges or pending index writes remain.
type IndexNotBuiltError struct {
	IndexName     string
	PendingWrites bool
}

func (e *IndexNotBuiltError) Error() string {
	if e.PendingWrites {
		return fmt.Sprintf("index is not built: %q has pending writes", e.IndexName)
	}
	return fmt.Sprintf("index is not built: %q has unbuilt ranges", e.IndexName)
}

// Phase 2: Missing error types for implemented features

// MetaDataError is returned for metadata validation failures.
// Matches Java's com.apple.foundationdb.record.metadata.MetaDataException.
type MetaDataError struct {
	Message string
	// Cause is Java's exception cause, when the MetaDataException was built with
	// one (MetaDataException(message, cause)); Error is the message alone, as
	// Java's getMessage is.
	Cause error
}

func (e *MetaDataError) Error() string {
	return e.Message
}

func (*MetaDataError) JavaRecordCoreException() {}

// Unwrap reports this as the RecordCoreError Java's MetaDataException is (it
// extends RecordCoreException), so a caller matching RecordCoreError catches it
// as `catch (RecordCoreException)` does, and returns the cause, so errors.As
// reaches it as Java's getCause does.
func (e *MetaDataError) Unwrap() []error {
	parent := &RecordCoreError{Message: e.Message}
	if e.Cause == nil {
		return []error{parent}
	}
	return []error{parent, e.Cause}
}

// RecordCoreException is implemented by every error type porting a Java
// RecordCoreException subclass. The relational layer gives one that none of
// its specific arms claims ErrorCode.UNKNOWN, as ExceptionUtil does.
type RecordCoreException interface {
	error
	JavaRecordCoreException()
}

// metaDataException marks the Go types whose Java class is MetaDataException
// or a subclass of it (IsMetaDataException).
type metaDataException interface{ javaMetaDataException() }

func (*MetaDataError) javaMetaDataException()                     {}
func (*MetaDataProtoDeserializationError) javaMetaDataException() {}
func (*UnknownIndexTypeError) javaMetaDataException()             {}
func (*IndexVersionTooNewError) javaMetaDataException()           {}
func (*IndexNotFoundError) javaMetaDataException()                {}
func (*MetaDataVersionMustIncreaseError) javaMetaDataException()  {}
func (*RecordTypeKeyTypeError) javaMetaDataException()            {}
func (*GoOnlyCollationError) javaMetaDataException()              {}

// IsMetaDataException reports whether err's outermost Java exception is a
// MetaDataException, as Java's `re instanceof MetaDataException` tests the
// exception thrown and not its causes (ExceptionUtil.recordCoreToRelationalException).
// The outermost Java exception is the first error of this package met walking
// err's wrappers (fmt's %w, and the first of several), each of which is a Java
// exception class; a MetaDataError that is only the cause of another is not.
func IsMetaDataException(err error) bool {
	switch OutermostJavaError(err).(type) {
	case metaDataException:
		return true
	case *protoname.InvalidNameError:
		// Java's ProtoUtils.InvalidNameException extends MetaDataException
		// (ProtoUtils.java:153); its Go type lives in protoname, which this
		// package aliases as InvalidNameError.
		return true
	}
	return false
}

// OutermostJavaError is the first error of this package (or of protoname,
// which it aliases) on err's chain of wrappers, following the first of
// several; nil when there is none.
func OutermostJavaError(err error) error {
	for e := err; e != nil; {
		if t := reflect.TypeOf(e); t.Kind() == reflect.Pointer && javaErrorPkgPaths[t.Elem().PkgPath()] {
			return e
		}
		switch u := e.(type) {
		case interface{ Unwrap() error }:
			e = u.Unwrap()
		case interface{ Unwrap() []error }:
			if errs := u.Unwrap(); len(errs) > 0 {
				e = errs[0]
			} else {
				e = nil
			}
		default:
			e = nil
		}
	}
	return nil
}

// javaErrorPkgPaths are the packages whose error types are Java exception
// classes: this one, and protoname, whose InvalidNameError this package
// aliases.
var javaErrorPkgPaths = map[string]bool{
	reflect.TypeOf(MetaDataError{}).PkgPath():              true,
	reflect.TypeOf(protoname.InvalidNameError{}).PkgPath(): true,
}

// RecordCoreMessages is the message of every RecordCoreError in err's tree, in
// errors.As order (depth first, each error before what it wraps), each once:
// the Java RecordCoreExceptions an error is, and wraps, as their messages. A
// test asserts with it which exceptions a refusal carries, where errors.As
// finds only the first.
func RecordCoreMessages(err error) []string {
	var out []string
	seen := map[string]bool{}
	var walk func(error)
	walk = func(e error) {
		if e == nil {
			return
		}
		if core, ok := e.(*RecordCoreError); ok && !seen[core.Message] {
			seen[core.Message] = true
			out = append(out, core.Message)
		}
		switch u := e.(type) {
		case interface{ Unwrap() error }:
			walk(u.Unwrap())
		case interface{ Unwrap() []error }:
			for _, c := range u.Unwrap() {
				walk(c)
			}
		}
	}
	walk(err)
	return out
}

// UnknownIndexTypeError is raised when no index maintainer implements an index's
// type. It is the port of Java's registry miss:
// IndexMaintainerFactoryRegistryImpl.getIndexMaintainerFactory looks the type up
// and throws MetaDataException("Unknown index type for " + index) when the lookup
// returns null (IndexMaintainerFactoryRegistryImpl.java:78-82).
//
// It FAILS CLOSED, and the reason is a wire-format one rather than a tidiness
// one. Go used to answer an unrecognised type with the STANDARD maintainer — the
// VALUE-index one. An index whose type this build does not implement was
// therefore not rejected: it was silently maintained as a value index, writing
// value-index key bytes into that index's own subspace. Nothing surfaces at write
// time, because a value index is perfectly happy to serve those writes. The
// damage appears when a build that DOES implement the type reads that subspace
// and finds another format's entries, or when Java reads it and finds entries its
// maintainer never wrote. An index this process cannot maintain must stop the
// write, not receive a guess.
//
// Unwraps to *MetaDataError so `errors.As` for the general metadata failure
// matches — the Go equivalent of Java's `catch (MetaDataException)`, which is
// what callers of the registry actually catch — while a caller that wants the
// index identity can match this type directly.
type UnknownIndexTypeError struct {
	IndexName string
	IndexType string
}

func (e *UnknownIndexTypeError) Error() string {
	return fmt.Sprintf("Unknown index type %q for index %q", e.IndexType, e.IndexName)
}

func (*UnknownIndexTypeError) JavaRecordCoreException() {}

// Unwrap reports this as a metadata failure. Java's exception IS a
// MetaDataException; in Go the identity fields need their own struct, so the
// relationship Java gets from inheritance is spelled out here.
func (e *UnknownIndexTypeError) Unwrap() error {
	return &MetaDataError{Message: e.Error()}
}

// GoOnlyCollationError rejects provider-specific collation keys without explicit
// Go-only opt-in. It unwraps to MetaDataError; Java has no equivalent refusal.
type GoOnlyCollationError struct {
	Function       string
	IndexName      string // the refused index, or "" for a primary key
	RecordTypeName string // the record type whose primary key is refused
	RecordCountKey bool   // the legacy record-count expression is refused
}

func (e *GoOnlyCollationError) Error() string {
	subject := fmt.Sprintf("index %q", e.IndexName)
	if e.RecordCountKey {
		subject = "record count key"
	} else if e.IndexName == "" {
		subject = fmt.Sprintf("primary key of record type %q", e.RecordTypeName)
	}
	return fmt.Sprintf("%s uses %s, whose Go collation keys are not the bytes Java writes; "+
		"only a store no Java process opens may use it, opened with StoreBuilder.SetGoOnlyCollation(true)",
		subject, e.Function)
}

func (*GoOnlyCollationError) JavaRecordCoreException() {}

func (e *GoOnlyCollationError) Unwrap() error {
	return &MetaDataError{Message: e.Error()}
}

// IndexVersionKind names which of an index's two version stamps a
// IndexVersionTooNewError refers to.
type IndexVersionKind string

const (
	// IndexVersionAdded is the version at which the index was introduced.
	IndexVersionAdded IndexVersionKind = "added"
	// IndexVersionLastModified is the version at which the index definition last changed.
	IndexVersionLastModified IndexVersionKind = "last modified"
)

// IndexVersionTooNewError is returned when an index declares a version that is
// newer than the metadata version carrying it.
//
// Such metadata is not merely untidy: an index whose lastModifiedVersion exceeds
// the metadata version is permanently "new since" every store header version, so
// every subsequent version bump re-runs the rebuild decision for it and can clear
// an index a background build already populated.
//
// Matches Java's MetaDataValidator.validateIndex(), which throws MetaDataException
// for both the added-version and last-modified-version cases
// (MetaDataValidator.java:124-133).
type IndexVersionTooNewError struct {
	IndexName           string
	Kind                IndexVersionKind
	AddedVersion        int
	LastModifiedVersion int
	MetaDataVersion     int
}

func (e *IndexVersionTooNewError) Error() string {
	offending := e.AddedVersion
	if e.Kind == IndexVersionLastModified {
		offending = e.LastModifiedVersion
	}
	// Java's text (MetaDataValidator.java:124-133): the index name unquoted.
	return fmt.Sprintf("Index %s has %s version %d which is greater than the meta-data version %d",
		e.IndexName, e.Kind, offending, e.MetaDataVersion)
}

func (*IndexVersionTooNewError) JavaRecordCoreException() {}

// Unwrap reports this as a metadata validation failure so that callers matching
// on *MetaDataError keep working, mirroring Java where this is a MetaDataException.
func (e *IndexVersionTooNewError) Unwrap() error {
	return &MetaDataError{Message: e.Error()}
}

// UnsupportedFormatVersionError is returned when a store header contains a format
// version higher than the maximum version this code supports.
// Matches Java's com.apple.foundationdb.record.provider.foundationdb.UnsupportedFormatVersionException.
type UnsupportedFormatVersionError struct {
	Version    int32
	MaxVersion int32
}

func (e *UnsupportedFormatVersionError) Error() string {
	return fmt.Sprintf("unsupported format version %d (max supported: %d)", e.Version, e.MaxVersion)
}

func (*UnsupportedFormatVersionError) JavaRecordCoreException() {}

// UnsupportedFeatureForFormatVersionError is returned when a version-gated store
// feature is used on a store whose header format version predates it.
//
// Java raises a RecordCoreException with LogMessageKeys.FORMAT_VERSION at each
// such site — e.g. "Store does not support setting a store lock state"
// (FDBRecordStore.java:3478/:3494), "Store does not support updating record count
// state" (:3443), "Store does not support incarnation" (:3503/:3517), "cannot
// access header user fields at current format version" (:3222). The guard exists
// because these features WRITE new store-header fields: an instance still pinned
// at the older format can open the store and will simply not understand them, so
// a lock it cannot see is a lock it will not honour.
type UnsupportedFeatureForFormatVersionError struct {
	Feature         string
	Version         int32
	RequiredVersion int32
}

func (e *UnsupportedFeatureForFormatVersionError) Error() string {
	return fmt.Sprintf("store does not support %s at format version %d (requires >= %d)",
		e.Feature, e.Version, e.RequiredVersion)
}

func (*UnsupportedFeatureForFormatVersionError) JavaRecordCoreException() {}

// RecordSerializationError is Java's
// com.apple.foundationdb.record.provider.common.RecordSerializationException:
// a record's bytes could not be produced, or a transformation's could not be
// read back (a compression, encryption or prefix failure on either path).
// Message is the exception's message; one with only a cause (a protobuf
// marshal failure, Java's RecordSerializationException(Throwable)) renders as
// "failed to serialize record".
type RecordSerializationError struct {
	Message string
	Cause   error
	// RetryCount and RetryResult are the log keys Java's
	// decryptAndDecompressWithRetries adds to a read's failure: the configured
	// reattempt count and "failure" when every attempt failed, or the attempt
	// that succeeded and "success" when failOnDeserializeReattempt refuses a
	// reattempt's success. RetryResult is "" on every other error.
	RetryCount  int
	RetryResult string
	// MetaDataVersion is the reading store's metadata version on a refused
	// reattempt (Java's META_DATA_VERSION log key), when a store read it.
	MetaDataVersion int
	// generalSecurity marks the wrapping of a cipher failure, Java's
	// GeneralSecurityException, which the write-time encryption validation
	// catches and a key manager's own RecordSerializationException it does not.
	generalSecurity bool
}

func (e *RecordSerializationError) Error() string {
	switch {
	case e.Message != "" && e.Cause != nil:
		return e.Message + ": " + e.Cause.Error()
	case e.Message != "":
		return e.Message
	}
	return fmt.Sprintf("failed to serialize record: %v", e.Cause)
}

func (*RecordSerializationError) JavaRecordCoreException() {}

func (e *RecordSerializationError) Unwrap() error {
	return e.Cause
}

// RecordSerializationValidationError is Java's
// com.apple.foundationdb.record.provider.common.RecordSerializationValidationException:
// a sampled write-time validation found a record's stored bytes would not read
// back as the record ("cannot deserialize record", "record serialization
// mismatch") or its encryption would not decrypt to its input ("encryption
// validation error: ..."). Like Java's, it is a RecordCoreException and not a
// RecordSerializationException. RecordType and PrimaryKey are its log keys.
type RecordSerializationValidationError struct {
	Message    string
	RecordType string
	PrimaryKey tuple.Tuple
	Cause      error
}

func (e *RecordSerializationValidationError) Error() string {
	msg := e.Message
	if e.RecordType != "" {
		msg += fmt.Sprintf(" (record type %s, primary key %v)", e.RecordType, e.PrimaryKey)
	}
	if e.Cause != nil {
		msg += ": " + e.Cause.Error()
	}
	return msg
}

func (*RecordSerializationValidationError) JavaRecordCoreException() {}

func (e *RecordSerializationValidationError) Unwrap() error {
	return e.Cause
}

// RecordDeserializationError is returned when a record fails to deserialize (unmarshal) from protobuf.
// Matches Java's com.apple.foundationdb.record.provider.foundationdb.RecordDeserializationException.
type RecordDeserializationError struct {
	PrimaryKey any // tuple.Tuple, but using any to avoid import cycle
	Cause      error
}

func (e *RecordDeserializationError) Error() string {
	if e.PrimaryKey != nil {
		return fmt.Sprintf("failed to deserialize record %v: %v", e.PrimaryKey, e.Cause)
	}
	return fmt.Sprintf("failed to deserialize record: %v", e.Cause)
}

func (*RecordDeserializationError) JavaRecordCoreException() {}

func (e *RecordDeserializationError) Unwrap() error {
	return e.Cause
}

// ContinuationParseError is returned when continuation bytes fail to parse as
// their wrapper proto or cursor-specific encoding. For proto wrappers, it matches
// Java's RecordCoreException("error parsing continuation") with the "raw_bytes"
// log info key (e.g. OrElseCursor's constructor, RecordCursor.fromList).
// Chained's bool-returning decoder cannot supply an underlying error, so Cause
// describes its rejection instead; Java propagates the decoder's exception.
// A corrupt continuation must surface, never silently become a fresh start.
//
// Message overrides the default "error parsing continuation" text for the Java
// classes whose RecordCoreException wording differs (ConcatCursor uses
// "Error parsing ConcatCursor continuation", DedupCursor uses
// "Error parsing continuation"). Leave empty for the common wording.
type ContinuationParseError struct {
	Message  string
	RawBytes []byte
	Cause    error
}

func (e *ContinuationParseError) Error() string {
	msg := e.Message
	if msg == "" {
		msg = "error parsing continuation"
	}
	return fmt.Sprintf("%s (raw_bytes=%x): %v", msg, e.RawBytes, e.Cause)
}

func (*ContinuationParseError) JavaRecordCoreException() {}

func (e *ContinuationParseError) Unwrap() error {
	return e.Cause
}

// ContinuationEncodeError reports a value whose encoder cannot supply a
// resumable continuation. Java requires a non-null ChainedCursor encoder and
// RecordCursorResult.withNextValue throws RecordCoreException if its encoding
// represents the end. Go reports these failures as errors rather than panics.
type ContinuationEncodeError struct {
	Message string
}

func (e *ContinuationEncodeError) Error() string {
	return e.Message
}

func (*ContinuationEncodeError) JavaRecordCoreException() {}

// QueryInvalidExpressionError is Java's
// com.apple.foundationdb.record.query.expressions.Query.InvalidExpressionException,
// an IllegalStateException (Query.java:273), not a RecordCoreException and not
// KeyExpression's: key validation raises it for a message field read as a
// scalar.
type QueryInvalidExpressionError struct {
	Message string
}

func (e *QueryInvalidExpressionError) Error() string {
	return e.Message
}

// KeyExpressionError is returned when a key expression evaluation fails.
// Matches Java's com.apple.foundationdb.record.metadata.expressions.KeyExpression.InvalidExpressionException.
type KeyExpressionError struct {
	Message string
}

func (e *KeyExpressionError) Error() string {
	return e.Message
}

// unknownRecordTypeError is Java's RecordMetaData.unknownTypeException
// (RecordMetaData.java:825-827), which getRecordType, getIndexableRecordType and
// getRecordTypeForDescriptor throw for a name the meta-data does not hold.
func unknownRecordTypeError(name string) *MetaDataError {
	return &MetaDataError{Message: "Unknown record type " + name}
}

// KeyExpressionDeserializationError is Java's
// KeyExpression.DeserializationException (a RecordCoreException): a
// serialized key expression that cannot be read back, as one with no root or
// with several (KeyExpression.java:404-405), a field without its name or fan
// type (FieldKeyExpression.java:122-128), a nesting without its parent
// (NestingKeyExpression.java:69) or a then of fewer than two children
// (ThenKeyExpression.java:84).
type KeyExpressionDeserializationError struct {
	Message string
}

func (e *KeyExpressionDeserializationError) Error() string {
	return e.Message
}

func (*KeyExpressionDeserializationError) JavaRecordCoreException() {}

// Unwrap reports it as the RecordCoreError Java's exception is, so a caller
// matching RecordCoreError catches it as `catch (RecordCoreException)` does.
func (e *KeyExpressionDeserializationError) Unwrap() error {
	return &RecordCoreError{Message: e.Message}
}

// MetaDataProtoDeserializationError is Java's
// RecordMetaDataBuilder.MetaDataProtoDeserializationException, a
// MetaDataException "Error converting from protobuf" whose cause is the
// failure: a key expression of the meta-data proto that cannot be read (an
// index's root, a record type's primary key, the record-count key; a
// KeyExpressionDeserializationError), or the subspace-key counter settings
// disagreeing (RecordMetaDataBuilder.java:187-292).
type MetaDataProtoDeserializationError struct {
	Cause error
}

func (e *MetaDataProtoDeserializationError) Error() string { return "Error converting from protobuf" }

// Unwrap reports it as the MetaDataError Java's exception is, and its cause.
func (e *MetaDataProtoDeserializationError) Unwrap() []error {
	return []error{&MetaDataError{Message: e.Error(), Cause: e.Cause}, e.Cause}
}

func (*MetaDataProtoDeserializationError) JavaRecordCoreException() {}

// UnsupportedOperationError corresponds to Java's UnsupportedOperationException.
type UnsupportedOperationError struct{ Message string }

func (e *UnsupportedOperationError) Error() string { return e.Message }

// ClassCastError corresponds to Java's ClassCastException, e.g. a vector
// index reading a value column that is not bytes (Tuple.getBytes).
type ClassCastError struct{ Message string }

func (e *ClassCastError) Error() string { return e.Message }

// IndexOutOfBoundsError corresponds to Java's IndexOutOfBoundsException, e.g.
// a vector index entry without a value column or with an unknown vector type.
type IndexOutOfBoundsError struct{ Message string }

func (e *IndexOutOfBoundsError) Error() string { return e.Message }

// RecordCoreError carries Java's base RecordCoreException diagnostics and cause.
type RecordCoreError struct {
	IndexOption string
	Message     string
	IndexName   string
	Cause       error
}

func (e *RecordCoreError) Error() string { return e.Message }
func (e *RecordCoreError) Unwrap() error { return e.Cause }

// RecordCoreInternalError reports an internal invariant violation, matching
// Java's RecordCoreInternalException.
type RecordCoreInternalError struct {
	Message string
}

func (*RecordCoreError) JavaRecordCoreException() {}

func (e *RecordCoreInternalError) Error() string { return e.Message }

// RecordCoreStorageError signals storage-level corruption detected while
// resolving an index entry to its base record. Matches Java's
// com.apple.foundationdb.record.RecordCoreStorageException.
//
// When a record is fetched from an index entry with IndexOrphanBehavior.ERROR
// (FDBRecordStoreBase.loadIndexEntryRecord) and the referenced record is
// missing, Java throws this exception rather than dropping the row, attaching
// LogMessageKeys.INDEX_NAME / PRIMARY_KEY / INDEX_KEY. An index entry with no
// base record means the index and the records disagree — index corruption, an
// out-of-band delete, or a maintainer bug — and both query execution
// (RecordQueryIndexPlan → FetchIndexRecords.PRIMARY_KEY) and the index-from-index
// rebuild (scanIndexRecords defaults to ERROR) use this loud path. Silently
// skipping would convert detectable corruption into quietly-fewer rows.
type RecordCoreStorageError struct {
	Message       string      // Java's RecordCoreStorageException message
	IndexName     string      // LogMessageKeys.INDEX_NAME
	PrimaryKey    tuple.Tuple // LogMessageKeys.PRIMARY_KEY (nil if the entry yielded no PK)
	IndexKey      tuple.Tuple // LogMessageKeys.INDEX_KEY
	KeyTuple      tuple.Tuple // LogMessageKeys.KEY_TUPLE
	Version       *int32      // LogMessageKeys.VERSION (reader version)
	StoredVersion *int32      // LogMessageKeys.STORED_VERSION
	ExpectedType  string      // Bound protobuf full name, the language-independent message identity
	ActualType    string      // LogMessageKeys.ACTUAL_TYPE (stored Any type URL)
	Cause         error       // the exception's cause, e.g. the store header's parse error
}

func (*RecordCoreInternalError) JavaRecordCoreException() {}

func (e *RecordCoreStorageError) Error() string {
	if e.Cause != nil && e.KeyTuple == nil && e.IndexName == "" {
		return fmt.Sprintf("%s: %v", e.Message, e.Cause)
	}
	if e.KeyTuple != nil {
		message := fmt.Sprintf("%s (key_tuple=%v", e.Message, e.KeyTuple)
		if e.Version != nil && e.StoredVersion != nil {
			message += fmt.Sprintf(", version=%d, stored_version=%d", *e.Version, *e.StoredVersion)
		}
		if e.ExpectedType != "" {
			message += fmt.Sprintf(", expected_type=%s, actual_type=%s", e.ExpectedType, e.ActualType)
		}
		return message + ")"
	}
	return fmt.Sprintf("%s (index_name=%s, primary_key=%v, index_key=%v)",
		e.Message, e.IndexName, e.PrimaryKey, e.IndexKey)
}

func (*RecordCoreStorageError) JavaRecordCoreException() {}

// Unwrap returns the cause.
func (e *RecordCoreStorageError) Unwrap() error { return e.Cause }

// RecordContextNotActiveError is Java's RecordContextNotActiveException, a
// RecordCoreStorageException: the context's transaction is no longer active.
// A context is deactivated by its commit whatever the outcome, and a context a
// transaction route (FDBDatabase.Run and its variants, the runner) hands its
// body is the route's to commit, so a commit there is refused before anything
// commits. errors.As finds it as itself and as a *RecordCoreStorageError.
type RecordContextNotActiveError struct{ Message string }

func (e *RecordContextNotActiveError) Error() string { return e.Message }

func (*RecordContextNotActiveError) JavaRecordCoreException() {}

// Unwrap exposes the RecordCoreStorageException superclass.
func (e *RecordContextNotActiveError) Unwrap() error {
	return &RecordCoreStorageError{Message: e.Message}
}

// errTransactionNotActive is FDBRecordContext.ensureActive's refusal.
func errTransactionNotActive() error {
	return &RecordContextNotActiveError{Message: "Transaction is no longer active."}
}

// FoundSplitOutOfOrderError is raised when a split record's segments are present
// but not in sequence — segment N+1 was expected and something else was found.
//
// Ports Java's SplitHelper.FoundSplitOutOfOrderException
// (SplitHelper.java:1225-1231), which extends RecordCoreStorageException and
// carries LogMessageKeys.SPLIT_EXPECTED / SPLIT_FOUND. Java additionally attaches
// KEY_TUPLE and SUBSPACE at the throw site (SplitHelper.java:826-828); KeyTuple
// carries the first of those, and the subspace is implicit in it here.
//
// It is a distinct type from FoundSplitWithoutStartError on purpose, because the
// two describe different damage: this one says the record's pieces are all
// there but mis-sequenced, which points at a writer that interleaved or a range
// that spans two records. A caller that wants to tell "corrupt but complete"
// from "truncated" cannot do it from a formatted string.
type FoundSplitOutOfOrderError struct {
	Expected int64       // LogMessageKeys.SPLIT_EXPECTED
	Found    int64       // LogMessageKeys.SPLIT_FOUND
	KeyTuple tuple.Tuple // LogMessageKeys.KEY_TUPLE — the key whose suffix broke the sequence
}

func (e *FoundSplitOutOfOrderError) Error() string {
	return fmt.Sprintf("Split record segments out of order (split_expected=%d, split_found=%d, key_tuple=%v)",
		e.Expected, e.Found, e.KeyTuple)
}

func (*FoundSplitOutOfOrderError) JavaRecordCoreException() {}

// Unwrap reports this as storage corruption. Java's exception IS a
// RecordCoreStorageException; Go spells that relationship out so a caller
// matching the general storage-corruption type keeps working, the way
// `catch (RecordCoreStorageException)` does.
func (e *FoundSplitOutOfOrderError) Unwrap() error {
	return &RecordCoreStorageError{Message: "Split record segments out of order"}
}

// FoundSplitWithoutStartError is raised when a split record's continuation
// segments are found with no start segment — the record is truncated at the
// front, not merely mis-ordered.
//
// Ports Java's SplitHelper.FoundSplitWithoutStartException
// (SplitHelper.java:1213-1219), carrying LogMessageKeys.SPLIT_NEXT_INDEX and
// SPLIT_REVERSE, plus KEY_TUPLE from the throw sites.
//
// Java chooses between this and FoundSplitOutOfOrderException by whether any
// start-or-later segment has already been seen — `lastIndex >= START_SPLIT_RECORD`
// picks out-of-order, otherwise without-start (SplitHelper.java:824-835). Go
// raised one untyped error for both, so a truncated record and a scrambled one
// were indistinguishable to every caller and to every log.
//
// Reverse matters for reading the report: under a reverse scan the segments
// arrive highest-first, so "no start yet" is the expected intermediate state
// rather than evidence of damage, and Java records which direction produced the
// judgement.
type FoundSplitWithoutStartError struct {
	NextIndex int64       // LogMessageKeys.SPLIT_NEXT_INDEX — the segment found instead of the start
	Reverse   bool        // LogMessageKeys.SPLIT_REVERSE — direction of the scan that found it
	KeyTuple  tuple.Tuple // LogMessageKeys.KEY_TUPLE
}

func (e *FoundSplitWithoutStartError) Error() string {
	return fmt.Sprintf("Found split record without start (next_index=%d, reverse=%t, key_tuple=%v)",
		e.NextIndex, e.Reverse, e.KeyTuple)
}

func (*FoundSplitWithoutStartError) JavaRecordCoreException() {}

// PartlyBuiltError is returned when an OnlineIndexer encounters an index that was
// partly built by another method or is blocked from continuing.
// Matches Java's com.apple.foundationdb.record.provider.foundationdb.IndexingBase.PartlyBuiltException.
type PartlyBuiltError struct {
	IndexName     string
	SavedStamp    string // string representation of the saved stamp
	ExpectedStamp string // string representation of the expected stamp
	Message       string
	// Saved and Expected are the stamps themselves (Java getSavedStamp and
	// getExpectedStamp). The build catcher resumes the saved stamp's method.
	Saved    *gen.IndexBuildIndexingStamp
	Expected *gen.IndexBuildIndexingStamp
	// IndexerID is the refusing indexer's identity, Java's INDEXER_ID log key
	// (IndexingBase.java:604, :1011-1012).
	IndexerID uuid.UUID
	// IndexVersion is the index's last-modified version, Java's INDEX_VERSION
	// log key (IndexingBase.java:1291).
	IndexVersion int
}

func (e *PartlyBuiltError) Error() string {
	return fmt.Sprintf("index %q: %s (saved=%s, expected=%s)",
		e.IndexName, e.Message, e.SavedStamp, e.ExpectedStamp)
}

func (*PartlyBuiltError) JavaRecordCoreException() {}

// DuplicateIndexOptionError is returned when stored index metadata lists one
// option key twice. The Java counterpart is the IllegalArgumentException Guava's
// ImmutableMap.Builder.build throws from Index.buildOptions (Index.java:253-266);
// Error reproduces its message, which names the later entry first.
type DuplicateIndexOptionError struct {
	Key string
	// First and Second are the values in stored order.
	First, Second string
}

func (e *DuplicateIndexOptionError) Error() string {
	return fmt.Sprintf("Multiple entries with same key: %s=%s and %s=%s", e.Key, e.Second, e.Key, e.First)
}

// IncompleteVersionstampError is returned when a tuple carrying an INCOMPLETE
// versionstamp reaches an encoder that can only write a complete one.
//
// The Java counterpart is the IllegalArgumentException thrown by
// TupleOrdering.packNullsLast (TupleOrdering.java:178) and by Tuple.pack, whose
// message this reproduces verbatim. Java THROWS; the Go port used to reach the
// same condition through tuple.Pack, which PANICS — a library-boundary crash
// where Java hands the caller a recoverable failure. Every site that can put a
// versionstamp in front of a vanilla pack returns this instead.
//
// Reachable from a VERSION index whose version lands in the VALUE portion of a
// KeyWithValue split (IndexTest.createVersionIndexWithVersionInValue), or from
// ordering functions over versions in legal VALUE indexes and primary keys.
// A VERSION index rooted at an ordering function is instead refused at metadata
// validation because functions declare zero version columns.
type IncompleteVersionstampError struct {
	// Context names the encoder that refused, e.g. the index whose entry was
	// being written.
	Context string
}

func (e *IncompleteVersionstampError) Error() string {
	const msg = "Incomplete Versionstamp included in vanilla tuple pack"
	if e.Context == "" {
		return msg
	}
	return e.Context + ": " + msg
}
