// Portions derived from FoundationDB Record Layer (FDBRecordContextConfig.java,
// FDBDatabaseRunner.java, FDBRecordContext.java, FDBDatabaseRunnerImpl.java),
// Copyright 2015-2018 Apple Inc. and the FoundationDB project authors
// Copyright 2015-2019 Apple Inc. and the FoundationDB project authors
// Copyright 2015-2020 Apple Inc. and the FoundationDB project authors
// Licensed under the Apache License, Version 2.0; translated to Go and modified.

package recordlayer

import (
	"context"
	"sort"
	"time"

	"fdb.dev/pkg/fdbgo/fdb"
)

// RecordContextConfig holds configuration for creating FDBRecordContext instances.
// Matches Java's FDBRecordContextConfig.
type RecordContextConfig struct {
	// TransactionTimeout is the timeout for the FDB transaction.
	// Zero means use FDB's default.
	TransactionTimeout time.Duration

	// Priority sets the transaction priority.
	Priority TransactionPriority

	// TransactionID is an optional identifier for tracing/debugging.
	TransactionID string

	// TransactionSizeWarnBytes (Go-only): past it, a save or delete logs and counts
	// CountTransactionSizeWarning once per transaction, and still succeeds. Zero disables it.
	TransactionSizeWarnBytes int64

	// TransactionSizeErrorBytes causes operations to return
	// TransactionSizeExceededError when the approximate transaction
	// size exceeds this threshold. Zero disables the check.
	// Setting this below FDB's 10MB limit lets callers commit early.
	TransactionSizeErrorBytes int64

	// Tags are transaction tags used for tag-based throttling, applied to every
	// transaction this config creates. Matches Java's FDBRecordContextConfig
	// tags (FDBRecordContextConfig.java:60), which are applied one at a time via
	// transaction.options().setTag (FDBRecordContext.java:205-207) — the plain
	// TAG option, never AUTO_THROTTLE_TAG.
	//
	// Java models this as a Set<String>, so duplicates collapse and iteration
	// order is arbitrary. ValidateTags dedups; SetTags sorts, because the commit
	// request's TagSet is a length-prefixed concatenation in insertion order and
	// an arbitrary order would make the commit bytes vary run to run for the
	// same config. Order is not a wire contract on either side.
	Tags []string

	// Timer is the StoreTimer every context this config creates records into.
	// Matches Java's FDBRecordContextConfig.timer (FDBRecordContextConfig.java:42,
	// Builder.setTimer :357-368), which likewise defaults to null/nil.
	//
	// Nil does NOT mean uninstrumented: it means "inherit the database's timer",
	// which is the same relationship Java has between FDBDatabaseRunner.setTimer and
	// the context config it delegates to (FDBDatabaseRunner.java:105-119). Set it only
	// to give one runner's transactions a timer separate from the rest of the process
	// — an index build measured on its own, say.
	Timer *StoreTimer
}

// Java's tag limits (FDBRecordContextConfig.java:661-672). These are STRICTER
// than the FDB client's own 5/255 (TagThrottle.actor.cpp:35-39): the record
// layer caps a tag at 16 characters, so a tag the client would accept can still
// be rejected here. Validation happens at config time, as in Java, so a bad tag
// fails before any transaction is opened rather than mid-commit.
const (
	MaxRecordContextTags   = 5
	MaxRecordContextTagLen = 16
)

// TagValidationError reports a tag set rejected by the record layer's limits.
// Java throws IllegalArgumentException with these exact messages.
type TagValidationError struct {
	Message string
	// Tag is the offending tag for a length violation, empty for a count violation.
	Tag string
}

func (e *TagValidationError) Error() string { return e.Message }

// ValidateTags applies Java's setTags checks in Java's order — the COUNT first,
// then each tag's length (FDBRecordContextConfig.java:662-669). The order is
// observable: an over-long tag in an over-large set reports the count error.
// Note this is the opposite of the FDB client's TagSet::addTag, which checks
// length first because it validates one tag at a time rather than a whole set.
//
// Returns the deduplicated tag set; Java's Set<String> collapses duplicates
// before the size check, so ("a","a","b") is two tags, not three.
func ValidateTags(tags []string) ([]string, error) {
	seen := make(map[string]struct{}, len(tags))
	uniq := make([]string, 0, len(tags))
	for _, t := range tags {
		if _, dup := seen[t]; dup {
			continue
		}
		seen[t] = struct{}{}
		uniq = append(uniq, t)
	}
	if len(uniq) > MaxRecordContextTags {
		return nil, &TagValidationError{Message: "At most 5 tags allowed"}
	}
	for _, t := range uniq {
		// Java uses String.length(), which counts UTF-16 code units — not bytes
		// and not code points. A character outside the BMP is stored as a
		// surrogate PAIR and therefore costs TWO, so a 16-code-point tag of
		// astral characters is length 32 in Java and rejected. Counting runes
		// would accept it: rune count is a LOWER bound on the UTF-16 count, so
		// it is more permissive than Java, never less.
		if utf16Len(t) > MaxRecordContextTagLen {
			return nil, &TagValidationError{
				Message: "Tag must be 16 characters or shorter",
				Tag:     t,
			}
		}
	}
	return uniq, nil
}

// utf16Len returns the length of s in UTF-16 code units — what Java's
// String.length() reports. Equivalent to len(utf16.Encode([]rune(s))) without
// the two intermediate allocations.
func utf16Len(s string) int {
	n := 0
	for _, r := range s {
		n++
		if r > 0xFFFF {
			n++ // surrogate pair
		}
	}
	return n
}

// SetTags validates and stores the tag set, returning an error rather than
// panicking where Java throws. Tags are sorted so the resulting commit bytes are
// deterministic for a given config.
func (c *RecordContextConfig) SetTags(tags []string) error {
	uniq, err := ValidateTags(tags)
	if err != nil {
		return err
	}
	sort.Strings(uniq)
	c.Tags = uniq
	return nil
}

// tagSetter is the narrow slice of the transaction options surface that tag
// application needs. Naming it keeps applyTagsTo testable without standing up a
// whole fdb.TransactionOptions.
type tagSetter interface {
	SetTag(tag string) error
}

// applyTagsTo issues one SetTag per tag, in order, matching
// FDBRecordContext.java:205-207 — the record layer sets each tag individually
// via the plain TAG option, never AUTO_THROTTLE_TAG.
func applyTagsTo(o tagSetter, tags []string) error {
	for _, tag := range tags {
		if err := o.SetTag(tag); err != nil {
			return err
		}
	}
	return nil
}

// applyTags sets the config's tags on a transaction. Java guards the whole
// block on a non-empty set (FDBRecordContext.java:205), so an untagged config
// touches the options surface not at all.
func applyTags(tx interface{ Options() fdb.TransactionOptions }, tags []string) error {
	if len(tags) == 0 {
		return nil
	}
	return applyTagsTo(tx.Options(), tags)
}

// FDBDatabaseRunner provides configurable retry logic for FDB transactions.
// Matches Java's FDBDatabaseRunnerImpl.
type FDBDatabaseRunner struct {
	db *FDBDatabase

	// MaxAttempts is the maximum number of retry attempts (default 10).
	MaxAttempts int

	// InitialDelay is the initial delay between retries (default 10ms).
	InitialDelay time.Duration

	// MaxDelay is the maximum delay between retries (default 1s).
	MaxDelay time.Duration

	// ContextConfig is applied to each transaction.
	ContextConfig *RecordContextConfig
}

// NewFDBDatabaseRunner creates a runner with default settings.
func NewFDBDatabaseRunner(db *FDBDatabase) *FDBDatabaseRunner {
	return &FDBDatabaseRunner{
		db:           db,
		MaxAttempts:  10,
		InitialDelay: 10 * time.Millisecond,
		MaxDelay:     1 * time.Second,
	}
}

// SetMaxAttempts sets the maximum retry attempts.
func (r *FDBDatabaseRunner) SetMaxAttempts(n int) *FDBDatabaseRunner {
	r.MaxAttempts = n
	return r
}

// SetInitialDelay sets the initial retry delay.
func (r *FDBDatabaseRunner) SetInitialDelay(d time.Duration) *FDBDatabaseRunner {
	r.InitialDelay = d
	return r
}

// SetMaxDelay sets the maximum retry delay.
func (r *FDBDatabaseRunner) SetMaxDelay(d time.Duration) *FDBDatabaseRunner {
	r.MaxDelay = d
	return r
}

// SetContextConfig sets the transaction context configuration.
func (r *FDBDatabaseRunner) SetContextConfig(config *RecordContextConfig) *FDBDatabaseRunner {
	r.ContextConfig = config
	return r
}

// contextTimer resolves the StoreTimer for a context this runner is about to open:
// the context config's timer when one is set, otherwise the database's.
//
// The fallback is what makes a runner's retries visible to a process-wide exporter
// without every caller configuring one, and it is Java's arrangement read the other
// way round — there, FDBDatabaseRunner.getTimer/setTimer ARE the context config's
// timer (FDBDatabaseRunner.java:105-119), so a runner and the contexts it opens can
// never disagree. Go keeps the two objects separate, so the tie has to be broken
// explicitly; the config wins because it is the more specific statement of intent.
func (r *FDBDatabaseRunner) contextTimer() *StoreTimer {
	if r.ContextConfig != nil && r.ContextConfig.Timer != nil {
		return r.ContextConfig.Timer
	}
	return r.db.Timer()
}

// RunWithRetry executes fn with configurable retry logic and exponential backoff.
// Retries on FDB retryable errors (conflict, etc.) up to MaxAttempts times.
// Non-retryable errors are returned immediately.
// Matches Java's FDBDatabaseRunnerImpl.run().
func (r *FDBDatabaseRunner) RunWithRetry(ctx context.Context, fn func(rtx *FDBRecordContext) (any, error)) (any, error) {
	policy := attemptPolicy{owner: "runner", maxAttempts: r.MaxAttempts, initialDelay: r.InitialDelay, maxDelay: r.MaxDelay, timer: r.contextTimer()}
	return attemptLoop(ctx, r.db.Env(), r.db.observer(), policy, RouteOwnTransaction, func(AttemptCall) (any, error) {
		return r.runOnce(ctx, fn)
	})
}

// runOnce executes fn in a single transaction, applying context config.
func (r *FDBDatabaseRunner) runOnce(ctx context.Context, fn func(rtx *FDBRecordContext) (any, error)) (any, error) {
	// CreateWritableTransaction is backend-agnostic (handles tenant / pure-Go /
	// libfdb_c internally) and returns the WritableTransaction interface the record
	// context holds — so the manual runner works on either backend (RFC-109).
	tx, err := r.db.CreateWritableTransaction()
	if err != nil {
		return nil, err
	}
	r.db.applyReadSystemKeys(tx.Options())

	recordCtx := &FDBRecordContext{
		createTime: r.db.env.Now(),
		tx:         tx,
		ctx:        ctx,
		env:        r.db.env,
		database:   r.db,
		// RunWithRetry commits each attempt itself.
		routeOwned: true,
	}
	recordCtx.SetTimer(r.contextTimer())

	// Apply context config
	if r.ContextConfig != nil {
		if r.ContextConfig.TransactionTimeout > 0 {
			if err := tx.Options().SetTimeout(int64(r.ContextConfig.TransactionTimeout / time.Millisecond)); err != nil {
				tx.Cancel()
				return nil, err
			}
		}
		if r.ContextConfig.Priority != PriorityDefault {
			if err := recordCtx.SetTransactionPriority(r.ContextConfig.Priority); err != nil {
				tx.Cancel()
				return nil, err
			}
		}
		if r.ContextConfig.TransactionID != "" {
			if err := tx.Options().SetDebugTransactionIdentifier(r.ContextConfig.TransactionID); err != nil {
				tx.Cancel()
				return nil, err
			}
		}
		if err := applyTags(tx, r.ContextConfig.Tags); err != nil {
			tx.Cancel()
			return nil, err
		}
	}

	result, err := fn(recordCtx)
	if err != nil {
		tx.Cancel()
		return nil, err
	}

	// Run pre-commit checks
	if err := recordCtx.runCommitChecks(); err != nil {
		tx.Cancel()
		return nil, err
	}

	recordCtx.flushVersionMutations()

	if err := tx.Commit().Get(); err != nil {
		tx.Cancel()
		return nil, err
	}

	recordCtx.runPostCommits()
	return result, nil
}

// OpenContext creates a new FDBRecordContext with a fresh transaction, applying
// the runner's context configuration. Matches Java's FDBDatabaseRunner.openContext().
// The caller is responsible for committing or cancelling the transaction.
func (r *FDBDatabaseRunner) OpenContext(ctx context.Context) (*FDBRecordContext, error) {
	// Backend-agnostic (RFC-109): works on the libfdb_c backend too.
	tx, err := r.db.CreateWritableTransaction()
	if err != nil {
		return nil, err
	}
	r.db.applyReadSystemKeys(tx.Options())

	recordCtx := &FDBRecordContext{
		createTime: r.db.env.Now(),
		tx:         tx,
		ctx:        ctx,
		env:        r.db.env,
		database:   r.db,
	}
	recordCtx.SetTimer(r.contextTimer())

	if r.ContextConfig != nil {
		if r.ContextConfig.TransactionTimeout > 0 {
			if err := tx.Options().SetTimeout(int64(r.ContextConfig.TransactionTimeout / time.Millisecond)); err != nil {
				tx.Cancel()
				return nil, err
			}
		}
		if r.ContextConfig.Priority != PriorityDefault {
			if err := recordCtx.SetTransactionPriority(r.ContextConfig.Priority); err != nil {
				tx.Cancel()
				return nil, err
			}
		}
		if r.ContextConfig.TransactionID != "" {
			if err := tx.Options().SetDebugTransactionIdentifier(r.ContextConfig.TransactionID); err != nil {
				tx.Cancel()
				return nil, err
			}
		}
		if err := applyTags(tx, r.ContextConfig.Tags); err != nil {
			tx.Cancel()
			return nil, err
		}
		recordCtx.txSizeWarnBytes = r.ContextConfig.TransactionSizeWarnBytes
		recordCtx.txSizeErrorBytes = r.ContextConfig.TransactionSizeErrorBytes
	}

	return recordCtx, nil
}
