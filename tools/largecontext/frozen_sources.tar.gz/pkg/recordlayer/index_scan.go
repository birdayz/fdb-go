// Portions derived from FoundationDB Record Layer (TupleRange.java,
// IndexScanType.java, FDBRecordStore.java, IndexEntry.java, and others),
// Copyright 2015-2018 Apple Inc. and the FoundationDB project authors
// Licensed under the Apache License, Version 2.0; translated to Go and modified.

package recordlayer

import (
	"context"
	"fmt"

	"fdb.dev/pkg/recordlayer/internal/tuplefast"

	"fdb.dev/pkg/fdbgo/fdb"
	"fdb.dev/pkg/fdbgo/fdb/subspace"
	"fdb.dev/pkg/fdbgo/fdb/tuple"
	"google.golang.org/protobuf/proto"
)

// IndexScanType identifies the type of index scan.
// Matches Java's com.apple.foundationdb.record.IndexScanType.
type IndexScanType string

const (
	// IndexScanByValue scans a VALUE index by its indexed values.
	IndexScanByValue IndexScanType = "BY_VALUE"
	// IndexScanByRank scans [group..., numeric rank], using Java's Number.longValue().
	// A null rank bound is unbounded.
	IndexScanByRank IndexScanType = "BY_RANK"

	// IndexScanByTextToken scans a TEXT index by text token.
	// Matches Java's IndexScanType.BY_TEXT_TOKEN.
	IndexScanByTextToken IndexScanType = "BY_TEXT_TOKEN"

	// IndexScanByGroup scans a PERMUTED_MIN/MAX index by group in the
	// secondary (permuted) subspace. Returns one entry per group with the
	// extremum value, ordered by [groupPrefix, value, groupSuffix].
	// Matches Java's IndexScanType.BY_GROUP.
	IndexScanByGroup IndexScanType = "BY_GROUP"

	// IndexScanByTimeWindow scans a TIME_WINDOW_LEADERBOARD index within a
	// specific time window. The scan range contains score bounds; the
	// leaderboard type and timestamp are provided via TimeWindowScanRange.
	// Matches Java's IndexScanType.BY_TIME_WINDOW.
	IndexScanByTimeWindow IndexScanType = "BY_TIME_WINDOW"

	// IndexScanByDistance scans a VECTOR index by distance to a query vector.
	// Returns results sorted by distance (closest first) as a kNN search.
	// Must be used with ScanVectorIndex which provides VectorScanBounds.
	// Matches Java's IndexScanType.BY_DISTANCE.
	IndexScanByDistance IndexScanType = "BY_DISTANCE"

	// IndexScanByDistanceOrderedStream is the RFC-156 Phase C VBASE distance-
	// ordered STREAMING scan: a demand-driven cursor that widens its scanned
	// horizon in batches as the consumer (Filter → Limit) pulls, bounded by a
	// budget cap (honest ScanLimitReached truncation, never a silent < k). Go-only
	// read-side extension; no wire-format change.
	IndexScanByDistanceOrderedStream IndexScanType = "BY_DISTANCE_ORDERED_STREAM"
)

// TupleRange specifies a range of tuples for index scanning.
// Matches Java's com.apple.foundationdb.record.TupleRange.
type TupleRange struct {
	Low          tuple.Tuple
	High         tuple.Tuple
	LowEndpoint  EndpointType
	HighEndpoint EndpointType
}

// TupleRangeAll covers all entries in the index.
// Matches Java's TupleRange.ALL.
var TupleRangeAll = TupleRange{
	LowEndpoint:  EndpointTypeTreeStart,
	HighEndpoint: EndpointTypeTreeEnd,
}

// TupleRangeAllOf returns a range for all entries with the given tuple prefix.
// Matches Java's TupleRange.allOf(Tuple).
// For example, TupleRangeAllOf(tuple.Tuple{"alice"}) returns all index entries
// where the first indexed value is "alice".
func TupleRangeAllOf(prefix tuple.Tuple) TupleRange {
	if prefix == nil {
		return TupleRangeAll
	}
	return TupleRange{
		Low:          prefix,
		High:         prefix,
		LowEndpoint:  EndpointTypeRangeInclusive,
		HighEndpoint: EndpointTypeRangeInclusive,
	}
}

// TupleRangeBetween returns a range [low, high) — low inclusive, high exclusive.
// Matches Java's TupleRange.between(Tuple, Tuple).
func TupleRangeBetween(low, high tuple.Tuple) TupleRange {
	return TupleRange{
		Low:          low,
		High:         high,
		LowEndpoint:  EndpointTypeRangeInclusive,
		HighEndpoint: EndpointTypeRangeExclusive,
	}
}

// TupleRangeBetweenInclusive returns a range [low, high] — both inclusive.
// Matches Java's TupleRange.betweenInclusive(Tuple, Tuple).
func TupleRangeBetweenInclusive(low, high tuple.Tuple) TupleRange {
	return TupleRange{
		Low:          low,
		High:         high,
		LowEndpoint:  EndpointTypeRangeInclusive,
		HighEndpoint: EndpointTypeRangeInclusive,
	}
}

// TupleRangePrefixString creates a range scanning all entries whose string
// element starts with the given prefix. Both endpoints use
// EndpointTypePrefixString so that the tuple-packed trailing null byte is
// stripped (low) or strinc'd (high).
// Matches Java's TupleRange.prefixedBy(String).
func TupleRangePrefixString(token string) TupleRange {
	return TupleRange{
		Low:          tuple.Tuple{token},
		High:         tuple.Tuple{token},
		LowEndpoint:  EndpointTypePrefixString,
		HighEndpoint: EndpointTypePrefixString,
	}
}

// Prepend prepends a tuple prefix to both Low and High bounds.
// Matches Java's TupleRange.prepend(Tuple) (TupleRange.java:160-186): an open
// bound becomes the prefix itself, inclusive.
func (r TupleRange) Prepend(prefix tuple.Tuple) TupleRange {
	join := func(t tuple.Tuple) tuple.Tuple {
		result := make(tuple.Tuple, 0, len(prefix)+len(t))
		return append(append(result, prefix...), t...)
	}
	out := TupleRange{LowEndpoint: r.LowEndpoint, HighEndpoint: r.HighEndpoint}
	if r.Low == nil {
		out.Low, out.LowEndpoint = prefix, EndpointTypeRangeInclusive
	} else {
		out.Low = join(r.Low)
	}
	if r.High == nil {
		out.High, out.HighEndpoint = prefix, EndpointTypeRangeInclusive
	} else {
		out.High = join(r.High)
	}
	return out
}

// ToFDBRange converts this TupleRange to an fdb.KeyRange relative to a subspace.
// Matches Java's TupleRange.toRange(Subspace).
func (r TupleRange) ToFDBRange(ss subspace.Subspace) fdb.KeyRange {
	var begin, end fdb.Key

	switch r.LowEndpoint {
	case EndpointTypeTreeStart:
		begin = ss.FDBKey()
	case EndpointTypeRangeInclusive:
		begin = ss.Pack(r.Low)
	case EndpointTypeRangeExclusive:
		// Exclusive low = Strinc(pack(low)), matching Java TupleRange.toRange()
		// (TupleRange.java:485: `lowBytes = ByteArrayUtil.strinc(lowBytes)`). This is
		// the prefix-exclusion boundary, NOT firstGreaterThan(pack(low)) (append
		// 0x00). The distinction is observable for byte/string keys: `col > X` skips
		// not only the exact `X` entry but also any entry whose encoding is `pack(X)`
		// followed by bytes that sort below Strinc's increment — most notably a stored
		// value equal to X plus a trailing 0x00 (e.g. `b > X'01'` excludes the stored
		// value X'0100', whose encoding `01 01 00 FF 00` sorts before Strinc's
		// `01 01 01`). Java behaves identically, so this is REQUIRED for wire-level
		// cross-engine result consistency — do NOT "correct" it to append-0x00, which
		// would make Go return rows Java omits on a shared cluster. Pinned by
		// bytes_gt_index_conformance_probe_test.go.
		packed := ss.Pack(r.Low)
		inc, err := fdb.Strinc(packed)
		if err != nil {
			begin = ss.FDBKey()
		} else {
			begin = inc
		}
	case EndpointTypePrefixString:
		// Strip the trailing null byte (string terminator in FDB tuple encoding).
		// Matches Java's TupleRange.toRange() PREFIX_STRING low handling:
		//   lowBytes = Arrays.copyOfRange(lowBytes, 0, lowBytes.length - 1)
		packed := ss.Pack(r.Low)
		begin = packed[:len(packed)-1]
	default:
		begin = ss.FDBKey()
	}

	switch r.HighEndpoint {
	case EndpointTypeTreeEnd:
		_, endKey := ss.FDBRangeKeys()
		end = endKey.FDBKey()
	case EndpointTypeRangeInclusive:
		packed := ss.Pack(r.High)
		end = append(packed, 0xFF)
	case EndpointTypeRangeExclusive:
		end = ss.Pack(r.High)
	case EndpointTypePrefixString:
		// Strip the trailing null byte, then strinc the result.
		// Matches Java's TupleRange.toRange() PREFIX_STRING high handling:
		//   strip trailing 0xFF bytes, then increment last byte.
		packed := ss.Pack(r.High)
		stripped := packed[:len(packed)-1]
		// Remove trailing 0xFF bytes
		newLen := len(stripped)
		for newLen >= 1 && stripped[newLen-1] == 0xFF {
			newLen--
		}
		if newLen == 0 {
			end = fdb.Key{0xFF}
		} else {
			dest := make([]byte, newLen)
			copy(dest, stripped[:newLen])
			dest[newLen-1]++
			end = dest
		}
	default:
		_, endKey := ss.FDBRangeKeys()
		end = endKey.FDBKey()
	}

	return fdb.KeyRange{Begin: begin, End: end}
}

// IndexEntry represents a single entry from an index scan.
// Matches Java's com.apple.foundationdb.record.IndexEntry.
type IndexEntry struct {
	Index *Index
	Key   tuple.Tuple // Full key (indexed values + primary key components)
	Value tuple.Tuple // Value tuple (empty for VALUE indexes)

	primaryKey tuple.Tuple // Lazily extracted
}

// IndexEntryKey is the entry's raw KEY tuple, the tuple an index-entry reader
// Value's KEY source reads.
func (e *IndexEntry) IndexEntryKey() tuple.Tuple { return e.Key }

// IndexEntryValue is the entry's raw VALUE tuple.
func (e *IndexEntry) IndexEntryValue() tuple.Tuple { return e.Value }

// PrimaryKey extracts the primary key portion from the index entry key.
// When the index has primaryKeyComponentPositions, some PK components are
// pulled from the index key portion (deduplicated) and the rest from the
// appended tail. Matches Java's IndexEntry.getPrimaryKey() → Index.getEntryPrimaryKey().
func (e *IndexEntry) PrimaryKey() tuple.Tuple {
	if e.Index == nil {
		return tuple.Tuple{}
	}
	if e.primaryKey == nil {
		e.primaryKey = e.Index.EntryPrimaryKey(e.Key)
	}
	return e.primaryKey
}

// IndexValues extracts the indexed values portion from the entry key.
// Returns the prefix of Key up to the index expression's column count.
func (e *IndexEntry) IndexValues() tuple.Tuple {
	if e.Index == nil {
		return tuple.Tuple{}
	}
	colSize := e.Index.RootExpression.ColumnSize()
	if colSize <= len(e.Key) {
		return e.Key[:colSize]
	}
	return e.Key
}

// ScanIndex scans a secondary index and returns a cursor over IndexEntry results.
// Returns an error cursor if the index is not in a scannable state (DISABLED or WRITE_ONLY).
// Dispatches to the appropriate maintainer's Scan() method (VALUE vs COUNT).
// Matches Java's FDBRecordStore.scanIndex().
func (store *FDBRecordStore) ScanIndex(
	index *Index,
	scanRange TupleRange,
	continuation []byte,
	scanProperties ScanProperties,
) RecordCursor[*IndexEntry] {
	state, err := store.readIndexState(index.Name)
	if err != nil {
		return &errorCursor[*IndexEntry]{err: err}
	}
	if !state.IsScannable() {
		return &errorCursor[*IndexEntry]{
			err: &IndexNotReadableError{IndexName: index.Name, CurrentState: state},
		}
	}
	if err := scanTypeOnlyError(index); err != nil {
		return &errorCursor[*IndexEntry]{err: err}
	}
	// VECTOR indexes must be scanned with BY_DISTANCE via ScanVectorIndex.
	// Matches Java's VectorIndexMaintainer.scan(IndexScanType, TupleRange, ...) which
	// throws IllegalStateException("index maintainer does not support this scan api").
	if index.Type == IndexTypeVector {
		return &errorCursor[*IndexEntry]{
			err: fmt.Errorf("VECTOR index %q must be scanned with BY_DISTANCE via ScanVectorIndex", index.Name),
		}
	}
	// TIME_WINDOW_LEADERBOARD indexes should use ScanTimeWindowLeaderboard.
	// Standard ScanIndex falls back to all-time BY_VALUE which is acceptable.
	// No rejection here — matches Java's behavior where plain scan() works on all-time.
	maintainer, err := store.getIndexMaintainer(index)
	if err != nil {
		return &errorCursor[*IndexEntry]{err: err}
	}
	// Instrument the CURSOR, not the call that builds it. Java wraps the
	// maintainer's cursor here (FDBRecordStore.java:1479-1481) so the event times
	// each entry produced; timing the construction of a lazy cursor measures
	// allocation and reports one occurrence for a scan of any size.
	return instrumentCursor(store.context.Timer(), EventScanIndex,
		maintainer.Scan(scanRange, continuation, scanProperties))
}

// ScanIndexByType scans a secondary index with an explicit scan type.
// For BY_VALUE, delegates to the maintainer's Scan. For BY_RANK, converts rank
// range to score range and scans the B-tree.
// Matches Java's FDBRecordStore.scanIndex(index, scanType, range, ...).
func (store *FDBRecordStore) ScanIndexByType(
	index *Index,
	scanType IndexScanType,
	scanRange TupleRange,
	continuation []byte,
	scanProperties ScanProperties,
) RecordCursor[*IndexEntry] {
	// EventScanIndex covers EVERY scan type, not just BY_VALUE. Java has a single
	// scanIndex entry point that takes the scan type inside its IndexScanBounds and
	// instruments there (FDBRecordStore.java:1479-1481); Go split the by-type
	// dispatch into its own method, and instrumenting only the other one left the
	// query executor's aggregate/group scans (executor_new_plans.go BY_GROUP) and
	// every vector scan invisible. Wrapping the dispatch once, here, restores Java's
	// property that no index scan can happen without the event.
	return instrumentCursor(store.context.Timer(), EventScanIndex,
		store.scanIndexByType(index, scanType, scanRange, continuation, scanProperties))
}

func (store *FDBRecordStore) scanIndexByType(
	index *Index,
	scanType IndexScanType,
	scanRange TupleRange,
	continuation []byte,
	scanProperties ScanProperties,
) RecordCursor[*IndexEntry] {
	state, err := store.readIndexState(index.Name)
	if err != nil {
		return &errorCursor[*IndexEntry]{err: err}
	}
	if !state.IsScannable() {
		return &errorCursor[*IndexEntry]{
			err: &IndexNotReadableError{IndexName: index.Name, CurrentState: state},
		}
	}
	maintainer, err := store.getIndexMaintainer(index)
	if err != nil {
		return &errorCursor[*IndexEntry]{err: err}
	}
	switch scanType {
	case IndexScanByRank:
		switch rm := maintainer.(type) {
		case *rankIndexMaintainer:
			return rm.ScanByRank(scanRange, continuation, scanProperties)
		case *timeWindowLeaderboardIndexMaintainer:
			// BY_RANK on leaderboard: uses all-time leaderboard.
			return rm.ScanByRankInTimeWindow(AllTimeLeaderboardType, 0, scanRange, continuation, scanProperties)
		default:
			return &errorCursor[*IndexEntry]{
				err: &RecordCoreError{Message: fmt.Sprintf("index %q (type %s) does not support BY_RANK scan", index.Name, index.Type), IndexName: index.Name},
			}
		}
	case IndexScanByTextToken:
		tm, ok := maintainer.(*textIndexMaintainer)
		if !ok {
			return &errorCursor[*IndexEntry]{
				err: &RecordCoreError{Message: fmt.Sprintf("index %q (type %s) does not support BY_TEXT_TOKEN scan", index.Name, index.Type), IndexName: index.Name},
			}
		}
		return tm.Scan(scanRange, continuation, scanProperties)
	case IndexScanByGroup:
		switch m := maintainer.(type) {
		case *permutedMinMaxIndexMaintainer:
			return m.ScanByGroup(scanRange, continuation, scanProperties)
		case *bitmapValueIndexMaintainer:
			return m.ScanByGroup(scanRange, continuation, scanProperties)
		case *atomicMutationIndexMaintainer, *maxEverVersionIndexMaintainer:
			// BY_GROUP is the only scan type Java's AtomicMutationIndexMaintainer.scan accepts.
			return m.Scan(scanRange, continuation, scanProperties)
		default:
			return &errorCursor[*IndexEntry]{
				err: &RecordCoreError{Message: fmt.Sprintf("index %q (type %s) does not support BY_GROUP scan", index.Name, index.Type), IndexName: index.Name},
			}
		}
	case IndexScanByDistance:
		// HNSW and SPFresh share the BY_DISTANCE TupleRange/IndexEntry
		// contract (RFC-094 §10) — dispatch by interface, not concrete type.
		vm, ok := IndexMaintainerAs[ByDistanceScanner](maintainer)
		if !ok {
			return &errorCursor[*IndexEntry]{
				err: &RecordCoreError{Message: fmt.Sprintf("index %q (type %s) does not support BY_DISTANCE scan", index.Name, index.Type), IndexName: index.Name},
			}
		}
		return vm.ScanByDistance(scanRange, continuation, scanProperties)
	case IndexScanByDistanceOrderedStream:
		// RFC-156 Phase C: the VBASE distance-ordered STREAMING scan (demand-driven
		// widening + budget-bounded honest truncation). Only SPFresh implements
		// widening; an HNSW ordered scan has no posting cells to widen, so it falls
		// back to the fixed-horizon ScanByDistance (Phase B, unchanged).
		if sm, ok := IndexMaintainerAs[OrderedStreamScanner](maintainer); ok {
			return sm.ScanByDistanceOrderedStream(scanRange, continuation, scanProperties)
		}
		vm, ok := IndexMaintainerAs[ByDistanceScanner](maintainer)
		if !ok {
			return &errorCursor[*IndexEntry]{
				err: &RecordCoreError{Message: fmt.Sprintf("index %q (type %s) does not support BY_DISTANCE scan", index.Name, index.Type), IndexName: index.Name},
			}
		}
		return vm.ScanByDistance(scanRange, continuation, scanProperties)
	default:
		if err := scanTypeOnlyError(index); err != nil {
			return &errorCursor[*IndexEntry]{err: err}
		}
		return maintainer.Scan(scanRange, continuation, scanProperties)
	}
}

// scanTypeOnlyError is the RecordCoreException Java's bitmap and text
// maintainers throw for any scan type but their own (BitmapValueIndexMaintainer
// .scan, TextIndexMaintainer.scan).
func scanTypeOnlyError(index *Index) error {
	switch canonicalIndexType(index.Type) {
	case IndexTypeBitmapValue:
		return &RecordCoreError{Message: "Can only scan bitmap index by group.", IndexName: index.Name}
	case IndexTypeText:
		return &RecordCoreError{Message: "Can only scan text index by text token.", IndexName: index.Name}
	}
	return nil
}

// ScanTimeWindowLeaderboard scans a TIME_WINDOW_LEADERBOARD index within a specific
// time window. The scanType determines how the range is interpreted:
//   - BY_TIME_WINDOW / BY_VALUE: scanRange contains score bounds
//   - BY_RANK: scanRange contains rank bounds (converted to score bounds via RankedSet)
//
// Matches Java's FDBRecordStore.scanIndex() with TimeWindowScanRange.
func (store *FDBRecordStore) ScanTimeWindowLeaderboard(
	index *Index,
	scanType IndexScanType,
	leaderboardType int,
	leaderboardTimestamp int64,
	scanRange TupleRange,
	continuation []byte,
	scanProperties ScanProperties,
) RecordCursor[*IndexEntry] {
	// Instrumented for the same reason ScanIndexByType is: it is a third entry
	// point into an index scan, and an entry point that skips the event makes the
	// metric a function of which index type the query happened to use.
	return instrumentCursor(store.context.Timer(), EventScanIndex,
		store.scanTimeWindowLeaderboard(index, scanType, leaderboardType, leaderboardTimestamp,
			scanRange, continuation, scanProperties))
}

func (store *FDBRecordStore) scanTimeWindowLeaderboard(
	index *Index,
	scanType IndexScanType,
	leaderboardType int,
	leaderboardTimestamp int64,
	scanRange TupleRange,
	continuation []byte,
	scanProperties ScanProperties,
) RecordCursor[*IndexEntry] {
	state, err := store.readIndexState(index.Name)
	if err != nil {
		return &errorCursor[*IndexEntry]{err: err}
	}
	if !state.IsScannable() {
		return &errorCursor[*IndexEntry]{
			err: &IndexNotReadableError{IndexName: index.Name, CurrentState: state},
		}
	}
	maintainer, err := store.getIndexMaintainer(index)
	if err != nil {
		return &errorCursor[*IndexEntry]{err: err}
	}
	lm, ok := maintainer.(*timeWindowLeaderboardIndexMaintainer)
	if !ok {
		return &errorCursor[*IndexEntry]{
			err: fmt.Errorf("index %q (type %s) is not a TIME_WINDOW_LEADERBOARD", index.Name, index.Type),
		}
	}
	switch scanType {
	case IndexScanByTimeWindow, IndexScanByValue:
		return lm.ScanByTimeWindow(leaderboardType, leaderboardTimestamp, scanRange, continuation, scanProperties)
	case IndexScanByRank:
		return lm.ScanByRankInTimeWindow(leaderboardType, leaderboardTimestamp, scanRange, continuation, scanProperties)
	default:
		return &errorCursor[*IndexEntry]{
			err: fmt.Errorf("TIME_WINDOW_LEADERBOARD does not support %s scan type", scanType),
		}
	}
}

// indexCursor iterates key-value pairs from an index subspace and maps
// them to IndexEntry objects. This is simpler than keyValueCursor — no
// split record handling, no deserialization. Each FDB KV maps to one IndexEntry.
// Matches Java's KeyValueCursor.map(unpackKeyValue) pattern from StandardIndexMaintainer.
type indexCursor struct {
	index         *Index
	indexSubspace subspace.Subspace
	tx            fdb.WritableTransaction
	tupleRange    TupleRange
	continuation  []byte
	scanProps     ScanProperties

	iterator     rangeIterator
	closed       bool
	recordsRead  int
	initialPass  bool
	clock        *ScanLimiterState
	bounds       kvScanBounds
	prefixLength int
	lastCont     *keyValueContinuation
	lastNoNext   RecordCursorResult[*IndexEntry]
	hasNoNext    bool

	// scanState is the (possibly shared) scanned-records/scanned-bytes/time
	// counter set — see ScanLimiterState's doc comment. Never nil.
	scanState *ScanLimiterState
}

func newIndexCursor(
	index *Index,
	indexSubspace subspace.Subspace,
	tx fdb.WritableTransaction,
	tupleRange TupleRange,
	continuation []byte,
	scanProps ScanProperties,
) *indexCursor {
	bounds := newKVScanBounds(indexSubspace, tupleRange.Low, tupleRange.High, tupleRange.LowEndpoint, tupleRange.HighEndpoint)
	return &indexCursor{
		index:         index,
		indexSubspace: indexSubspace,
		tx:            tx,
		tupleRange:    tupleRange,
		continuation:  continuation,
		scanProps:     scanProps,
		bounds:        bounds,
		prefixLength:  bounds.prefixLength,
		scanState:     resolveScanLimiterState(scanProps.ExecuteProperties),
	}
}

// OnNext returns the next IndexEntry or indicates why iteration stopped.
func (c *indexCursor) OnNext(ctx context.Context) (RecordCursorResult[*IndexEntry], error) {
	if c.hasNoNext && !c.closed {
		return c.lastNoNext, nil
	}
	result, err := c.advance(ctx)
	if err == nil && !result.HasNext() {
		// Java replays the first terminal result on subsequent calls.
		c.lastNoNext = result
		c.hasNoNext = true
	}
	return result, err
}

func (c *indexCursor) advance(ctx context.Context) (RecordCursorResult[*IndexEntry], error) {
	if c.closed {
		return RecordCursorResult[*IndexEntry]{}, fmt.Errorf("cursor is closed")
	}

	// Honor a statement deadline (RFC-106a): draining an already-fetched range
	// batch must still return on ctx cancellation/timeout, not run to the
	// per-page time limit. context.DeadlineExceeded → 54F01 "statement timeout".
	if err := ctx.Err(); err != nil {
		return RecordCursorResult[*IndexEntry]{}, err
	}

	if c.iterator == nil {
		if err := c.initIterator(); err != nil {
			return RecordCursorResult[*IndexEntry]{}, err
		}
	}

	executeProps := c.scanProps.GetExecuteProperties()

	clock := c.clock
	if clock == nil {
		clock = c.scanState
	}
	if allowed, reason := tryScanLimits(c.scanState, clock, executeProps, &c.initialPass); !allowed {
		return noNextOrFail[*IndexEntry](executeProps, reason, c.limitContinuation())
	}
	// Java reports the passed-down row limit even if it exactly exhausted the source.
	if executeProps.ReturnedRowLimit > 0 && c.recordsRead >= executeProps.ReturnedRowLimit {
		if c.iterator.Advance() {
			return NewResultNoNext[*IndexEntry](
				ReturnLimitReached,
				c.limitContinuation(),
			), nil
		}
		// Advance() returns false on exhaustion OR error — check Get() for the stored
		// error so a transient transaction_too_old (1007) / timeout at the row-limit
		// boundary surfaces instead of being read as end-of-data (silent row loss).
		if _, err := c.iterator.Get(); err != nil {
			return RecordCursorResult[*IndexEntry]{}, fmt.Errorf("index scan at row-limit boundary: %w", err)
		}
		return NewResultNoNext[*IndexEntry](ReturnLimitReached, c.limitContinuation()), nil
	}

	if !c.iterator.Advance() {
		// Advance() returns false on exhaustion OR error — Get() returns the stored
		// error in the error case. Surface it instead of reporting SourceExhausted,
		// which would silently truncate the index scan.
		if _, err := c.iterator.Get(); err != nil {
			return RecordCursorResult[*IndexEntry]{}, fmt.Errorf("index scan: %w", err)
		}
		return NewResultNoNext[*IndexEntry](
			SourceExhausted,
			&EndContinuation{},
		), nil
	}

	kv, err := c.iterator.Get()
	if err != nil {
		return RecordCursorResult[*IndexEntry]{}, fmt.Errorf("index scan get: %w", err)
	}

	entry, err := c.unpackKeyValue(kv)
	if err != nil {
		return RecordCursorResult[*IndexEntry]{}, err
	}

	// Accumulate bytes scanned — checked pre-read on next call
	c.scanState.AddBytesScanned(int64(len(kv.Key) + len(kv.Value)))

	c.recordsRead++

	cont, err := c.makeContinuation(kv.Key)
	if err != nil {
		return RecordCursorResult[*IndexEntry]{}, err
	}
	c.lastCont = cont

	return NewResultWithValue(entry, cont), nil
}

func (c *indexCursor) unpackKeyValue(kv fdb.KeyValue) (*IndexEntry, error) {
	// Use fastUnpack instead of tuple.Unpack for the index key.
	// fastUnpack avoids heap allocations on the integer decode path,
	// which matters heavily in tight scan loops (2x speedup on index scans).
	prefixLen := len(c.indexSubspace.Bytes())
	if len(kv.Key) < prefixLen {
		return nil, fmt.Errorf("index key shorter than subspace prefix")
	}
	keyTuple, err := tuplefast.Unpack(kv.Key[prefixLen:])
	if err != nil {
		return nil, fmt.Errorf("unpack index key: %w", err)
	}

	var valueTuple tuple.Tuple
	if len(kv.Value) > 0 {
		valueTuple, err = tuplefast.Unpack(kv.Value)
		if err != nil {
			return nil, fmt.Errorf("unpack index value: %w", err)
		}
	}

	return &IndexEntry{
		Index: c.index,
		Key:   keyTuple,
		Value: valueTuple,
	}, nil
}

// limitContinuation returns the appropriate continuation when a limit is hit.
func (c *indexCursor) limitContinuation() RecordCursorContinuation {
	if c.lastCont != nil {
		return c.lastCont
	}
	return &StartContinuation{}
}

// makeContinuation aliases kv.Key without copying: RangeIterator never reuses
// returned key bytes, so the lazily marshaled suffix stays valid.
func (c *indexCursor) makeContinuation(key fdb.Key) (*keyValueContinuation, error) {
	suffix, err := keySuffix(key, c.prefixLength)
	if err != nil {
		return nil, err
	}
	return &keyValueContinuation{suffix: suffix}, nil
}

func (c *indexCursor) initIterator() error {
	rng, err := c.bounds.keyRange(c.continuation, c.scanProps.IsReverse())
	if err != nil {
		return err
	}
	options := kvRangeOptions(c.scanProps)
	r := indexSkipRange(rng, c.scanProps.ExecuteProperties.Skip, options.Reverse)

	var rangeResult fdb.RangeResult
	if c.scanProps.ExecuteProperties.IsolationLevel == SnapshotIsolation {
		rangeResult = c.tx.Snapshot().GetRange(r, options)
	} else {
		rangeResult = c.tx.GetRange(r, options)
	}

	c.iterator = rangeResult.Iterator()
	return nil
}

// Close releases resources held by the cursor.
func (c *indexCursor) Close() error {
	c.closed = true
	return nil
}

func (c *indexCursor) IsClosed() bool { return c.closed }

// FDBIndexedRecord wraps a record that was found via an index scan.
// Contains both the index entry used to locate the record and the record itself.
// Matches Java's com.apple.foundationdb.record.provider.foundationdb.FDBIndexedRecord.
type FDBIndexedRecord struct {
	IndexEntry *IndexEntry
	Record     *FDBStoredRecord[proto.Message]
}

// ScanIndexRecords scans a secondary index and fetches the actual records.
// For each index entry, it loads the record by primary key.
// An orphan index entry (pointing to a record that no longer exists) raises a
// RecordCoreStorageError — this mirrors Java's scanIndexRecords, whose default
// IndexOrphanBehavior is ERROR (not SKIP), so store corruption surfaces loudly
// instead of returning fewer records.
// Matches Java's FDBRecordStore.scanIndexRecords().
func (store *FDBRecordStore) ScanIndexRecords(
	indexName string,
	scanRange TupleRange,
	continuation []byte,
	scanProperties ScanProperties,
) RecordCursor[*FDBIndexedRecord] {
	index := store.metaData.GetIndex(indexName)
	if index == nil {
		return &errorCursor[*FDBIndexedRecord]{
			err: &IndexNotFoundError{IndexName: indexName},
		}
	}

	if scanProperties.ExecuteProperties.ScanState == nil {
		// Record loads charge the byte budget of the scan that found them.
		scanProperties.ExecuteProperties.ScanState = NewScanLimiterState()
	}
	indexCursor := store.ScanIndex(index, scanRange, continuation, scanProperties)
	loader := &indexRecordLoader{store: store, scanState: scanProperties.ExecuteProperties.ScanState}
	return MapPipelined(indexCursor, loader.load, DefaultPipelineSize)
}

// indexRecordLoader loads the record of each index entry, applying its
// IndexOrphanBehavior to an entry whose record no longer exists.
type indexRecordLoader struct {
	store     *FDBRecordStore
	scanState *ScanLimiterState
	orphan    IndexOrphanBehavior
}

func (c *indexRecordLoader) load(entry *IndexEntry) PendingRead[*FDBIndexedRecord] {
	pk := entry.PrimaryKey()
	return &indexRecordLoad{loader: c, pending: c.store.LoadRecordAsync(pk, c.scanState), entry: entry, primaryKey: pk}
}

type indexRecordLoad struct {
	loader     *indexRecordLoader
	pending    PendingRead[*FDBStoredRecord[proto.Message]] // nil after completion
	entry      *IndexEntry
	primaryKey tuple.Tuple
	record     *FDBIndexedRecord
	err        error
}

func (l *indexRecordLoad) Get() (*FDBIndexedRecord, error) {
	if l.pending != nil {
		record, err := l.pending.Get()
		indexed, err := l.loader.finish(l.entry, l.primaryKey, record, err)
		*l = indexRecordLoad{record: indexed, err: err}
	}
	return l.record, l.err
}

func (l *indexRecordLoad) IsReady() bool { return l.pending == nil || l.pending.IsReady() }

func (c *indexRecordLoader) finish(entry *IndexEntry, pk tuple.Tuple, rec *FDBStoredRecord[proto.Message], err error) (*FDBIndexedRecord, error) {
	if err != nil {
		return nil, fmt.Errorf("load record for index entry %v: %w", pk, err)
	}
	if rec == nil {
		// ScanIndexRecords keeps Java's ERROR default, which the index-from-index
		// rebuild (IndexingByIndex) relies on to abort rather than drop the row.
		return c.store.handleOrphanEntry(entry, pk, c.orphan, false)
	}

	return &FDBIndexedRecord{
		IndexEntry: entry,
		Record:     rec,
	}, nil
}

// ByDistanceScanner is the BY_DISTANCE access-method contract every vector
// index maintainer implements (RFC-094 §10): Low = (serialized query vector
// [, prefix...]), High = (k [, tuning...]); entries ascend by distance.
// Compile-time assertions catch signature drift at build time.
type ByDistanceScanner interface {
	ScanByDistance(TupleRange, []byte, ScanProperties) RecordCursor[*IndexEntry]
}

// OrderedStreamScanner is the RFC-156 Phase C distance-ordered STREAMING scan
// (demand-driven widening + budget-bounded honest truncation). Same TupleRange/
// IndexEntry contract as ScanByDistance; only partition indices with a widenable
// posting structure (SPFresh) implement it — others use the ScanByDistance
// fixed-horizon fallback.
type OrderedStreamScanner interface {
	ScanByDistanceOrderedStream(TupleRange, []byte, ScanProperties) RecordCursor[*IndexEntry]
}
