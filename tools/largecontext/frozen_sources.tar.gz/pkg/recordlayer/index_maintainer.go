// Portions derived from FoundationDB Record Layer (
// StandardIndexMaintainer.java, IndexEntry.java, IndexMaintainer.java,
// FDBStoredRecord.java, and others),
// Copyright 2015-2018 Apple Inc. and the FoundationDB project authors
// Copyright 2015-2026 Apple Inc. and the FoundationDB project authors
// Licensed under the Apache License, Version 2.0; translated to Go and modified.

package recordlayer

import (
	"fmt"
	"unsafe"

	"fdb.dev/pkg/recordlayer/internal/tuplefast"

	"fdb.dev/pkg/dst"
	"fdb.dev/pkg/fdbgo/fdb"
	"fdb.dev/pkg/fdbgo/fdb/subspace"
	"fdb.dev/pkg/fdbgo/fdb/tuple"
	"google.golang.org/protobuf/proto"
	"google.golang.org/protobuf/types/known/anypb"
)

// emptyTuplePacked is the pre-computed packed form of an empty tuple.
// Used as the value for VALUE index entries (which store no value data).
var emptyTuplePacked = tuple.Tuple{}.Pack()

// SAFETY: The unsafe cast (*tuple.Tuple)(unsafe.Pointer(&[]any{})) in the
// insert fast path depends on tuple.Tuple being []TupleElement where
// TupleElement is a defined type with underlying type any. From tuple.go:
//   type TupleElement any   // defined type, underlying = interface{}
//   type Tuple []TupleElement
// Both []any and []TupleElement have identical memory layout (slice of
// 16-byte interface values). If TupleElement ever becomes a struct or
// constrained interface, the cast silently corrupts memory.
// No compile-time check can enforce this — verify on tuple.go changes.

// IndexMaintainer handles index updates and scanning.
// Matches Java's com.apple.foundationdb.record.provider.foundationdb.IndexMaintainer.
type IndexMaintainer interface {
	// MergeIndex performs the backend's deferred maintenance, if any.
	MergeIndex() error

	// Update updates the index for a record change.
	// oldRecord is nil for inserts, newRecord is nil for deletes.
	Update(oldRecord, newRecord *FDBStoredRecord[proto.Message]) error

	// UpdateWhileWriteOnly updates the index during WRITE_ONLY state (index being built).
	// For idempotent indexes (VALUE), this is a pass-through to Update().
	// For non-idempotent indexes, checks if the record's PK is in the already-built range.
	// Matches Java's standardIndexMaintainer.updateWhileWriteOnly().
	UpdateWhileWriteOnly(oldRecord, newRecord *FDBStoredRecord[proto.Message]) error

	// Pending queue support is opt-in; serialization applies maintenance filters
	// now, while replay applies the captured entries without reevaluating them.
	IsPendingWriteQueueAllowed() bool
	SerializePendingWriteQueue(oldRecord, newRecord *FDBStoredRecord[proto.Message]) (*anypb.Any, error)
	UpdateFromQueue(data *anypb.Any) error

	// Scan scans the index within the given tuple range.
	// Matches Java's IndexMaintainer.scan().
	Scan(scanRange TupleRange, continuation []byte, scanProperties ScanProperties) RecordCursor[*IndexEntry]

	// DeleteWhere clears all index entries whose key starts with the given prefix.
	// Uses FDB range clears — no scanning. Called by DeleteRecordsWhere.
	// Matches Java's IndexMaintainer.deleteWhere().
	DeleteWhere(prefix tuple.Tuple) error

	// CanDeleteWhere reports whether this maintainer can clear exactly the
	// entries the given prefix names, returning the reason it cannot.
	// Matches Java's IndexMaintainer.canDeleteWhere.
	//
	// It is part of the interface — not an optional capability a maintainer may
	// leave out — for the same reason Java declares it ABSTRACT: a new index
	// type must not be able to reach the DeleteRecordsWhere path without having
	// decided what its physical keys are prefixed by. That is not hypothetical:
	// while the check was an optional interface here, the bound was absent on
	// one type after another — RANK's ranked sets, PERMUTED's permuted
	// secondary, the aggregates' grouping keys, TEXT's bunched tokens — because
	// an optional check reads "does not implement it" and "can clear any prefix"
	// as the same answer, and the first is by far the more common. Closing that
	// one index type at a time converges only as fast as someone thinks to look;
	// a compile error converges immediately.
	//
	// standardIndexMaintainer supplies the default, so a type embedding it gets
	// the bound its root expression implies and overrides only to NARROW it.
	//
	// WHERE the question is asked is the other half, and it cannot be left to
	// DeleteWhere. DeleteRecordsWhere queues the record, version and count
	// clears BEFORE calling any maintainer, so a refusal raised inside
	// DeleteWhere arrives after the records are already gone from the
	// transaction: a caller that logs the error and commits anyway loses the
	// records while the index keeps describing them. Every refusal therefore
	// belongs in the store's preflight, and the matching check inside
	// DeleteWhere stays only as a backstop for direct callers — which is exactly
	// the split Java has between canDeleteWhere and the Verify.verify inside
	// deleteWhere.
	CanDeleteWhere(prefix tuple.Tuple) error
}

// deleteWhereMatchableBound is how many leading index columns a
// DeleteRecordsWhere prefix may cover. It is a property of the ROOT EXPRESSION,
// not of the maintainer, which is why it lives here and every per-maintainer
// bound narrows it rather than restating it.
//
// Java never asks a maintainer "is this prefix short enough". It asks
// QueryToKeyMatcher to match the delete predicate against the index's root
// expression, and QueryToKeyMatcher.matches() UNWRAPS the root before matching
// anything:
//
//	GroupingKeyExpression   -> getGroupingSubKey()  (grouping columns only)
//	DimensionsKeyExpression -> getPrefixSubKey()    (prefix columns only)
//	KeyWithValueExpression  -> getKeyExpression()   (key columns only)
//
// so a predicate naming more columns than the unwrapped expression holds can
// never produce an EQUALITY match, and CanDeleteWhere returns false. The bound
// below is that same width, reached directly.
//
// It is not an arbitrary limit: the columns each wrapper hides are exactly the
// ones an index's SECONDARY structures are not keyed by. A ranked set, a
// permuted entry, an aggregate value, a bunched token map and a tokenizer
// version are all keyed by the GROUP and nothing finer. A prefix reaching past
// the group clears the primary entries and misses every one of those, leaving
// index data that still answers for records that are gone.
//
// (KeyWithValueExpression needs no arm: its ColumnSize already reports the split
// point, since the value columns are not in the key at all.)
func deleteWhereMatchableBound(root KeyExpression) int {
	switch e := root.(type) {
	case *GroupingKeyExpression:
		return e.GetGroupingCount()
	case *DimensionsKeyExpression:
		return e.PrefixSize
	default:
		return root.ColumnSize()
	}
}

// deleteWhereBoundError is the shared refusal for a prefix that reaches past the
// columns an index's structures are keyed by.
func deleteWhereBoundError(index *Index, prefix tuple.Tuple, bound int) error {
	return fmt.Errorf(
		"%s index %q: deleteWhere prefix has %d columns but the index is keyed by %d; "+
			"a longer prefix would clear some of its structures and miss others, leaving "+
			"index data that answers for records that are gone",
		index.Type, index.Name, len(prefix), bound)
}

// checkDeleteWhereBound is the shared CanDeleteWhere body: everything except the
// maintainers that need a NARROWER bound than the root expression implies.
func checkDeleteWhereBound(index *Index, prefix tuple.Tuple) error {
	bound := deleteWhereMatchableBound(index.RootExpression)
	if len(prefix) > bound {
		return deleteWhereBoundError(index, prefix, bound)
	}
	return nil
}

// CanDeleteWhere bounds a prefix by the index's matchable width. Every
// maintainer embedding standardIndexMaintainer inherits this — which is how
// RANK's ranked sets, MULTIDIMENSIONAL's R-trees and TIME_WINDOW_LEADERBOARD's
// directory get a bound without each restating it, exactly as they inherit
// StandardIndexMaintainer.canDeleteWhere in Java. The types whose secondary
// layout is narrower still (permuted min/max, sliding window) override.
func (m *StandardIndexMaintainer) CanDeleteWhere(prefix tuple.Tuple) error {
	return checkDeleteWhereBound(m.index, prefix)
}

// IndexStoreContext provides the store methods needed by index maintainers.
// Avoids circular dependency by using an interface instead of *FDBRecordStore directly.
type IndexStoreContext interface {
	readIndexState(indexName string) (IndexState, error)
	addUniquenessViolation(index *Index, indexKey tuple.Tuple, primaryKey tuple.Tuple, existingKey tuple.Tuple) error
	removeUniquenessViolations(index *Index, indexKey tuple.Tuple, primaryKey tuple.Tuple) error
	// isKeyInIndexBuildRange checks if a primary key is in the already-built range
	// of an index being built online. Used by non-idempotent index maintainers
	// (COUNT) during WRITE_ONLY to avoid double-counting.
	// Matches Java's standardIndexMaintainer.addedRangeWithKey().
	isKeyInIndexBuildRange(index *Index, primaryKey tuple.Tuple) (bool, error)
	// writeOnlyBuildSource is the source index of the BY_INDEX build of an
	// index under construction, from its indexing type stamp, or nil when the
	// build is by records or has no stamp (Java's updateWhileWriteOnly
	// dispatch, StandardIndexMaintainer.java:260-280).
	writeOnlyBuildSource(index *Index) (*Index, error)
	// sourceIndexEntryKey is Java's evaluateSingletonIndexKey
	// (StandardIndexMaintainer.java:331-345): the record's one entry key in
	// the source index, with its primary key, or nil when the record has none.
	sourceIndexEntryKey(source *Index, record *FDBStoredRecord[proto.Message]) (tuple.Tuple, error)

	// AcquireWriteLock acquires an exclusive lock for the given subspace key.
	// Used by tree-structured indexes (HNSW, R-tree) to serialize mutations.
	// Matches Java's FDBRecordContext.doWithWriteLock(LockIdentifier).
	AcquireWriteLock(key string)
	ReleaseWriteLock(key string)
	// AcquireReadLock acquires a shared lock for the given subspace key.
	// Used by tree-structured indexes to allow concurrent reads during scans.
	// Matches Java's FDBRecordContext.doWithReadLock(LockIdentifier).
	AcquireReadLock(key string)
	ReleaseReadLock(key string)

	// Env exposes the DST Tier-0 environment (Clock + Randomness + Buggify)
	// inherited from the record context. Nil-safe: a nil *dst.Env means
	// production, and the *dst.Env accessors fall back to wall clock / crypto/rand.
	// Vector-index maintainers (HNSW, R-tree) draw node-ID and sample-key nonces
	// through Env().Read so a simulation run reproduces the persisted bytes.
	Env() *dst.Env

	// indexMaintenanceFilter is the store's IndexMaintenanceFilter, Java's
	// IndexMaintainerState.filter.
	indexMaintenanceFilter() IndexMaintenanceFilter
}

// StandardIndexMaintainer handles VALUE index maintenance.
// Evaluates the index key expression against records, then sets/clears entries
// in the index subspace. Matches Java's standardIndexMaintainer.
type StandardIndexMaintainer struct {
	index         *Index
	indexSubspace subspace.Subspace
	tx            fdb.WritableTransaction
	store         IndexStoreContext
}

// ReadTransaction resolves the transaction a SCAN's reads go through, from the
// caller's isolation level. Every maintainer that performs a query read uses
// this — it is the one mechanism, inherited rather than re-decided per leaf,
// which is the whole point: an index type that reads through
// tx.Snapshot() directly silently overrides the statement's isolation, and
// nothing about the leaf's own code looks wrong when it does.
//
// Java's shape exactly: IndexMaintainerState.context.readTransaction(
// scanProperties.getExecuteProperties().getIsolationLevel().isSnapshot()) —
// VectorIndexMaintainer.java:201-202, TextIndexMaintainer.java:542,
// RankIndexMaintainer.java:292, and the generic leaf at
// KeyValueCursorBase.java:358 all spell it the same way.
func (m *StandardIndexMaintainer) ReadTransaction(scanProperties ScanProperties) fdb.ReadTransaction {
	return readTransactionFor(m.tx,
		scanProperties.ExecuteProperties.IsolationLevel.IsSnapshot())
}

func newStandardIndexMaintainer(index *Index, indexSubspace subspace.Subspace, tx fdb.WritableTransaction, store IndexStoreContext) *StandardIndexMaintainer {
	return &StandardIndexMaintainer{
		index:         index,
		indexSubspace: indexSubspace,
		tx:            tx,
		store:         store,
	}
}

// UpdateWhileWriteOnly updates the index during WRITE_ONLY state.
// standardIndexMaintainer is idempotent, so this is a pass-through to Update().
// Matches Java's standardIndexMaintainer.updateWhileWriteOnly() + isIdempotent() = true.
func (m *StandardIndexMaintainer) UpdateWhileWriteOnly(oldRecord, newRecord *FDBStoredRecord[proto.Message]) error {
	return m.Update(oldRecord, newRecord)
}

// Update handles insert (old=nil), delete (new=nil), or update (both non-nil).
// Matches Java's standardIndexMaintainer.update().
func (m *StandardIndexMaintainer) Update(oldRecord, newRecord *FDBStoredRecord[proto.Message]) error {
	// Fast path: insert-only — skip evaluateIndex wrapper,
	// common-entry filtering, and old-entries loop.
	if oldRecord == nil && newRecord != nil {
		_, isKWV := m.index.RootExpression.(*KeyWithValueExpression)
		if !isKWV && indexValuesFor(m.store, m.index, newRecord) == IndexValuesAll {
			// Int64 fast path: avoids any boxing alloc for integer fields.
			if ie, ok := m.index.RootExpression.(Int64Evaluator); ok {
				val, ok, err := ie.EvaluateInt64(newRecord, newRecord.Record)
				if err == nil && ok {
					return m.insertInt64Entry(val, newRecord)
				}
			}
			// DirectPacker: encode fields straight into FDB key bytes.
			// Avoids scalarToInterface boxing — handles both single-field and
			// composite keys without going through any.
			if dp, ok := m.index.RootExpression.(DirectPacker); ok {
				pk := tuple.GetPacker()
				pk.Reset()
				if dp.PackDirect(pk, newRecord, newRecord.Record) {
					trimmedPK, pkErr := m.index.TrimPrimaryKey(newRecord.PrimaryKey)
					if pkErr == nil {
						pk.EncodeTuple(trimmedPK)
						var buf []byte
						keyBytes := pk.AppendInto(&buf, m.indexSubspace.Bytes())
						tuple.PutPacker(pk)
						if err := checkKeyValueSizes(m.index, newRecord.PrimaryKey, keyBytes, emptyTuplePacked); err != nil {
							return err
						}
						if m.index.IsUnique() {
							keyTuple, uErr := tuplefast.SubspaceUnpack(keyBytes, len(m.indexSubspace.Bytes()))
							if uErr != nil {
								return fmt.Errorf("unpack index key for uniqueness check: %w", uErr)
							}
							colCount := m.index.RootExpression.ColumnSize()
							if colCount > 0 && len(keyTuple) > colCount {
								entry := EvaluatedIndexEntry{key: keyTuple[:colCount], primaryKey: newRecord.PrimaryKey, value: tuple.Tuple{}}
								if err := m.checkUniqueness(entry); err != nil {
									return err
								}
							}
						}
						m.tx.Set(fdb.Key(keyBytes), emptyTuplePacked)
						return nil
					}
				}
				tuple.PutPacker(pk)
			}
			if fe, ok := m.index.RootExpression.(FlatEvaluator); ok {
				values, err := fe.EvaluateFlat(newRecord, newRecord.Record)
				if err == nil {
					// Zero-alloc: reinterpret []any as tuple.Tuple (same layout).
					key := *(*tuple.Tuple)(unsafe.Pointer(&values))
					entry := EvaluatedIndexEntry{key: key, primaryKey: newRecord.PrimaryKey, value: tuple.Tuple{}}
					return m.insertSingleEntry(entry, newRecord)
				}
			}
		}
	}

	var oldEntries []EvaluatedIndexEntry
	var newEntries []EvaluatedIndexEntry

	if oldRecord != nil {
		entries, err := m.FilteredIndexEntries(oldRecord)
		if err != nil {
			return fmt.Errorf("evaluate index %q for old record: %w", m.index.Name, err)
		}
		oldEntries = entries
	}

	if newRecord != nil {
		entries, err := m.FilteredIndexEntries(newRecord)
		if err != nil {
			return fmt.Errorf("evaluate index %q for new record: %w", m.index.Name, err)
		}
		newEntries = entries
	}

	// Skip unchanged entries (optimization matching Java's skipUpdateForUnchangedKeys)
	if oldEntries != nil && newEntries != nil {
		var err error
		oldEntries, newEntries, err = RemoveCommonEntries(m.index, oldEntries, newEntries)
		if err != nil {
			return err
		}
	}

	// Remove old entries first so uniqueness checks see clean state
	state, err := m.currentIndexState()
	if err != nil {
		return err
	}
	isWriteOnlyOrUniquePending := state.IsWriteOnly() || state == IndexStateReadableUniquePending
	for i := range oldEntries {
		oldEntryKey, err := indexEntryKey(m.index, oldEntries[i].key, oldEntries[i].primaryKey)
		if err != nil {
			return err
		}
		m.tx.ClearBytes(m.indexSubspace.Pack(oldEntryKey))
		// Clean up violation entries on delete for WRITE_ONLY/READABLE_UNIQUE_PENDING indexes.
		// Matches Java's standardIndexMaintainer.updateOneKeyAsync() remove path.
		if isWriteOnlyOrUniquePending && m.index.IsUnique() && m.store != nil {
			if err := m.store.removeUniquenessViolations(m.index, oldEntries[i].key, oldEntries[i].primaryKey); err != nil {
				return err
			}
		}
	}

	// Add new entries
	emptyValue := emptyTuplePacked
	for i := range newEntries {
		entryTupleKey, err := indexEntryKey(m.index, newEntries[i].key, newEntries[i].primaryKey)
		if err != nil {
			return err
		}
		keyBytes := m.indexSubspace.Pack(entryTupleKey)

		// For KeyWithValueExpression indexes, store the value portion in the FDB value.
		// Otherwise, store empty tuple (standard VALUE index behavior).
		valueBytes := emptyValue
		if newEntries[i].value != nil {
			valueBytes = newEntries[i].value.Pack()
		}

		if err := checkKeyValueSizes(m.index, newEntries[i].primaryKey, keyBytes, valueBytes); err != nil {
			return err
		}

		if m.index.IsUnique() && !keyContainsNonUniqueNull(m.index.RootExpression, newEntries[i].key) {
			if err := m.checkUniqueness(newEntries[i]); err != nil {
				return err
			}
		}

		m.tx.SetBytes(keyBytes, valueBytes)
	}

	return nil
}

// insertInt64Entry handles inserting a VALUE index entry for an integer field.
// Avoids the any boxing allocation by packing int64 directly.
func (m *StandardIndexMaintainer) insertInt64Entry(val int64, record *FDBStoredRecord[proto.Message]) error {
	trimmedPK, err := m.index.TrimPrimaryKey(record.PrimaryKey)
	if err != nil {
		return err
	}

	var keyBytes []byte
	if len(trimmedPK) == 0 {
		keyBytes = tuple.Pack1WithPrefix(m.indexSubspace.Bytes(), val)
	} else {
		keyBytes = tuple.Pack1ConcatWithPrefix(m.indexSubspace.Bytes(), val, trimmedPK)
	}

	if err := checkKeyValueSizes(m.index, record.PrimaryKey, keyBytes, emptyTuplePacked); err != nil {
		return err
	}

	if m.index.IsUnique() {
		entry := EvaluatedIndexEntry{key: tuple.Tuple{val}, primaryKey: record.PrimaryKey, value: tuple.Tuple{}}
		if err := m.checkUniqueness(entry); err != nil {
			return err
		}
	}

	m.tx.Set(fdb.Key(keyBytes), emptyTuplePacked)
	return nil
}

func (m *StandardIndexMaintainer) insertScalarEntry(val any, record *FDBStoredRecord[proto.Message]) error {
	trimmedPK, err := m.index.TrimPrimaryKey(record.PrimaryKey)
	if err != nil {
		return err
	}

	var keyBytes []byte
	if len(trimmedPK) == 0 {
		keyBytes = tuple.Pack1WithPrefix(m.indexSubspace.Bytes(), tuple.TupleElement(val))
	} else {
		keyBytes = tuple.Pack1ConcatWithPrefix(m.indexSubspace.Bytes(), tuple.TupleElement(val), trimmedPK)
	}

	if err := checkKeyValueSizes(m.index, record.PrimaryKey, keyBytes, emptyTuplePacked); err != nil {
		return err
	}

	if m.index.IsUnique() && val != nil {
		entry := EvaluatedIndexEntry{key: tuple.Tuple{tuple.TupleElement(val)}, primaryKey: record.PrimaryKey, value: tuple.Tuple{}}
		if err := m.checkUniqueness(entry); err != nil {
			return err
		}
	}

	m.tx.Set(fdb.Key(keyBytes), emptyTuplePacked)
	return nil
}

// insertSingleEntry handles the insert of a single VALUE index entry.
// Extracted from the Update loop to support the insert-only fast path.
func (m *StandardIndexMaintainer) insertSingleEntry(entry EvaluatedIndexEntry, record *FDBStoredRecord[proto.Message]) error {
	trimmedPK, err := m.index.TrimPrimaryKey(entry.primaryKey)
	if err != nil {
		return err
	}

	// Pack index values + trimmed PK directly into the key, avoiding
	// the intermediate tuple allocation in indexEntryKey.
	var keyBytes fdb.Key
	if len(trimmedPK) == 0 {
		keyBytes = m.indexSubspace.Pack(entry.key)
	} else if len(entry.key) == 0 {
		keyBytes = m.indexSubspace.Pack(trimmedPK)
	} else {
		keyBytes = fdb.Key(tuple.PackConcatWithPrefix(m.indexSubspace.Bytes(), entry.key, trimmedPK))
	}

	if err := checkKeyValueSizes(m.index, entry.primaryKey, keyBytes, emptyTuplePacked); err != nil {
		return err
	}

	if m.index.IsUnique() && !keyContainsNonUniqueNull(m.index.RootExpression, entry.key) {
		if err := m.checkUniqueness(entry); err != nil {
			return err
		}
	}

	m.tx.Set(keyBytes, emptyTuplePacked)
	return nil
}

// Scan scans index entries within the given tuple range.
// Creates a KeyValueCursor over the index subspace and maps KVs to IndexEntry.
// Matches Java's standardIndexMaintainer.scan().
func (m *StandardIndexMaintainer) Scan(scanRange TupleRange, continuation []byte, scanProperties ScanProperties) RecordCursor[*IndexEntry] {
	cursor := newIndexCursor(m.index, m.indexSubspace, m.tx, scanRange, continuation, scanProperties)
	if store, ok := m.store.(*FDBRecordStore); ok {
		cursor.withContext(store.context)
	}
	return cursor
}

// deleteWhereRange clears all index entries whose key starts with the given prefix
// in the specified subspace. Uses FDB PrefixRange to include the exact prefix key
// (important for ungrouped aggregate indexes).
// Shared implementation for all index maintainer types.
func deleteWhereRange(tx fdb.WritableTransaction, indexSubspace subspace.Subspace, prefix tuple.Tuple) error {
	key := indexSubspace.Pack(prefix)
	pr, err := fdb.PrefixRange(key)
	if err != nil {
		return fmt.Errorf("deleteWhereRange: PrefixRange(%x): %w", key, err)
	}
	tx.ClearRange(pr)
	return nil
}

// DeleteWhere clears all index entries whose key starts with the given prefix.
// Matches Java's standardIndexMaintainer.deleteWhere().
func (m *StandardIndexMaintainer) DeleteWhere(prefix tuple.Tuple) error {
	// Backstop for direct callers; DeleteRecordsWhere asks CanDeleteWhere BEFORE
	// it clears anything. Method dispatch here is static, so a maintainer that
	// embeds this and overrides CanDeleteWhere with a NARROWER bound must — and
	// does — call its own before delegating.
	if err := m.CanDeleteWhere(prefix); err != nil {
		return err
	}
	return deleteWhereRange(m.tx, m.indexSubspace, prefix)
}

// EvaluatedIndexEntry represents a single index entry (indexed values + record primary key).
type EvaluatedIndexEntry struct {
	key        tuple.Tuple
	primaryKey tuple.Tuple
	value      tuple.Tuple // Non-nil for KeyWithValueExpression covering indexes
}

// FilteredIndexEntries is Java's StandardIndexMaintainer.filteredIndexEntries
// (:348-384): nil for a nil record or one the index does not maintain
// (indexValuesFor), otherwise its evaluated entries, only those the store's
// filter admits under IndexValuesSome. Every maintainer's update path reads a
// record's entries through it, as Java's StandardIndexMaintainer.update does.
func (m *StandardIndexMaintainer) FilteredIndexEntries(record *FDBStoredRecord[proto.Message]) ([]EvaluatedIndexEntry, error) {
	if record == nil {
		return nil, nil
	}
	values := indexValuesFor(m.store, m.index, record)
	if values == IndexValuesNone {
		return nil, nil
	}
	entries, err := m.evaluateIndex(record)
	if err != nil {
		return nil, err
	}
	return keepMaintainedEntries(m.store, m.index, record, values, entries), nil
}

// evaluateIndex evaluates the index expression against a record to produce index entries.
// Fans out when the expression returns multiple key tuples (e.g. repeated fields).
// If the index has a predicate and the record doesn't match, returns nil (no entries).
// Matches Java's standardIndexMaintainer.evaluateIndex().
func (m *StandardIndexMaintainer) evaluateIndex(record *FDBStoredRecord[proto.Message]) ([]EvaluatedIndexEntry, error) {
	// Check predicate for sparse/filtered indexes
	if m.index.Predicate != nil && !m.index.Predicate(record.Record) {
		return nil, nil
	}

	kwv, isKeyWithValue := m.index.RootExpression.(*KeyWithValueExpression)

	// Fast path: EvaluateFlat for simple non-KeyWithValue, non-fan-out indexes.
	// Avoids the [][]any allocation from Evaluate.
	if !isKeyWithValue {
		if fe, ok := m.index.RootExpression.(FlatEvaluator); ok {
			values, err := fe.EvaluateFlat(record, record.Record)
			if err == nil {
				key := make(tuple.Tuple, len(values))
				for j, v := range values {
					key[j] = v
				}
				return []EvaluatedIndexEntry{{key: key, primaryKey: record.PrimaryKey, value: tuple.Tuple{}}}, nil
			}
			// Fall through on error (e.g. fan-out)
		}
	}

	tuples, err := m.index.RootExpression.Evaluate(record, record.Record)
	if err != nil {
		return nil, err
	}

	entries := make([]EvaluatedIndexEntry, len(tuples))
	for i, values := range tuples {
		if isKeyWithValue {
			// Split at splitPoint: key columns go in FDB key, value columns in FDB value.
			// Matches Java's standardIndexMaintainer.evaluateIndex() KeyWithValueExpression path.
			keyPart, valuePart := kwv.SplitEvaluatedKey(values)
			key := make(tuple.Tuple, len(keyPart))
			for j, v := range keyPart {
				key[j] = v
			}
			val := make(tuple.Tuple, len(valuePart))
			for j, v := range valuePart {
				val[j] = v
			}
			entries[i] = EvaluatedIndexEntry{key: key, primaryKey: record.PrimaryKey, value: val}
		} else {
			key := make(tuple.Tuple, len(values))
			for j, v := range values {
				key[j] = v
			}
			entries[i] = EvaluatedIndexEntry{key: key, primaryKey: record.PrimaryKey}
		}
	}

	return entries, nil
}

// checkUniqueness verifies no other record has the same index value.
// Scans the value's whole tuple range (no limit) so FDB's read-conflict
// tracking covers it, preventing concurrent inserts of conflicting entries.
// Java reads the full range too (no limit) and registers the scan as a
// commit check via addIndexUniquenessCommitCheck().
// Matches Java's standardIndexMaintainer.checkUniqueness().
func (m *StandardIndexMaintainer) checkUniqueness(entry EvaluatedIndexEntry) error {
	// Java's indexSubspace.range(valueKey), [pack+00, pack+ff): a byte prefix
	// range would also cover values whose packing extends this one ("a" and "a\x00b").
	r := m.indexSubspace.Sub(entry.key...)

	// No Limit — read the full range so FDB records a read conflict on the
	// whole range r. With Limit:1, FDB only tracks conflict up to the first
	// key found, allowing concurrent inserts at higher keys to go undetected.
	kvs, err := m.tx.GetRange(r, fdb.RangeOptions{}).GetSliceWithError()
	if err != nil {
		return fmt.Errorf("uniqueness scan for index %q: %w", m.index.Name, err)
	}

	for _, kv := range kvs {
		existingTuple, err := tuplefast.SubspaceUnpack(kv.Key, len(m.indexSubspace.Bytes()))
		if err != nil {
			return fmt.Errorf("unpack existing index entry: %w", err)
		}

		// Reconstruct full PK from the FDB entry key using getEntryPrimaryKey.
		// The raw suffix after the value columns is the TRIMMED PK (deduped
		// components removed). Must use getEntryPrimaryKey to get full PK
		// for correct comparison and violation entries.
		// Matches Java's Index.getEntryPrimaryKey(indexEntry).
		existingPK := m.index.EntryPrimaryKey(existingTuple)
		if tuplesEqual(existingPK, entry.primaryKey) {
			continue // Our own record — not a violation
		}

		// WRITE_ONLY indexes: write violation entries instead of throwing.
		// Matches Java's standardIndexMaintainer.checkUniqueness() which
		// calls addUniquenessViolation() for both conflicting PKs.
		state, err := m.currentIndexState()
		if err != nil {
			return err
		}
		if m.store != nil && state.IsWriteOnly() {
			if err := m.store.addUniquenessViolation(m.index, entry.key, entry.primaryKey, existingPK); err != nil {
				return err
			}
			if err := m.store.addUniquenessViolation(m.index, entry.key, existingPK, entry.primaryKey); err != nil {
				return err
			}
			return nil
		}
		return &RecordIndexUniquenessViolationError{
			IndexName:   m.index.Name,
			IndexKey:    entry.key,
			PrimaryKey:  entry.primaryKey,
			ExistingKey: existingPK,
		}
	}

	return nil
}

// currentIndexState uses the context's shared state view, not a store object's
// open-time snapshot. Explicit state-key conflicts cover negative decisions too,
// without issuing a point read for each maintained record.
func (m *StandardIndexMaintainer) currentIndexState() (IndexState, error) {
	if m.store == nil {
		return IndexStateReadable, nil
	}
	return m.store.readIndexState(m.index.Name)
}

// checkKeyValueSizes validates that an index entry's key and value don't exceed
// FDB limits. Called on insert only (not delete).
// Matches Java's standardIndexMaintainer.checkKeyValueSizes().
func checkKeyValueSizes(index *Index, primaryKey tuple.Tuple, keyBytes, valueBytes []byte) error {
	if len(keyBytes) > keySizeLimit {
		return &IndexKeySizeError{
			IndexName:  index.Name,
			PrimaryKey: primaryKey,
			KeySize:    len(keyBytes),
			Limit:      keySizeLimit,
		}
	}
	if len(valueBytes) > valueSizeLimit {
		return &IndexValueSizeError{
			IndexName:  index.Name,
			PrimaryKey: primaryKey,
			ValueSize:  len(valueBytes),
			Limit:      valueSizeLimit,
		}
	}
	return nil
}

// IndexKeySizeError indicates an index entry key exceeds the FDB key size limit.
// Matches Java's FDBExceptions.FDBStoreKeySizeException.
type IndexKeySizeError struct {
	IndexName  string
	PrimaryKey tuple.Tuple
	KeySize    int
	Limit      int
}

func (e *IndexKeySizeError) Error() string {
	return fmt.Sprintf("index entry key too large for index %q (pk=%v): %d bytes exceeds limit %d",
		e.IndexName, e.PrimaryKey, e.KeySize, e.Limit)
}

func (*IndexKeySizeError) JavaRecordCoreException() {}

// IndexValueSizeError indicates an index entry value exceeds the FDB value size limit.
// Matches Java's FDBExceptions.FDBStoreValueSizeException.
type IndexValueSizeError struct {
	IndexName  string
	PrimaryKey tuple.Tuple
	ValueSize  int
	Limit      int
}

func (e *IndexValueSizeError) Error() string {
	return fmt.Sprintf("index entry value too large for index %q (pk=%v): %d bytes exceeds limit %d",
		e.IndexName, e.PrimaryKey, e.ValueSize, e.Limit)
}

func (*IndexValueSizeError) JavaRecordCoreException() {}

// keyContainsNonUniqueNull is Java's IndexEntry.keyContainsNonUniqueNull
// (IndexEntry.java:183-191): whether a column of key holds NullStandin.NULL,
// the null a unique index ignores. Key is the leading columns of expr's
// evaluation, as an IndexEntry's key is. A null that is not NullStandin.NULL
// (a NULL_UNIQUE or NOT_NULL field, a function's plain null) does not count:
// two records whose keys hold it collide under a unique index.
func keyContainsNonUniqueNull(expr KeyExpression, key tuple.Tuple) bool {
	var standins []bool
	for i, v := range key {
		if v != nil {
			continue
		}
		if standins == nil {
			standins = nonUniqueNullColumns(expr)
		}
		if i < len(standins) && standins[i] {
			return true
		}
	}
	return false
}

// nonUniqueNullColumns reports, per column of expr's evaluation, whether a
// null there is NullStandin.NULL. Go evaluates every standin to a plain nil,
// so where Java reads the standin off the evaluated value
// (IndexEntry.java:64-79) Go reads it off the leaf that produced the column:
// each leaf's nulls are all of one kind.
//   - A field's null is only ever its getNullResult, so it is the field's
//     standin: a nullable-tuple-field message converts to a primitive, never
//     to null (TupleFieldsHelper.java:110-160). A nesting's null is its child's
//     (an absent parent evaluates the child over a null message).
//   - Literal(null), a record without a version and a null record are
//     Key.Evaluated.NULL (LiteralKeyExpression.java:68,
//     VersionKeyExpression.java:66, RecordTypeKeyExpression.java:74).
//   - A function's null is NULL only for the functions that return
//     Key.Evaluated.NULL (functionNullIsNonUnique).
//   - A list column holds a nested list and a split column holds repeated
//     values, never a standin (ListKeyExpression.java:113 converts each child
//     to its tuple-appropriate list).
func nonUniqueNullColumns(expr KeyExpression) []bool {
	cols := make([]bool, 0, expr.ColumnSize())
	return appendNonUniqueNullColumns(cols, expr)
}

func appendNonUniqueNullColumns(cols []bool, expr KeyExpression) []bool {
	switch e := expr.(type) {
	case *FieldKeyExpression:
		return append(cols, e.nullStandin == NullStandinNull)
	case *NestingKeyExpression:
		return appendNonUniqueNullColumns(cols, e.child)
	case *CompositeKeyExpression:
		for _, child := range e.expressions {
			cols = appendNonUniqueNullColumns(cols, child)
		}
		return cols
	case *GroupingKeyExpression:
		return appendNonUniqueNullColumns(cols, e.wholeKey)
	case *KeyWithValueExpression:
		return appendNonUniqueNullColumns(cols, e.innerKey)
	case *DimensionsKeyExpression:
		return appendNonUniqueNullColumns(cols, e.WholeKey)
	case *LiteralKeyExpression, *VersionKeyExpression, *RecordTypeKeyExpression:
		return append(cols, true)
	case *CardinalityFunctionKeyExpression:
		return appendRepeated(cols, e.ColumnSize(), functionNullIsNonUnique(e.name))
	case *FunctionKeyExpression:
		return appendRepeated(cols, e.ColumnSize(), functionNullIsNonUnique(e.name))
	default:
		return appendRepeated(cols, expr.ColumnSize(), false)
	}
}

func appendRepeated(cols []bool, n int, v bool) []bool {
	for range n {
		cols = append(cols, v)
	}
	return cols
}

// tuplesEqual compares two tuples by their packed byte representation.
func tuplesEqual(a, b tuple.Tuple) bool {
	return string(a.Pack()) == string(b.Pack())
}

// RemoveCommonEntries filters out entries that are identical in both old and new.
// This avoids unnecessary FDB mutations when a record update doesn't change
// the indexed value. Matches Java's standardIndexMaintainer.commonKeys optimization.
func RemoveCommonEntries(idx *Index, old, new []EvaluatedIndexEntry) ([]EvaluatedIndexEntry, []EvaluatedIndexEntry, error) {
	packEntry := func(e EvaluatedIndexEntry) (string, error) {
		// Include value in the comparison key for KeyWithValueExpression indexes.
		// Matches Java's IndexEntry.equals() which compares both key and value.
		ek, err := indexEntryKey(idx, e.key, e.primaryKey)
		if err != nil {
			return "", err
		}
		s := string(ek.Pack())
		if e.value != nil {
			s += "|" + string(e.value.Pack())
		}
		return s, nil
	}

	newSet := make(map[string]struct{}, len(new))
	for _, e := range new {
		p, err := packEntry(e)
		if err != nil {
			return nil, nil, err
		}
		newSet[p] = struct{}{}
	}

	common := make(map[string]struct{})
	var filteredOld []EvaluatedIndexEntry
	for _, e := range old {
		p, err := packEntry(e)
		if err != nil {
			return nil, nil, err
		}
		if _, ok := newSet[p]; ok {
			common[p] = struct{}{}
		} else {
			filteredOld = append(filteredOld, e)
		}
	}

	var filteredNew []EvaluatedIndexEntry
	for _, e := range new {
		p, err := packEntry(e)
		if err != nil {
			return nil, nil, err
		}
		if _, ok := common[p]; !ok {
			filteredNew = append(filteredNew, e)
		}
	}

	return filteredOld, filteredNew, nil
}

// RecordIndexUniquenessViolationError indicates a unique index constraint violation.
// Matches Java's RecordIndexUniquenessViolation.
type RecordIndexUniquenessViolationError struct {
	IndexName   string
	IndexKey    tuple.Tuple
	PrimaryKey  tuple.Tuple
	ExistingKey tuple.Tuple
}

func (e *RecordIndexUniquenessViolationError) Error() string {
	return fmt.Sprintf("uniqueness violation for index %q: value %v already exists for record %v (new record: %v)",
		e.IndexName, e.IndexKey, e.ExistingKey, e.PrimaryKey)
}

func (*RecordIndexUniquenessViolationError) JavaRecordCoreException() {}
