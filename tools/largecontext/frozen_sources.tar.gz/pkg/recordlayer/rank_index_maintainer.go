// Portions derived from FoundationDB Record Layer (RankedSetIndexHelper.java,
// IndexOptions.java, StandardIndexMaintainer.java, TupleRange.java),
// Copyright 2015-2018 Apple Inc. and the FoundationDB project authors
// Copyright 2015-2026 Apple Inc. and the FoundationDB project authors
// Licensed under the Apache License, Version 2.0; translated to Go and modified.

package recordlayer

import (
	"fmt"

	"fdb.dev/pkg/recordlayer/internal/tuplefast"

	"fdb.dev/pkg/fdbgo/fdb"
	"fdb.dev/pkg/fdbgo/fdb/subspace"
	"fdb.dev/pkg/fdbgo/fdb/tuple"
	"google.golang.org/protobuf/proto"
)

// RankQuerier is the public interface for rank-based queries on a RANK index maintainer.
type RankQuerier interface {
	RankForScore(score tuple.Tuple, nullsAreLow bool) (*int64, error)
	ScoreForRank(rank tuple.Tuple) (tuple.Tuple, error)
}

// rankIndexMaintainer maintains a RANK index.
// A RANK index has two subspaces:
//   - Primary (B-tree): standard VALUE index on [group..., score...]
//   - Secondary: a RankedSet per group for rank/select queries
//
// Matches Java's rankIndexMaintainer.
type rankIndexMaintainer struct {
	StandardIndexMaintainer                   // embedded — primary B-tree operations
	secondarySubspace       subspace.Subspace // ranked sets per group
	rankedSetConfig         rankedSetConfig
}

// Index option keys for RANK indexes.
// Matches Java's IndexOptions.RANK_*.
const (
	IndexOptionRankNLevels         = "rankNLevels"
	IndexOptionRankHashFunction    = "rankHashFunction"
	IndexOptionRankCountDuplicates = "rankCountDuplicates"
)

func newRankIndexMaintainer(
	index *Index,
	indexSubspace, secondarySubspace subspace.Subspace,
	tx fdb.WritableTransaction,
	store IndexStoreContext,
) (*rankIndexMaintainer, error) {
	config, err := parseRankedSetConfig(index)
	if err != nil {
		return nil, err
	}
	return &rankIndexMaintainer{
		StandardIndexMaintainer: *newStandardIndexMaintainer(index, indexSubspace, tx, store),
		secondarySubspace:       secondarySubspace,
		rankedSetConfig:         config.withEnv(store.Env()),
	}, nil
}

// parseRankedSetConfig reads RankedSet configuration from index options,
// as Java's RankedSetIndexHelper.getConfig does and in its order: the hash
// function by exact name (an unknown one refused), the level count by
// Integer.parseInt and RankedSet.ConfigBuilder.setNLevels's range, and
// count-duplicates by Boolean.parseBoolean. Java raises the refusals when a
// maintainer is made and when the option check reads the config; so does Go.
func parseRankedSetConfig(index *Index) (rankedSetConfig, error) {
	config := defaultRankedSetConfig
	if v, ok := index.Options[IndexOptionRankHashFunction]; ok {
		fn, found := rankedSetHashFunctions[v]
		if !found {
			return rankedSetConfig{}, &RecordCoreArgumentError{Message: "hash function not found: " + v}
		}
		config.HashFunction, config.HashFunctionName = fn, v
	}
	if v, ok := index.Options[IndexOptionRankNLevels]; ok {
		n, err := JavaParseInt(v)
		if err != nil {
			return rankedSetConfig{}, err
		}
		if n < 2 || n > rankedSetMaxLevels {
			return rankedSetConfig{}, &IllegalArgumentError{Message: fmt.Sprintf("levels must be between 2 and %d", rankedSetMaxLevels)}
		}
		config.NLevels = int(n)
	}
	if v, ok := index.Options[IndexOptionRankCountDuplicates]; ok {
		config.CountDuplicates = javaParseBoolean(v)
	}
	return config, nil
}

// DeleteWhere clears both the primary B-tree and secondary ranked set entries
// for the given prefix. Matches Java's rankIndexMaintainer.deleteWhere().
func (m *rankIndexMaintainer) DeleteWhere(prefix tuple.Tuple) error {
	// Clear primary (B-tree) entries.
	if err := m.StandardIndexMaintainer.DeleteWhere(prefix); err != nil {
		return err
	}
	// Clear secondary (ranked set) entries.
	key := m.secondarySubspace.Pack(prefix)
	pr, err := fdb.PrefixRange(key)
	if err != nil {
		return fmt.Errorf("rankIndexMaintainer.DeleteWhere: PrefixRange(%x): %w", key, err)
	}
	m.tx.ClearRange(pr)
	return nil
}

// Update handles insert/delete/update for the RANK index.
// Maintains both the primary B-tree and the secondary ranked set.
// Acquires write lock because the ranked set does read-modify-write on the
// skip list structure — concurrent updates cause lost updates.
// Matches Java where per-record index updates are serialized via the
// CompletableFuture pipeline.
func (m *rankIndexMaintainer) Update(oldRecord, newRecord *FDBStoredRecord[proto.Message]) error {
	lockKey := string(m.secondarySubspace.Bytes())
	m.store.AcquireWriteLock(lockKey)
	defer m.store.ReleaseWriteLock(lockKey)
	var oldEntries, newEntries []EvaluatedIndexEntry

	if oldRecord != nil {
		entries, err := m.FilteredIndexEntries(oldRecord)
		if err != nil {
			return fmt.Errorf("evaluate index %q for old record: %w", m.index.Name, err)
		}
		oldEntries = entries
	}
	if newRecord != nil {
		entries, err := m.FilteredIndexEntries(newRecord)
		if err != nil {
			return fmt.Errorf("evaluate index %q for new record: %w", m.index.Name, err)
		}
		newEntries = entries
	}

	if oldEntries != nil && newEntries != nil {
		var err error
		oldEntries, newEntries, err = RemoveCommonEntries(m.index, oldEntries, newEntries)
		if err != nil {
			return err
		}
	}

	state, err := m.currentIndexState()
	if err != nil {
		return err
	}
	isWriteOnlyOrUniquePending := state.IsWriteOnly() || state == IndexStateReadableUniquePending

	// Process removes: clear B-tree + update ranked set.
	for i := range oldEntries {
		oldEntryKey, err := indexEntryKey(m.index, oldEntries[i].key, oldEntries[i].primaryKey)
		if err != nil {
			return err
		}
		m.tx.ClearBytes(m.indexSubspace.Pack(oldEntryKey))
		if isWriteOnlyOrUniquePending && m.index.IsUnique() && m.store != nil {
			if err := m.store.removeUniquenessViolations(m.index, oldEntries[i].key, oldEntries[i].primaryKey); err != nil {
				return err
			}
		}
		if err := m.updateRankedSet(oldEntries[i], true); err != nil {
			return err
		}
	}

	// Process inserts: set B-tree + update ranked set.
	valueBytes := tuple.Tuple{}.Pack()
	for i := range newEntries {
		entryTupleKey, err := indexEntryKey(m.index, newEntries[i].key, newEntries[i].primaryKey)
		if err != nil {
			return err
		}
		keyBytes := m.indexSubspace.Pack(entryTupleKey)

		if err := checkKeyValueSizes(m.index, newEntries[i].primaryKey, keyBytes, valueBytes); err != nil {
			return err
		}
		if m.index.IsUnique() && !keyContainsNonUniqueNull(m.index.RootExpression, newEntries[i].key) {
			if err := m.checkUniqueness(newEntries[i]); err != nil {
				return err
			}
		}

		m.tx.SetBytes(keyBytes, valueBytes)

		if err := m.updateRankedSet(newEntries[i], false); err != nil {
			return err
		}
	}

	return nil
}

// UpdateWhileWriteOnly handles updates during WRITE_ONLY state.
// RANK is idempotent when !CountDuplicates.
func (m *rankIndexMaintainer) UpdateWhileWriteOnly(oldRecord, newRecord *FDBStoredRecord[proto.Message]) error {
	if !m.rankedSetConfig.CountDuplicates {
		return m.Update(oldRecord, newRecord) // idempotent
	}
	// Non-idempotent: only where the build has covered the record, as Java's
	// StandardIndexMaintainer.updateWhileWriteOnly decides it.
	return updateWhileWriteOnlyNonIdempotent(oldRecord, newRecord, m.index, m.store, m.index.Type, m.Update)
}

// Scan scans the primary B-tree (BY_VALUE).
// Inherited from standardIndexMaintainer — no override needed.

// ScanByRank converts [group..., numeric rank] with Java's Number.longValue(), then scans BY_VALUE.
// A null rank bound is unbounded, as in Java's scan(BY_RANK, ...).
func (m *rankIndexMaintainer) ScanByRank(
	rankRange TupleRange,
	continuation []byte,
	scanProperties ScanProperties,
) RecordCursor[*IndexEntry] {
	scoreRange, err := m.rankRangeToScoreRange(rankRange)
	if err != nil {
		return &errorCursor[*IndexEntry]{err: err}
	}
	if scoreRange == nil {
		return Empty[*IndexEntry]()
	}
	return m.StandardIndexMaintainer.Scan(*scoreRange, continuation, scanProperties)
}

// updateRankedSet adds or removes a score from the ranked set for the entry's group.
// On remove with !CountDuplicates, only removes if no other B-tree entry has this score.
// Matches Java's RankedSetIndexHelper.updateRankedSet().
func (m *rankIndexMaintainer) updateRankedSet(entry EvaluatedIndexEntry, remove bool) error {
	groupPrefixSize := m.getGroupingCount()

	var rankSubspace subspace.Subspace
	var scoreKey tuple.Tuple

	if groupPrefixSize > 0 && groupPrefixSize <= len(entry.key) {
		groupPrefix := tuple.Tuple(entry.key[:groupPrefixSize])
		rankSubspace = m.secondarySubspace.Sub(groupPrefix...)
		scoreKey = tuple.Tuple(entry.key[groupPrefixSize:])
	} else {
		rankSubspace = m.secondarySubspace
		scoreKey = entry.key
	}

	rankedSet := newRankedSet(rankSubspace, m.rankedSetConfig)
	score := scoreKey.Pack()

	// Init if needed — use snapshot check to avoid conflicts with atomic mutations.
	needed, err := rankedSet.InitNeeded(m.tx.Snapshot())
	if err != nil {
		return err
	}
	if needed {
		if err := rankedSet.Init(m.tx); err != nil {
			return err
		}
	}

	if remove {
		state, err := m.currentIndexState()
		if err != nil {
			return err
		}
		if m.rankedSetConfig.CountDuplicates {
			exists, err := rankedSet.Remove(m.tx, score)
			if err != nil {
				return err
			}
			if !exists && m.store != nil && !state.IsWriteOnly() {
				return fmt.Errorf("rank index %q: score not present in ranked set", m.index.Name)
			}
		} else {
			// Remove the score only if no other record holds it: probe (after our clear)
			// Java's indexSubspace.range(valueKey), which excludes extending packings.
			kvs, err := m.tx.GetRange(m.indexSubspace.Sub(entry.key...), fdb.RangeOptions{Limit: 1}).GetSliceWithError()
			if err != nil {
				return err
			}
			if len(kvs) == 0 {
				exists, err := rankedSet.Remove(m.tx, score)
				if err != nil {
					return err
				}
				if !exists && m.store != nil && !state.IsWriteOnly() {
					return fmt.Errorf("rank index %q: score not present in ranked set", m.index.Name)
				}
			}
		}
	} else {
		if _, err := rankedSet.Add(m.tx, score); err != nil {
			return err
		}
	}
	return nil
}

// rankRangeToScoreRange converts rank endpoints to score endpoints.
// Returns nil if the range is empty. Matches Java's RankedSetIndexHelper.rankRangeToScoreRange().
func (m *rankIndexMaintainer) rankRangeToScoreRange(rankRange TupleRange) (*TupleRange, error) {
	groupPrefixSize := m.getGroupingCount()

	var prefix tuple.Tuple
	var rankSubspace subspace.Subspace

	if groupPrefixSize > 0 {
		if rankRange.Low == nil || len(rankRange.Low) < groupPrefixSize ||
			rankRange.High == nil || len(rankRange.High) < groupPrefixSize {
			return nil, fmt.Errorf("rank scan range must include group (size %d)", groupPrefixSize)
		}
		prefix = tuple.Tuple(rankRange.Low[:groupPrefixSize])
		highPrefix := tuple.Tuple(rankRange.High[:groupPrefixSize])
		if !tuplesEqual(prefix, highPrefix) {
			return nil, fmt.Errorf("rank scan range crosses groups")
		}
		rankSubspace = m.secondarySubspace.Sub(prefix...)
	} else {
		rankSubspace = m.secondarySubspace
	}

	lowRank, err := extractRankValue(groupPrefixSize, rankRange.Low)
	if err != nil {
		return nil, err
	}
	highRank, err := extractRankValue(groupPrefixSize, rankRange.High)
	if err != nil {
		return nil, err
	}

	startFromBeginning := lowRank == nil || *lowRank < 0
	lowEndpoint := rankRange.LowEndpoint
	if startFromBeginning {
		lowEndpoint = EndpointTypeRangeInclusive
	}

	highEndpoint := rankRange.HighEndpoint
	if highRank != nil {
		if *highRank < 0 || (highEndpoint == EndpointTypeRangeExclusive && *highRank == 0) {
			return nil, nil // Empty range
		}
	}
	if highRank != nil && lowRank != nil &&
		highEndpoint == EndpointTypeRangeExclusive &&
		lowEndpoint == EndpointTypeRangeExclusive &&
		*highRank == *lowRank {
		return nil, nil // Exclusively empty
	}

	if startFromBeginning && highRank == nil {
		result := TupleRangeAllOf(prefix)
		return &result, nil
	}

	rankedSet := newRankedSet(rankSubspace, m.rankedSetConfig)

	// Init if needed.
	needed, err := rankedSet.InitNeeded(m.tx.Snapshot())
	if err != nil {
		return nil, err
	}
	if needed {
		if err := rankedSet.Init(m.tx); err != nil {
			return nil, err
		}
	}

	// Prefetch sparse upper skip-list levels for the upcoming GetNth calls.
	rankedSet.PreloadForLookup(m.tx.Snapshot())

	// Convert low rank to score.
	var lowScore tuple.Tuple
	lowRankVal := int64(0)
	if !startFromBeginning {
		lowRankVal = *lowRank
	}
	lowScoreBytes, err := rankedSet.GetNth(m.tx, lowRankVal)
	if err != nil {
		return nil, err
	}
	if lowScoreBytes != nil {
		lowScore, err = tuplefast.Unpack(lowScoreBytes)
		if err != nil {
			return nil, fmt.Errorf("unpack low score: %w", err)
		}
	}
	if lowScore == nil {
		return nil, nil // Low rank past end.
	}

	// Convert high rank to score.
	var highScore tuple.Tuple
	if highRank != nil {
		highScoreBytes, err := rankedSet.GetNth(m.tx, *highRank)
		if err != nil {
			return nil, err
		}
		if highScoreBytes != nil {
			highScore, err = tuplefast.Unpack(highScoreBytes)
			if err != nil {
				return nil, fmt.Errorf("unpack high score: %w", err)
			}
		}
	}

	adjustedHighEndpoint := highEndpoint
	if highScore == nil {
		if prefix != nil {
			adjustedHighEndpoint = EndpointTypeRangeInclusive
		} else {
			adjustedHighEndpoint = EndpointTypeTreeEnd
		}
	}

	scoreRange := TupleRange{
		Low:          lowScore,
		High:         highScore,
		LowEndpoint:  lowEndpoint,
		HighEndpoint: adjustedHighEndpoint,
	}

	// Prepend group prefix to score range.
	if prefix != nil {
		scoreRange = scoreRange.Prepend(prefix)
	}

	return &scoreRange, nil
}

// getGroupingCount returns the number of grouping columns in the index expression.
func (m *rankIndexMaintainer) getGroupingCount() int {
	if g, ok := m.index.RootExpression.(*GroupingKeyExpression); ok {
		return g.GetGroupingCount()
	}
	return 0
}

// RankForScore returns the rank of a given score in the ranked set for the
// specified group. Returns nil if the score is not present and nullIfMissing is true.
func (m *rankIndexMaintainer) RankForScore(groupAndScore tuple.Tuple, nullIfMissing bool) (*int64, error) {
	groupPrefixSize := m.getGroupingCount()

	var rankSubspace subspace.Subspace
	var scoreTuple tuple.Tuple

	if groupPrefixSize > 0 && groupPrefixSize <= len(groupAndScore) {
		prefix := tuple.Tuple(groupAndScore[:groupPrefixSize])
		rankSubspace = m.secondarySubspace.Sub(prefix...)
		scoreTuple = tuple.Tuple(groupAndScore[groupPrefixSize:])
	} else {
		rankSubspace = m.secondarySubspace
		scoreTuple = groupAndScore
	}

	rankedSet := newRankedSet(rankSubspace, m.rankedSetConfig)
	rankedSet.PreloadForLookup(m.tx.Snapshot())
	return rankedSet.Rank(m.tx, scoreTuple.Pack(), nullIfMissing)
}

// ScoreForRank returns the score at the given rank in the ranked set for the
// specified group. Returns nil if rank is out of bounds.
func (m *rankIndexMaintainer) ScoreForRank(groupAndRank tuple.Tuple) (tuple.Tuple, error) {
	groupPrefixSize := m.getGroupingCount()

	var rankSubspace subspace.Subspace
	var rankValue any

	if groupPrefixSize > 0 && groupPrefixSize < len(groupAndRank) {
		prefix := tuple.Tuple(groupAndRank[:groupPrefixSize])
		rankSubspace = m.secondarySubspace.Sub(prefix...)
		rankValue = groupAndRank[groupPrefixSize]
	} else if len(groupAndRank) > 0 {
		rankSubspace = m.secondarySubspace
		rankValue = groupAndRank[0]
	} else {
		return nil, fmt.Errorf("rank index: empty group and rank tuple")
	}
	// Java's scoreForRank answers a null rank with null.
	rank, err := javaRank(rankValue)
	if err != nil || rank == nil {
		return nil, err
	}

	rankedSet := newRankedSet(rankSubspace, m.rankedSetConfig)
	rankedSet.PreloadForLookup(m.tx.Snapshot())
	scoreBytes, err := rankedSet.GetNth(m.tx, *rank)
	if err != nil {
		return nil, err
	}
	if scoreBytes == nil {
		return nil, nil
	}
	return tuplefast.Unpack(scoreBytes)
}

// extractRankValue extracts the rank value from a scan range tuple.
// The rank is at position groupPrefixSize (after the group prefix).
// Returns error if the tuple has unexpected extra elements.
// Matches Java's RankedSetIndexHelper.extractRank().
func extractRankValue(groupPrefixSize int, maybeTuple tuple.Tuple) (*int64, error) {
	if maybeTuple == nil {
		return nil, nil
	}
	if len(maybeTuple) == groupPrefixSize+1 {
		return javaRank(maybeTuple[groupPrefixSize])
	}
	if len(maybeTuple) <= groupPrefixSize {
		return nil, nil
	}
	return nil, fmt.Errorf("ranked set range bound is not correct size: groupPrefixSize=%d, tuple=%v", groupPrefixSize, maybeTuple)
}

// javaRank is Java's (Number) cast of a rank and its longValue(): nil stays
// nil, and a value that is not a number is a ClassCastError.
func javaRank(v any) (*int64, error) {
	if v == nil {
		return nil, nil
	}
	r, ok := javaNumberLongValue(v)
	if !ok {
		return nil, &ClassCastError{Message: fmt.Sprintf("class %s cannot be cast to class java.lang.Number", javaTupleValueClassName(v))}
	}
	return &r, nil
}
