// Portions derived from FoundationDB Record Layer (FDBRecordContext.java,
// FDBDatabase.java, FDBDatabaseRunner.java, FDBDatabaseFactory.java,
// and others),
// Copyright 2015-2018 Apple Inc. and the FoundationDB project authors
// Copyright 2015-2019 Apple Inc. and the FoundationDB project authors
// Copyright 2015-2021 Apple Inc. and the FoundationDB project authors
// Licensed under the Apache License, Version 2.0; translated to Go and modified.

package recordlayer

import (
	"bytes"
	"context"
	"errors"
	"fmt"
	"log/slog"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"fdb.dev/pkg/dst"
	"fdb.dev/pkg/fdbgo/fdb"
	"fdb.dev/pkg/fdbgo/fdb/tuple"
	"fdb.dev/pkg/internal/fdbclient"
)

// WeakReadSemantics configures relaxed read consistency for a transaction.
// When provided, the transaction may read at a slightly stale version,
// reducing GRV latency at the cost of freshness.
// Matches Java's FDBDatabase.WeakReadSemantics.
type WeakReadSemantics struct {
	// MinVersion is the minimum read version acceptable. If the cached read
	// version is >= MinVersion, it will be reused without a GRV round-trip.
	MinVersion int64

	// StalenessBoundMillis is the maximum staleness (in ms) of a cached read
	// version. If the cached version is older than this, a fresh GRV is fetched.
	StalenessBoundMillis int64

	// IsCausalReadRisky sets the FDB_TR_OPTION_CAUSAL_READ_RISKY flag.
	// This allows the transaction to read from any storage replica, not
	// just the one with the latest committed data.
	IsCausalReadRisky bool
}

// FDBDatabase provides access to the underlying FoundationDB database or tenant
// and manages transaction execution with retry logic.
// This is the Record Layer equivalent of Java's FDBDatabase.
//
// The transactor field can be either an fdb.Database or fdb.Tenant, both of which
// implement the fdb.Transactor interface. This allows transparent support for both
// regular database operations and tenant-isolated operations.
type FDBDatabase struct {
	transactor fdb.Transactor
	// Keep original db/tenant for CreateTransaction which isn't on Transactor interface
	db     fdb.Database
	tenant fdb.Tenant
	// isTenant is true for a tenant-backed database (NewFDBDatabaseFromTenant). The record layer
	// must NOT set READ_SYSTEM_KEYS on a tenant transaction: libfdb_c throws invalid_option there
	// (system-key access can't be tenant-scoped, NativeAPI.actor.cpp:7159-7171), and it is also
	// unnecessary — the only system key the record layer reads (\xff/metadataVersion) is exempt
	// from the system-key gate and read globally even on a tenant transaction.
	isTenant bool

	// resolverCache is the directory cache of committed resolver mappings
	// (Java's FDBDatabase.getDirectoryCache); reverseCacheEntry the long of
	// the reverse directory cache's directory, resolved once.
	resolverCacheOnce sync.Once
	resolverCache     *resolverCache
	reverseCacheMu    sync.Mutex
	reverseCacheEntry *int64

	// storeStateCache caches store state across transactions.
	// Default: PassThroughRecordStoreStateCache (no caching).
	// Matches Java's FDBDatabase.storeStateCache field.
	storeStateCache FDBRecordStoreStateCache

	// env is the DST Tier-0 environment (Clock + Randomness + Buggify) inherited by every
	// FDBRecordContext this database opens. Nil means production (wall clock, crypto/rand,
	// buggify off) — the nil-safe *dst.Env accessors handle that. A simulation sets a
	// seeded env via SetEnv so persisted timestamps/nonces are reproducible (RFC-199 Tier 0).
	env *dst.Env

	// timer is the StoreTimer inherited by every FDBRecordContext this database opens,
	// and therefore the aggregation point for record-layer instrumentation across all
	// transactions in the process. Nil (the default) means uninstrumented — the
	// nil-receiver-safe StoreTimer methods make that a single nil check per site, and it
	// matches Java, where FDBRecordContextConfig's timer defaults to null
	// (FDBRecordContextConfig.java:266).
	//
	// Sharing ONE timer instance across many contexts is Java's own aggregation model,
	// not a Go shortcut: FDBDatabaseRunner.setTimer installs a timer on the shared
	// context-config builder and every context the retry loop opens writes into that same
	// instance (FDBDatabaseRunner.java:105-119). Java's other model — a fresh timer per
	// transaction folded into a process-level registry (RecordLayerTransactionManager.java:62-70
	// with MetricRegistryStoreTimer) — needs a per-commit fold and a second registry type to
	// aggregate into; sharing the instance gets the same operator-visible totals with neither.
	// StoreTimer.Add ports the fold for callers who want the first model anyway.
	//
	// atomic.Pointer because SetTimer may be called on a database other goroutines are
	// already opening contexts against.
	timer atomic.Pointer[StoreTimer]

	// The attempt policy of Run and its variants (attempt_loop.go): Java's
	// FDBDatabaseFactory maxAttempts / initialDelayMillis / maxDelayMillis.
	// Zero means the default.
	maxAttempts  atomic.Int64
	initialDelay atomic.Int64
	maxDelay     atomic.Int64
	delaysSet    atomic.Bool

	attemptObserver atomic.Pointer[AttemptObserver]
}

// SetTimer installs the StoreTimer that every context this database opens will record
// into, replacing any previous one. Passing nil disables instrumentation.
//
// Matches Java's FDBDatabaseRunner.setTimer / FDBRecordContextConfig.Builder.setTimer
// (FDBDatabaseRunner.java:112-119, FDBRecordContextConfig.java:357-368): the timer is a
// caller-supplied object whose lifetime and scope the caller chooses, never something the
// database owns or creates for you. Contexts already open keep the timer they were built
// with — the read happens once at context construction, as in Java.
func (d *FDBDatabase) SetTimer(timer *StoreTimer) {
	d.timer.Store(timer)
}

// Timer returns the StoreTimer installed by SetTimer, or nil when the database is
// uninstrumented. Matches Java's FDBDatabaseRunner.getTimer (FDBDatabaseRunner.java:105-110).
func (d *FDBDatabase) Timer() *StoreTimer {
	if d == nil {
		return nil
	}
	return d.timer.Load()
}

// SetEnv installs the DST environment inherited by every context this database opens. A
// simulation driver calls this with dst.NewSim(seed) right after constructing the database
// (typically over a SimFDB backend); production leaves it unset. Returns d for chaining.
func (d *FDBDatabase) SetEnv(env *dst.Env) *FDBDatabase {
	d.env = env
	return d
}

// Env returns the database's DST environment, or nil (which the *dst.Env accessors treat
// as production). Nil-safe on the receiver, like FDBRecordContext.Env: an accessor whose whole
// contract is "nil means production" must not be the one call in the chain that panics.
func (d *FDBDatabase) Env() *dst.Env {
	if d == nil {
		return nil
	}
	return d.env
}

// FDBDatabaseFactory caches FDBDatabase instances by cluster file path.
// Thread-safe. Matches Java's FDBDatabaseFactory.getDatabase(clusterFile).
type FDBDatabaseFactory struct {
	mu        sync.Mutex
	databases map[string]*FDBDatabase

	// knobs are the client knobs set (SetKnob), knobOrder the order they were
	// first set, and inited whether the client has started (the first open).
	knobs     map[string]string
	knobOrder []string
	inited    bool

	// StoreStateCacheFactory creates a store state cache for each new database.
	// If nil, PassThroughStoreStateCache is used.
	StoreStateCacheFactory func() FDBRecordStoreStateCache
}

// NewFDBDatabaseFactory creates a factory for caching database instances.
func NewFDBDatabaseFactory() *FDBDatabaseFactory {
	return &FDBDatabaseFactory{
		databases: make(map[string]*FDBDatabase),
	}
}

// GetDatabase returns a cached FDBDatabase for the given cluster file path.
// Creates a new one on first call for each unique path.
// Matches Java's FDBDatabaseFactory.getDatabase(clusterFile).
func (f *FDBDatabaseFactory) GetDatabase(clusterFile string) (*FDBDatabase, error) {
	f.mu.Lock()
	defer f.mu.Unlock()

	if db, ok := f.databases[clusterFile]; ok {
		return db, nil
	}
	if err := f.startClientLocked(); err != nil {
		return nil, fmt.Errorf("open database %q: %w", clusterFile, err)
	}

	// Open through the build-tag-selectable seam (RFC-109): the default build is
	// the pure-Go client; -tags libfdbc swaps in Apple's libfdb_c, with no source
	// change here. NewFDBDatabaseWithBackend keeps the pure-Go concrete handle when
	// the backend IS pure-Go (so CreateTransaction/locality are unaffected in the
	// default build) and fail-fasts those direct paths only under libfdb_c.
	rawDB, err := fdbclient.Open(clusterFile)
	if err != nil {
		return nil, fmt.Errorf("open database %q: %w", clusterFile, err)
	}

	db := NewFDBDatabaseWithBackend(rawDB)
	if f.StoreStateCacheFactory != nil {
		db.SetStoreStateCache(f.StoreStateCacheFactory())
	}
	f.databases[clusterFile] = db
	return db, nil
}

// NewFDBDatabase creates a new FDBDatabase wrapping the core FDB database
func NewFDBDatabase(db fdb.Database) *FDBDatabase {
	// Record layer reads \xff/metadataVersion — set ReadSystemKeys as default
	// so ALL transactions (including test helpers that bypass Run()) get it.
	db.Options().SetReadSystemKeys()
	return &FDBDatabase{
		transactor:      db,
		db:              db,
		storeStateCache: PassThroughStoreStateCache(),
	}
}

// NewFDBDatabaseWithTransactor creates a new FDBDatabase with a custom Transactor.
// The transactor is used for Run()/RunWithVersionstamp() (transaction execution),
// while the db is used for CreateTransaction() (direct transaction creation).
// This enables wrapping the transactor for fault injection, tracing, or middleware.
func NewFDBDatabaseWithTransactor(transactor fdb.Transactor, db fdb.Database) *FDBDatabase {
	return &FDBDatabase{
		transactor:      transactor,
		db:              db,
		storeStateCache: PassThroughStoreStateCache(),
	}
}

// NewFDBDatabaseWithBackend creates an FDBDatabase driven by a build-selected fdb
// backend (RFC-109) — e.g. the libfdb_c escape hatch, opened via fdbclient.Open
// (which a build tag points at the pure-Go or libfdb_c client). The backend drives
// the Run / RunRead gold path (record save/load, query, index maintenance) through
// the Transactor interface.
//
// The concrete-db slot is left empty for a non-pure-Go backend. Standalone
// transactions go through CreateWritableTransaction and locality through
// LocalityGetBoundaryKeys — both delegate to the backend's own
// interface-returning methods, so explicit transactions, the FDBDatabaseRunner,
// AND online MUTUAL indexing all work on libfdb_c. The one remaining
// concrete-only path is the pure-Go-typed CreateTransaction (it returns the
// concrete fdb.Transaction a non-pure-Go backend cannot build), which stays
// pure-Go-only in v1 and fails fast with BackendCapabilityError (not a nil panic)
// — the same scope boundary the RFC draws around tenants.
func NewFDBDatabaseWithBackend(backend fdb.BackendDatabase) *FDBDatabase {
	d := &FDBDatabase{
		transactor:      backend,
		storeStateCache: PassThroughStoreStateCache(),
	}
	// If the selected backend is actually the pure-Go client, keep its concrete
	// handle so the direct CreateTransaction / FDBDatabaseRunner / locality paths
	// still work — only a non-pure-Go backend (libfdb_c) genuinely lacks them.
	// Without this, the pure-Go client via this constructor would needlessly cripple
	// those paths.
	if goDB, ok := backend.(fdb.Database); ok {
		// Match NewFDBDatabase: the record layer reads \xff/metadataVersion, so make
		// ReadSystemKeys the default on every transaction (including the direct
		// CreateTransaction path) — otherwise the pure-Go client via this constructor
		// would behave differently from NewFDBDatabase and fail those reads.
		goDB.Options().SetReadSystemKeys()
		d.db = goDB
	}
	return d
}

// NewFDBDatabaseFromTenant creates a new FDBDatabase wrapping an FDB tenant
// for tenant-isolated operations. All operations will be scoped to the tenant's keyspace.
func NewFDBDatabaseFromTenant(tenant fdb.Tenant) *FDBDatabase {
	return &FDBDatabase{
		transactor:      tenant,
		tenant:          tenant,
		isTenant:        true,
		storeStateCache: PassThroughStoreStateCache(),
	}
}

// SetStoreStateCache sets the cache used for store state across transactions.
// Matches Java's FDBDatabase.setStoreStateCache().
func (d *FDBDatabase) SetStoreStateCache(cache FDBRecordStoreStateCache) {
	d.storeStateCache = cache
}

// GetStoreStateCache returns the current store state cache.
// Matches Java's FDBDatabase.getStoreStateCache().
func (d *FDBDatabase) GetStoreStateCache() FDBRecordStoreStateCache {
	return d.storeStateCache
}

// applyReadSystemKeys grants the per-transaction READ_SYSTEM_KEYS the record layer uses to read
// \xff/metadataVersion. It is a NO-OP on a tenant-backed database: libfdb_c rejects READ_SYSTEM_KEYS
// on a tenant transaction (invalid_option, NativeAPI.actor.cpp:7159-7171 — system-key access can't
// be tenant-scoped), and it is unnecessary there because metadataVersion is exempt from the
// system-key gate and read globally even under a tenant.
func (d *FDBDatabase) applyReadSystemKeys(o fdb.TransactionOptions) {
	if !d.isTenant {
		o.SetReadSystemKeys()
	}
}

// Run executes fn in a transaction and commits it, retrying as Java's
// FDBDatabaseRunner does (FDBDatabaseRunnerImpl.RunRetriable): at most
// MaxAttempts attempts (default 10), each a fresh transaction, retried while
// some cause of the error is retriable, with Java's ExponentialDelay between
// attempts (attemptLoop). Before committing it runs the commit checks and
// flushes queued versionstamp mutations, as FDBRecordContext.commitAsync does;
// the post-commit hooks run once, after the attempt that committed.
func (d *FDBDatabase) Run(ctx context.Context, fn func(rtx *FDBRecordContext) (any, error)) (any, error) {
	result, _, err := d.runContexts(ctx, d.policy("run"), RouteAttempt, nil, false, fn)
	return result, err
}

// RunWithMaxAttempts is Run with its own attempt bound in place of the
// database's, as an FDBDatabaseRunner with setMaxAttempts runs. One attempt is
// how the relational layer runs a DDL statement: a conflict surfaces instead of
// re-executing the statement.
func (d *FDBDatabase) RunWithMaxAttempts(ctx context.Context, maxAttempts int, fn func(rtx *FDBRecordContext) (any, error)) (any, error) {
	policy := d.policy("run")
	if maxAttempts > 0 {
		policy.maxAttempts = maxAttempts
	}
	result, _, err := d.runContexts(ctx, policy, RouteAttempt, nil, false, fn)
	return result, err
}

// RunClientLoop runs fn through the transactor's own retry loop, which is
// unbounded on the pure-Go client and libfdb_c and capped at 100 retries on
// SimFDB. Only SPFresh's background lifecycles use it (spfreshRun): RFC-094
// keeps them on the client loop, and nothing else may.
func (d *FDBDatabase) RunClientLoop(ctx context.Context, fn func(rtx *FDBRecordContext) (any, error)) (any, error) {
	result, _, err := d.runContexts(ctx, attemptPolicy{owner: "spfresh.lifecycle", maxAttempts: 1}, RouteClientLoop, nil, false, fn)
	return result, err
}

// runContexts is Run and its variants. Each attempt is one transactor call
// whose body opens a route-owned record context; on RouteAttempt the backend's
// own retry limit is 0, so the backend makes exactly one attempt and the loop
// counts it. weak applies to the first execution only, as Java's
// TransactionalRunner clears weak-read semantics on a retry
// (TransactionalRunner.java:181-192), so a retry never reuses an old read
// version. versionstamp asks for the committed versionstamp.
func (d *FDBDatabase) runContexts(ctx context.Context, policy attemptPolicy, route AttemptRoute, weak *WeakReadSemantics, versionstamp bool, fn func(rtx *FDBRecordContext) (any, error)) (any, []byte, error) {
	var (
		lastCtx     *FDBRecordContext
		commitStart time.Time
		vsFuture    fdb.FutureKey
		body        bodyErrorRecorder
	)
	execute := func(call AttemptCall) (any, error) {
		result, err := d.transactAttempt(ctx, call, func(tx fdb.WritableTransaction) (any, error) {
			// Each execution starts clean: a previous execution's context,
			// commit timing and versionstamp future are stale.
			body.start()
			lastCtx, commitStart, vsFuture = nil, time.Time{}, nil
			if route == RouteAttempt {
				if err := tx.Options().SetRetryLimit(0); err != nil {
					return nil, body.record(err)
				}
			}
			d.applyReadSystemKeys(tx.Options())
			if weak != nil && weak.IsCausalReadRisky && call.Execution == 0 {
				tx.Options().SetCausalReadRisky()
			}
			recordCtx := &FDBRecordContext{
				createTime:    d.env.Now(),
				transactionID: nextTransactionID.Add(1),
				tx:            tx,
				ctx:           ctx,
				env:           d.env,
				database:      d,
				routeOwned:    true,
			}
			recordCtx.SetTimer(d.Timer())
			lastCtx = recordCtx

			result, err := fn(recordCtx)
			if err != nil {
				return nil, body.record(err)
			}
			result, err = d.precommit(recordCtx, result, &commitStart)
			if err != nil {
				return nil, body.record(err)
			}
			if versionstamp && recordCtx.HasVersionMutations() {
				vsFuture = tx.GetVersionstamp()
			}
			return result, nil
		})
		return result, body.resolve(err)
	}

	var result any
	var err error
	if route == RouteClientLoop {
		result, err = execute(AttemptCall{Route: route, Owner: policy.owner, CallID: nextAttemptCallID.Add(1)})
	} else {
		result, err = attemptLoop(ctx, d.env, d.observer(), policy, route, execute)
	}
	if err != nil {
		return nil, nil, err
	}
	recordCommitSince(lastCtx, commitStart)
	// Post-commit callbacks run once, after the attempt that committed.
	if lastCtx != nil {
		lastCtx.runPostCommits()
	}
	if vsFuture != nil {
		vs, err := vsFuture.Get()
		if err != nil {
			return result, nil, fmt.Errorf("failed to get versionstamp: %w", err)
		}
		return result, []byte(vs), nil
	}
	return result, nil, nil
}

// precommit is the part of FDBRecordContext.commitAsync that runs before the
// transactor commits: the commit checks and the versionstamp flush.
func (d *FDBDatabase) precommit(recordCtx *FDBRecordContext, result any, commitStart *time.Time) (any, error) {
	// EventCommit spans the pre-commit checks plus the commit itself, which is
	// the interval Java measures: startTimeNanos is taken at the first line of
	// commitAsync, before runCommitChecks, and the event is recorded when the
	// commit future completes (FDBRecordContext.java:478, :513-533; the
	// FDBStoreTimer javadoc at :81-86 says so explicitly). Post-commit hooks
	// are outside the span in Java and are outside it here.
	//
	// It has to be recorded out here rather than in FDBRecordContext.Commit
	// because on this path the commit belongs to the transactor's retry loop —
	// nothing ever calls Commit, which is why the whole autocommit SQL path
	// reported zero commits while committing on every statement.
	*commitStart = time.Now()
	if err := recordCtx.runCommitChecks(); err != nil {
		return nil, err
	}
	// Flush queued version mutations before the transactor commits.
	recordCtx.flushVersionMutations()
	return result, nil
}

// recordCommitSince records EventCommit for a transaction that committed inside
// the transactor's retry loop. On a retry, commitStart is overwritten by each
// attempt, so the recorded span is the successful attempt's — the same one Java
// records, since Java's per-attempt commitAsync only reaches its success arm on
// the attempt that commits.
//
// Zero commitStart means the closure returned before reaching the commit (fn
// failed), so there was no commit to time.
//
// Java's other two commit outcomes are NOT ported here, deliberately.
// COMMIT_READ_ONLY needs the committed version to tell a write-free transaction
// apart (FDBRecordContext.java:492, :524) and COMMIT_FAILURE needs the commit's
// own exception (:517); on this path the transactor owns the commit and surfaces
// neither. Recording a plain COMMIT for those cases would be worse than
// recording nothing — it would inflate the commit count with transactions that
// did not commit.
func recordCommitSince(rc *FDBRecordContext, commitStart time.Time) {
	if rc == nil || commitStart.IsZero() {
		return
	}
	rc.Timer().RecordSince(EventCommit, commitStart)
}

// runTransactCtx threads ctx into the transactor's retry loop + backoff + reads when
// the transactor supports it (Database/Tenant via fdb.CtxTransactor), else falls back
// to the ctx-less Transact (RFC-090). The dispatched commit + commit_unknown barrier
// run detached regardless, so ctx never cancels an in-flight commit.
func runTransactCtx(t fdb.Transactor, ctx context.Context, fn func(fdb.WritableTransaction) (any, error)) (any, error) {
	if ct, ok := t.(fdb.CtxTransactor); ok {
		return ct.TransactCtx(ctx, fn)
	}
	return t.Transact(fn)
}

// runReadTransactCtx is the read-side analog of runTransactCtx.
func runReadTransactCtx(t fdb.ReadTransactor, ctx context.Context, fn func(fdb.ReadTransaction) (any, error)) (any, error) {
	if ct, ok := t.(fdb.CtxReadTransactor); ok {
		return ct.ReadTransactCtx(ctx, fn)
	}
	return t.ReadTransact(fn)
}

// RunRead executes a read-only function with automatic retry but no commit.
// Uses ReadTransact under the hood — no write conflict ranges, no commit
// round-trip. Suitable for statistics, metadata reads, or any read-only
// operation where a full read-write transaction would waste a commit.
//
// ctx bounds the read-retry loop + backoff when the transactor supports it
// (fdb.CtxReadTransactor); the entry check also returns early if already cancelled.
func (d *FDBDatabase) RunRead(ctx context.Context, fn func(rtx fdb.ReadTransaction) (any, error)) (any, error) {
	var body bodyErrorRecorder
	return attemptLoop(ctx, d.env, d.observer(), d.policy("run.read"), RouteAttempt, func(call AttemptCall) (any, error) {
		result, err := d.readTransactAttempt(ctx, call, func(rtx fdb.ReadTransaction) (any, error) {
			body.start()
			if err := rtx.Options().SetRetryLimit(0); err != nil {
				return nil, body.record(err)
			}
			d.applyReadSystemKeys(rtx.Options())
			result, err := fn(rtx)
			if err != nil {
				return nil, body.record(err)
			}
			return result, nil
		})
		return result, body.resolve(err)
	})
}

// RunWithWeakReads is like Run but applies weak read semantics to the transaction.
// If IsCausalReadRisky is set, the transaction reads from any replica.
// Matches Java's FDBDatabase.openContext(config, timer, weakReadSemantics, ...).
func (d *FDBDatabase) RunWithWeakReads(ctx context.Context, weak WeakReadSemantics, fn func(rtx *FDBRecordContext) (any, error)) (any, error) {
	result, _, err := d.runContexts(ctx, d.policy("run.weak"), RouteAttempt, &weak, false, fn)
	return result, err
}

// RunWithVersionstamp is like Run but also returns the committed versionstamp.
// Use this when you need the versionstamp after commit (e.g. for record versioning).
// Returns (result, versionstamp, error). Versionstamp is nil for read-only transactions.
func (d *FDBDatabase) RunWithVersionstamp(ctx context.Context, fn func(rtx *FDBRecordContext) (any, error)) (any, []byte, error) {
	return d.runContexts(ctx, d.policy("run.versionstamp"), RouteAttempt, nil, true, fn)
}

// BackendCapabilityError is returned when an operation is not supported on the
// configured fdb backend. The libfdb_c escape hatch (RFC-109) drives the
// Run / RunRead gold path, standalone transactions (CreateWritableTransaction —
// used by the FDBDatabaseRunner and SQL BeginTx), and LocalityGetBoundaryKeys
// (online MUTUAL indexing) all through backend interfaces, so those work on
// libfdb_c. Only the pure-Go-typed CreateTransaction (which returns the concrete
// fdb.Transaction) is pure-Go-only in v1; it — and any operation a custom
// transactor genuinely can't provide — fail fast with this error.
type BackendCapabilityError struct {
	Op string // the unavailable operation, e.g. "CreateTransaction"
}

func (e *BackendCapabilityError) Error() string {
	return fmt.Sprintf("recordlayer: %s is not supported on this fdb backend "+
		"(pure-Go-only; the libfdb_c escape hatch covers the Run/RunRead path)", e.Op)
}

// CreateTransaction creates a new transaction without retry logic.
// This is primarily used for testing scenarios where manual transaction control is needed,
// such as testing isolation levels with concurrent transactions.
// For tenant-isolated databases, the transaction will be scoped to the tenant's keyspace.
func (d *FDBDatabase) CreateTransaction() (fdb.Transaction, error) {
	if d.tenant != (fdb.Tenant{}) {
		return d.tenant.CreateTransaction()
	}
	if !d.db.IsValid() {
		return fdb.Transaction{}, &BackendCapabilityError{Op: "CreateTransaction"}
	}
	return d.db.CreateTransaction()
}

// CreateWritableTransaction creates a standalone, non-retry transaction as the
// backend-agnostic WritableTransaction interface. Unlike CreateTransaction (which
// returns the concrete pure-Go fdb.Transaction and is therefore pure-Go-only), this
// works on ANY backend — including the libfdb_c escape hatch — so the SQL engine's
// database/sql explicit transactions (BeginTx / COMMIT, which span multiple driver
// calls and so can't use the closure-based Run gold path) are not silently
// pure-Go-only. Prefer this over CreateTransaction wherever a concrete pure-Go
// handle isn't specifically required.
func (d *FDBDatabase) CreateWritableTransaction() (fdb.WritableTransaction, error) {
	if d.tenant != (fdb.Tenant{}) {
		return d.tenant.CreateTransaction()
	}
	// Pure-Go concrete handle present (default open, chaos transactor, or a pure-Go
	// fdbclient backend): use it directly — identical to CreateTransaction.
	if d.db.IsValid() {
		return d.db.CreateTransaction()
	}
	// No concrete handle ⇒ a non-pure-Go backend (libfdb_c). Delegate to the
	// backend's own standalone-transaction creator.
	if be, ok := d.transactor.(fdb.BackendDatabase); ok {
		return be.CreateWritableTransaction()
	}
	return nil, &BackendCapabilityError{Op: "CreateWritableTransaction"}
}

// LocalityGetBoundaryKeys returns the FDB shard boundary keys within r, working on
// both the pure-Go and libfdb_c backends (the online MUTUAL indexer uses them to
// partition the keyspace into fragments for concurrent building). It's a read of
// the \xff/keyServers system range — byte-identical on the pure-Go and libfdb_c
// clients against the same cluster — so mutual indexing parallelizes on either
// backend. A handle that can't provide it (a tenant-backed FDBDatabase, or a
// custom transactor) returns BackendCapabilityError; callers that want graceful
// degradation (1 fragment) treat an error as "no boundaries".
//
// Unlike CreateWritableTransaction there is no tenant branch: shard boundaries
// are a cluster-wide property of the keyServers map, independent of any tenant.
func (d *FDBDatabase) LocalityGetBoundaryKeys(r fdb.ExactRange, limit int, readVersion int64) ([]fdb.Key, error) {
	if d.db.IsValid() {
		return d.db.LocalityGetBoundaryKeys(r, limit, readVersion)
	}
	if be, ok := d.transactor.(fdb.BackendDatabase); ok {
		return be.LocalityGetBoundaryKeys(r, limit, readVersion)
	}
	return nil, &BackendCapabilityError{Op: "LocalityGetBoundaryKeys"}
}

// TransactionPriority controls the priority of FDB transactions.
// Matches Java's FDBTransactionPriority.
type TransactionPriority int

const (
	// PriorityDefault is the default transaction priority.
	PriorityDefault TransactionPriority = iota
	// PriorityBatch is a lower priority for background/batch operations.
	PriorityBatch
	// PrioritySystemImmediate is the highest priority, bypasses throttling.
	// Use with extreme care — only for system-level operations.
	PrioritySystemImmediate
)

// CommitCheckFunc is a pre-commit check that runs before the transaction commits.
// If it returns an error, the commit is aborted.
// Matches Java's CommitCheckAsync interface.
type CommitCheckFunc func() error

// PostCommitFunc is a callback that runs after a successful commit.
// Matches Java's PostCommit interface.
type PostCommitFunc func()

// VersionMutationType represents the type of versionstamp mutation.
// Matches Java's MutationType used in FDBRecordContext.addVersionMutation().
type VersionMutationType int

const (
	// MutationTypeSetVersionstampedValue queues a SET_VERSIONSTAMPED_VALUE mutation.
	MutationTypeSetVersionstampedValue VersionMutationType = iota
	// MutationTypeSetVersionstampedKey queues a SET_VERSIONSTAMPED_KEY mutation.
	MutationTypeSetVersionstampedKey
)

// versionMutation holds a queued versionstamp mutation with its type and value.
type versionMutation struct {
	mutationType VersionMutationType
	value        []byte
}

// commitCheckRegistration keeps a canceled check distinguishable from a new
// registration with the same name, including during a pre-commit snapshot.
type commitCheckRegistration struct {
	check  CommitCheckFunc
	active bool // protected by FDBRecordContext.commitMu
}

// nextTransactionID generates unique IDs for FDBRecordContext instances.
var nextTransactionID atomic.Int64

// FDBRecordContext represents a transactional context for record operations.
// It wraps an FDB transaction and provides additional record layer functionality.
// Goroutine-safe: all mutable fields are protected by atomics, mutexes, or the
// lockRegistry. Multiple goroutines may safely operate on the same context
// within a single FDB transaction (matching Java's CompletableFuture model).
// Matches Java's FDBRecordContext.
type FDBRecordContext struct {
	tx            fdb.WritableTransaction
	ctx           context.Context
	transactionID int64 // unique ID for logging/tracing
	createTime    time.Time

	// routeOwned marks a context a transaction route (Run and its variants,
	// the runner's RunWithRetry) handed its body: the route commits it, and
	// the body's own commit is refused before anything commits.
	routeOwned bool
	// deactivated is set by the first commit, whatever its outcome (Java's
	// closeTransaction(false) on both arms of commitAsync); a later commit is
	// refused as Java's ensureActive refuses it.
	deactivated atomic.Bool

	// database is the FDBDatabase that opened this context (Java's
	// FDBRecordContext.getDatabase); nil for a context over an external
	// transaction built by NewFDBRecordContext.
	database *FDBDatabase

	// configure is reapplied to child transactions (Java's newRunner).
	configure TransactionConfigurer

	// env is the DST Tier-0 environment inherited from the FDBDatabase (Clock + Randomness +
	// Buggify). Nil means production; read it through Env() which is nil-safe. Persisted-byte
	// sites (store header LastUpdateTime, lock-state timestamp, heartbeats, nonces) route
	// their time/randomness through here so a simulation run is byte-reproducible.
	env *dst.Env

	// Client-side transaction size thresholds. Zero = disabled.
	txSizeWarnBytes  int64
	txSizeErrorBytes int64
	txSizeWarned     atomic.Bool // only warn once per transaction

	// Version management — matches Java's FDBRecordContext.
	// Java uses AtomicInteger + ConcurrentSkipListMap.
	// Go uses atomic.Int32 + mutex-protected maps.
	localVersion      atomic.Int32               // per-transaction local version counter
	versionMu         sync.Mutex                 // protects localVersionCache + versionMutations
	localVersionCache map[string]int             // key (string) → local version (int)
	versionMutations  map[string]versionMutation // key (string) → mutation (type + value)

	// Commit hooks — matches Java's CommitCheckAsync / PostCommit.
	// Java uses synchronized blocks on all access.
	commitMu          sync.Mutex
	commitChecks      []*commitCheckRegistration
	namedCommitChecks map[string]*commitCheckRegistration
	postCommits       []PostCommitFunc

	// Diagnostic: tracked read conflict ranges for debugging
	conflictMu     sync.Mutex
	conflictRanges []fdb.KeyRange

	// Store state cache invalidation tracking — matches Java's FDBRecordContext.
	// Java leaves these unprotected (benign single-word writes).
	// Go uses atomics for race-detector cleanliness.
	dirtyStoreState           atomic.Bool // set when any store header or index state is modified
	dirtyMetaDataVersionStamp atomic.Bool // set when SetMetaDataVersionStamp() is called

	// Per-subspace read-write locks for tree-structured indexes (HNSW, R-tree).
	// Matches Java's LockRegistry on FDBRecordContext.
	locks lockRegistry

	// Instrumentation timer — matches Java's FDBRecordContext.timer field.
	// Set once during construction, nil means no instrumentation.
	// Atomic for race-detector cleanliness (concurrent reads from goroutines).
	timer atomic.Pointer[StoreTimer]

	// Session storage — matches Java's FDBRecordContext session
	// (getSession/putSessionIfAbsent): transaction-scoped values shared by
	// index maintainers across store instances opened in the same context.
	// SPFresh keeps its tx-local routing cache here so a same-transaction
	// write-then-search pairs up even when the statements open separate
	// stores.
	// Keys are strings or typed ContextSessionKey names (contextSessionKeyID),
	// which never equal a string key, as Java's ContextSessionKey never equals a
	// String.
	sessionMu sync.Mutex
	session   map[any]any

	pendingWriteQueueOptions atomic.Pointer[PendingWriteQueueOptions]

	indexStateMu    sync.Mutex
	indexStateViews map[string]*transactionIndexStateView
}

// Env returns the DST environment for this context (Clock + Randomness + Buggify),
// inherited from the FDBDatabase. Never nil in the sense that matters: the returned *dst.Env
// may be nil, and the *dst.Env accessors (Now/Read/Fault) treat nil as production. Use this
// at every persisted-byte site instead of time.Now / crypto.rand so a simulation run is
// byte-reproducible.
func (rc *FDBRecordContext) Env() *dst.Env {
	if rc == nil {
		return nil
	}
	return rc.env
}

// Session returns the transaction-scoped value stored under key, or nil.
// Matches Java's FDBRecordContext.getSession.
func (rc *FDBRecordContext) Session(key string) any {
	rc.sessionMu.Lock()
	defer rc.sessionMu.Unlock()
	return rc.session[key]
}

// PutSession stores a transaction-scoped value under key. Matches Java's
// FDBRecordContext session storage; values die with the context.
func (rc *FDBRecordContext) PutSession(key string, value any) {
	rc.sessionMu.Lock()
	defer rc.sessionMu.Unlock()
	if rc.session == nil {
		rc.session = make(map[any]any)
	}
	rc.session[key] = value
}

// NewFDBRecordContext wraps an externally-created FDB transaction — the path SQL's explicit
// BeginTx→COMMIT takes, plus direct-transaction-control tests.
//
// env is REQUIRED rather than defaulted, and that is the point. This is the sixth construction
// site of an FDBRecordContext; the other five (Run/RunAsync/ReadOnly in this file and the two
// in runner.go) all thread d.env, and this one silently did not. The consequence was that every
// explicit transaction ran with env==nil — production seams, wall clock, crypto/rand — even
// under a fully seeded simulation environment. That is precisely the path an explicit-COMMIT
// semantics RFC needs to replay, so it was the one path the seam did not cover. A default here
// would reintroduce the same silence; passing nil is allowed but has to be written down.
//
// Callers holding an *FDBDatabase should NOT call this — call db.NewRecordContext(tx),
// which threads every piece of per-database state at once. Enumerating the fields at each
// call site is what let env go unthreaded here in the first place, and a second such field
// (the StoreTimer) would have repeated it exactly.
func NewFDBRecordContext(tx fdb.WritableTransaction, env *dst.Env) *FDBRecordContext {
	return &FDBRecordContext{
		createTime: env.Now(),
		tx:         tx,
		ctx:        context.Background(),
		env:        env,
	}
}

// NewRecordContext wraps an externally-created FDB transaction in a context that inherits
// everything this database gives the contexts it opens itself: the DST environment and the
// StoreTimer. It is the form every caller holding an *FDBDatabase should use; one with a
// context (SQL's explicit BeginTx→COMMIT path) uses NewRecordContextIn.
//
// The point is that per-database state is threaded in ONE place. NewFDBRecordContext takes
// the fields one by one, which is why env was silently dropped on the explicit-transaction
// path until someone noticed; adding the timer as a second such parameter would have set up
// the identical failure for instrumentation, where the symptom is even quieter (a metric
// that reads zero looks exactly like a workload that did nothing).
func (d *FDBDatabase) NewRecordContext(tx fdb.WritableTransaction) *FDBRecordContext {
	return d.NewRecordContextIn(context.Background(), tx)
}

// NewRecordContextIn is NewRecordContext with ctx as the context's Context(),
// which bounds the reads and child transactions that take it from there.
func (d *FDBDatabase) NewRecordContextIn(ctx context.Context, tx fdb.WritableTransaction) *FDBRecordContext {
	rc := NewFDBRecordContext(tx, d.Env())
	rc.ctx = ctx
	rc.SetTimer(d.Timer())
	rc.database = d
	return rc
}

// TransactionConfigurer is the opener's part of Java's FDBRecordContextConfig.
type TransactionConfigurer func(fdb.TransactionOptions) error

// Configure applies f and keeps it for child transactions, which Java's
// newRunner opens with the parent context's config.
func (rc *FDBRecordContext) Configure(f TransactionConfigurer) error {
	if f == nil {
		return nil
	}
	if err := f(rc.tx.Options()); err != nil {
		return err
	}
	rc.configure = f
	return nil
}

// runChild is parentContext.newRunner().run: its own commit, this context's config.
func (rc *FDBRecordContext) runChild(ctx context.Context, fn func(*FDBRecordContext) (any, error)) (any, error) {
	return rc.database.Run(ctx, func(child *FDBRecordContext) (any, error) {
		if err := child.Configure(rc.configure); err != nil {
			return nil, err
		}
		return fn(child)
	})
}

// GetDatabase is the database that opened this context, Java's
// FDBRecordContext.getDatabase; nil for a context NewFDBRecordContext built
// over an external transaction.
func (rc *FDBRecordContext) GetDatabase() *FDBDatabase {
	return rc.database
}

// Transaction returns the underlying FDB transaction
func (rc *FDBRecordContext) Transaction() fdb.WritableTransaction {
	return rc.tx
}

// ReadTransaction returns the transaction a READ should go through for the
// given isolation: the snapshot view (no read conflict ranges) when snapshot
// is true, the plain transaction (conflict-tracking) otherwise.
//
// This is the ONE place the snapshot/serializable choice is made, so that
// "serializable" is a property of the mechanism rather than of each leaf
// remembering to ask. Java has exactly this method —
// FDBRecordContext.readTransaction(boolean) (FDBRecordContext.java:660-666) —
// and every Java leaf resolves through it with the same expression:
// context.readTransaction(scanProperties.getExecuteProperties()
// .getIsolationLevel().isSnapshot()) (KeyValueCursorBase.java:358,
// VectorIndexMaintainer.java:201-202, TextIndexMaintainer.java:542,
// RankIndexMaintainer.java:292).
//
// A leaf that calls Transaction().Snapshot() directly instead is not making a
// local choice — it is silently overriding the caller's isolation, which reads
// as isolated and commits as non-serializable.
func (rc *FDBRecordContext) ReadTransaction(snapshot bool) fdb.ReadTransaction {
	return readTransactionFor(rc.tx, snapshot)
}

// readTransactionFor is the single implementation behind every
// snapshot-vs-serializable choice in the package. It is a pure function of the
// transaction and the flag — which is exactly what Java's
// FDBRecordContext.readTransaction is (`snapshot ? ensureActive().snapshot() :
// ensureActive()`), so siting it here rather than only on the context lets an
// index maintainer resolve isolation from the transaction it already holds
// without needing a context reference it may not have.
func readTransactionFor(tx fdb.WritableTransaction, snapshot bool) fdb.ReadTransaction {
	if snapshot {
		return tx.Snapshot()
	}
	return tx
}

// TransactionID returns a unique ID for this record context.
// Useful for logging and tracing. Matches Java's FDBRecordContext transaction ID.
func (rc *FDBRecordContext) TransactionID() int64 {
	return rc.transactionID
}

// Context returns the Go context
func (rc *FDBRecordContext) Context() context.Context {
	return rc.ctx
}

// GetApproximateTransactionSize returns the approximate size in bytes of the
// transaction's mutations so far. Useful for monitoring proximity to FDB's
// 10MB transaction size limit.
// Matches Java's FDBRecordContext.getApproximateTransactionSize().
func (rc *FDBRecordContext) GetApproximateTransactionSize() (int64, error) {
	return rc.tx.GetApproximateSize().Get()
}

// CheckTransactionSize returns TransactionSizeExceededError past the error threshold; past the
// warning threshold it logs and counts CountTransactionSizeWarning once per transaction.
func (rc *FDBRecordContext) CheckTransactionSize() error {
	if rc.txSizeWarnBytes == 0 && rc.txSizeErrorBytes == 0 {
		return nil
	}
	size, err := rc.GetApproximateTransactionSize()
	if err != nil {
		return err
	}
	if rc.txSizeErrorBytes > 0 && size >= rc.txSizeErrorBytes {
		return &TransactionSizeExceededError{CurrentBytes: size, LimitBytes: rc.txSizeErrorBytes}
	}
	if rc.txSizeWarnBytes > 0 && size >= rc.txSizeWarnBytes && rc.txSizeWarned.CompareAndSwap(false, true) {
		// A warning, not an error: the write that crossed the threshold succeeded.
		rc.Timer().Increment(CountTransactionSizeWarning)
		ctx := rc.ctx
		if ctx == nil {
			ctx = context.Background()
		}
		slog.Default().LogAttrs(ctx, slog.LevelWarn, "transaction size exceeds warning threshold",
			slog.Int64("current_bytes", size), slog.Int64("limit_bytes", rc.txSizeWarnBytes))
	}
	return nil
}

// TransactionSizeExceededError is returned when the approximate transaction
// size exceeds the configured error threshold. Callers should commit the
// current transaction and start a new one.
type TransactionSizeExceededError struct {
	CurrentBytes int64
	LimitBytes   int64
}

func (e *TransactionSizeExceededError) Error() string {
	return fmt.Sprintf("transaction size %d bytes exceeds limit %d bytes", e.CurrentBytes, e.LimitBytes)
}

// Commit runs pre-commit checks, flushes pending version mutations, commits the
// transaction, and runs post-commit callbacks. All explicit commit APIs share
// this lifecycle, matching Java's FDBRecordContext.commitAsync().
func (rc *FDBRecordContext) Commit() error {
	_, err := rc.CommitWithVersionstamp()
	return err
}

// CommitWithHooks is an alias for Commit; checks and hooks always run.
func (rc *FDBRecordContext) CommitWithHooks() error {
	return rc.Commit()
}

// Cancel cancels the transaction
func (rc *FDBRecordContext) Cancel() {
	rc.tx.Cancel()
}

// ClaimLocalVersion atomically claims the next local version number.
// Goroutine-safe via atomic.Int32 (matches Java's AtomicInteger.getAndIncrement()).
func (rc *FDBRecordContext) ClaimLocalVersion() int {
	return int(rc.localVersion.Add(1) - 1) // returns 0, 1, 2, ...
}

// AddToLocalVersionCache caches a local version for a version key within this transaction.
// Goroutine-safe via versionMu.
// Matches Java's FDBRecordContext.addToLocalVersionCache().
func (rc *FDBRecordContext) AddToLocalVersionCache(versionKey []byte, localVersion int) {
	rc.versionMu.Lock()
	defer rc.versionMu.Unlock()
	if rc.localVersionCache == nil {
		rc.localVersionCache = make(map[string]int)
	}
	rc.localVersionCache[string(versionKey)] = localVersion
}

// GetLocalVersion retrieves a cached local version for the given key.
// Returns (localVersion, true) if found, (0, false) otherwise.
// Goroutine-safe via versionMu.
func (rc *FDBRecordContext) GetLocalVersion(versionKey []byte) (int, bool) {
	rc.versionMu.Lock()
	defer rc.versionMu.Unlock()
	v, ok := rc.localVersionCache[string(versionKey)]
	return v, ok
}

// RemoveLocalVersion removes a cached local version entry.
// Goroutine-safe via versionMu.
func (rc *FDBRecordContext) RemoveLocalVersion(versionKey []byte) {
	rc.versionMu.Lock()
	defer rc.versionMu.Unlock()
	delete(rc.localVersionCache, string(versionKey))
}

// AddVersionMutation queues a versionstamp mutation to be applied at commit.
// mutationType selects SET_VERSIONSTAMPED_KEY or SET_VERSIONSTAMPED_VALUE.
// The key or value (depending on type) must include the versionstamp placeholder bytes.
// Goroutine-safe via versionMu.
// Returns the previous value for this key, or nil if absent, matching Java's
// FDBRecordContext.addVersionMutation(MutationType, key, value).
func (rc *FDBRecordContext) AddVersionMutation(mutationType VersionMutationType, versionKey []byte, value []byte) []byte {
	rc.versionMu.Lock()
	defer rc.versionMu.Unlock()
	if rc.versionMutations == nil {
		rc.versionMutations = make(map[string]versionMutation)
	}
	previous, existed := rc.versionMutations[string(versionKey)]
	if existed && previous.value == nil {
		previous.value = []byte{}
	}
	rc.versionMutations[string(versionKey)] = versionMutation{
		mutationType: mutationType,
		value:        value,
	}
	return previous.value
}

// UpdateVersionMutation queues or updates a versionstamp mutation with a merge function.
// If a mutation for the same key already exists, the merge function decides which value to keep.
// Goroutine-safe via versionMu.
// Matches Java's FDBRecordContext.updateVersionMutation(MutationType, key, value, BiFunction).
func (rc *FDBRecordContext) UpdateVersionMutation(mutationType VersionMutationType, versionKey []byte, value []byte, merge func(oldValue, newValue []byte) []byte) {
	rc.versionMu.Lock()
	defer rc.versionMu.Unlock()
	if rc.versionMutations == nil {
		rc.versionMutations = make(map[string]versionMutation)
	}
	key := string(versionKey)
	if existing, ok := rc.versionMutations[key]; ok && merge != nil {
		merged := merge(existing.value, value)
		rc.versionMutations[key] = versionMutation{
			mutationType: mutationType,
			value:        merged,
		}
	} else {
		rc.versionMutations[key] = versionMutation{
			mutationType: mutationType,
			value:        value,
		}
	}
}

// RemoveVersionMutation removes a queued version mutation.
// Goroutine-safe via versionMu.
func (rc *FDBRecordContext) RemoveVersionMutation(versionKey []byte) {
	rc.versionMu.Lock()
	defer rc.versionMu.Unlock()
	delete(rc.versionMutations, string(versionKey))
}

// RemoveVersionMutationsInRange removes all queued version mutations whose key
// falls in [begin, end). Goroutine-safe via versionMu.
// Matches Java's FDBRecordContext.removeVersionMutationRange().
func (rc *FDBRecordContext) RemoveVersionMutationsInRange(begin, end fdb.Key) {
	rc.versionMu.Lock()
	defer rc.versionMu.Unlock()
	for k := range rc.versionMutations {
		kb := []byte(k)
		if bytes.Compare(kb, begin) >= 0 && bytes.Compare(kb, end) < 0 {
			delete(rc.versionMutations, k)
		}
	}
}

// HasVersionMutationsInRange checks surviving buffered mutations in [begin, end).
// It shares the registry and mutex used by context-aware clears.
func (rc *FDBRecordContext) HasVersionMutationsInRange(begin, end fdb.Key) bool {
	rc.versionMu.Lock()
	defer rc.versionMu.Unlock()
	for key := range rc.versionMutations {
		if bytes.Compare([]byte(key), begin) >= 0 && bytes.Compare([]byte(key), end) < 0 {
			return true
		}
	}
	return false
}

// RemoveLocalVersionsInRange removes all cached local versions whose key
// falls in [begin, end). Goroutine-safe via versionMu.
// Matches Java's FDBRecordContext.removeLocalVersionRange().
func (rc *FDBRecordContext) RemoveLocalVersionsInRange(begin, end fdb.Key) {
	rc.versionMu.Lock()
	defer rc.versionMu.Unlock()
	for k := range rc.localVersionCache {
		kb := []byte(k)
		if bytes.Compare(kb, begin) >= 0 && bytes.Compare(kb, end) < 0 {
			delete(rc.localVersionCache, k)
		}
	}
}

// ClearRange clears transactional data and pending version state together, so
// flushing version mutations at commit cannot restore keys inside the range.
// Matches Java's FDBRecordContext.clear(Range).
func (rc *FDBRecordContext) ClearRange(keyRange fdb.ExactRange) {
	rc.clearRange(keyRange, true)
}

// clearRange permits store-aware callers to supply an already-applied metadata
// invalidation policy, while preserving state projections and version cleanup.
func (rc *FDBRecordContext) clearRange(keyRange fdb.ExactRange, invalidateState bool) {
	begin, end := keyRange.FDBRangeKeys()
	rc.clearRangeWithIndexStateViews(keyRange, invalidateState)
	rc.RemoveVersionMutationsInRange(begin.FDBKey(), end.FDBKey())
	rc.RemoveLocalVersionsInRange(begin.FDBKey(), end.FDBKey())
}

// flushVersionMutations applies all queued versionstamp mutations
// to the underlying FDB transaction. Called before commit.
// Dispatches to SetVersionstampedKey or SetVersionstampedValue based on mutation type.
// Goroutine-safe via versionMu (though typically called after all goroutines are done).
func (rc *FDBRecordContext) flushVersionMutations() {
	rc.versionMu.Lock()
	defer rc.versionMu.Unlock()
	for key, mut := range rc.versionMutations {
		switch mut.mutationType {
		case MutationTypeSetVersionstampedKey:
			rc.tx.SetVersionstampedKey(fdb.Key(key), mut.value)
		case MutationTypeSetVersionstampedValue:
			rc.tx.SetVersionstampedValue(fdb.Key(key), mut.value)
		}
	}
}

// AddCommitCheck registers a pre-commit check function.
// All checks run before the transaction commits. If any returns an error,
// the commit is aborted with that error.
// Goroutine-safe via commitMu (matches Java's synchronized blocks).
// Matches Java's FDBRecordContext.addCommitCheck(CommitCheckAsync).
func (rc *FDBRecordContext) AddCommitCheck(check CommitCheckFunc) {
	rc.commitMu.Lock()
	defer rc.commitMu.Unlock()
	rc.commitChecks = append(rc.commitChecks, &commitCheckRegistration{check: check, active: true})
}

// GetOrCreateCommitCheck returns the named check, invoking ifNotExists only when
// absent. The supplier runs under the registration lock and must not call back
// into context hook registration. The supplied check runs outside that lock.
// Matches Java's FDBRecordContext.getOrCreateCommitCheck().
func (rc *FDBRecordContext) GetOrCreateCommitCheck(name string, ifNotExists func(string) CommitCheckFunc) CommitCheckFunc {
	rc.commitMu.Lock()
	defer rc.commitMu.Unlock()
	if entry := rc.namedCommitChecks[name]; entry != nil {
		return entry.check
	}
	entry := &commitCheckRegistration{check: ifNotExists(name), active: true}
	if rc.namedCommitChecks == nil {
		rc.namedCommitChecks = make(map[string]*commitCheckRegistration)
	}
	rc.namedCommitChecks[name] = entry
	rc.commitChecks = append(rc.commitChecks, entry)
	return entry.check
}

// getCommitCheck returns a previously registered named check, or nil.
// Matches Java's FDBRecordContext.getCommitCheck().
func (rc *FDBRecordContext) getCommitCheck(name string) CommitCheckFunc {
	rc.commitMu.Lock()
	defer rc.commitMu.Unlock()
	if entry := rc.namedCommitChecks[name]; entry != nil {
		return entry.check
	}
	return nil
}

// removeCommitCheck cancels a named check that has not started, including one
// in the current run's snapshot. It does not stop an already executing check.
// Store deletion uses this before clearing data to prevent deferred retirement
// from recreating deleted index-state keys.
func (rc *FDBRecordContext) removeCommitCheck(name string) {
	rc.commitMu.Lock()
	defer rc.commitMu.Unlock()
	if entry := rc.namedCommitChecks[name]; entry != nil {
		entry.active = false
		delete(rc.namedCommitChecks, name)
	}
}

// removeCommitChecksWithPrefix cancels pending store-scoped callback families.
func (rc *FDBRecordContext) removeCommitChecksWithPrefix(prefix string) {
	rc.commitMu.Lock()
	defer rc.commitMu.Unlock()
	for name, entry := range rc.namedCommitChecks {
		if strings.HasPrefix(name, prefix) {
			entry.active = false
			delete(rc.namedCommitChecks, name)
		}
	}
}

// AddPostCommit registers a post-commit callback.
// All callbacks run after the transaction successfully commits.
// Goroutine-safe via commitMu (matches Java's synchronized blocks).
// Matches Java's FDBRecordContext.addPostCommit(PostCommit).
func (rc *FDBRecordContext) AddPostCommit(hook PostCommitFunc) {
	rc.commitMu.Lock()
	defer rc.commitMu.Unlock()
	rc.postCommits = append(rc.postCommits, hook)
}

// runCommitChecks runs all registered pre-commit checks.
// Returns the first error encountered, or nil if all pass.
// Called at commit time when all goroutines should be done. Registration state
// is locked, but checks run without the lock so they can cancel pending checks.
func (rc *FDBRecordContext) runCommitChecks() error {
	rc.commitMu.Lock()
	checks := make([]*commitCheckRegistration, len(rc.commitChecks))
	copy(checks, rc.commitChecks)
	rc.commitMu.Unlock()
	for _, entry := range checks {
		rc.commitMu.Lock()
		active := entry.active
		rc.commitMu.Unlock()
		if !active {
			continue
		}
		if err := entry.check(); err != nil {
			return err
		}
	}
	return nil
}

// runPostCommits runs all registered post-commit callbacks.
// Called after commit when all goroutines should be done; holds commitMu
// for race-detector cleanliness.
func (rc *FDBRecordContext) runPostCommits() {
	rc.commitMu.Lock()
	hooks := make([]PostCommitFunc, len(rc.postCommits))
	copy(hooks, rc.postCommits)
	rc.commitMu.Unlock()
	for _, hook := range hooks {
		hook()
	}
}

// GetReadVersion returns the transaction's read version.
// Matches Java's FDBRecordContext.getReadVersion().
func (rc *FDBRecordContext) GetReadVersion() (int64, error) {
	startTime := time.Now()
	v, err := rc.tx.GetReadVersion().Get()
	rc.Timer().RecordSince(EventGetReadVersion, startTime)
	return v, err
}

// SetReadVersion sets the transaction's read version explicitly.
// Matches Java's FDBRecordContext.setReadVersion().
func (rc *FDBRecordContext) SetReadVersion(version int64) {
	rc.tx.SetReadVersion(version)
}

// SetTransactionPriority sets the priority for this transaction.
// Matches Java's FDBRecordContext applying FDBTransactionPriority.
func (rc *FDBRecordContext) SetTransactionPriority(priority TransactionPriority) error {
	switch priority {
	case PriorityBatch:
		return rc.tx.Options().SetPriorityBatch()
	case PrioritySystemImmediate:
		return rc.tx.Options().SetPrioritySystemImmediate()
	default:
		return nil // Default priority, no option needed
	}
}

// GetConflictingKeys attempts to identify conflicting keys after a commit failure.
// Reads the transaction's read conflict ranges. This is a best-effort diagnostic tool.
// Goroutine-safe via conflictMu.
// Matches Java's FDBRecordContext.reportConflictingKeys() (diagnostic, not exact).
func (rc *FDBRecordContext) GetConflictingKeys() []fdb.KeyRange {
	rc.conflictMu.Lock()
	defer rc.conflictMu.Unlock()
	result := make([]fdb.KeyRange, len(rc.conflictRanges))
	copy(result, rc.conflictRanges)
	return result
}

// AddReadConflictRange adds a read conflict range and tracks it for diagnostics.
// Goroutine-safe via conflictMu (FDB transaction is already goroutine-safe).
func (rc *FDBRecordContext) AddReadConflictRange(r fdb.ExactRange) error {
	if err := rc.tx.AddReadConflictRange(r); err != nil {
		return err
	}
	begin, end := r.FDBRangeKeys()
	rc.conflictMu.Lock()
	rc.conflictRanges = append(rc.conflictRanges, fdb.KeyRange{
		Begin: begin.FDBKey(),
		End:   end.FDBKey(),
	})
	rc.conflictMu.Unlock()
	return nil
}

// HasVersionMutations returns true if there are pending version mutations.
// Goroutine-safe via versionMu.
func (rc *FDBRecordContext) HasVersionMutations() bool {
	rc.versionMu.Lock()
	defer rc.versionMu.Unlock()
	return len(rc.versionMutations) > 0
}

// Timer returns the instrumentation timer for this context, or nil if not set.
// Goroutine-safe via atomic.Pointer.
// Matches Java's FDBRecordContext.getTimer().
// Nil-safe on the receiver, for the same reason FDBRecordContext.Env is: every
// StoreTimer method tolerates a nil timer, so "no instrumentation" is a supported
// state all the way down — and an accessor at the head of that chain must not be
// the one call in it that panics. Call sites are of the form
// store.context.Timer().RecordSince(...), where the nil check would otherwise have
// to be repeated at each one.
func (rc *FDBRecordContext) Timer() *StoreTimer {
	if rc == nil {
		return nil
	}
	return rc.timer.Load()
}

// SetTimer sets the instrumentation timer for this context.
// Goroutine-safe via atomic.Pointer.
// Matches Java's FDBRecordContext.setTimer().
func (rc *FDBRecordContext) SetTimer(timer *StoreTimer) {
	rc.timer.Store(timer)
}

// HasDirtyStoreState returns true if any store state was modified in this transaction.
// When true, cached store state should not be used.
// Goroutine-safe via atomic.Bool.
// Matches Java's FDBRecordContext.hasDirtyStoreState().
func (rc *FDBRecordContext) HasDirtyStoreState() bool {
	return rc.dirtyStoreState.Load()
}

// SetDirtyStoreState marks that store state was modified in this transaction.
// Goroutine-safe via atomic.Bool.
// Matches Java's FDBRecordContext.setDirtyStoreState().
func (rc *FDBRecordContext) SetDirtyStoreState(dirty bool) {
	rc.dirtyStoreState.Store(dirty)
}

// metaDataVersionStampValue is 14 zero bytes: 10 bytes for the global versionstamp
// + 4 bytes for the little-endian offset (0). FDB replaces the first 10 bytes with
// the commit versionstamp when SET_VERSIONSTAMPED_VALUE is used.
// Matches Java's FDBRecordContext.META_DATA_VERSION_STAMP_VALUE.
// Using an array (not slice) to prevent accidental mutation.
var metaDataVersionStampValue [14]byte

// metaDataVersionKey is the FDB system key used to track metadata version changes.
// Matches Java's SystemKeyspace.METADATA_VERSION_KEY = \xff/metadataVersion.
var metaDataVersionKey = append([]byte{0xFF}, []byte("/metadataVersion")...)

// SetMetaDataVersionStamp schedules a SET_VERSIONSTAMPED_VALUE mutation on the
// metadata version key. After commit, this key will contain the commit versionstamp,
// which invalidates any cached store state entries with older stamps.
// Goroutine-safe via atomic.Bool + goroutine-safe FDB transaction.
// Matches Java's FDBRecordContext.setMetaDataVersionStamp().
func (rc *FDBRecordContext) SetMetaDataVersionStamp() {
	rc.dirtyMetaDataVersionStamp.Store(true)
	rc.tx.SetVersionstampedValue(fdb.Key(metaDataVersionKey), metaDataVersionStampValue[:])
}

// GetMetaDataVersionStamp reads the metadata version stamp at snapshot isolation.
// Returns nil if the stamp was written in this transaction (dirty) or doesn't exist.
// On ACCESSED_UNREADABLE errors (FDB code 1036), marks the stamp as dirty and returns nil.
// Goroutine-safe via atomic.Bool + goroutine-safe FDB transaction.
// Matches Java's FDBRecordContext.getMetaDataVersionStampAsync().
func (rc *FDBRecordContext) GetMetaDataVersionStamp() ([]byte, error) {
	if rc.dirtyMetaDataVersionStamp.Load() {
		return nil, nil
	}
	val, err := rc.tx.Snapshot().Get(fdb.Key(metaDataVersionKey)).Get()
	if err != nil {
		// Check for ACCESSED_UNREADABLE (1036) — the versionstamped value was
		// written in this transaction and can't be read back yet.
		// Matches Java's handle() which catches this specific error code.
		var fdbErr fdb.Error
		if errors.As(err, &fdbErr) && fdbErr.Code == 1036 {
			rc.dirtyMetaDataVersionStamp.Store(true)
			return nil, nil
		}
		// For genuine errors (network, transaction_too_old, etc.), propagate.
		return nil, err
	}
	if val == nil {
		return nil, nil
	}
	return val, nil
}

// CommitWithVersionstamp commits the transaction, first running pre-commit checks,
// then flushing all queued versionstamp mutations. Returns the committed
// versionstamp (10 bytes) or nil for read-only transactions / no versionstamp mutations.
// Runs post-commit hooks after successful commit.
// Matches Java's FDBRecordContext.commitAsync() which always runs checks and hooks.
func (rc *FDBRecordContext) CommitWithVersionstamp() ([]byte, error) {
	// Java's ensureActive, the first statement of commitAsync: a committed
	// context, and one its route owns, commits nothing.
	if rc.routeOwned || !rc.deactivated.CompareAndSwap(false, true) {
		return nil, errTransactionNotActive()
	}
	// Include pre-commit checks in the commit span, but not post-commit hooks.
	commitStart := time.Now()
	if err := rc.runCommitChecks(); err != nil {
		rc.Timer().RecordSince(EventCommit, commitStart)
		return nil, err
	}

	rc.flushVersionMutations()

	// Only request versionstamp future if we actually queued versionstamp mutations.
	// Matches the pattern in RunWithVersionstamp.
	hasVersionMutations := rc.HasVersionMutations()
	var vsFuture fdb.FutureKey
	if hasVersionMutations {
		vsFuture = rc.tx.GetVersionstamp()
	}

	if err := rc.tx.Commit().Get(); err != nil {
		rc.Timer().RecordSince(EventCommit, commitStart)
		return nil, err
	}

	// Java resolves the committed versionstamp before running post-commit hooks.
	var versionstamp []byte
	if hasVersionMutations && vsFuture != nil {
		vs, err := vsFuture.Get()
		if err != nil {
			rc.Timer().RecordSince(EventCommit, commitStart)
			return nil, fmt.Errorf("get versionstamp after commit: %w", err)
		}
		versionstamp = []byte(vs)
	}
	rc.Timer().RecordSince(EventCommit, commitStart)
	rc.runPostCommits()
	return versionstamp, nil
}

// buildVersionstampedValue builds the value for SET_VERSIONSTAMPED_VALUE mutation.
// Matches Java's SplitHelper.packVersion(): wraps an incomplete versionstamp in
// a Tuple and uses PackWithVersionstamp to produce bytes with the offset appended.
// After FDB commit, the stored value is a packed Tuple containing the completed versionstamp.
func buildVersionstampedValue(version *FDBRecordVersion) ([]byte, error) {
	vs := tuple.Versionstamp{
		UserVersion: uint16(version.GetLocalVersion()),
	}
	// TransactionVersion is all 0xFF for incomplete versionstamps (placeholder)
	copy(vs.TransactionVersion[:], incompleteGlobalVersionMarker[:])
	return tuple.Tuple{vs}.PackWithVersionstamp(nil)
}

// lockRegistry provides per-key read-write locks within a transaction context.
// Matches Java's LockRegistry (ConcurrentHashMap<LockIdentifier, AtomicReference<AsyncLock>>).
// Used by tree-structured indexes (HNSW, R-tree) to serialize mutations.
//
// An entry lives while anyone holds or waits for its lock, and is removed when
// the last of them releases (Java 4.14 #4545: a completed lock is removed only
// when no registered work depends on it). Removing it any earlier would let a
// later caller create a second live lock for the same key.
type lockRegistry struct {
	mu    sync.Mutex
	locks map[string]*lockEntry
}

// lockEntry is one key's lock and the number of holders and waiters it has,
// counted under lockRegistry.mu.
type lockEntry struct {
	rw   sync.RWMutex
	refs int
}

// acquire registers one more holder or waiter of key's lock.
func (r *lockRegistry) acquire(key string) *lockEntry {
	r.mu.Lock()
	defer r.mu.Unlock()
	if r.locks == nil {
		r.locks = make(map[string]*lockEntry)
	}
	e, ok := r.locks[key]
	if !ok {
		e = &lockEntry{}
		r.locks[key] = e
	}
	e.refs++
	return e
}

// held is key's entry, which the caller holds.
func (r *lockRegistry) held(key string) *lockEntry {
	r.mu.Lock()
	defer r.mu.Unlock()
	e, ok := r.locks[key]
	if !ok {
		panic(fmt.Sprintf("recordlayer: unlock of an unlocked key %q", key))
	}
	return e
}

// release drops one holder of key's lock, removing the entry with the last.
func (r *lockRegistry) release(key string, e *lockEntry) {
	r.mu.Lock()
	defer r.mu.Unlock()
	e.refs--
	if e.refs == 0 {
		delete(r.locks, key)
	}
}

// size is the number of live entries.
func (r *lockRegistry) size() int {
	r.mu.Lock()
	defer r.mu.Unlock()
	return len(r.locks)
}

// WriteLock acquires an exclusive lock for the given key.
// Matches Java's FDBRecordContext.doWithWriteLock(LockIdentifier).
func (r *lockRegistry) WriteLock(key string) {
	r.acquire(key).rw.Lock()
}

// WriteUnlock releases the exclusive lock for the given key.
func (r *lockRegistry) WriteUnlock(key string) {
	e := r.held(key)
	e.rw.Unlock()
	r.release(key, e)
}

// ReadLock acquires a shared lock for the given key.
// Matches Java's FDBRecordContext.doWithReadLock(LockIdentifier).
func (r *lockRegistry) ReadLock(key string) {
	r.acquire(key).rw.RLock()
}

// ReadUnlock releases the shared lock for the given key.
func (r *lockRegistry) ReadUnlock(key string) {
	e := r.held(key)
	e.rw.RUnlock()
	r.release(key, e)
}
