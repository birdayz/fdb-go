// Portions derived from FoundationDB Record Layer (
// AtomicMutationIndexMaintainer.java, FDBStoredRecord.java,
// StandardIndexMaintainer.java, AtomicMutation.java),
// Copyright 2015-2018 Apple Inc. and the FoundationDB project authors
// Copyright 2015-2026 Apple Inc. and the FoundationDB project authors
// Licensed under the Apache License, Version 2.0; translated to Go and modified.

package recordlayer

import (
	"encoding/binary"
	"fmt"
	"unsafe"

	"fdb.dev/pkg/fdbgo/fdb"
	"fdb.dev/pkg/fdbgo/fdb/subspace"
	"fdb.dev/pkg/fdbgo/fdb/tuple"
	"google.golang.org/protobuf/proto"
)

// atomicMutationIndexMaintainer is the unified maintainer for all atomic index types.
// Matches Java's AtomicMutationIndexMaintainer — one class handles COUNT, SUM,
// MIN_EVER_LONG, MAX_EVER_LONG, MIN_EVER_TUPLE, MAX_EVER_TUPLE, COUNT_NOT_NULL,
// and COUNT_UPDATES via the atomicMutation strategy interface.
type atomicMutationIndexMaintainer struct {
	index         *Index
	indexSubspace subspace.Subspace
	tx            fdb.WritableTransaction
	store         IndexStoreContext
	mutation      atomicMutation
}

func newAtomicMutationIndexMaintainer(
	index *Index,
	indexSubspace subspace.Subspace,
	tx fdb.WritableTransaction,
	store IndexStoreContext,
	mutation atomicMutation,
) *atomicMutationIndexMaintainer {
	return &atomicMutationIndexMaintainer{
		index:         index,
		indexSubspace: indexSubspace,
		tx:            tx,
		store:         store,
		mutation:      mutation,
	}
}

// Update handles insert (old=nil), delete (new=nil), or update (both non-nil).
// Delegates evaluation, common-entry filtering, and mutation application to the
// atomicMutation strategy. Matches Java's AtomicMutationIndexMaintainer.updateIndexKeys().
func (m *atomicMutationIndexMaintainer) Update(oldRecord, newRecord *FDBStoredRecord[proto.Message]) error {
	// _EVER and COUNT_UPDATES: deletes are no-ops.
	if m.mutation.deleteIsNoOp() && newRecord == nil {
		return nil
	}

	// Insert-only fast path: evaluate + apply inline, no intermediate slices.
	// Saves 2 allocs per call ([]atomicMutationEntry + make(tuple.Tuple)).
	if oldRecord == nil && newRecord != nil {
		if ok, err := m.updateInsertOnly(newRecord); ok || err != nil {
			return err
		}
	}

	var oldEntries, newEntries []atomicMutationEntry

	// Evaluate old record entries (skip if delete is no-op).
	if oldRecord != nil && !m.mutation.deleteIsNoOp() {
		entries, err := m.mutation.evaluateEntries(m.store, oldRecord)
		if err != nil {
			return fmt.Errorf("evaluate %s index %q for old record: %w", m.index.Type, m.index.Name, err)
		}
		oldEntries = entries
	}

	// Evaluate new record entries.
	if newRecord != nil {
		entries, err := m.mutation.evaluateEntries(m.store, newRecord)
		if err != nil {
			return fmt.Errorf("evaluate %s index %q for new record: %w", m.index.Type, m.index.Name, err)
		}
		newEntries = entries
	}

	// Remove common entries — skipped for idempotent types and COUNT_UPDATES.
	if oldEntries != nil && newEntries != nil {
		oldEntries, newEntries = m.mutation.removeCommon(oldEntries, newEntries)
	}

	// Apply removal mutations for old entries.
	for _, e := range oldEntries {
		fdbKey := fdb.Key(m.indexSubspace.Pack(e.groupKey))
		if err := m.mutation.applyMutation(m.tx, fdbKey, e, true); err != nil {
			return err
		}
	}

	// Apply insert mutations for new entries (with size checks).
	for _, e := range newEntries {
		fdbKey := fdb.Key(m.indexSubspace.Pack(e.groupKey))
		if newRecord != nil {
			if err := checkKeyValueSizes(m.index, newRecord.PrimaryKey, fdbKey, e.param); err != nil {
				return err
			}
		}
		if err := m.mutation.applyMutation(m.tx, fdbKey, e, false); err != nil {
			return err
		}
	}

	return nil
}

// clearIfZero issues the COMPARE_AND_CLEAR that has to follow every mutation of
// a clear-when-zero index, matching AtomicMutationIndexMaintainer.updateIndexKeys,
// which emits it after the mutate with no remove guard.
//
// It exists because the SUM fast paths below write their ADD inline rather than
// going through sumMutation.applyMutation -- they skip the boxing that path
// costs, and in skipping it they also skipped the clear. A grouped SUM index
// with clearWhenZero therefore kept an entry on insert that Java would have
// cleared, while the ungrouped spelling (which has no fast path) cleared
// correctly. Any new inline mutation site has to call this too.
func (m *atomicMutationIndexMaintainer) clearIfZero(fdbKey fdb.Key) {
	if m.index.IsClearWhenZero() {
		m.tx.CompareAndClearBytes(fdbKey, littleEndianInt64Zero)
	}
}

// updateInsertOnly is the insert-only fast path for atomic index maintenance.
// Evaluates the expression and applies the mutation inline without allocating
// []atomicMutationEntry or make(tuple.Tuple). Returns (true, nil) on success,
// (false, nil) to fall through to the standard path.
func (m *atomicMutationIndexMaintainer) updateInsertOnly(newRecord *FDBStoredRecord[proto.Message]) (bool, error) {
	switch indexValuesFor(m.store, m.index, newRecord) {
	case IndexValuesNone:
		return true, nil // not maintained: the predicate or the filter refused it
	case IndexValuesSome:
		return false, nil // entries filtered one by one: the standard path
	}

	// Try zero-alloc path: evaluate grouping key fields directly via ScalarEvaluator,
	// bypassing CompositeKeyExpression.EvaluateFlat's make([]any, 0, N).
	if gke, ok := m.index.RootExpression.(*GroupingKeyExpression); ok {
		if ok, err := m.updateInsertOnlyGrouped(gke, newRecord); ok || err != nil {
			return ok, err
		}
	}

	// Standard path: use EvaluateFlat (allocates []any for composite expressions).
	fe, ok := m.index.RootExpression.(FlatEvaluator)
	if !ok {
		return false, nil
	}

	values, err := fe.EvaluateFlat(newRecord, newRecord.Record)
	if err != nil {
		return false, nil
	}

	gc := indexGroupingCount(m.index.RootExpression)
	n := gc
	if n > len(values) {
		n = len(values)
	}
	groupKey := *(*tuple.Tuple)(unsafe.Pointer(&values))
	groupKey = groupKey[:n]
	fdbKey := fdb.Key(m.indexSubspace.Pack(groupKey))

	if err := checkKeyValueSizes(m.index, newRecord.PrimaryKey, fdbKey, nil); err != nil {
		return true, err
	}

	var entry atomicMutationEntry
	entry.groupKey = groupKey

	switch m.mutation.(type) {
	case *countMutation, *countUpdatesMutation:
	case *sumMutation:
		if gc >= len(values) || values[gc] == nil {
			return true, nil
		}
		sumValue, err := toInt64(values[gc])
		if err != nil {
			return true, fmt.Errorf("sum index %q: value at column %d: %w", m.index.Name, gc, err)
		}
		var param [8]byte
		binary.LittleEndian.PutUint64(param[:], uint64(sumValue))
		entry.param = param[:]
	default:
		return false, nil
	}

	if err := m.mutation.applyMutation(m.tx, fdbKey, entry, false); err != nil {
		return true, err
	}
	return true, nil
}

// updateInsertOnlyGrouped handles the insert-only fast path for GroupingKeyExpression
// roots. Evaluates grouping key fields directly via ScalarEvaluator, bypassing
// CompositeKeyExpression.EvaluateFlat's make([]any) allocation.
// Returns (true, nil) on success, (false, nil) to fall through.
func (m *atomicMutationIndexMaintainer) updateInsertOnlyGrouped(
	gke *GroupingKeyExpression,
	newRecord *FDBStoredRecord[proto.Message],
) (bool, error) {
	gc := gke.GetGroupingCount()

	// Ungrouped (gc=0): all records share empty group key. No evaluation needed.
	// Only handles COUNT variants (no grouped value required). SUM with gc=0
	// falls through to the standard EvaluateFlat path.
	if gc == 0 {
		switch m.mutation.(type) {
		case *countMutation, *countUpdatesMutation:
			fdbKey := fdb.Key(m.indexSubspace.Pack(tuple.Tuple{}))
			return m.applyInsertMutation(fdbKey, nil, gc, newRecord, gke)
		}
		return false, nil // SUM/other with gc=0: fall through
	}

	// Single-field grouping (gc=1): try ScalarEvaluator on first child.
	if gc == 1 {
		comp, ok := gke.wholeKey.(*CompositeKeyExpression)
		if !ok {
			return false, nil
		}
		if len(comp.expressions) == 0 {
			return false, nil
		}
		// Try Int64Evaluator for zero-alloc group key packing.
		var fdbKey fdb.Key
		if ie, ok := comp.expressions[0].(Int64Evaluator); ok {
			groupInt64, valid, err := ie.EvaluateInt64(newRecord, newRecord.Record)
			if err != nil {
				return false, nil
			}
			if !valid {
				return false, nil
			}
			fdbKey = fdb.Key(tuple.Pack1WithPrefix(m.indexSubspace.Bytes(), groupInt64))
		} else if se, ok := comp.expressions[0].(ScalarEvaluator); ok {
			groupVal, err := se.EvaluateScalar(newRecord, newRecord.Record)
			if err != nil {
				return false, nil
			}
			fdbKey = fdb.Key(tuple.Pack1WithPrefix(m.indexSubspace.Bytes(), tuple.TupleElement(groupVal)))
		} else {
			return false, nil
		}

		// For SUM: extract the sum value and apply inline to avoid int64→any boxing.
		if _, isSumMut := m.mutation.(*sumMutation); isSumMut && len(comp.expressions) > 1 {
			var sumInt64 int64
			if ie, ok := comp.expressions[1].(Int64Evaluator); ok {
				val, valid, err := ie.EvaluateInt64(newRecord, newRecord.Record)
				if err != nil || !valid {
					return false, nil
				}
				sumInt64 = val
			} else if se2, ok := comp.expressions[1].(ScalarEvaluator); ok {
				val, err := se2.EvaluateScalar(newRecord, newRecord.Record)
				if err != nil || val == nil {
					return false, nil
				}
				sumInt64, err = toInt64(val)
				if err != nil {
					return true, fmt.Errorf("sum index %q: %w", m.index.Name, err)
				}
			} else {
				return false, nil
			}
			if err := checkKeyValueSizes(m.index, newRecord.PrimaryKey, fdbKey, nil); err != nil {
				return true, err
			}
			// Inline SUM mutation with stack-allocated param buffer.
			var sumParam [8]byte
			binary.LittleEndian.PutUint64(sumParam[:], uint64(sumInt64))
			m.tx.AddBytes(fdbKey, sumParam[:])
			m.clearIfZero(fdbKey)
			return true, nil
		}

		return m.applyInsertMutation(fdbKey, nil, gc, newRecord, gke)
	}

	// Multi-field grouping (gc > 1): try DirectPacker on the grouping fields.
	comp, ok := gke.wholeKey.(*CompositeKeyExpression)
	if !ok || len(comp.expressions) < gc {
		return false, nil
	}
	pk := tuple.GetPacker()
	defer tuple.PutPacker(pk)
	pk.Reset()
	allDirect := true
	for i := 0; i < gc; i++ {
		if dp, ok2 := comp.expressions[i].(DirectPacker); ok2 {
			if !dp.PackDirect(pk, newRecord, newRecord.Record) {
				allDirect = false
				break
			}
		} else {
			allDirect = false
			break
		}
	}
	if !allDirect {
		return false, nil
	}
	var buf []byte
	fdbKey := fdb.Key(pk.AppendInto(&buf, m.indexSubspace.Bytes()))

	// Extract SUM value directly if this is a SUM mutation.
	var sumSource any
	if _, isSumMut := m.mutation.(*sumMutation); isSumMut && len(comp.expressions) > gc {
		sumExpr := comp.expressions[gc]
		if ie, ok2 := sumExpr.(Int64Evaluator); ok2 {
			val, valid, err := ie.EvaluateInt64(newRecord, newRecord.Record)
			if err != nil || !valid {
				return false, nil
			}
			if err := checkKeyValueSizes(m.index, newRecord.PrimaryKey, fdbKey, nil); err != nil {
				return true, err
			}
			var param [8]byte
			binary.LittleEndian.PutUint64(param[:], uint64(val))
			m.tx.AddBytes(fdbKey, param[:])
			m.clearIfZero(fdbKey)
			return true, nil
		}
		if se, ok2 := sumExpr.(ScalarEvaluator); ok2 {
			val, err := se.EvaluateScalar(newRecord, newRecord.Record)
			if err != nil {
				return false, nil
			}
			sumSource = val
		} else {
			return false, nil
		}
	}

	return m.applyInsertMutation(fdbKey, sumSource, gc, newRecord, gke)
}

// applyInsertMutation applies the mutation for insert-only, given a pre-packed FDB key.
// sumSource is the raw value for SUM mutations (nil for COUNT).
func (m *atomicMutationIndexMaintainer) applyInsertMutation(
	fdbKey fdb.Key,
	sumSource any,
	gc int,
	newRecord *FDBStoredRecord[proto.Message],
	gke *GroupingKeyExpression,
) (bool, error) {
	if err := checkKeyValueSizes(m.index, newRecord.PrimaryKey, fdbKey, nil); err != nil {
		return true, err
	}

	var entry atomicMutationEntry
	switch m.mutation.(type) {
	case *countMutation, *countUpdatesMutation:
		// param ignored by applyMutation
	case *sumMutation:
		if sumSource == nil {
			return true, nil
		}
		sumValue, err := toInt64(sumSource)
		if err != nil {
			return true, fmt.Errorf("sum index %q: %w", m.index.Name, err)
		}
		var param [8]byte
		binary.LittleEndian.PutUint64(param[:], uint64(sumValue))
		entry.param = param[:]
	default:
		return false, nil
	}

	if err := m.mutation.applyMutation(m.tx, fdbKey, entry, false); err != nil {
		return true, err
	}
	return true, nil
}

// UpdateWhileWriteOnly updates the index during WRITE_ONLY state.
// For idempotent indexes (_EVER), pass-through to Update().
// For non-idempotent indexes (COUNT, SUM), checks the index build range first.
func (m *atomicMutationIndexMaintainer) UpdateWhileWriteOnly(oldRecord, newRecord *FDBStoredRecord[proto.Message]) error {
	if m.mutation.isIdempotent() {
		return m.Update(oldRecord, newRecord)
	}
	// Non-idempotent: short-circuit deletes for deleteIsNoOp types (COUNT_UPDATES).
	if m.mutation.deleteIsNoOp() && newRecord == nil {
		return nil
	}
	return updateWhileWriteOnlyNonIdempotent(oldRecord, newRecord, m.index, m.store, m.index.Type, m.Update)
}

// CanDeleteWhere bounds the prefix at the GROUPING columns.
//
// An aggregate index is physically keyed by its grouping columns alone — the
// grouped column is the thing being aggregated, not part of the key — while the
// store's alignment check normalises a GroupingKeyExpression to its WHOLE key.
// So a prefix reaching into the grouped column aligns positionally and is
// accepted, and the clear then addresses a subspace no entry lives in: the
// records go, the aggregate at the shorter key survives, and the call reports
// success. A COUNT that still counts deleted records is worse than one that
// refuses to be cleared.
//
// Java reaches the same bound from the other side: StandardIndexMaintainer's
// canDeleteWhere matches the query against the root expression, and the matcher
// unwraps a grouping expression to its grouping subkey.
func (m *atomicMutationIndexMaintainer) CanDeleteWhere(prefix tuple.Tuple) error {
	return checkDeleteWhereBound(m.index, prefix)
}

// DeleteWhere clears all index entries whose key starts with the given prefix.
func (m *atomicMutationIndexMaintainer) DeleteWhere(prefix tuple.Tuple) error {
	// Backstop for direct callers; DeleteRecordsWhere asks CanDeleteWhere
	// BEFORE it clears anything.
	if err := m.CanDeleteWhere(prefix); err != nil {
		return err
	}
	return deleteWhereRange(m.tx, m.indexSubspace, prefix)
}

// Scan scans index entries within the given tuple range.
// Uses countKVCursor (int64 values) or tuple variant based on mutation type.
func (m *atomicMutationIndexMaintainer) Scan(scanRange TupleRange, continuation []byte, scanProperties ScanProperties) RecordCursor[*IndexEntry] {
	var cursor *countKVCursor
	if m.mutation.tupleValues() {
		cursor = newTupleValueIndexCursor(m.index, m.indexSubspace, m.tx, scanRange, continuation, scanProperties)
	} else {
		cursor = newCountIndexCursor(m.index, m.indexSubspace, m.tx, scanRange, continuation, scanProperties)
	}
	if store, ok := m.store.(*FDBRecordStore); ok {
		cursor.withContext(store.context)
	}
	return cursor
}

// indexAggregator is implemented by index maintainers that support aggregate evaluation.
// Used by evaluateAtomicAggregate to get the reducer from the maintainer itself,
// eliminating the string-name dispatch. Matches Java's pattern where getIdentity()
// and getAggregator() live on the AtomicMutation enum.
type indexAggregator interface {
	aggregateIdentity() tuple.Tuple
	aggregate(accum, entry tuple.Tuple) tuple.Tuple
}

func (m *atomicMutationIndexMaintainer) aggregateIdentity() tuple.Tuple {
	return m.mutation.aggregateIdentity()
}

func (m *atomicMutationIndexMaintainer) aggregate(accum, entry tuple.Tuple) tuple.Tuple {
	return m.mutation.aggregate(accum, entry)
}

var (
	_ IndexMaintainer = (*atomicMutationIndexMaintainer)(nil)
	_ indexAggregator = (*atomicMutationIndexMaintainer)(nil)
)
