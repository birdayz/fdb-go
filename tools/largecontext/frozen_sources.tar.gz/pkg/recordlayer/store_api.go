// Portions derived from FoundationDB Record Layer (FDBRecordStore.java,
// FDBRecordStoreBase.java, PlanContext.java, FDBRecordContext.java,
// and others),
// Copyright 2015-2018 Apple Inc. and the FoundationDB project authors
// Copyright 2021-2025 Apple Inc. and the FoundationDB project authors
// Licensed under the Apache License, Version 2.0; translated to Go and modified.

package recordlayer

import (
	"fmt"
	"maps"
	"time"

	"fdb.dev/pkg/recordlayer/internal/tuplefast"

	"fdb.dev/pkg/fdbgo/fdb"
	"fdb.dev/pkg/fdbgo/fdb/subspace"
	"fdb.dev/pkg/fdbgo/fdb/tuple"
	"google.golang.org/protobuf/proto"

	"fdb.dev/gen"
)

// RecordsSubspace returns the subspace where records are stored.
// Matches Java's FDBRecordStore.recordsSubspace().
func (store *FDBRecordStore) RecordsSubspace() subspace.Subspace {
	return store.subspace.Sub(RecordKey)
}

// IndexSubspace returns the subspace for a specific index's entries.
// Matches Java's FDBRecordStore.indexSubspace(index).
func (store *FDBRecordStore) IndexSubspace(index *Index) subspace.Subspace {
	return store.indexSubspace(index)
}

// IndexSecondarySubspace returns the secondary subspace for a specific index.
// Matches Java's FDBRecordStore.indexSecondarySubspace(index).
func (store *FDBRecordStore) IndexSecondarySubspace(index *Index) subspace.Subspace {
	return store.indexSecondarySubspace(index)
}

// GetReadableIndexes returns all indexes that are in READABLE or READABLE_UNIQUE_PENDING state.
// Matches Java's FDBRecordStoreBase.getReadableIndexes().
func (store *FDBRecordStore) GetReadableIndexes() []*Index {
	var result []*Index
	for _, idx := range store.metaData.GetAllIndexes() {
		if store.GetIndexState(idx.Name).IsScannable() {
			result = append(result, idx)
		}
	}
	return result
}

// GetEnabledIndexes returns all indexes that are NOT in DISABLED state.
// Matches Java's FDBRecordStoreBase.getEnabledIndexes().
func (store *FDBRecordStore) GetEnabledIndexes() []*Index {
	var result []*Index
	for _, idx := range store.metaData.GetAllIndexes() {
		if !store.GetIndexState(idx.Name).IsDisabled() {
			result = append(result, idx)
		}
	}
	return result
}

// GetReadableUniversalIndexes returns universal indexes in READABLE state.
// Matches Java's FDBRecordStore.getReadableUniversalIndexes().
func (store *FDBRecordStore) GetReadableUniversalIndexes() []*Index {
	var result []*Index
	for _, idx := range store.metaData.GetUniversalIndexes() {
		if store.GetIndexState(idx.Name).IsScannable() {
			result = append(result, idx)
		}
	}
	return result
}

// GetEnabledUniversalIndexes returns universal indexes NOT in DISABLED state.
// Matches Java's FDBRecordStore.getEnabledUniversalIndexes().
func (store *FDBRecordStore) GetEnabledUniversalIndexes() []*Index {
	var result []*Index
	for _, idx := range store.metaData.GetUniversalIndexes() {
		if !store.GetIndexState(idx.Name).IsDisabled() {
			result = append(result, idx)
		}
	}
	return result
}

// SetFormatVersion updates the store's format version in the header.
// This is used during store migration to enable new features.
// Matches Java's FDBRecordStore.setFormatVersion().
func (store *FDBRecordStore) SetFormatVersion(version int32) error {
	store.stateMu.Lock()
	defer store.stateMu.Unlock()
	if store.storeHeader == nil {
		return &RecordStoreStateNotLoadedError{}
	}
	store.storeHeader.FormatVersion = &version
	return store.writeStoreHeader(store.storeHeader)
}

// IndexStateSubspace returns the subspace where index states are stored.
// Matches Java's FDBRecordStore.indexStateSubspace().
func (store *FDBRecordStore) IndexStateSubspace() subspace.Subspace {
	return store.subspace.Sub(IndexStateSpaceKey)
}

// GetAllIndexStates returns a map of all index names to their current states.
// Indexes without an explicit state entry default to READABLE. Like Java's
// FDBRecordStore.getAllIndexStates (addStoreStateReadConflict,
// FDBRecordStore.java:4205-4213, 4610-4617), it adds ONE read-conflict range
// over the whole index-state subspace: any state change in the store
// conflicts with the caller's transaction.
func (store *FDBRecordStore) GetAllIndexStates() map[string]IndexState {
	if store.context != nil {
		// The signature returns no error, as before, when a per-index read
		// dropped its conflict error; a dead transaction fails its commit.
		_ = store.context.AddReadConflictRange(store.IndexStateSubspace())
	}
	return store.PeekIndexStates()
}

// PeekIndexStates returns the state of every index the metadata names, an
// index with no stored state defaulted to READABLE, WITHOUT any read conflict:
// the states the store loaded at open, Java's getRecordStoreState().getState
// (PlanContext.java:237-260 plans from them and adds no conflict). It serves
// SQL planning and the per-page plan revalidation only; a scan takes its own
// per-index conflict key (ReadIndexState), so a state change of an index a
// statement never scans does not abort its transaction.
func (store *FDBRecordStore) PeekIndexStates() map[string]IndexState {
	store.ensureStoreStateLoaded()
	store.stateMu.RLock()
	defer store.stateMu.RUnlock()
	loaded := store.snapshotIndexStatesLocked()
	result := make(map[string]IndexState)
	for name := range store.metaData.GetAllIndexes() {
		state, ok := loaded[name]
		if !ok {
			state = IndexStateReadable
		}
		result[name] = state
	}
	return result
}

// GetIndexesToBuild returns eligible indexes that are not exactly READABLE.
// State reads are serializable, including decisions to omit readable indexes.
// Matches Java's FDBRecordStore.getIndexesToBuild().
func (store *FDBRecordStore) GetIndexesToBuild() ([]*Index, error) {
	var result []*Index
	for _, index := range store.metaData.GetIndexesToBuildSince(-1) {
		state, err := store.readIndexState(index.Name)
		if err != nil {
			return nil, err
		}
		if state != IndexStateReadable {
			result = append(result, index)
		}
	}
	return result, nil
}

// RebuildAllIndexes rebuilds eligible indexes that are not in READABLE state.
// Replaced originals are excluded, but explicit RebuildIndex remains supported.
// Matches Java's FDBRecordStore.rebuildAllIndexes().
func (store *FDBRecordStore) RebuildAllIndexes() error {
	indexes, err := store.GetIndexesToBuild()
	if err != nil {
		return err
	}
	for _, idx := range indexes {
		if err := store.RebuildIndex(idx); err != nil {
			return fmt.Errorf("rebuild all indexes: %w", err)
		}
	}
	return nil
}

// VacuumReadableIndexesBuildData clears build artifacts (range sets, stamps,
// progress counters) for indexes that are already READABLE.
// Matches Java's FDBRecordStore.vacuumReadableIndexesBuildData().
func (store *FDBRecordStore) VacuumReadableIndexesBuildData() {
	tx := store.context.Transaction()
	for _, idx := range store.metaData.GetAllIndexes() {
		if store.GetIndexState(idx.Name) != IndexStateReadable {
			continue
		}
		// Clear build space [IndexBuildSpaceKey, indexSubspaceKey]
		buildSub := store.subspace.Sub(IndexBuildSpaceKey, idx.SubspaceTupleKey())
		tx.ClearRange(buildSub)

		// Clear range space [IndexRangeSpaceKey, indexSubspaceKey]
		rangeSub := store.subspace.Sub(IndexRangeSpaceKey, idx.SubspaceTupleKey())
		tx.ClearRange(rangeSub)
	}
}

// EventWaitDeleteStore is FDBStoreTimer.Waits.WAIT_DELETE_STORE, the wait a
// caller records around a store deletion (Java's relational DROP SCHEMA).
var EventWaitDeleteStore = Event{"wait_delete_store", "wait for delete store", KindTimed}

// DeleteStore completely removes all data in a store subspace.
// Matches Java's header-aware FDBRecordStore.deleteStoreAsync.
func DeleteStore(ctx *FDBRecordContext, ss subspace.Subspace) error {
	headerBytes, err := ctx.Transaction().Get(ss.Pack(tuple.Tuple{StoreInfoKey})).Get()
	if err != nil {
		return fmt.Errorf("delete store: read header: %w", err)
	}
	if headerBytes != nil {
		header := &gen.DataStoreInfo{}
		// Malformed headers must not prevent deletion or leave cached state
		// valid. Unknown fields and unsupported format numbers remain deletable.
		if err := UnmarshalAsJava(headerBytes, header); err != nil || header.GetCacheable() {
			ctx.SetMetaDataVersionStamp()
		}
	}
	// Java 4.14.2.0 leaves its captured replacement-retirement callback queued,
	// which can recreate a DISABLED state key after this clear. Cancel the
	// subspace's pending check so deletion cannot resurrect store data (RFC-257).
	ctx.removeCommitCheck(replacementRetirementCheckName(ss))
	ctx.removeCommitChecksWithPrefix(PendingWriteCommitCheckPrefix(ss))
	ctx.PutSession(replacementRetirementMetadataKey(ss), nil)
	ctx.SetDirtyStoreState(true)
	begin, end := ss.FDBRangeKeys()
	// The header read above is authoritative even for an already-opened store.
	ctx.clearRange(fdb.KeyRange{Begin: begin, End: end}, false)
	return nil
}

// FirstUnbuiltRange returns the first range of the index that hasn't been built yet.
// Returns nil, nil if the index is fully built.
// Matches Java's FDBRecordStore.firstUnbuiltRange(index).
func (store *FDBRecordStore) FirstUnbuiltRange(index *Index) (*RangeSetRange, error) {
	rangeSet := NewIndexingRangeSet(store.subspace, index)
	return rangeSet.FirstMissingRange(store.context.Transaction())
}

// IsCacheable returns whether the store state is marked as cacheable in the header.
// Goroutine-safe via stateMu (read lock).
// Matches Java's FDBRecordStore.getRecordStoreState().getStoreHeader().getCacheable().
func (store *FDBRecordStore) IsCacheable() bool {
	store.stateMu.RLock()
	defer store.stateMu.RUnlock()
	if store.storeHeader == nil {
		return false
	}
	return store.storeHeader.GetCacheable()
}

// GetStoreHeader returns a copy of the current store header proto.
// Goroutine-safe via stateMu (read lock).
// Matches Java's FDBRecordStore.getRecordStoreState().getStoreHeader().
func (store *FDBRecordStore) GetStoreHeader() *gen.DataStoreInfo {
	store.stateMu.RLock()
	defer store.stateMu.RUnlock()
	if store.storeHeader == nil {
		return nil
	}
	return proto.Clone(store.storeHeader).(*gen.DataStoreInfo)
}

// GetAllIndexStatesMap returns a copy of the raw index states map (non-READABLE only).
// Goroutine-safe via stateMu (read lock).
// For a complete map including defaulted READABLE states, use GetAllIndexStates().
func (store *FDBRecordStore) GetAllIndexStatesMap() map[string]IndexState {
	store.ensureStoreStateLoaded()
	store.stateMu.RLock()
	defer store.stateMu.RUnlock()
	return store.snapshotIndexStatesLocked()
}

// snapshotIndexStatesLocked copies the context authority, not a handle's older
// initialization snapshot. Caller holds stateMu after lazy initialization.
func (store *FDBRecordStore) snapshotIndexStatesLocked() map[string]IndexState {
	states := store.indexStates
	if store.indexStateView != nil {
		store.indexStateView.mu.Lock()
		defer store.indexStateView.mu.Unlock()
		states = store.indexStateView.states
	}
	result := make(map[string]IndexState, len(states))
	maps.Copy(result, states)
	return result
}

// OverrideLockSaveRecord saves a record even when the store is locked for record updates
// (FORBID_RECORD_UPDATE). This is used by the OnlineIndexer to write index maintenance
// records while the store is locked.
// Goroutine-safe: uses parameter-based override instead of mutable field.
// Matches Java's FDBRecordStore.overrideLockSaveRecordAsync().
func (store *FDBRecordStore) OverrideLockSaveRecord(
	record proto.Message,
	existenceCheck RecordExistenceCheck,
) (*FDBStoredRecord[proto.Message], error) {
	return store.saveRecordInternal(record, existenceCheck, nil, VersionstampSaveBehaviorDefault, true, nil, nil)
}

// OverrideLockSaveRecordWithVersion is OverrideLockSaveRecord with SaveRecordWithVersion's
// version choice: Java's overrideLockSaveRecordAsync(rec, existenceCheck, version, behavior).
func (store *FDBRecordStore) OverrideLockSaveRecordWithVersion(
	record proto.Message,
	existenceCheck RecordExistenceCheck,
	version *FDBRecordVersion,
	behavior VersionstampSaveBehavior,
) (*FDBStoredRecord[proto.Message], error) {
	return store.saveRecordInternal(record, existenceCheck, version, behavior, true, nil, nil)
}

// GetRecordMetaData returns the metadata associated with this store.
// Matches Java's FDBRecordStore.getRecordMetaData().
func (store *FDBRecordStore) GetRecordMetaData() *RecordMetaData {
	return store.metaData
}

// GetContext returns the record context (transaction wrapper) for this store.
// Matches Java's FDBRecordStore.getRecordContext().
func (store *FDBRecordStore) GetContext() *FDBRecordContext {
	return store.context
}

// GetSubspace returns the FDB subspace for this store.
// Matches Java's FDBRecordStore.getSubspace().
func (store *FDBRecordStore) GetSubspace() subspace.Subspace {
	return store.subspace
}

// DryRunSaveRecord validates a save and returns what the stored record would look
// like if saved, without actually writing data.
//
// Scope — matches Java's FDBRecordStore.saveTypedRecord(isDryRun=true), which early-returns
// at FDBRecordStore.java:578 BEFORE the store-lock check (validateRecordUpdateAllowed, line
// 584), serializeAndSaveRecord (staging, line 586) and updateSecondaryIndexes (line 594).
// The PRIMARY-KEY existence/type checks run EARLIER (Java lines 561-577, before the isDryRun
// branch), so this keeps them. It deliberately does NOT validate store-lock state, does NOT
// stage the write, and does NOT run secondary-index maintenance. Consequences, all
// Java-faithful:
//   - a DRY RUN on a FORBID_RECORD_UPDATE-locked store previews SUCCESS (the lock check is
//     skipped — Java's early-return precedes it), and
//   - a secondary-UNIQUE conflict is NOT detected in dry-run (only the real save's
//     updateSecondaryIndexes catches it), and
//   - a duplicate PK introduced WITHIN the same statement is not seen by a later row (no
//     write is staged between rows).
//
// Doing any of these would make Go's preview STRICTER than Java's — a conformance divergence
// (Go rejecting a DRY RUN that Java previews as success). Pinned by
// TestFDB_DmlDryRun_MatchesJavaLightweightValidation and TestFDB_DmlDryRun_LockedStorePreviews.
//
// Matches Java's FDBRecordStore.dryRunSaveRecordAsync().
func (store *FDBRecordStore) DryRunSaveRecord(
	record proto.Message,
	existenceCheck RecordExistenceCheck,
) (*FDBStoredRecord[proto.Message], error) {
	target, err := store.saveTargetFor(record, nil, VersionstampSaveBehaviorDefault)
	if err != nil {
		return nil, err
	}
	recordTypeName, recordType := target.recordTypeName, target.recordType
	record, writeRecord, primaryKey := target.record, target.write, target.primaryKey

	defer store.context.Timer().RecordSince(EventSaveRecord, time.Now())

	// Load existing record for existence/type validation.
	recordsSubspace := store.subspace.Sub(RecordKey)
	splitEnabled := store.metaData.IsSplitLongRecords()
	var oldsizeInfo sizeInfo
	loadTimer := recordLoadTimer{timer: store.context.Timer(), start: time.Now()}
	defer loadTimer.finish()
	load := store.startRecordLoad(store.context.Transaction(), primaryKey)
	oldValue, oldVersion, err := load.raw.finish(&oldsizeInfo)
	if err != nil {
		return nil, fmt.Errorf("load existing record: %w", err)
	}
	oldRecordExists := oldValue != nil
	// A dry run loads the existing record through the serializer too
	// (saveTypedRecord's loadExistingRecord precedes its isDryRun return), so a
	// record the store cannot read fails the preview as it fails the save.
	var oldRT *RecordType
	var oldMsg proto.Message
	var oldWire *recordWire
	if oldRecordExists {
		var deserErr error
		oldRT, oldMsg, oldWire, deserErr = store.deserializeAndDiscover(oldValue)
		if deserErr != nil {
			return nil, &RecordDeserializationError{PrimaryKey: primaryKey, Cause: deserErr}
		}
	}

	if oldRecordExists {
		if _, err := load.finishVersion(oldVersion); err != nil {
			return nil, fmt.Errorf("load old record version for dry-run save: %w", err)
		}
	}

	loadTimer.finish()

	if existenceCheck.ErrorIfExists() && oldRecordExists {
		return nil, &RecordAlreadyExistsError{
			Message:    "record already exists",
			PrimaryKey: primaryKey,
		}
	}

	if existenceCheck.ErrorIfNotExists() && !oldRecordExists {
		return nil, &RecordDoesNotExistError{
			Message:    "record does not exist",
			PrimaryKey: primaryKey,
		}
	}

	if existenceCheck.ErrorIfTypeChanged() && oldRecordExists {
		existingTypeName := string(oldMsg.ProtoReflect().Descriptor().Name())
		if existingTypeName != recordTypeName {
			return nil, &RecordTypeChangedError{
				Message:      "record type changed",
				PrimaryKey:   primaryKey,
				ActualType:   existingTypeName,
				ExpectedType: recordTypeName,
			}
		}
	}

	// NOTE: deliberately NO validateRecordUpdateAllowed() here. Java's
	// saveTypedRecord(isDryRun=true) early-returns at FDBRecordStore.java:578 — BEFORE the
	// store-lock check validateRecordUpdateAllowed(recordStoreState) at line 584, which lives
	// only in the non-dry-run continuation. So on a FORBID_RECORD_UPDATE-locked store Java's
	// DRY RUN INSERT/UPDATE previews SUCCESS; calling the lock check here would make Go
	// STRICTER than Java (rejecting a preview Java allows). DryRunDeleteRecord already skips it
	// for the same reason (Java line 1735). Pinned by TestFDB_DmlDryRun_LockedStorePreviews.

	// Serialize as the save would, over the stored record (a type holding a map
	// is written in the stored record's map order), so the preview's sizes are
	// the save's.
	data, err := serializeUnionOver(writeRecord, recordType, priorRecordInner(oldRT, oldWire, recordType))
	if err != nil {
		return nil, &RecordSerializationError{Cause: err}
	}
	stored, err := store.writeStoredRecord(data, recordType, primaryKey)
	if err != nil {
		return nil, err
	}

	// Java's dryRunSetSizeInfo: the stored bytes' keys and values, chunk by
	// chunk, as the save would write them.
	sizes := dryRunSaveWithSplitSizeInfo(recordsSubspace, primaryKey, stored, splitEnabled, store.omitUnsplitRecordSuffix())

	// The inline version's key and value (dryRunWriteVersionSizeInfo). Java
	// passes no version in the old version format (splitVersion is null when
	// useOldVersionFormat), whose version lives in its own subspace.
	if store.metaData.IsStoreRecordVersions() && !store.useOldVersionFormat() {
		sizes.KeyCount++
		sizes.KeySize += len(store.versionKey(primaryKey))
		// A tuple-packed Versionstamp: VersionBytes (12) and its type code, the
		// incomplete version's 4-byte offset excluded as Java excludes it.
		sizes.ValueSize += VersionBytes + 1
		sizes.VersionedInline = true
	}

	return &FDBStoredRecord[proto.Message]{
		PrimaryKey:      primaryKey,
		Record:          record,
		RecordType:      recordType,
		Version:         target.version,
		KeyCount:        sizes.KeyCount,
		KeySize:         sizes.KeySize,
		ValueSize:       sizes.ValueSize,
		Split:           sizes.IsSplit,
		VersionedInline: sizes.VersionedInline,
	}, nil
}

// DryRunDeleteRecord checks whether a record with the given primary key exists
// and could be deleted, without actually deleting it.
// Returns true if the record exists (and would be deleted), false if not found.
// Note: does NOT check store lock state, matching Java's dryRunDeleteRecordAsync
// which only loads the record without calling validateRecordUpdateAllowed.
// Matches Java's FDBRecordStore.dryRunDeleteRecordAsync().
func (store *FDBRecordStore) DryRunDeleteRecord(primaryKey tuple.Tuple) (bool, error) {
	defer store.context.Timer().RecordSince(EventLoadRecord, time.Now())
	var sizeInfo sizeInfo
	load := store.startRecordLoad(store.context.Transaction(), primaryKey)
	value, version, err := load.raw.finish(&sizeInfo)
	if err != nil {
		return false, fmt.Errorf("dry run delete record: %w", err)
	}
	if value == nil {
		return false, nil
	}
	// Java's dry run loads the record through the serializer
	// (deleteTypedRecord's loadTypedRecord), so one the store cannot read
	// fails the preview as it fails the delete.
	if _, _, _, err := store.deserializeAndDiscover(value); err != nil {
		return false, &RecordDeserializationError{PrimaryKey: primaryKey, Cause: err}
	}
	if _, err := load.finishVersion(version); err != nil {
		return false, fmt.Errorf("load old record version for dry-run delete: %w", err)
	}
	return true, nil
}

// IsIndexReadableUniquePending returns true if the index is in READABLE_UNIQUE_PENDING state.
// This state means the unique index is fully indexed but may have duplicate entries.
// Matches Java's FDBRecordStoreBase.isIndexReadableUniquePending().
func (store *FDBRecordStore) IsIndexReadableUniquePending(indexName string) bool {
	return store.GetIndexState(indexName) == IndexStateReadableUniquePending
}

// GetWriteOnlyIndexes returns all indexes that are in WRITE_ONLY state.
// These are indexes currently being built by an OnlineIndexer.
// Matches Java's FDBRecordStoreBase.getWriteOnlyIndexes() (derived from getAllIndexStates).
func (store *FDBRecordStore) GetWriteOnlyIndexes() []*Index {
	var result []*Index
	for _, idx := range store.metaData.GetAllIndexes() {
		if store.GetIndexState(idx.Name).IsWriteOnly() {
			result = append(result, idx)
		}
	}
	return result
}

// GetDisabledIndexes returns all indexes that are in DISABLED state.
// These indexes are not maintained or readable.
// Matches Java's FDBRecordStoreBase.getDisabledIndexes() (derived from getAllIndexStates).
func (store *FDBRecordStore) GetDisabledIndexes() []*Index {
	var result []*Index
	for _, idx := range store.metaData.GetAllIndexes() {
		if store.GetIndexState(idx.Name) == IndexStateDisabled {
			result = append(result, idx)
		}
	}
	return result
}

// GetIndexesToBuildSince returns all indexes that need to be built because they were
// added or modified since the given metadata version.
// Matches Java's FDBRecordStore.getIndexesToBuildSince(version).
func (store *FDBRecordStore) GetIndexesToBuildSince(version int) []*Index {
	return store.metaData.GetIndexesToBuildSince(version)
}

// ResolveUniquenessViolationByDeletion resolves uniqueness violations for a specific
// index value key by deleting all records that violate uniqueness, except for the
// record with remainPrimaryKey (if non-nil). If remainPrimaryKey is nil, all violating
// records are deleted.
// Matches Java's FDBRecordStore.resolveUniquenessViolation(index, valueKey, remainPrimaryKey).
func (store *FDBRecordStore) ResolveUniquenessViolationByDeletion(
	index *Index,
	valueKey tuple.Tuple,
	remainPrimaryKey tuple.Tuple,
) error {
	violations, err := store.ScanUniquenessViolationsForValue(index, valueKey)
	if err != nil {
		return fmt.Errorf("resolve uniqueness violation: %w", err)
	}
	for _, v := range violations {
		if remainPrimaryKey != nil && tuplesEqual(v.PrimaryKey, remainPrimaryKey) {
			continue
		}
		if _, err := store.DeleteRecord(v.PrimaryKey); err != nil {
			return fmt.Errorf("resolve uniqueness violation: delete pk=%v: %w", v.PrimaryKey, err)
		}
	}
	return nil
}

// ScanUniquenessViolationsForValue returns uniqueness violations for a specific index
// value key. This filters violations to only those matching the given value key.
// Matches Java's StandardIndexMaintainer.scanUniquenessViolations(index, valueKey).
func (store *FDBRecordStore) ScanUniquenessViolationsForValue(
	index *Index,
	valueKey tuple.Tuple,
) ([]UniquenessViolation, error) {
	violationSubspace := store.subspace.Sub(IndexUniquenessViolationsKey, index.SubspaceTupleKey())
	// Java's TupleRange.allOf(valueKey): a byte prefix range would also return, and
	// resolve by deletion, the violations of values whose packing extends it.
	kvs, err := store.context.Transaction().GetRange(violationSubspace.Sub(valueKey...), fdb.RangeOptions{}).GetSliceWithError()
	if err != nil {
		return nil, fmt.Errorf("scan violations for value on index %q: %w", index.Name, err)
	}

	colCount := index.RootExpression.ColumnSize()
	var violations []UniquenessViolation
	for _, kv := range kvs {
		t, err := tuplefast.SubspaceUnpack(kv.Key, len(violationSubspace.Bytes()))
		if err != nil {
			return nil, fmt.Errorf("unpack violation key: %w", err)
		}
		if len(t) > colCount {
			v := UniquenessViolation{
				IndexName:  index.Name,
				IndexKey:   tuple.Tuple(t[:colCount]),
				PrimaryKey: tuple.Tuple(t[colCount:]),
			}
			if len(kv.Value) > 0 {
				existingKey, err := tuplefast.Unpack(kv.Value)
				if err == nil {
					v.ExistingKey = existingKey
				}
			}
			violations = append(violations, v)
		}
	}
	return violations, nil
}

// EstimateRecordsSizeInRange returns the estimated size in bytes of records within
// the given tuple range. Uses FDB's native GetEstimatedRangeSizeBytes.
// Matches Java's FDBRecordStore.estimateRecordsSizeAsync(TupleRange).
func (store *FDBRecordStore) EstimateRecordsSizeInRange(tupleRange TupleRange) (int64, error) {
	recordsSubspace := store.subspace.Sub(RecordKey)
	fdbRange := tupleRange.ToFDBRange(recordsSubspace)
	return store.context.Transaction().GetEstimatedRangeSizeBytes(fdbRange).Get()
}

// EstimateIndexSize returns the estimated size in bytes of a specific index.
// Uses FDB's native GetEstimatedRangeSizeBytes on the index's subspace.
func (store *FDBRecordStore) EstimateIndexSize(index *Index) (int64, error) {
	indexSub := store.indexSubspace(index)
	return store.context.Transaction().GetEstimatedRangeSizeBytes(indexSub).Get()
}

// GetRangeSplitPoints returns split points that divide the store's records subspace
// into approximately equal-sized chunks of the given byte size. Useful for
// parallelizing scans across multiple transactions.
// Uses FDB's native GetRangeSplitPoints which is efficient for large datasets.
func (store *FDBRecordStore) GetRangeSplitPoints(chunkSize int64) ([]fdb.Key, error) {
	recordsSub := store.subspace.Sub(RecordKey)
	return store.context.Transaction().GetRangeSplitPoints(recordsSub, chunkSize).Get()
}

// ScanRecordKeys scans only the primary keys of records without deserializing
// record data. This is significantly faster than ScanRecords when you only need
// the keys (avoids protobuf deserialization overhead).
// Split records (multiple KV entries per PK) are automatically deduplicated.
// Matches Java's FDBRecordStore.scanRecordKeys().
func (store *FDBRecordStore) ScanRecordKeys(
	continuation []byte,
	scanProperties ScanProperties,
) RecordCursor[tuple.Tuple] {
	return &recordKeyCursor{
		store:          store,
		continuation:   continuation,
		scanProperties: scanProperties,
		scanState:      resolveScanLimiterState(scanProperties.ExecuteProperties),
		// Bare-key layout applies ONLY when the store does not split long records
		// (a split-capable store always suffixes its keys). Matches Java's
		// scanRecordKeys, which gates the bare-key branch on !isSplitLongRecords().
		omitUnsplitRecordSuffix: store.omitUnsplitRecordSuffix() && !store.metaData.IsSplitLongRecords(),
	}
}
