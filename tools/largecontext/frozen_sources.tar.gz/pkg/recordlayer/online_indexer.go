// Portions derived from FoundationDB Record Layer (OnlineIndexer.java,
// IndexingBase.java, OnlineIndexOperationConfig.java, IndexingByIndex.java,
// and others),
// Copyright 2015-2018 Apple Inc. and the FoundationDB project authors
// Copyright 2015-2020 Apple Inc. and the FoundationDB project authors
// Copyright 2015-2024 Apple Inc. and the FoundationDB project authors
// Licensed under the Apache License, Version 2.0; translated to Go and modified.

package recordlayer

import (
	"bytes"
	"context"
	"errors"
	"fmt"
	"log/slog"
	"slices"
	"sort"
	"strings"
	"time"

	"fdb.dev/pkg/recordlayer/internal/tuplefast"

	"fdb.dev/gen"
	"fdb.dev/pkg/dst"
	"fdb.dev/pkg/fdbgo/fdb"
	"fdb.dev/pkg/fdbgo/fdb/subspace"
	"fdb.dev/pkg/fdbgo/fdb/tuple"
	"github.com/google/uuid"
	"google.golang.org/protobuf/proto"
)

// TakeoverType represents allowed build method conversions when resuming an index build
// that was started by a different indexing method.
// Matches Java's OnlineIndexer.IndexingPolicy.TakeoverTypes.
type TakeoverType int

const (
	// TakeoverMultiTargetToSingle allows a single-target BY_RECORDS build to continue
	// a MULTI_TARGET_BY_RECORDS build.
	TakeoverMultiTargetToSingle TakeoverType = iota
	// TakeoverMutualToSingle allows a single-target BY_RECORDS build to continue
	// a MUTUAL_BY_RECORDS build.
	TakeoverMutualToSingle
	// TakeoverByRecordsToMutual allows a MUTUAL_BY_RECORDS build to continue
	// a BY_RECORDS or MULTI_TARGET_BY_RECORDS build.
	TakeoverByRecordsToMutual
)

// IndexingDesiredAction is what a build session does with the index state it
// finds. Matches Java's OnlineIndexer.IndexingPolicy.DesiredAction.
type IndexingDesiredAction int

const (
	// DesiredActionDefault leaves the choice to Java's builder default for the
	// state: REBUILD if disabled, CONTINUE if write-only or readable. It is the
	// zero value, so an IndexingPolicy that never mentions a state gets Java's
	// default for it.
	DesiredActionDefault IndexingDesiredAction = iota
	// DesiredActionError refuses to start a session over the state.
	DesiredActionError
	// DesiredActionRebuild clears the index and builds it from scratch.
	DesiredActionRebuild
	// DesiredActionContinue continues a write-only build, builds a disabled index
	// without clearing it, and leaves a readable index alone.
	DesiredActionContinue
	// DesiredActionMarkReadable publishes the index without building it.
	DesiredActionMarkReadable
)

// IndexingPolicy configures how the OnlineIndexer handles stamp conflicts,
// blocked stamps, and build method conversions.
// Matches Java's OnlineIndexer.IndexingPolicy.
type IndexingPolicy struct {
	// IfDisabled, IfWriteOnly and IfReadable choose what a session does with the
	// primary index's state (Java ifDisabled/ifWriteOnly/ifReadable). The zero
	// value is Java's default for that state; see GetStateDesiredAction.
	IfDisabled  IndexingDesiredAction
	IfWriteOnly IndexingDesiredAction
	IfReadable  IndexingDesiredAction

	// IfMismatchPrevious chooses what BuildIndex does when the index is partly
	// built by a different method than the one requested (Java
	// ifMismatchPrevious, read by OnlineIndexer.indexingCatcher). CONTINUE, the
	// zero value's meaning, continues the previous method; REBUILD clears and
	// builds by the requested one; ERROR and MARK_READABLE return the
	// PartlyBuiltError. See GetIfMismatchPrevious.
	IfMismatchPrevious IndexingDesiredAction

	// ForbidRecordScan stops a BY_INDEX build whose source index cannot be used
	// from falling back to a records scan (Java forbidRecordScan).
	ForbidRecordScan bool

	// InitialMergesCountLimit is the initial deferred-merge budget (zero is unlimited).
	InitialMergesCountLimit int64
	// ForceStampOverwrite forces writing the stamp without conflict checks on
	// fresh (non-continued) builds, or allows overwriting on continued builds
	// when no records have been scanned. Used internally during rebuild.
	ForceStampOverwrite bool

	// AllowUnblock permits unblocking a blocked stamp during resume.
	AllowUnblock bool

	// AllowUnblockID restricts unblocking to stamps with a matching blockID.
	// Empty string means any blockID is accepted (when AllowUnblock is true).
	AllowUnblockID string

	// AllowedTakeovers is the set of allowed build method conversions.
	AllowedTakeovers map[TakeoverType]bool

	// PendingWriteQueueIndexes explicitly requests deferred maintenance by index name.
	PendingWriteQueueIndexes map[string]bool
	// Nil selects Java's default of 100 closeout attempts; zero remains explicit.
	PendingWriteQueueIndexesMaxDrainAttempts *int64
}

// GetStateDesiredAction resolves what a session does with an index in state.
// Matches Java's IndexingPolicy.getStateDesiredAction, with the builder defaults
// (IndexingPolicy.Builder: ifDisabled REBUILD, ifWriteOnly CONTINUE, ifReadable
// CONTINUE) standing in for an unset field. READABLE_UNIQUE_PENDING is always
// MARK_READABLE, as in Java: the index is built and only publication remains.
func (p *IndexingPolicy) GetStateDesiredAction(state IndexState) (IndexingDesiredAction, error) {
	var set, def IndexingDesiredAction
	switch state {
	case IndexStateDisabled:
		def = DesiredActionRebuild
		if p != nil {
			set = p.IfDisabled
		}
	case IndexStateWriteOnly, IndexStateWriteOnlyWithQueue:
		def = DesiredActionContinue
		if p != nil {
			set = p.IfWriteOnly
		}
	case IndexStateReadable:
		def = DesiredActionContinue
		if p != nil {
			set = p.IfReadable
		}
	case IndexStateReadableUniquePending:
		return DesiredActionMarkReadable, nil
	default:
		return 0, &RecordCoreError{Message: "bad index state: " + state.String()}
	}
	switch set {
	case DesiredActionDefault:
		return def, nil
	case DesiredActionError, DesiredActionRebuild, DesiredActionContinue, DesiredActionMarkReadable:
		return set, nil
	default:
		return 0, &RecordCoreError{Message: fmt.Sprintf("bad indexing desired action %d for index state %s", int(set), state)}
	}
}

// GetIfMismatchPrevious resolves IfMismatchPrevious, with Java's builder default
// CONTINUE standing in for an unset field (IndexingPolicy.Builder). An action
// outside the enum is a RecordCoreError, as in GetStateDesiredAction.
func (p *IndexingPolicy) GetIfMismatchPrevious() (IndexingDesiredAction, error) {
	if p == nil || p.IfMismatchPrevious == DesiredActionDefault {
		return DesiredActionContinue, nil
	}
	switch p.IfMismatchPrevious {
	case DesiredActionError, DesiredActionRebuild, DesiredActionContinue, DesiredActionMarkReadable:
		return p.IfMismatchPrevious, nil
	}
	return 0, &RecordCoreError{Message: fmt.Sprintf("bad indexing desired action %d for a mismatched previous build", int(p.IfMismatchPrevious))}
}

// withIfWriteOnly is Java's policy.toBuilder().setIfWriteOnly(action).build():
// the catcher's retries replace the indexer's policy and never write through
// the caller's pointer.
func (p *IndexingPolicy) withIfWriteOnly(action IndexingDesiredAction) *IndexingPolicy {
	var copied IndexingPolicy
	if p != nil {
		copied = *p
	}
	copied.IfWriteOnly = action
	return &copied
}

func (p *IndexingPolicy) ShouldUsePendingWriteQueue(index *Index) bool {
	return p != nil && p.PendingWriteQueueIndexes[index.Name]
}

func (p *IndexingPolicy) GetPendingWriteQueueIndexesMaxDrainAttempts() int64 {
	if p == nil || p.PendingWriteQueueIndexesMaxDrainAttempts == nil {
		return 100
	}
	return *p.PendingWriteQueueIndexesMaxDrainAttempts
}

// ShouldAllowUnblock returns true if the policy allows unblocking a stamp with the given blockID.
// Matches Java's IndexingPolicy.shouldAllowUnblock().
func (p *IndexingPolicy) ShouldAllowUnblock(stampBlockID string) bool {
	if p == nil || !p.AllowUnblock {
		return false
	}
	return p.AllowUnblockID == "" || p.AllowUnblockID == stampBlockID
}

// ShouldAllowTypeConversionContinue returns true if switching from savedStamp's method
// to newStamp's method is permitted by the policy.
// Matches Java's IndexingPolicy.shouldAllowTypeConversionContinue().
func (p *IndexingPolicy) ShouldAllowTypeConversionContinue(newStamp, savedStamp *gen.IndexBuildIndexingStamp) bool {
	if p == nil || len(p.AllowedTakeovers) == 0 {
		return false
	}
	newMethod := newStamp.GetMethod()
	oldMethod := savedStamp.GetMethod()

	if newMethod == gen.IndexBuildIndexingStamp_BY_RECORDS {
		if oldMethod == gen.IndexBuildIndexingStamp_MULTI_TARGET_BY_RECORDS {
			return p.AllowedTakeovers[TakeoverMultiTargetToSingle]
		}
		if oldMethod == gen.IndexBuildIndexingStamp_MUTUAL_BY_RECORDS {
			return p.AllowedTakeovers[TakeoverMutualToSingle]
		}
	}

	if newMethod == gen.IndexBuildIndexingStamp_MUTUAL_BY_RECORDS {
		if !p.AllowedTakeovers[TakeoverByRecordsToMutual] {
			return false
		}
		if oldMethod == gen.IndexBuildIndexingStamp_MULTI_TARGET_BY_RECORDS {
			// Allow if same set of targets or single target.
			if len(newStamp.GetTargetIndex()) == 1 {
				return true
			}
			newTargets := newStamp.GetTargetIndex()
			oldTargets := savedStamp.GetTargetIndex()
			if len(newTargets) != len(oldTargets) {
				return false
			}
			oldSet := make(map[string]bool, len(oldTargets))
			for _, t := range oldTargets {
				oldSet[t] = true
			}
			for _, t := range newTargets {
				if !oldSet[t] {
					return false
				}
			}
			return true
		}
		if oldMethod == gen.IndexBuildIndexingStamp_BY_RECORDS {
			return len(newStamp.GetTargetIndex()) == 1
		}
	}
	return false
}

// isTypeStampBlocked returns true if the stamp has an active block.
// Matches Java's IndexingBase.isTypeStampBlocked().
//
// now comes from the DST clock seam, not time.Now. The WRITE side of this field already does
// (rtx.Env().Now().Add(ttl) where the stamp's expiry is minted), so a wall-clock read compares
// a simulated timestamp against real time — and the simulated clock starts at a fixed epoch far
// in the past, so under a sim env every expiry it wrote reads back as ALREADY EXPIRED. The
// branch a simulation exercises is then the opposite of the branch it wrote, which is worse than
// no coverage: the run looks like it tested the blocked path and tested the unblocked one.
func isTypeStampBlocked(stamp *gen.IndexBuildIndexingStamp, now time.Time) bool {
	if !stamp.GetBlock() {
		return false
	}
	expiry := stamp.GetBlockExpireEpochMilliSeconds()
	if expiry == 0 {
		return true // permanent block
	}
	return expiry > uint64(now.UnixMilli())
}

// areSimilarStamps returns true if two stamps differ only in block-related fields.
// Matches Java's IndexingBase.areSimilar().
func areSimilarStamps(a, b *gen.IndexBuildIndexingStamp) bool {
	if proto.Equal(a, b) {
		return true
	}
	return proto.Equal(blocklessStampOf(a), blocklessStampOf(b))
}

// blocklessStampOf returns a copy of the stamp with all block fields cleared.
// Matches Java's IndexingBase.blocklessStampOf().
func blocklessStampOf(stamp *gen.IndexBuildIndexingStamp) *gen.IndexBuildIndexingStamp {
	clone := proto.Clone(stamp).(*gen.IndexBuildIndexingStamp)
	clone.Block = nil
	clone.BlockID = nil
	clone.BlockExpireEpochMilliSeconds = nil
	return clone
}

// IndexBuildState reports the current state of an index build.
// Matches Java's com.apple.foundationdb.record.provider.foundationdb.IndexBuildState.
type IndexBuildState struct {
	State          IndexState
	RecordsScanned *int64 // nil if not WRITE_ONLY or not tracked
	RecordsInTotal *int64 // nil if no COUNT index available
}

// LoadIndexBuildState loads the build state for an index within an open store.
// Matches Java's IndexBuildState.loadIndexBuildStateAsync().
func LoadIndexBuildState(store *FDBRecordStore, index *Index) (*IndexBuildState, error) {
	state, err := store.readIndexState(index.Name)
	if err != nil {
		return nil, fmt.Errorf("load build state: %w", err)
	}
	if !state.IsWriteOnly() {
		return &IndexBuildState{State: state}, nil
	}

	scanned, err := store.LoadBuildProgress(index)
	if err != nil {
		return nil, fmt.Errorf("load build state: %w", err)
	}

	result := &IndexBuildState{
		State:          state,
		RecordsScanned: &scanned,
	}

	// Total record count, from the maintained counters or from a universal COUNT
	// index. Java catches exactly AggregateFunctionNotSupportedException here —
	// "very likely it is because there is no suitable COUNT type index defined" —
	// and reports an unknown total (IndexBuildState.java:76-82). Every other failure
	// propagates: a read error is not "no COUNT index".
	total, err := store.GetRecordCount()
	switch {
	case err == nil:
		result.RecordsInTotal = &total
	case errors.As(err, new(*AggregateFunctionNotSupportedError)):
		// RecordsInTotal stays nil.
	default:
		return nil, fmt.Errorf("load build state: %w", err)
	}

	return result, nil
}

// TimeLimitExceededError is returned when the OnlineIndexer's overall time limit is exceeded.
// Matches Java's com.apple.foundationdb.record.provider.foundationdb.IndexingBase.TimeLimitException.
type TimeLimitExceededError struct {
	TimeLimit time.Duration
	Elapsed   time.Duration
}

func (e *TimeLimitExceededError) Error() string {
	return fmt.Sprintf("online indexer time limit exceeded: limit=%v, elapsed=%v", e.TimeLimit, e.Elapsed)
}

func (*TimeLimitExceededError) JavaRecordCoreException() {}

// OnlineIndexer builds indexes on existing data across multiple transactions.
// Each transaction processes a chunk of records, tracks progress via IndexingRangeSet,
// and the build resumes from where it left off if interrupted.
//
// Supports four modes:
//   - BY_RECORDS (default, single target): scans all records in primary key order
//   - BY_INDEX (single target): scans an existing readable VALUE index to find records
//   - MULTI_TARGET_BY_RECORDS: scans records once, builds multiple indexes simultaneously
//   - MUTUAL_BY_RECORDS: concurrent multi-process building with fragment-based work division
//
// Matches Java's OnlineIndexer with IndexingByRecords, IndexingByIndex,
// IndexingMultiTargetByRecords, and IndexingMutuallyByRecords.
type OnlineIndexer struct {
	mergeRequiredIndexes []*Index
	mergers              map[string]*indexingMerger
	db                   *FDBDatabase
	metaData             *RecordMetaData
	targetIndexes        []*Index           // target indexes to build (first = primary for range tracking)
	queuedIndexes        []*Index           // reconstructed from persisted states after preparation commits
	sessionHeartbeat     *IndexingHeartbeat // stable across all transactions of the build
	admittedHeartbeat    *IndexingHeartbeat // published only after preparation commits
	retiredBuildTargets  map[string]bool    // commit-bound completion; targetIndexes still defines stamp identity
	sourceIndex          *Index             // non-nil = BY_INDEX strategy (single target only)
	subspace             subspace.Subspace
	limit                int
	maxRetries           int // max retries per range on transient failures (0 = no retries)
	// maxAttempts bounds each transaction the indexer runs (Java's runner
	// maxAttempts, OnlineIndexOperationBaseBuilder.setMaxAttempts); 0 means the
	// database's (default 10). maxRetries' lessen-work retries run over it.
	maxAttempts      int
	recordsPerSecond int // inter-transaction rate limit (0 = unlimited, default 10000)
	// enforcedPostTransactionDelay, if > 0, is a fixed per-transaction delay (ms) applied
	// INSTEAD of recordsPerSecond. Java OnlineIndexOperationConfig.enforcedPostTransactionDelay.
	enforcedPostTransactionDelay int
	timeLimit                    time.Duration     // overall build time limit (0 = unlimited)
	recordTypes                  []string          // record types to index (empty = all types; not allowed with multi-target)
	policy                       *IndexingPolicy   // stamp conflict resolution policy (nil = default behavior)
	throttle                     *indexingThrottle // adaptive throttle (created at Build time)
	mutual                       bool              // the policy asks for MUTUAL_BY_RECORDS; see buildsMutually
	// fallbackToRecordsScan is set by the build catcher when the requested
	// method cannot be used and the build continues as a records scan (Java
	// OnlineIndexer.fallbackToRecordsScan). Like Java's, it is never reset: a
	// later BuildIndex on the same indexer keeps scanning records.
	fallbackToRecordsScan bool

	// initialLimit, increaseLimitAfter, maxWriteLimitBytes and
	// transactionTimeLimitMs are Java's OnlineIndexOperationConfig fields of
	// those names: the starting per-transaction limit (0 = limit), the
	// successes before a re-increase, and the approximate transaction size and
	// age past which a range commits early (0 = no such limit).
	initialLimit           int
	increaseLimitAfter     int
	maxWriteLimitBytes     int64
	transactionTimeLimitMs int64
	// enforcedStampOverwrite is Java IndexingBase.enforceStampOverwrite, set with
	// the fallback: the records scan must replace the abandoned method's stamp.
	enforcedStampOverwrite bool
	// indexerID is this indexer's heartbeat identity, minted once (Java
	// IndexingCommon.indexerId): every attempt the catcher runs writes its
	// heartbeat under it, so an attempt never mistakes the previous attempt's
	// heartbeat for a live peer. Merges use it as their merge session ID.
	indexerID uuid.UUID
	// lastOutcome is what the last completed BuildIndex did; see LastBuildOutcome.
	lastOutcome      IndexBuildOutcome
	mutualBoundaries [][]byte // pre-set fragment boundaries (nil: read from the shard map)
	leaseLengthMs    int64    // heartbeat lease duration in ms (default defaultLeaseLengthMs)
	// markReadableEnabled controls whether BuildIndex marks the index readable (and
	// thus erases the per-build bookkeeping) at the end. Defaults to true. Matches
	// Java's OnlineIndexer.buildIndex(boolean markReadable): set false to build the
	// index data while leaving it WRITE_ONLY with its build stamp/progress intact
	// (e.g. to inspect or resume the build).
	markReadableEnabled bool

	// allowUniquePendingState opts in to leaving a unique index in
	// READABLE_UNIQUE_PENDING when the build finds duplicates, instead of failing
	// the build. Java OnlineIndexer.IndexingPolicy.Builder.allowUniquePendingState,
	// whose field defaults FALSE (OnlineIndexer.java:1220) and whose javadoc states
	// the contract exactly: "allow=false (default, backward compatible): throw an
	// exception."
	//
	// It is deliberately NOT enough on its own — see shouldAllowUniquePendingState.
	allowUniquePendingState bool

	// formatVersion pins the format version every store this indexer opens uses;
	// 0 means the newest this binary knows. Java carries it on the shared
	// record-store builder rather than as a separate indexer field.
	formatVersion *int32

	// maintenanceFilter is the IndexMaintenanceFilter every store this indexer
	// opens uses, so the build maintains the entries the store's writes do.
	// Java carries it on the shared record-store builder too.
	maintenanceFilter IndexMaintenanceFilter

	// storeTemplate is the caller's record-store builder (SetRecordStoreBuilder,
	// SetRecordStore), context-free: every store the indexer opens is opened
	// through a copy of it, so it carries what the caller configured and the
	// indexer has no field for (the serializer among it). Nil opens a fresh
	// builder.
	storeTemplate *StoreBuilder

	// progressLogIntervalMillis throttles the per-range "Indexer: Built Range"
	// progress log (see maybeLogBuildProgress). Matches Java
	// OnlineIndexOperationConfig.progressLogIntervalMillis:
	//   <0  → never log (DEFAULT_PROGRESS_LOG_INTERVAL = -1, disabled);
	//    0  → log after every range;
	//   >0  → log at most once per this many milliseconds.
	progressLogIntervalMillis int64
	// timeOfLastProgressLogMillis is the throttle clock for the progress log
	// (Java IndexingBase.timeOfLastProgressLogMillis). Mutated only by
	// shouldLogBuildProgress, which runs single-threaded in the build loop.
	timeOfLastProgressLogMillis int64
	// logger receives the operational progress events. nil → slog.Default() at
	// log time, mirroring the client's WithLogger convention (RFC-097) so a
	// zero-config app keeps the standard slog integration and tests never mutate
	// process globals.
	logger *slog.Logger
}

// shouldAllowUniquePendingState reports whether a finished build may leave a
// unique index in READABLE_UNIQUE_PENDING rather than failing on duplicates.
//
// Port of Java's OnlineIndexer.IndexingPolicy.shouldAllowUniquePendingState
// (OnlineIndexer.java:1117-1120), which is an AND of two independent conditions:
//
//	return allowUniquePendingState
//	        && store.getFormatVersionEnum().isAtLeast(FormatVersion.READABLE_UNIQUE_PENDING);
//
// The format-version half is not redundant belt-and-braces. READABLE_UNIQUE_PENDING
// is format version 9 (FormatVersion.java:145); writing that state into a store an
// older binary can still open would hand it an index state it cannot interpret. The
// opt-in alone must therefore never be sufficient.
func (oi *OnlineIndexer) shouldAllowUniquePendingState(store *FDBRecordStore) bool {
	return oi.allowUniquePendingState &&
		store.GetFormatVersion() >= int32(formatVersionReadableUniquePending)
}

// primaryIndex returns the first target index, which drives range tracking.
func (oi *OnlineIndexer) primaryIndex() *Index {
	return oi.targetIndexes[0]
}

// isMultiTarget returns true if building multiple indexes simultaneously.
func (oi *OnlineIndexer) isMultiTarget() bool {
	return len(oi.targetIndexes) > 1
}

// buildsMutually and buildsByIndex pick the build method the way Java's
// OnlineIndexer.getIndexer picks the indexer: mutual first, then by index for a
// single target, and a records scan once the catcher has fallen back. The
// policy's own mutual flag (oi.mutual) still decides what Java decides from
// policy.isMutual() rather than from the indexer: the queue refusals and the
// catcher's UnexpectedReadable arm.
func (oi *OnlineIndexer) buildsMutually() bool {
	return oi.mutual && !oi.fallbackToRecordsScan
}

func (oi *OnlineIndexer) buildsByIndex() bool {
	return oi.sourceIndex != nil && !oi.isMultiTarget() && !oi.fallbackToRecordsScan && !oi.buildsMutually()
}

// newHeartbeat is a heartbeat under this indexer's one identity, minted from
// env the first time it is needed.
func (oi *OnlineIndexer) newHeartbeat(info string, allowMutual bool, env *dst.Env) *IndexingHeartbeat {
	return newIndexingHeartbeatWithID(oi.ensureIndexerID(env), info, resolvedLeaseLengthMs(oi.leaseLengthMs), allowMutual, env)
}

// ensureIndexerID mints this indexer's one identity from env on first use.
func (oi *OnlineIndexer) ensureIndexerID(env *dst.Env) uuid.UUID {
	if oi.indexerID == uuid.Nil {
		oi.indexerID = newIndexerID(env)
	}
	return oi.indexerID
}

// IndexBuildOutcome is what a BuildIndex call did. It is a Go extension: Java's
// buildIndex returns nothing, and a session that left a READABLE index alone,
// one that only published, and a build over an empty store all return 0 records.
type IndexBuildOutcome int

const (
	// IndexBuildOutcomeNone: no BuildIndex call has completed, or the last one
	// failed.
	IndexBuildOutcomeNone IndexBuildOutcome = iota
	// IndexBuildOutcomeBuilt: the call succeeded and built. Either the attempt
	// that ended it ran the build over the targets' ranges (published unless
	// publication was disabled), which it counts even when it indexed no
	// records, as over an empty store; or an earlier attempt indexed records
	// and failed into a retry, whatever the attempt that ended the call then
	// found: the targets published, which it may have done itself
	// (MARK_READABLE), or a mutual build its peers completed.
	IndexBuildOutcomeBuilt
	// IndexBuildOutcomeLeftAlone: the call neither built nor published. That
	// covers two cases: the primary index was READABLE under CONTINUE (what frl
	// reports as already readable), or MARK_READABLE was resolved with
	// publication disabled (unreachable from frl, which always publishes).
	IndexBuildOutcomeLeftAlone
	// IndexBuildOutcomePublished: the call published the targets without
	// building them (MARK_READABLE).
	IndexBuildOutcomePublished
	// IndexBuildOutcomeCompletedByPeers: a mutual build found every target
	// already published by its peers, and this call indexed nothing.
	IndexBuildOutcomeCompletedByPeers
)

// LastBuildOutcome reports what the last BuildIndex call did, over all of its
// attempts, when it returned no error; IndexBuildOutcomeNone before any call,
// and after a call that failed, whatever an earlier call of the same indexer
// did.
func (oi *OnlineIndexer) LastBuildOutcome() IndexBuildOutcome {
	return oi.lastOutcome
}

// OnlineIndexerBuilder constructs an OnlineIndexer.
type OnlineIndexerBuilder struct {
	indexer OnlineIndexer
	// setIndexErr is the refusal Java's setIndex throws when targets are already
	// set (OnlineIndexer.java:668-671). Go's builder chains, so the refusal is
	// held here and Build returns it before anything else, where Java's would
	// have been thrown before build() was reached.
	setIndexErr error
}

// NewOnlineIndexerBuilder creates a new builder.
func NewOnlineIndexerBuilder() *OnlineIndexerBuilder {
	return &OnlineIndexerBuilder{
		indexer: OnlineIndexer{
			limit: 100,
			// Java OnlineIndexOperationConfig.Builder defaults maxRetries to
			// DEFAULT_MAX_RETRIES = 100 (OnlineIndexOperationConfig.java:52,251). A 0
			// default would leave every caller that never touches the builder without
			// the adaptive limit-halving, so one transaction_too_large escaping the
			// client's own retry loop aborts an otherwise-resumable build.
			maxRetries:          100,
			recordsPerSecond:    10000, // matches Java DEFAULT_RECORDS_PER_SECOND
			markReadableEnabled: true,  // Java buildIndex() defaults markReadable=true
			// Java DO_NOT_RE_INCREASE_LIMIT, DEFAULT_WRITE_LIMIT_BYTES and
			// DEFAULT_TRANSACTION_TIME_LIMIT (OnlineIndexOperationConfig.java:40-72).
			increaseLimitAfter:     doNotReIncreaseLimit,
			maxWriteLimitBytes:     900_000,
			transactionTimeLimitMs: 4_000,
			// Java DEFAULT_PROGRESS_LOG_INTERVAL = -1 → progress logging is OFF by
			// default; opt in via SetProgressLogIntervalMillis.
			progressLogIntervalMillis: -1,
		},
	}
}

// SetFormatVersion pins the format version the indexer opens its stores at,
// mirroring StoreBuilder.SetFormatVersion. Java gets this for free by reusing the
// caller's record-store builder (IndexingCommon.getRecordStoreBuilder).
func (b *OnlineIndexerBuilder) SetFormatVersion(version int32) *OnlineIndexerBuilder {
	b.indexer.formatVersion = &version
	return b
}

// SetIndexMaintenanceFilter sets the IndexMaintenanceFilter of the stores the
// indexer opens, mirroring StoreBuilder.SetIndexMaintenanceFilter; Java reads it
// off the caller's record-store builder (IndexingCommon.getRecordStoreBuilder).
func (b *OnlineIndexerBuilder) SetIndexMaintenanceFilter(filter IndexMaintenanceFilter) *OnlineIndexerBuilder {
	b.indexer.maintenanceFilter = filter
	return b
}

// SetAllowUniquePendingState opts in to leaving a unique index in
// READABLE_UNIQUE_PENDING when the build finds duplicates, instead of failing the
// build with a RecordIndexUniquenessViolationError.
//
// Java OnlineIndexer.IndexingPolicy.Builder.allowUniquePendingState(boolean)
// (OnlineIndexer.java:1354). Defaults FALSE here as it does there, and even when
// set it is honoured only on a store at format version >=
// READABLE_UNIQUE_PENDING — see OnlineIndexer.shouldAllowUniquePendingState.
//
// Java's javadoc carries the warning this option deserves: "This state might not be
// compatible with older code. Please verify that all instances are up-to-date before
// allowing it."
func (b *OnlineIndexerBuilder) SetAllowUniquePendingState(allow bool) *OnlineIndexerBuilder {
	b.indexer.allowUniquePendingState = allow
	return b
}

// SetDatabase sets the FDB database.
func (b *OnlineIndexerBuilder) SetDatabase(db *FDBDatabase) *OnlineIndexerBuilder {
	b.indexer.db = db
	return b
}

// SetMarkReadable controls whether BuildIndex marks the index readable when the build
// completes (default true). With false, the build populates the index but leaves it
// WRITE_ONLY with its build stamp and progress counter intact — matching Java's
// OnlineIndexer.buildIndex(boolean markReadable).
func (b *OnlineIndexerBuilder) SetMarkReadable(v bool) *OnlineIndexerBuilder {
	b.indexer.markReadableEnabled = v
	return b
}

// SetProgressLogIntervalMillis sets the throttle for the per-range
// "Indexer: Built Range" progress log. Matches Java
// OnlineIndexer.Builder.setProgressLogIntervalMillis():
//   - a negative value (the default, -1) disables progress logging;
//   - 0 logs after every range;
//   - a positive value logs at most once per that many milliseconds.
//
// Events go to the logger set via SetLogger (or slog.Default()) at INFO.
func (b *OnlineIndexerBuilder) SetProgressLogIntervalMillis(ms int64) *OnlineIndexerBuilder {
	b.indexer.progressLogIntervalMillis = ms
	return b
}

// SetLogger sets the slog.Logger that receives the indexer's operational
// progress events. A nil logger (the default) falls back to slog.Default() at
// log time, mirroring the client's WithLogger convention (RFC-097).
func (b *OnlineIndexerBuilder) SetLogger(logger *slog.Logger) *OnlineIndexerBuilder {
	b.indexer.logger = logger
	return b
}

// SetRecordStoreBuilder is Java's OnlineIndexOperationBaseBuilder.setRecordStoreBuilder:
// the indexer opens every store through a copy of builder's configuration
// (copyBuilder), in its own transaction (the builder's context is dropped), so
// the stores carry the caller's configuration, the serializer included. The
// builder's metadata, subspace, format version and maintenance filter become
// the indexer's (a later setter overrides them). When no database is set, the
// indexer takes the builder's, else that of the builder's context, as Java
// takes its runner from recordStoreBuilder.getContext()
// (OnlineIndexOperationBaseBuilder.java:124-128).
func (b *OnlineIndexerBuilder) SetRecordStoreBuilder(builder *StoreBuilder) *OnlineIndexerBuilder {
	t := builder.copyBuilder()
	t.context = nil
	b.indexer.storeTemplate = t
	if builder.metaData != nil {
		b.indexer.metaData = builder.metaData
	}
	if builder.subspace != nil {
		b.indexer.subspace = builder.subspace
	}
	if builder.formatVersion != nil {
		v := *builder.formatVersion
		b.indexer.formatVersion = &v
	}
	if builder.maintenanceFilter != nil {
		b.indexer.maintenanceFilter = builder.maintenanceFilter
	}
	if b.indexer.db == nil {
		switch {
		case builder.database != nil:
			b.indexer.db = builder.database
		case builder.context != nil:
			b.indexer.db = builder.context.GetDatabase()
		}
	}
	return b
}

// SetRecordStore is Java's setRecordStore (OnlineIndexOperationBaseBuilder.java:
// 138-143): the store as a template, SetRecordStoreBuilder(store.AsBuilder()),
// which carries the store's format version, and, when no database is set, the
// database of the store's context, as Java takes its runner from it.
func (b *OnlineIndexerBuilder) SetRecordStore(store *FDBRecordStore) *OnlineIndexerBuilder {
	b.SetRecordStoreBuilder(store.AsBuilder())
	if b.indexer.db == nil && store.context != nil {
		b.indexer.db = store.context.GetDatabase()
	}
	return b
}

// SetMetaData sets the record metadata.
func (b *OnlineIndexerBuilder) SetMetaData(md *RecordMetaData) *OnlineIndexerBuilder {
	b.indexer.metaData = md
	return b
}

// SetIndex adds the index to build, as Java's setIndex does
// (OnlineIndexer.java:668-676): it is refused when targets are already set
// ("setIndex may not be used when other target indexes are already set", an
// IndexingValidationError that Build returns), a nil index is skipped (Build
// then reports "index must be set"), and nothing stops AddTargetIndex after it.
func (b *OnlineIndexerBuilder) SetIndex(index *Index) *OnlineIndexerBuilder {
	if len(b.indexer.targetIndexes) > 0 {
		if b.setIndexErr == nil {
			b.setIndexErr = &IndexingValidationError{Message: "setIndex may not be used when other target indexes are already set"}
		}
		return b
	}
	if index != nil {
		b.indexer.targetIndexes = append(b.indexer.targetIndexes, index)
	}
	return b
}

// AddTargetIndex adds a target index for multi-target building. Matches Java's
// OnlineIndexer.Builder.addTargetIndex(), which checks nothing.
func (b *OnlineIndexerBuilder) AddTargetIndex(index *Index) *OnlineIndexerBuilder {
	b.indexer.targetIndexes = append(b.indexer.targetIndexes, index)
	return b
}

// SetTargetIndexes replaces the target list. Matches Java's
// OnlineIndexer.Builder.setTargetIndexes().
func (b *OnlineIndexerBuilder) SetTargetIndexes(indexes []*Index) *OnlineIndexerBuilder {
	// A copy, as Java's setTargetIndexes makes one (OnlineIndexer.java:698):
	// AddTargetIndex and SetIndex append to this slice, and Build reorders it,
	// neither of which may write into the caller's array.
	b.indexer.targetIndexes = slices.Clone(indexes)
	return b
}

// SetSubspace sets the store subspace.
func (b *OnlineIndexerBuilder) SetSubspace(ss subspace.Subspace) *OnlineIndexerBuilder {
	b.indexer.subspace = ss
	return b
}

// SetInitialLimit is Java's setInitialLimit: the per-transaction record limit
// a build starts at, at most the limit; 0 starts at the limit.
func (b *OnlineIndexerBuilder) SetInitialLimit(limit int) *OnlineIndexerBuilder {
	b.indexer.initialLimit = limit
	return b
}

// SetIncreaseLimitAfter is Java's setIncreaseLimitAfter: the consecutive
// successful transactions after which a lowered limit re-increases toward the
// limit.
func (b *OnlineIndexerBuilder) SetIncreaseLimitAfter(n int) *OnlineIndexerBuilder {
	b.indexer.increaseLimitAfter = n
	return b
}

// SetMaxWriteLimitBytes is Java's setMaxWriteLimitBytes: a range commits once
// its transaction's approximate size passes this many bytes (default 900,000;
// 0 or less disables the check).
func (b *OnlineIndexerBuilder) SetMaxWriteLimitBytes(n int64) *OnlineIndexerBuilder {
	b.indexer.maxWriteLimitBytes = n
	return b
}

// SetTransactionTimeLimitMilliseconds is Java's
// setTransactionTimeLimitMilliseconds: a range commits once its transaction
// is older than this (default 4,000 ms; 0 or less disables the check).
func (b *OnlineIndexerBuilder) SetTransactionTimeLimitMilliseconds(ms int64) *OnlineIndexerBuilder {
	b.indexer.transactionTimeLimitMs = ms
	return b
}

// SetLimit sets the maximum number of records to process per transaction.
func (b *OnlineIndexerBuilder) SetLimit(limit int) *OnlineIndexerBuilder {
	b.indexer.limit = limit
	return b
}

// SetRecordTypes sets which record types to index. If empty, indexes all types
// that have this index defined. Not allowed with multi-target building.
func (b *OnlineIndexerBuilder) SetRecordTypes(types ...string) *OnlineIndexerBuilder {
	b.indexer.recordTypes = types
	return b
}

// SetSourceIndex sets the source index for the BY_INDEX strategy. Build refuses
// it with several targets or a mutual policy. Everything else about it is
// checked when BuildIndex runs, as Java checks it: the source must be a
// scannable VALUE index on the target's one record type whose root expression
// creates no duplicates, and a source that is not is answered by the build
// catcher with a records-scan fallback (or an IndexingValidationError under
// IndexingPolicy.ForbidRecordScan).
// Matches Java's OnlineIndexer.Builder.setSourceIndex().
func (b *OnlineIndexerBuilder) SetSourceIndex(index *Index) *OnlineIndexerBuilder {
	b.indexer.sourceIndex = index
	return b
}

// SetMaxAttempts sets how many attempts each of the indexer's transactions
// makes, as Java's OnlineIndexOperationBaseBuilder.setMaxAttempts sets its
// runner's (default: the database's, 10). The lessen-work retries of
// SetMaxRetries run over each attempt-bounded transaction.
func (b *OnlineIndexerBuilder) SetMaxAttempts(maxAttempts int) *OnlineIndexerBuilder {
	b.indexer.maxAttempts = maxAttempts
	return b
}

// SetMaxRetries sets the maximum number of retries per range on transient FDB errors.
// When a range build fails with a transient error, the indexer retries with a halved limit.
// Default is 0 (no retries — errors propagate immediately).
// Matches Java's OnlineIndexer.Builder.setMaxRetries() (default 100 in Java).
func (b *OnlineIndexerBuilder) SetMaxRetries(maxRetries int) *OnlineIndexerBuilder {
	b.indexer.maxRetries = maxRetries
	return b
}

// SetTimeLimit sets the overall time limit for the entire build. If the build exceeds
// this duration, BuildIndex returns a TimeLimitExceededError after the current range
// completes. Zero means unlimited (default).
// Matches Java's OnlineIndexer.Builder.setTimeLimitMilliseconds().
func (b *OnlineIndexerBuilder) SetTimeLimit(d time.Duration) *OnlineIndexerBuilder {
	b.indexer.timeLimit = d
	return b
}

// SetRecordsPerSecond sets the inter-transaction rate limit. The indexer will
// sleep between transactions to maintain approximately this rate. Default is
// 10,000 records/second (matching Java). Set to 0 for unlimited.
// Matches Java's OnlineIndexer.Builder.setRecordsPerSecond().
func (b *OnlineIndexerBuilder) SetRecordsPerSecond(rps int) *OnlineIndexerBuilder {
	b.indexer.recordsPerSecond = rps
	return b
}

// SetEnforcedPostTransactionDelay sets a fixed delay in milliseconds applied after each
// build transaction. When positive, it is used INSTEAD of the records-per-second throttle.
// Default 0 disables it (records-per-second behaviour). Matches Java's
// OnlineIndexer.Builder.setEnforcedPostTransactionDelay().
func (b *OnlineIndexerBuilder) SetEnforcedPostTransactionDelay(ms int) *OnlineIndexerBuilder {
	b.indexer.enforcedPostTransactionDelay = ms
	return b
}

// SetPolicy sets the indexing policy for stamp conflict resolution.
// Matches Java's OnlineIndexer.Builder.setIndexingPolicy().
func (b *OnlineIndexerBuilder) SetPolicy(policy *IndexingPolicy) *OnlineIndexerBuilder {
	b.indexer.policy = policy
	return b
}

// SetMutualIndexing enables concurrent/mutual index building mode.
// Multiple indexer processes can run simultaneously, each building different
// fragments of the key space. Fragments are determined by FDB shard boundaries.
// Matches Java's OnlineIndexer.Builder.setMutualIndexing().
func (b *OnlineIndexerBuilder) SetMutualIndexing() *OnlineIndexerBuilder {
	b.indexer.mutual = true
	return b
}

// SetMutualIndexingBoundaries enables mutual mode with pre-set fragment boundaries.
// Each boundary is a packed tuple representing a primary key at which to split
// the key space. If nil/empty, the boundaries are the primary keys at the shard
// boundaries of the indexed records (GetPrimaryKeyBoundaries).
// Matches Java's OnlineIndexer.Builder.setMutualIndexingBoundaries().
func (b *OnlineIndexerBuilder) SetMutualIndexingBoundaries(boundaries [][]byte) *OnlineIndexerBuilder {
	b.indexer.mutual = true
	b.indexer.mutualBoundaries = boundaries
	return b
}

// defaultLeaseLengthMs is Java's OnlineIndexOperationConfig.DEFAULT_LEASE_LENGTH_MILLIS
// (OnlineIndexOperationConfig.java:61). A peer judges another session's heartbeat
// stale by ITS OWN lease (IndexingHeartbeat.java:106-107, indexing_heartbeat.go
// checkAdmission), so a default-configured Java builder treats a Go heartbeat
// older than 10s as dead; a longer Go default would only make Go slower to admit
// after a Java session died, while a Go session that renews less often than 10s
// is admitted-over by Java either way.
const defaultLeaseLengthMs int64 = 10_000

// resolvedLeaseLengthMs maps the unset (zero) lease to Java's default.
func resolvedLeaseLengthMs(ms int64) int64 {
	if ms == 0 {
		return defaultLeaseLengthMs
	}
	return ms
}

// SetLeaseLengthMs sets the heartbeat lease duration in milliseconds. If a
// heartbeat is not updated within this duration, the process is presumed dead.
// Default is Java's 10000 (defaultLeaseLengthMs). Only relevant for non-mutual
// mode; in mutual mode heartbeats are written but not checked.
// Matches Java's OnlineIndexer.IndexingPolicy.setLeaseLengthMillis().
func (b *OnlineIndexerBuilder) SetLeaseLengthMs(ms int64) *OnlineIndexerBuilder {
	b.indexer.leaseLengthMs = ms
	return b
}

// Build creates the OnlineIndexer.
// Matches Java's OnlineIndexer.Builder.build(): validates, deduplicates, and sorts
// target indexes by name (the alphabetically-first index becomes the "primary"
// that drives range tracking).
func (b *OnlineIndexerBuilder) Build() (*OnlineIndexer, error) {
	if b.setIndexErr != nil {
		return nil, b.setIndexErr
	}
	if b.indexer.db == nil {
		return nil, fmt.Errorf("online indexer: database is required")
	}
	if b.indexer.metaData == nil {
		return nil, fmt.Errorf("online indexer: metadata is required")
	}
	if len(b.indexer.targetIndexes) == 0 {
		// Java validateIndexSetting's first check (OnlineIndexer.java:862-864).
		return nil, &MetaDataError{Message: "index must be set"}
	}
	if b.indexer.subspace == nil {
		return nil, fmt.Errorf("online indexer: subspace is required")
	}
	if b.indexer.limit <= 0 {
		b.indexer.limit = 100
	}

	// Java OnlineIndexer.Builder.validateIndexSetting (OnlineIndexer.java:866-878),
	// in its order: a source index with more than one target, counted BEFORE
	// duplicates are removed, then the dedup, then a source index with a mutual
	// policy, each a ValidationException; the targets' presence in the metadata
	// after that, and the record types (validateTypes) last.
	if b.indexer.sourceIndex != nil {
		if len(b.indexer.targetIndexes) > 1 {
			return nil, &IndexingValidationError{Message: "Indexing multi targets by a source index is not supported (yet)", SourceIndexName: b.indexer.sourceIndex.Name}
		}
	}

	// Remove duplicates as Java's HashSet does (OnlineIndexer.java:871-874):
	// by Index.equals, the FIRST of equal objects kept. Two objects that share a
	// name but differ in anything Java's equality compares (a subspace key, a
	// version, a root) are both kept, and the one that is not the metadata's
	// own is refused below; an equal copy listed after the metadata's own is
	// dropped, and one listed before it is kept and refused, as in Java.
	deduped := make([]*Index, 0, len(b.indexer.targetIndexes))
	for _, idx := range b.indexer.targetIndexes {
		dup := false
		for _, kept := range deduped {
			if kept.equalsJava(idx) {
				dup = true
				break
			}
		}
		if !dup {
			deduped = append(deduped, idx)
		}
	}
	b.indexer.targetIndexes = deduped
	if b.indexer.sourceIndex != nil && b.indexer.mutual {
		return nil, &IndexingValidationError{Message: "Indexing mutually by a source index is not supported (yet)", SourceIndexName: b.indexer.sourceIndex.Name}
	}
	for _, idx := range b.indexer.targetIndexes {
		if idx == nil {
			// Java's ArrayList admits a null target, and its HashSet keeps one
			// of several. The build then fails with a NullPointerException at
			// the sort or the metadata check below (OnlineIndexer.java:879-880),
			// after the two ValidationExceptions above. Go reports the missing
			// index at the same point instead of panicking.
			return nil, &MetaDataError{Message: "index must be set"}
		}
	}

	// Sort target indexes by name before the metadata check, as Java does
	// (targetIndexes.sort(Comparator.comparing(Index::getName)),
	// OnlineIndexer.java:879), so the refusal names the alphabetically first
	// target that fails, and so the primary index (the first) is deterministic.
	// The sort is stable: objects of one name keep the order they were given.
	sort.SliceStable(b.indexer.targetIndexes, func(i, j int) bool {
		return b.indexer.targetIndexes[i].Name < b.indexer.targetIndexes[j].Name
	})

	// Every target must be the metadata's OWN index object, as Java's
	// validateIndexSetting requires (`index != metaData.getIndex(name)`,
	// OnlineIndexer.java:880-883): the range set, the maintainers and the index
	// entries are keyed by the object's subspace key and versions, so an object
	// that only shares the metadata index's name would build under keys the
	// metadata does not name, while the state and publication go by name.
	md := b.indexer.metaData
	for _, idx := range b.indexer.targetIndexes {
		if md.GetIndex(idx.Name) != idx {
			return nil, &MetaDataError{Message: "Index " + idx.Name + " not contained within specified metadata"}
		}
	}

	// And every PRESET RECORD TYPE, for the same reason and with a worse failure
	// if it is skipped. Both readers of recordTypes resolve a name, and neither
	// used to ERROR on one that resolves to nothing: indexedRecordTypes silently
	// dropped it, the empty set made computeRecordsRange decline, the build fell
	// back to a full scan, the per-record predicate matched nothing, and the index
	// was then marked READABLE. A built, readable, EMPTY index that queries answer
	// from -- the same disaster the resolution fix closed for a MISSPELLED name,
	// reached instead through a name that names nothing at all.
	//
	// Java cannot reach this: IndexingCommon.fillTargetIndexers takes a
	// Collection<RecordType>, so an unresolvable name is not expressible. This is
	// a Go-only builder API, and it failed OPEN on the write path.
	for _, name := range b.indexer.recordTypes {
		if md.GetRecordType(name) == nil {
			return nil, fmt.Errorf("online indexer: record type %q not contained within specified metadata", name)
		}
	}

	isMulti := len(b.indexer.targetIndexes) > 1

	// Multi-target restrictions (matches Java's IndexingCommon).
	if (isMulti || b.indexer.mutual) && len(b.indexer.recordTypes) > 0 {
		return nil, fmt.Errorf("online indexer: preset record types not allowed with multi-target/mutual indexing")
	}
	b.indexer.leaseLengthMs = resolvedLeaseLengthMs(b.indexer.leaseLengthMs)

	// Create adaptive throttle (matches Java's IndexingThrottle initialization)
	b.indexer.throttle = newIndexingThrottle(b.indexer.limit, b.indexer.maxRetries, b.indexer.recordsPerSecond, b.indexer.enforcedPostTransactionDelay).
		withLimits(b.indexer.limit, b.indexer.initialLimit, b.indexer.increaseLimitAfter)

	return &b.indexer, nil
}

// validateSourceAndTargetIndexes checks that the source index can feed a
// BY_INDEX build of the target. Matches Java's
// IndexingByIndex.validateSourceAndTargetIndexes (IndexingByIndex.java:240-252),
// messages included, and runs where Java runs it: at session time, after the
// state transaction, so that the build catcher can answer a failure by falling
// back to a records scan (or return it under ForbidRecordScan) rather than the
// builder refusing an indexer Java would build.
func (oi *OnlineIndexer) validateSourceAndTargetIndexes() error {
	src := oi.sourceIndex
	srcTypes := oi.metaData.RecordTypesForIndex(src)
	targetTypes := oi.indexedRecordTypes()
	if len(targetTypes) != 1 {
		return oi.sourceValidationError("target index has multiple types")
	}
	if len(srcTypes) != 1 {
		return oi.sourceValidationError("source index has multiple types")
	}
	for _, rt := range srcTypes {
		if rt.IsSynthetic() {
			return oi.sourceValidationError("source index is on synthetic record types")
		}
	}
	if createsDuplicates(src.RootExpression) {
		return oi.sourceValidationError("source index creates duplicates")
	}
	if src.Type != IndexTypeValue {
		return oi.sourceValidationError("source index is not a VALUE index")
	}
	for _, srcType := range srcTypes {
		covered := false
		for _, rt := range targetTypes {
			if rt.Name == srcType.Name {
				covered = true
				break
			}
		}
		if !covered {
			return oi.sourceValidationError("source index's type is not equal to target index's")
		}
	}
	return nil
}

// sourceValidationError is Java's IndexingBase.validateOrThrowEx failure, with
// its INDEX_NAME, SOURCE_INDEX and INDEXER_ID keys.
func (oi *OnlineIndexer) sourceValidationError(msg string) *IndexingValidationError {
	return &IndexingValidationError{Message: msg, IndexName: oi.primaryIndex().Name, SourceIndexName: oi.sourceIndex.Name, IndexerID: oi.indexerID}
}

// indexedRecordTypes returns the record types this build targets — the explicit
// SetRecordTypes filter, or the union of types covered by the target indexes.
// Matches Java's IndexingCommon.getAllRecordTypes().
func (oi *OnlineIndexer) indexedRecordTypes() []*RecordType {
	if len(oi.recordTypes) > 0 {
		types := make([]*RecordType, 0, len(oi.recordTypes))
		for _, name := range oi.recordTypes {
			if rt := oi.metaData.GetRecordType(name); rt != nil {
				types = append(types, rt)
			}
		}
		return types
	}
	seen := make(map[string]bool)
	var types []*RecordType
	for _, idx := range oi.targetIndexes {
		for _, rt := range oi.metaData.RecordTypesForIndex(idx) {
			if !seen[rt.Name] {
				seen[rt.Name] = true
				types = append(types, rt)
			}
		}
	}
	return types
}

// computeRecordsRange computes the [begin, end) byte range covering the records of the
// indexed record types, when each has a record-type-key primary-key prefix and none is
// synthetic. Returns ok=false (the whole records space may be relevant) if any indexed
// type lacks the prefix or is synthetic, or if there are no indexed types. The returned
// bounds are byte-for-byte Java's TupleRange.betweenInclusive(low, high).toRange():
// begin = low.Pack() verbatim, end = high.Pack()+0xff (RANGE_INCLUSIVE high appends one
// 0xff, NOT strinc). Matches Java's IndexingCommon.computeRecordsRange().
func (oi *OnlineIndexer) computeRecordsRange() (begin, end []byte, ok bool) {
	var lowBytes, highBytes []byte
	for _, rt := range oi.indexedRecordTypes() {
		if !rt.PrimaryKeyHasRecordTypePrefix() || rt.IsSynthetic() {
			return nil, nil, false
		}
		// Java's Tuple.compareTo is the order of the packed bytes, for a type
		// key of any tuple type.
		prefix := tuple.Tuple{rt.GetRecordTypeKey()}.Pack()
		switch {
		case lowBytes == nil:
			lowBytes, highBytes = prefix, prefix
		case bytes.Compare(lowBytes, prefix) > 0:
			lowBytes = prefix
		case bytes.Compare(highBytes, prefix) < 0:
			highBytes = prefix
		}
	}
	if lowBytes == nil {
		return nil, nil, false
	}
	// end = high.pack() + 0xff — Java TupleRange.toRange, RANGE_INCLUSIVE high.
	end = make([]byte, len(highBytes)+1)
	copy(end, highBytes)
	end[len(highBytes)] = 0xff
	return lowBytes, end, true
}

// maybePresetRecordsRange preemptively marks the key ranges OUTSIDE the indexed record
// types' range as already-built in every target index's range set, so the build skips
// scanning keys that cannot hold an indexed-type record. No-op when the whole records
// space may be relevant. Matches Java's IndexingBase.maybePresetRecordsRangeAsync (used
// by the multi-target and mutual build paths).
func (oi *OnlineIndexer) maybePresetRecordsRange(ctx context.Context) error {
	begin, end, ok := oi.computeRecordsRange()
	if !ok {
		return nil
	}
	_, err := oi.run(ctx, func(rtx *FDBRecordContext) (any, error) {
		store, err := oi.openStore(rtx)
		if err != nil {
			return nil, err
		}
		if err := oi.validateBuildSession(store); err != nil {
			return nil, err
		}
		tr := store.context.Transaction()
		// Mark the leading and trailing out-of-range gaps as built, sequentially per
		// target (ordered mutations within the transaction, matching Java's insertRanges):
		// [nil, begin) then [end, nil). requireEmpty=true keeps it resume-safe.
		for _, idx := range oi.targetIndexes {
			rangeSet := NewIndexingRangeSet(store.subspace, idx)
			if _, err := rangeSet.InsertRange(tr, nil, begin, true); err != nil {
				return nil, err
			}
			if _, err := rangeSet.InsertRange(tr, end, nil, true); err != nil {
				return nil, err
			}
		}
		return nil, nil
	})
	return err
}

// unpackRangeEndBoundary converts a range-set END boundary into a scan tuple plus its high
// endpoint type. A normal boundary is a packed primary key, scanned EXCLUSIVE. A
// RANGE_INCLUSIVE-high boundary — a tuple followed by a single 0xff (Java
// TupleRange.toRange's representation, written by the typed-records preset's high bound) —
// is not itself a valid tuple; it is scanned as the stripped tuple with an INCLUSIVE high
// endpoint, covering that tuple's whole sub-range exactly as the 0xff byte does. The plain
// tuple is tried first, so an ordinary key whose pack happens to end in 0xff (e.g. int 255 =
// 0x15 0xff) is correctly treated as that key, not as a +0xff bound.
func unpackRangeEndBoundary(b []byte) (tuple.Tuple, EndpointType, error) {
	if t, err := tuplefast.Unpack(b); err == nil {
		return t, EndpointTypeRangeExclusive, nil
	}
	if n := len(b); n > 0 && b[n-1] == 0xff {
		if t, err := tuplefast.Unpack(b[:n-1]); err == nil {
			return t, EndpointTypeRangeInclusive, nil
		}
	}
	return nil, 0, fmt.Errorf("range end boundary %x is neither a tuple nor a tuple+0xff bound", b)
}

// indexingAttemptsLimit is Java's OnlineIndexer.INDEXING_ATTEMPTS_RECURSION_LIMIT,
// a safety net over the catcher's retries that the algorithm should never reach.
const indexingAttemptsLimit = 5

// requestedIndexingMethod is what a BY_INDEX continuation replaced: the policy
// and source index the caller asked for, restored with REBUILD if the previous
// method's source index turns out to be unusable (Java indexingLauncher's
// requestedPolicy).
type requestedIndexingMethod struct {
	policy      *IndexingPolicy
	sourceIndex *Index
}

// indexingCatch is what the build catcher makes of a failed attempt.
type indexingCatch int

const (
	// indexingCatchFail returns the error.
	indexingCatchFail indexingCatch = iota
	// indexingCatchRetry runs another attempt under the adjusted method.
	indexingCatchRetry
	// indexingCatchDone ends the build successfully: mutual peers have
	// published every target.
	indexingCatchDone
)

// BuildIndex runs the index build and returns the number of records scanned.
// Matches Java's OnlineIndexer.buildIndex: every attempt resolves the session
// against the primary index's state, which may build (and then publish), only
// publish, or leave a READABLE index alone, and a failed attempt goes to
// indexingCatcher, which may retry it by another method.
//
// The count is every record scanned by every attempt, a retried one included.
// LastBuildOutcome reports what the call did.
func (oi *OnlineIndexer) BuildIndex(ctx context.Context) (int64, error) {
	oi.lastOutcome = IndexBuildOutcomeNone
	var requested *requestedIndexingMethod
	var total int64
	// The outcome is the CALL's, not its last attempt's: an attempt that indexed
	// records and then failed into a retry built them, whatever the next attempt
	// finds (a peer may publish in between, and the next attempt then leaves the
	// READABLE index alone or ends the mutual build as completed by its peers).
	built := false
	outcomeOfCall := func(last IndexBuildOutcome) IndexBuildOutcome {
		if built {
			return IndexBuildOutcomeBuilt
		}
		return last
	}
	for attempt := 1; ; attempt++ {
		n, outcome, err := oi.buildIndexAttempt(ctx)
		total += n
		if err == nil {
			oi.lastOutcome = outcomeOfCall(outcome)
			return total, nil
		}
		if n > 0 {
			built = true
		}
		catch, next, err := oi.indexingCatcher(ctx, err, attempt, requested)
		switch catch {
		case indexingCatchDone:
			oi.lastOutcome = outcomeOfCall(IndexBuildOutcomeCompletedByPeers)
			return total, nil
		case indexingCatchRetry:
			requested = next
		default:
			return total, err
		}
	}
}

// indexingCatcher ports Java's OnlineIndexer.indexingCatcher
// (OnlineIndexer.java:152-274) arm for arm:
//   - a PartlyBuiltError follows IfMismatchPrevious: CONTINUE resumes a single
//     target's previous method (a records scan for BY_RECORDS or
//     MULTI_TARGET_BY_RECORDS, the saved source index for BY_INDEX), REBUILD
//     rebuilds by the requested method, and anything else fails;
//   - an IndexingValidationError of a BY_INDEX build restores the requested
//     method with REBUILD when the failed source was a continuation's, and
//     otherwise falls back to a records scan unless ForbidRecordScan;
//   - under a mutual policy an UnexpectedReadableError ends the build when every
//     target is readable, and otherwise falls back to a records scan, whose
//     session start checks and publishes what the peers left.
//
// Java counts the attempt a failure arrived on from one; past
// indexingAttemptsLimit the error is returned whatever it is.
func (oi *OnlineIndexer) indexingCatcher(ctx context.Context, err error, attempt int, requested *requestedIndexingMethod) (indexingCatch, *requestedIndexingMethod, error) {
	logger := oi.logger
	if logger == nil {
		logger = slog.Default()
	}
	if attempt > indexingAttemptsLimit {
		logger.LogAttrs(ctx, slog.LevelError, "Too many indexing attempts",
			slog.Int("attempt", attempt), slog.String("index", oi.targetIndexNamesForLog()))
		return indexingCatchFail, nil, err
	}

	var partly *PartlyBuiltError
	if errors.As(err, &partly) {
		action, aerr := oi.policy.GetIfMismatchPrevious()
		if aerr != nil {
			return indexingCatchFail, nil, aerr
		}
		logger.LogAttrs(ctx, slog.LevelInfo, "conflicting indexing type stamp",
			slog.Int("attempt", attempt), slog.String("index", oi.targetIndexNamesForLog()),
			slog.Int("desired_action", int(action)),
			slog.String("actual", partly.SavedStamp), slog.String("expected", partly.ExpectedStamp))
		switch action {
		case DesiredActionContinue:
			if oi.isMultiTarget() {
				return indexingCatchFail, nil, err
			}
			switch partly.Saved.GetMethod() {
			case gen.IndexBuildIndexingStamp_BY_RECORDS, gen.IndexBuildIndexingStamp_MULTI_TARGET_BY_RECORDS:
				// Java allows the fallback from a multi-target build to a single
				// target, but not to a subset.
				oi.fallBackToRecordsScan()
				return indexingCatchRetry, nil, nil
			case gen.IndexBuildIndexingStamp_BY_INDEX:
				source, serr := oi.savedSourceIndex(partly.Saved)
				if serr != nil {
					return indexingCatchFail, nil, serr
				}
				orig := &requestedIndexingMethod{policy: oi.policy, sourceIndex: oi.sourceIndex}
				oi.sourceIndex = source
				return indexingCatchRetry, orig, nil
			}
			return indexingCatchFail, nil, err
		case DesiredActionRebuild:
			oi.policy = oi.policy.withIfWriteOnly(DesiredActionRebuild)
			return indexingCatchRetry, nil, nil
		}
		return indexingCatchFail, nil, err
	}

	var validation *IndexingValidationError
	if oi.sourceIndex != nil && errors.As(err, &validation) {
		if requested != nil {
			logger.LogAttrs(ctx, slog.LevelWarn, "The previous method's source index isn't usable. Rebuild by the requested policy",
				slog.Int("attempt", attempt), slog.String("index", oi.targetIndexNamesForLog()))
			oi.policy = requested.policy.withIfWriteOnly(DesiredActionRebuild)
			oi.sourceIndex = requested.sourceIndex
			return indexingCatchRetry, nil, nil
		}
		if (oi.policy == nil || !oi.policy.ForbidRecordScan) && !oi.fallbackToRecordsScan {
			logger.LogAttrs(ctx, slog.LevelWarn, "Fallback to a by-record scan",
				slog.Int("attempt", attempt), slog.String("index", oi.targetIndexNamesForLog()))
			oi.fallBackToRecordsScan()
			return indexingCatchRetry, nil, nil
		}
	}

	if oi.mutual {
		var unexpected *UnexpectedReadableError
		if errors.As(err, &unexpected) {
			if unexpected.AllReadable {
				return indexingCatchDone, nil, nil
			}
			oi.fallBackToRecordsScan()
			return indexingCatchRetry, nil, nil
		}
	}
	return indexingCatchFail, nil, err
}

// fallBackToRecordsScan is the catcher's switch to Java's
// IndexingMultiTargetByRecords, which getIndexer hands a forced stamp overwrite.
func (oi *OnlineIndexer) fallBackToRecordsScan() {
	oi.fallbackToRecordsScan = true
	oi.enforcedStampOverwrite = true
}

// savedSourceIndex resolves the source index a BY_INDEX stamp names, as Java
// resolves the policy's source index subspace key: Index.decodeSubspaceKey, then
// RecordMetaData.getIndexFromSubspaceKey.
func (oi *OnlineIndexer) savedSourceIndex(stamp *gen.IndexBuildIndexingStamp) (*Index, error) {
	key, err := tuple.Unpack(stamp.GetSourceIndexSubspaceKey())
	if err != nil || len(key) != 1 {
		return nil, &RecordCoreError{Message: "subspace key must encode a single item tuple"}
	}
	source := oi.metaData.GetIndexFromSubspaceKey(key[0])
	if source == nil {
		return nil, &MetaDataError{Message: fmt.Sprintf("Unknown index subspace key %v", key[0])}
	}
	return source, nil
}

// buildIndexAttempt is one launch of Java's indexing function: the session
// start, the build by the method the catcher has left in force, and the
// publication. Each attempt writes a heartbeat under that method with the
// indexer's one identity (Java's indexerId, shared by every attempt of the
// indexer, IndexingCommon.java:53), and removes it when the attempt ends; the
// throttle's adapted limit carries over, where Java's new indexer per attempt
// starts again from the configured one.
func (oi *OnlineIndexer) buildIndexAttempt(ctx context.Context) (int64, IndexBuildOutcome, error) {
	// Java's policy names its source index, and each session compiles the stamp
	// and validates the source from the metadata's index of that name
	// (IndexingByIndex.java:68-71, :95-101), so a caller's *Index whose subspace
	// key, versions or type differ from the metadata's never reaches the stamp or
	// validateSourceAndTargetIndexes. (The scan already reads the source by name.)
	// A name the metadata lacks is refused in the state transaction
	// (prepareIndexingState).
	if oi.buildsByIndex() && oi.metaData != nil {
		if resolved := oi.metaData.GetIndex(oi.sourceIndex.Name); resolved != nil {
			oi.sourceIndex = resolved
		}
	}
	// Java names a build's heartbeat by its stamp's method (IndexingBase.java:457);
	// Go's SynchronizedSessionLockedError also reports it as ExistingInfo, a Go
	// addition (Java's lock exception carries no info key).
	heartbeat := oi.newHeartbeat(oi.buildIndexingStamp().GetMethod().String(), oi.buildsMutually(), oi.db.Env())
	oi.sessionHeartbeat = heartbeat
	oi.admittedHeartbeat = nil
	defer func() {
		if oi.sessionHeartbeat != nil {
			oi.cleanupPendingQueueHeartbeat(heartbeat)
			oi.sessionHeartbeat = nil
			oi.admittedHeartbeat = nil
		}
	}()
	// The build clock, not a metric: this anchor is what throttleBetweenRanges measures the
	// configured timeLimit against, so it decides when the build stops and therefore HOW MANY
	// RANGES end up durably recorded in the built-range set. It has to come off the env clock
	// or a simulated build stops at a wall-clock-determined, unreproducible point.
	startTime := oi.db.Env().Now()

	// Step 1: Resolve the session against the index state, marking the targets
	// WRITE_ONLY when it builds.
	start, err := oi.markWriteOnly(ctx)
	if err != nil {
		return 0, IndexBuildOutcomeNone, fmt.Errorf("mark write-only: %w", err)
	}
	switch start {
	case indexingSessionSkip:
		return 0, IndexBuildOutcomeLeftAlone, nil
	case indexingSessionMarkReadable:
		if !oi.markReadableEnabled {
			return 0, IndexBuildOutcomeLeftAlone, nil
		}
		if err := oi.markReadable(ctx); err != nil {
			return 0, IndexBuildOutcomeNone, fmt.Errorf("mark readable: %w", err)
		}
		return 0, IndexBuildOutcomePublished, nil
	}

	// Step 2: Build in chunks across multiple transactions.
	if oi.buildsMutually() {
		n, err := oi.buildIndexMutual(ctx, startTime)
		return n, IndexBuildOutcomeBuilt, err
	}

	// A records-scan build presets the out-of-range gaps as already built so the scan
	// skips them. Java's records-scan indexer is IndexingMultiTargetByRecords for one
	// target or several (OnlineIndexer.getIndexer, :302-314: everything that is not
	// mutual or a single-target BY_INDEX build, a BY_INDEX fallen back to a records scan
	// included), and it presets (IndexingMultiTargetByRecords.java:120). Go preset only
	// for several targets, so a single-target build wrote a range set Java does not
	// (conformance "The online build presets a string-keyed record type's range as Java
	// does"). A BY_INDEX build does not preset, in either engine.
	if !oi.buildsByIndex() {
		if err := oi.maybePresetRecordsRange(ctx); err != nil {
			return 0, IndexBuildOutcomeNone, fmt.Errorf("preset records range: %w", err)
		}
	}

	buildFn := oi.buildRange
	if oi.buildsByIndex() {
		// Java IndexingByIndex.buildIndexInternalAsync validates after the state
		// transaction has committed, so a failure leaves the target WRITE_ONLY
		// under a BY_INDEX stamp that the catcher's records scan then overwrites.
		if err := oi.validateSourceAndTargetIndexes(); err != nil {
			return 0, IndexBuildOutcomeNone, err
		}
		buildFn = oi.buildRangeByIndex
	}

	var totalRecords int64
	for {
		n, hasMore, err := oi.buildRangeWithRetries(ctx, buildFn)
		if err != nil {
			return totalRecords, IndexBuildOutcomeNone, fmt.Errorf("build range: %w", err)
		}
		totalRecords += n
		if err := oi.drainPendingIndexWrites(ctx, heartbeat); err != nil {
			return totalRecords, IndexBuildOutcomeNone, err
		}
		if err := oi.mergeRequestedIndexes(ctx); err != nil {
			return totalRecords, IndexBuildOutcomeNone, err
		}
		if !hasMore {
			break
		}

		// Time-limit check + enforced post-transaction delay + progress log between ranges.
		if err := oi.throttleBetweenRanges(ctx, startTime, totalRecords, n); err != nil {
			return totalRecords, IndexBuildOutcomeNone, err
		}
	}

	// Step 3: Mark all target indexes as READABLE (unless disabled — e.g. to inspect or
	// resume the build). Matches Java OnlineIndexer.buildIndex(boolean markReadable).
	if oi.markReadableEnabled {
		if err := oi.markReadable(ctx); err != nil {
			return totalRecords, IndexBuildOutcomeNone, fmt.Errorf("mark readable: %w", err)
		}
	}

	return totalRecords, IndexBuildOutcomeBuilt, nil
}

// buildIndexMutual runs the mutual (concurrent) build path.
func (oi *OnlineIndexer) buildIndexMutual(ctx context.Context, startTime time.Time) (int64, error) {
	mutual := newMutualIndexBuilder(oi)

	// Mutual builds preset the out-of-range gaps as already-built (Java
	// IndexingMutuallyByRecords), before the fragmented build loop.
	if err := oi.maybePresetRecordsRange(ctx); err != nil {
		return 0, fmt.Errorf("preset records range: %w", err)
	}

	var totalRecords int64
	for {
		// Use buildRangeWithRetries for adaptive throttling + retry on transient
		// FDB errors, matching the BY_RECORDS path. Without this, mutual builds
		// had no limit adjustment on failure and no rate limiting.
		n, hasMore, err := oi.buildRangeWithRetries(ctx, func(ctx context.Context) (int64, bool, error) {
			return mutual.buildMutual(ctx)
		})
		if err != nil {
			return totalRecords, fmt.Errorf("mutual build range: %w", err)
		}
		totalRecords += n
		if err := oi.mergeRequestedIndexes(ctx); err != nil {
			return totalRecords, err
		}
		if !hasMore {
			break
		}

		// Time-limit check + enforced post-transaction delay + progress log between ranges.
		if err := oi.throttleBetweenRanges(ctx, startTime, totalRecords, n); err != nil {
			return totalRecords, err
		}
	}

	// Mark all target indexes as READABLE (unless disabled). Matches Java
	// OnlineIndexer.buildIndex(boolean markReadable).
	if oi.markReadableEnabled {
		if err := oi.markReadable(ctx); err != nil {
			return totalRecords, fmt.Errorf("mark readable: %w", err)
		}
	}

	return totalRecords, nil
}

// shouldLessenWork returns true if the error is a transient FDB error indicating
// the transaction did too much work (too large, timed out, conflicted, etc.).
// Only these errors warrant retrying with a smaller limit.
//
// Ports Java's IndexingThrottle.lessenWorkCodes (IndexingThrottle.java:64-70)
// 1:1, with codes from the FDB error table (flow/error_definitions.h):
// TIMED_OUT(1004), TRANSACTION_TOO_OLD(1007), NOT_COMMITTED(1020),
// TRANSACTION_TIMED_OUT(1031), COMMIT_READ_INCOMPLETE(2002),
// TRANSACTION_TOO_LARGE(2101). The previous list had the right error NAMES but
// wrong NUMBERS — 1028 is new_coordinators_timed_out, 1039 is
// cluster_version_changed, 2501 is not transaction_timed_out — and was missing
// 1004/2002/2101, so a transaction_too_large(2101) batch was not retried with a
// smaller limit (the bug surfaced once the client started enforcing the txn-size
// limit; see RFC-067).
func shouldLessenWork(err error) bool {
	var fdbErr fdb.Error
	if !errors.As(err, &fdbErr) {
		return false
	}
	switch fdbErr.Code {
	case 1004, // timed_out
		1007, // transaction_too_old
		1020, // not_committed (conflict)
		1031, // transaction_timed_out
		2002, // commit_read_incomplete
		2101: // transaction_too_large
		return true
	}
	return false
}

// buildRangeWithRetries wraps a buildRange call with retry logic.
// On transient FDB failures indicating the transaction was too large/slow,
// halves the limit and retries up to maxRetries times. Permanent errors
// are returned immediately without retry.
// Matches Java's IndexingThrottle.mayRetryAfterHandlingException().
func (oi *OnlineIndexer) buildRangeWithRetries(ctx context.Context, buildFn func(context.Context) (int64, bool, error)) (int64, bool, error) {
	if oi.throttle == nil {
		return buildFn(ctx)
	}

	var delay *exponentialDelay // made at the first retry: it draws from the env
	for attempt := 0; ; attempt++ {
		// Apply adaptive limit from throttle
		oi.limit = oi.throttle.getLimit()

		// No pacing wait here. Java takes the whole inter-range wait once per RANGE in
		// doneOrThrottleDelayAndMaybeLogProgress (IndexingBase.java:512) — i.e. in
		// throttleBetweenRanges — not once per retry ATTEMPT, so a range that retries
		// does not pay the rate-limit wait repeatedly.
		n, hasMore, err := buildFn(ctx)
		if err == nil {
			oi.throttle.handleSuccess(int(n))
			// The enforced post-transaction delay is applied by the build loop via
			// throttleBetweenRanges AFTER the time-limit check (Java
			// doneOrThrottleDelayAndMaybeLogProgress), not here — so an over-budget build
			// returns a TimeLimitExceededError without paying the delay, and the final range
			// pays nothing.
			return n, hasMore, nil
		}
		if oi.maxRetries <= 0 || !oi.throttle.mayRetryAfterHandlingException(err, attempt, int(n)) {
			return n, hasMore, err
		}
		// The limit is decreased; Java's buildCommitRetryAsync also waits before the retry.
		if delay == nil {
			delay = newExponentialDelay(oi.db.InitialDelay(), oi.db.MaxDelay(), oi.db.Env())
		}
		if werr := waitRetryDelay(ctx, oi.db.Env(), oi.db.Timer(), delay.delay(), err); werr != nil {
			return n, hasMore, werr
		}
	}
}

// throttleBetweenRanges paces the build between committed ranges: it validates the time
// limit FIRST (accounting for the upcoming enforced delay) and only then applies the
// enforced post-transaction delay. It returns a TimeLimitExceededError — without sleeping —
// when the build has already run, or after the delay would have run, past its time limit.
// This matches Java IndexingBase.doneOrThrottleDelayAndMaybeLogProgress + validateTimeLimit,
// where the time check precedes the wait and includes the wait duration. It is called only
// when more ranges remain, so the final range pays no delay (Java returns READY_FALSE when
// done). With no enforced delay configured it reduces to the prior plain time-limit check.
func (oi *OnlineIndexer) throttleBetweenRanges(ctx context.Context, startTime time.Time, totalRecords, rangeRecords int64) error {
	// One wait per range, computed once and then both logged and slept — exactly Java's
	// `long toWait = throttle.waitTimeMilliseconds()`. It is the enforced
	// post-transaction delay when set, otherwise the records-per-second pacing; a
	// negative enforced delay is not a wait, so it falls through to the rps path
	// rather than being subtracted from elapsed and loosening the time-limit check.
	delayMs := 0
	if oi.throttle != nil {
		delayMs = oi.throttle.waitTimeMillis()
	}
	// Java emits the progress log (with DELAY=toWait) BEFORE validateTimeLimit + the
	// delay, so the final range that trips the time limit still reports progress.
	oi.maybeLogBuildProgress(ctx, totalRecords, rangeRecords, delayMs)
	if oi.timeLimit > 0 {
		// Same clock the anchor was minted on. Measuring a sim-clock anchor against the wall
		// clock does not merely lose determinism — it compares two unrelated epochs, so the
		// limit trips on the first range or never.
		if elapsed := oi.db.Env().Since(startTime); elapsed+time.Duration(delayMs)*time.Millisecond >= oi.timeLimit {
			return &TimeLimitExceededError{TimeLimit: oi.timeLimit, Elapsed: elapsed}
		}
	}
	if oi.throttle != nil {
		oi.throttle.sleepMillis(ctx, delayMs)
	}
	return nil
}

// shouldLogBuildProgress is the progress-log throttle, ported 1:1 from Java
// IndexingBase.shouldLogBuildProgress(): interval<0 never logs; interval==0 logs
// every range; interval>0 logs at most once per interval ms. It advances the
// throttle clock only when it returns true. Single-threaded in the build loop.
func (oi *OnlineIndexer) shouldLogBuildProgress() bool {
	interval := oi.progressLogIntervalMillis
	now := time.Now().UnixMilli()
	if interval < 0 || (interval != 0 && interval > now-oi.timeOfLastProgressLogMillis) {
		return false
	}
	oi.timeOfLastProgressLogMillis = now
	return true
}

// maybeLogBuildProgress emits the per-range "Indexer: Built Range" INFO event,
// throttled by shouldLogBuildProgress. Ports Java
// IndexingBase.doneOrThrottleDelayAndMaybeLogProgress's logging arm. The
// Enabled(INFO) guard runs FIRST so a disabled INFO level skips both the log AND
// the throttle-clock advance — matching Java's `LOGGER.isInfoEnabled() &&
// shouldLogBuildProgress()` short-circuit (otherwise a disabled logger would
// still consume the throttle interval).
func (oi *OnlineIndexer) maybeLogBuildProgress(ctx context.Context, totalRecords, rangeRecords int64, delayMs int) {
	logger := oi.logger
	if logger == nil {
		logger = slog.Default()
	}
	if !logger.Enabled(ctx, slog.LevelInfo) {
		return
	}
	if !oi.shouldLogBuildProgress() {
		return
	}
	logger.LogAttrs(ctx, slog.LevelInfo, "Indexer: Built Range",
		slog.String("index", oi.targetIndexNamesForLog()),
		slog.Int64("records_scanned", totalRecords),
		slog.Int64("range_records", rangeRecords),
		slog.Int("limit", oi.currentLimitForLog()),
		slog.Int("delay_ms", delayMs),
	)
}

// targetIndexNamesForLog joins the target index names for the progress log
// (Java logs LogMessageKeys.INDEX_NAME = common.getTargetIndexesNames()).
func (oi *OnlineIndexer) targetIndexNamesForLog() string {
	names := make([]string, len(oi.targetIndexes))
	for i, idx := range oi.targetIndexes {
		names[i] = idx.Name
	}
	return strings.Join(names, ",")
}

// currentLimitForLog reports the throttle's live per-transaction record limit
// (Java throttle.logMessageKeyValues() includes LIMIT), falling back to the
// configured limit before the throttle is created.
func (oi *OnlineIndexer) currentLimitForLog() int {
	if oi.throttle != nil {
		return oi.throttle.getLimit()
	}
	return oi.limit
}

// markWriteOnly runs the session's state transaction (prepareIndexingState):
// Java IndexingBase.handleStateAndDoBuildIndexAsync's first transaction, where
// the primary index's state and the policy decide whether the session builds
// (marking every target WRITE_ONLY), only publishes, or leaves the index alone.
// The primary (first by name) drives the decision and the followers must agree
// with it.
//
// The store is opened through the ordinary open path, whose metadata
// reconciliation (checkPossiblyRebuild) may itself rebuild or disable indexes
// before the session reads their states. checkOpenHeartbeats runs first for
// that reason.
func (oi *OnlineIndexer) markWriteOnly(ctx context.Context) (indexingSessionStart, error) {
	oi.admittedHeartbeat = nil
	oi.retiredBuildTargets = nil
	var start indexingSessionStart
	result, err := oi.run(ctx, func(rtx *FDBRecordContext) (any, error) {
		store, err := oi.openStoreWithPreflight(rtx, func(store *FDBRecordStore) error {
			// Reject before the session commits any clearing or state transitions.
			for _, index := range oi.targetIndexes {
				if err := store.checkIndexCollation(index); err != nil {
					return err
				}
			}
			if oi.sourceIndex != nil {
				if err := store.checkIndexCollation(oi.sourceIndex); err != nil {
					return err
				}
			}
			return oi.checkOpenHeartbeats(store)
		})
		if err != nil {
			return nil, err
		}
		queued, attemptStart, err := oi.prepareIndexingState(store)
		start = attemptStart
		return queued, err
	})
	if err != nil {
		return 0, err
	}
	// Never publish a target set derived from an attempt that did not commit.
	oi.queuedIndexes = result.([]*Index)
	if start == indexingSessionBuild {
		oi.admittedHeartbeat = oi.sessionHeartbeat
	}
	return start, nil
}

// setIndexingTypeOrThrow implements Java's IndexingBase.setIndexingTypeOrThrow().
// It validates whether the new stamp can be written, considering the saved stamp,
// block state, policy, and build method conversion rules.
func (oi *OnlineIndexer) setIndexingTypeOrThrow(store *FDBRecordStore, continuedBuild bool, newStamp *gen.IndexBuildIndexingStamp) error {
	for _, idx := range oi.targetIndexes {
		if err := oi.setIndexingTypeOrThrowForIndex(store, continuedBuild, idx, newStamp); err != nil {
			return err
		}
	}
	return nil
}

// setIndexingTypeOrThrowForIndex is the per-index stamp resolution logic.
// Matches Java's IndexingBase.setIndexingTypeOrThrow(store, continuedBuild, index, newStamp).
func (oi *OnlineIndexer) setIndexingTypeOrThrowForIndex(store *FDBRecordStore, continuedBuild bool, index *Index, newStamp *gen.IndexBuildIndexingStamp) error {
	policy := oi.policy
	state, err := store.readIndexState(index.Name)
	if err != nil {
		return err
	}
	if oi.mutual && state.IsWriteOnlyWithQueue() {
		return &RecordCoreError{Message: "Mutual indexing cannot continue a pending write queue index build", IndexName: index.Name}
	}
	forceStampOverwrite := oi.enforcedStampOverwrite || (policy != nil && policy.ForceStampOverwrite)

	// Step 1: forceStampOverwrite + fresh session = no questions asked.
	if forceStampOverwrite && !continuedBuild {
		return store.SaveIndexingTypeStamp(index, newStamp)
	}

	// Step 2: Load saved stamp.
	savedStamp, err := store.LoadIndexingTypeStamp(index)
	if err != nil {
		return err
	}

	// Step 3: No saved stamp.
	if savedStamp == nil {
		if continuedBuild && newStamp.GetMethod() != gen.IndexBuildIndexingStamp_BY_RECORDS {
			// Backward compatibility: maybe continuing an old BY_RECORDS session that
			// didn't write stamps. Check if any records have been scanned.
			// Matches Java's throwAsByRecordsUnlessNoRecordWasScanned().
			if !isWriteOnlyButNoRecordScanned(store, store.context, index) {
				// Records were scanned under old BY_RECORDS — reject non-BY_RECORDS takeover.
				fakeSavedStamp := &gen.IndexBuildIndexingStamp{
					Method: gen.IndexBuildIndexingStamp_BY_RECORDS.Enum(),
				}
				return oi.newPartlyBuiltError(fakeSavedStamp, newStamp, index,
					"this index was partly built by records (no stamp)")
			}
		}
		// Fresh session or BY_RECORDS or no records scanned: write stamp.
		return store.SaveIndexingTypeStamp(index, newStamp)
	}

	// Step 4: Exact match — nothing to do.
	if proto.Equal(savedStamp, newStamp) {
		return nil
	}

	// Step 5: Check if blocked.
	if isTypeStampBlocked(savedStamp, store.context.Env().Now()) {
		if policy == nil || !policy.ShouldAllowUnblock(savedStamp.GetBlockID()) {
			return oi.newPartlyBuiltError(savedStamp, newStamp, index,
				"this index was partly built, and blocked")
		}
	}

	// Step 6: Similar stamps (differ only in block fields).
	if areSimilarStamps(newStamp, savedStamp) {
		return store.SaveIndexingTypeStamp(index, newStamp)
	}

	// Step 7: Type conversion allowed?
	if continuedBuild && policy != nil && policy.ShouldAllowTypeConversionContinue(newStamp, savedStamp) {
		return store.SaveIndexingTypeStamp(index, newStamp)
	}

	// Step 8: forceStampOverwrite + continued build — allow if no records scanned.
	if forceStampOverwrite {
		if isWriteOnlyButNoRecordScanned(store, store.context, index) {
			return store.SaveIndexingTypeStamp(index, newStamp)
		}
		return oi.newPartlyBuiltError(savedStamp, newStamp, index,
			"this index was partly built by another method")
	}

	// Step 9: Fall through — mismatch, not allowed.
	return oi.newPartlyBuiltError(savedStamp, newStamp, index,
		"this index was partly built by another method")
}

// isWriteOnlyButNoRecordScanned returns true if the index is WRITE_ONLY with a
// completely empty range set (no records have been scanned yet).
// Matches Java's IndexingBase.isWriteOnlyButNoRecordScanned().
func isWriteOnlyButNoRecordScanned(store *FDBRecordStore, rtx *FDBRecordContext, index *Index) bool {
	rangeSet := NewIndexingRangeSet(store.subspace, index)
	missing, err := rangeSet.FirstMissingRange(rtx.Transaction())
	if err != nil {
		return false
	}
	if missing == nil {
		return false // fully built — no missing ranges
	}
	// Empty if the first missing range spans the entire key space.
	return bytes.Equal(missing.Begin, rangeSetFirstKey) && bytes.Equal(missing.End, rangeSetFinalKey)
}

// newPartlyBuiltError creates a PartlyBuiltError with stamp descriptions.
func (oi *OnlineIndexer) newPartlyBuiltError(savedStamp, expectedStamp *gen.IndexBuildIndexingStamp, index *Index, msg string) *PartlyBuiltError {
	return &PartlyBuiltError{
		IndexName:     index.Name,
		SavedStamp:    stampToString(savedStamp),
		ExpectedStamp: stampToString(expectedStamp),
		Message:       msg,
		Saved:         savedStamp,
		Expected:      expectedStamp,
		IndexerID:     oi.indexerID,
		IndexVersion:  index.LastModifiedVersion,
	}
}

// stampToString returns a human-readable representation of a stamp.
func stampToString(stamp *gen.IndexBuildIndexingStamp) string {
	if stamp == nil {
		return "<nil>"
	}
	return stamp.GetMethod().String()
}

// markReadable transitions all target indexes to READABLE (or READABLE_UNIQUE_PENDING
// for unique indexes with violations) after the build completes.
//
// Each index is marked in its own transaction so one failure doesn't block others.
// Matches Java's IndexingBase.markIndexReadable() → forEachTargetIndex() where each
// index uses getRunner().runAsync() (separate transaction per index).
func (oi *OnlineIndexer) markReadable(ctx context.Context) error {
	var firstErr error
	for _, idx := range oi.targetIndexes {
		if oi.retiredBuildTargets[idx.Name] {
			continue
		}
		var err error
		attempts := max(int64(1), oi.policy.GetPendingWriteQueueIndexesMaxDrainAttempts())
		queuedInSession := false
		for _, queued := range oi.queuedIndexes {
			if queued.Name == idx.Name {
				queuedInSession = true
				break
			}
		}
		for {
			if err = ctx.Err(); err != nil {
				return err
			}
			if queuedInSession {
				err = oi.drainPendingIndexWritesForIndex(ctx, idx, oi.sessionHeartbeat)
			}
			if err == nil {
				err = oi.mergeRequestedIndexes(ctx)
			}
			if err == nil {
				_, err = oi.run(ctx, func(rtx *FDBRecordContext) (any, error) {
					store, err := oi.openStore(rtx)
					if err != nil {
						return nil, err
					}
					// Java IndexingBase.markIndexReadableForIndex (IndexingBase.java:322-326)
					// picks between the two marks on the policy, NOT unconditionally:
					//   policy.shouldAllowUniquePendingState(store)
					//       ? store.markIndexReadableOrUniquePending(index)
					//       : store.markIndexReadable(index);
					// The default policy answers false, so the default outcome of a build that
					// found duplicates is a failed build, not a quietly pending index.
					if oi.shouldAllowUniquePendingState(store) {
						if _, err = store.MarkIndexReadableOrUniquePending(idx.Name); err != nil {
							return nil, err
						}
					} else if _, err = store.MarkIndexReadable(idx.Name); err != nil {
						return nil, err
					}
					// Once the index is readable there is no need for the per-build bookkeeping.
					// Matches Java's IndexingBase: erase scanned-records/type-stamp/heartbeats in
					// the same transaction as the mark (eraseAllIndexingDataButTheLockAndRangeSet),
					// for both READABLE and READABLE_UNIQUE_PENDING.
					return nil, store.eraseAllIndexingDataButTheLockAndRangeSet(idx)
				})
			}
			attempts--
			// A non-empty queue is worth another attempt only when this session
			// drains it, as Java re-drains its queued indexes. A MARK_READABLE
			// session publishes a WRITE_ONLY_WITH_QUEUE index it never drained;
			// Java's store erases the queue as it marks the index readable, losing
			// the queued writes, while Go's MarkIndexReadable refuses a non-empty
			// queue with PendingWrites. Retrying that refusal would only repeat it,
			// so it is returned at once.
			var notBuilt *IndexNotBuiltError
			var conflict fdb.Error
			retry := (errors.As(err, &notBuilt) && notBuilt.PendingWrites && queuedInSession) || (errors.As(err, &conflict) && conflict.Code == 1020)
			if err == nil || attempts <= 0 || !retry {
				break
			}
			err = nil
		}
		if err == nil {
			oi.retireBuildTarget(idx)
		} else if firstErr == nil {
			firstErr = err
		}
	}
	return firstErr
}

// buildRange processes one chunk of records in a single transaction.
// Returns (recordsProcessed, hasMore, error).
//
// Uses Java's limit+1 look-ahead pattern (IndexingBase.scanPropertiesWithLimits):
// requests limit+1 records, indexes only the first limit, and uses the (limit+1)th
// record's PK as the exclusive range boundary. This prevents boundary records from
// being re-scanned in the next chunk — critical for non-idempotent indexes (COUNT, SUM).
//
// For multi-target: scans records once and updates all target index maintainers per
// record. Range tracking uses the primary index's RangeSet for reading, but inserts
// into all target indexes' RangeSets. Matches Java's IndexingMultiTargetByRecords.
func (oi *OnlineIndexer) buildRange(ctx context.Context) (int64, bool, error) {
	var r buildRangeResult
	_, err := oi.run(ctx, func(rtx *FDBRecordContext) (any, error) {
		var err error
		// Each attempt starts from a fresh result; a retry's values are stale.
		r, err = oi.buildRangeInTransaction(ctx, rtx)
		return nil, err
	})
	if err == nil {
		oi.mergeRequiredIndexes = r.mergeRequests
	}
	return r.recordsProcessed, r.hasMore, err
}

// buildRangeResult is one buildRange transaction's outcome.
type buildRangeResult struct {
	recordsProcessed int64
	hasMore          bool
	mergeRequests    []*Index
}

// buildRangeInTransaction is buildRange's body: it indexes one chunk in rtx,
// which the caller commits.
func (oi *OnlineIndexer) buildRangeInTransaction(ctx context.Context, rtx *FDBRecordContext) (buildRangeResult, error) {
	var r buildRangeResult
	started := rtx.Env().Now()

	store, err := oi.openStore(rtx)
	if err != nil {
		return r, err
	}

	if err := oi.validateBuildSession(store); err != nil {
		return r, err
	}

	// Primary index's RangeSet determines the build boundaries.
	primaryRangeSet := NewIndexingRangeSet(store.subspace, oi.primaryIndex())

	// Find first missing range.
	missing, err := primaryRangeSet.FirstMissingRange(rtx.Transaction())
	if err != nil {
		return r, err
	}
	if missing == nil {
		r.hasMore = false
		return r, nil
	}

	// Convert byte boundaries to a TupleRange for record scanning. The end boundary may
	// be a tuple+0xff (RANGE_INCLUSIVE high) written by the typed-records preset, which
	// unpackRangeEndBoundary maps to an INCLUSIVE high endpoint.
	var rangeStart, rangeEnd tuple.Tuple
	lowEp := EndpointTypeRangeInclusive
	highEp := EndpointTypeRangeExclusive
	if bytes.Equal(missing.Begin, rangeSetFirstKey) {
		lowEp = EndpointTypeTreeStart
	} else if rangeStart, err = tuplefast.Unpack(missing.Begin); err != nil {
		return r, fmt.Errorf("unpack range start: %w", err)
	}
	if bytes.Equal(missing.End, rangeSetFinalKey) {
		highEp = EndpointTypeTreeEnd
	} else if rangeEnd, highEp, err = unpackRangeEndBoundary(missing.End); err != nil {
		return r, fmt.Errorf("unpack range end: %w", err)
	}

	// Scan limit+1 records: process up to limit, use the extra as continuation.
	// Idempotent indexes use SNAPSHOT reads (no conflict tracking) for better
	// throughput. Non-idempotent indexes use SERIALIZABLE to prevent double-counting.
	// Matches Java's IndexingBase.scanPropertiesWithLimits().
	scanProps := ForwardScan()
	scanProps.ExecuteProperties.ReturnedRowLimit = saturatingAdd(oi.limit, 1)
	if oi.allTargetIndexesIdempotent() {
		scanProps.ExecuteProperties.IsolationLevel = IsolationLevelSnapshot
	}

	cursor := store.ScanRecordsInRange(rangeStart, rangeEnd, lowEp, highEp, nil, scanProps)

	var scannedCount int
	var extraPK tuple.Tuple
	// reachedLimits: the last record indexed took the transaction past its
	// time or write limit, so the next record ends the range.
	var reachedLimits bool

	for rec, iterErr := range Seq2(cursor, ctx) {
		if iterErr != nil {
			return r, iterErr
		}

		scannedCount++

		if scannedCount > oi.limit || reachedLimits {
			extraPK = rec.PrimaryKey
			break
		}

		// Count ALL scanned records, not just indexed ones.
		// Matches Java's IndexingBase.handleCursorResult() which increments
		// recordsScannedCounter for every record regardless of type filtering.
		r.recordsProcessed++

		indexed, err := oi.indexScannedRecord(store, rec)
		if err != nil {
			return r, err
		}
		if indexed {
			if reachedLimits, err = oi.transactionReachedLimits(rtx, started); err != nil {
				return r, err
			}
		}
	}

	// Mark progress in ALL target indexes' RangeSets.
	var rangeBeginBytes, rangeEndBytes []byte
	if rangeStart != nil {
		rangeBeginBytes = rangeStart.Pack()
	}

	if extraPK != nil {
		rangeEndBytes = extraPK.Pack()
		r.hasMore = true
	} else {
		// Mark up to the ORIGINAL byte boundary, not rangeEnd.Pack(): the boundary may
		// be a tuple+0xff (RANGE_INCLUSIVE high) written by the typed-records preset, and
		// the stripped rangeEnd.Pack() would drop the 0xff and invert the range.
		if !bytes.Equal(missing.End, rangeSetFinalKey) {
			rangeEndBytes = missing.End
		}
		r.hasMore = !bytes.Equal(missing.End, rangeSetFinalKey)
	}

	for _, idx := range oi.targetIndexes {
		rangeSet := NewIndexingRangeSet(store.subspace, idx)
		if err := insertIndexBuildRange(rangeSet, rtx.Transaction(), idx, rangeBeginBytes, rangeEndBytes); err != nil {
			return r, fmt.Errorf("mark range built for %q: %w", idx.Name, err)
		}
	}

	// Track progress: atomic ADD of records scanned per target index.
	// Matches Java's IndexingBase.tieredMergeAndCommit() progress tracking.
	if r.recordsProcessed > 0 {
		for _, idx := range oi.targetIndexes {
			store.AddBuildProgress(idx, r.recordsProcessed)
		}
	}

	r.mergeRequests = store.GetIndexDeferredMaintenanceControl().GetMergeRequiredIndexes()
	return r, nil
}

// indexScannedRecord maintains the targets covering rec, reporting whether any did. As in Java's
// handleCursorResult, the record-type filter precedes the read conflict.
func (oi *OnlineIndexer) indexScannedRecord(store *FDBRecordStore, rec *FDBStoredRecord[proto.Message]) (bool, error) {
	var applicable []*Index
	for _, idx := range oi.targetIndexes {
		if oi.shouldIndexRecordForIndex(rec, idx) {
			applicable = append(applicable, idx)
		}
	}
	if len(applicable) == 0 {
		return false, nil
	}
	if oi.allTargetIndexesIdempotent() {
		if err := store.AddRecordReadConflict(rec.PrimaryKey); err != nil {
			return false, err
		}
	}
	for _, idx := range applicable {
		maintainer, err := store.getIndexMaintainer(idx)
		if err != nil {
			return false, fmt.Errorf("index %q get maintainer: %w", idx.Name, err)
		}
		if err := maintainer.Update(nil, rec); err != nil {
			return false, fmt.Errorf("index %q record pk=%v: %w", idx.Name, rec.PrimaryKey, err)
		}
	}
	return true, nil
}

// buildIndexingStamp creates the IndexBuildIndexingStamp proto for this build.
//
// Single-target BY_RECORDS: method=BY_RECORDS.
// Single-target BY_INDEX: method=BY_INDEX with source index info.
// Multi-target: method=MULTI_TARGET_BY_RECORDS with sorted target index names.
//
// Matches Java's IndexingByRecords/IndexingByIndex/IndexingMultiTargetByRecords
// compileSingleTargetLegacyIndexingTypeStamp()/compileTargetIndexesLegacyIndexingTypeStamp().
func (oi *OnlineIndexer) buildIndexingStamp() *gen.IndexBuildIndexingStamp {
	if oi.buildsByIndex() {
		return &gen.IndexBuildIndexingStamp{
			Method:                         gen.IndexBuildIndexingStamp_BY_INDEX.Enum(),
			SourceIndexSubspaceKey:         tuple.Tuple{oi.sourceIndex.SubspaceTupleKey()}.Pack(),
			SourceIndexLastModifiedVersion: proto.Int32(int32(oi.sourceIndex.LastModifiedVersion)),
		}
	}

	if len(oi.targetIndexes) == 1 && !oi.buildsMutually() {
		return &gen.IndexBuildIndexingStamp{
			Method: gen.IndexBuildIndexingStamp_BY_RECORDS.Enum(),
		}
	}

	// Multi-target or mutual: index names in stamp (already sorted by Build()).
	// Matches Java's compileTargetIndexesLegacyIndexingTypeStamp().
	names := make([]string, len(oi.targetIndexes))
	for i, idx := range oi.targetIndexes {
		names[i] = idx.Name
	}

	method := gen.IndexBuildIndexingStamp_MULTI_TARGET_BY_RECORDS
	if oi.buildsMutually() {
		method = gen.IndexBuildIndexingStamp_MUTUAL_BY_RECORDS
	}

	return &gen.IndexBuildIndexingStamp{
		Method:      method.Enum(),
		TargetIndex: names,
	}
}

// transactionReachedLimits is Java's IndexingBase.hadTransactionReachedLimits:
// the range's transaction is older than the transaction time limit or larger
// than the write limit, so the range commits before its next record (which
// becomes the range's exclusive end, as a record past the count limit does).
func (oi *OnlineIndexer) transactionReachedLimits(rtx *FDBRecordContext, started time.Time) (bool, error) {
	if oi.transactionTimeLimitMs > 0 && rtx.Env().Now().Sub(started).Milliseconds() > oi.transactionTimeLimitMs {
		return true, nil
	}
	if oi.maxWriteLimitBytes > 0 {
		size, err := rtx.GetApproximateTransactionSize()
		if err != nil {
			return false, err
		}
		return size > oi.maxWriteLimitBytes, nil
	}
	return false, nil
}

// buildRangeByIndex processes one chunk via the BY_INDEX strategy: scans the
// source index to find records, then feeds them to the target index maintainer.
// Range tracking uses source index entry keys (not primary keys).
// Only valid for single-target builds.
// Matches Java's IndexingByIndex.buildRangeOnly().
func (oi *OnlineIndexer) buildRangeByIndex(ctx context.Context) (int64, bool, error) {
	var recordsProcessed int64
	var hasMore bool
	var mergeRequests []*Index

	_, err := oi.run(ctx, func(rtx *FDBRecordContext) (any, error) {
		// Reset on retry — previous attempt's values are stale.
		recordsProcessed = 0
		mergeRequests = nil
		hasMore = false
		started := rtx.Env().Now()

		store, err := oi.openStore(rtx)
		if err != nil {
			return nil, err
		}

		if err := oi.validateBuildSession(store); err != nil {
			return nil, err
		}

		// FormatVersion 10 check: non-idempotent indexes cannot be built from a source
		// index on stores with format version < CHECK_INDEX_BUILD_TYPE_DURING_UPDATE.
		// On older format versions, UpdateWhileWriteOnly uses primary key range set checks
		// which are incorrect for source-index-based builds. Both this and the
		// scannability check below are Java IndexingByIndex.buildRangeOnly's
		// validateOrThrowEx failures, which the build catcher answers by falling
		// back to a records scan.
		if store.GetFormatVersion() < formatVersionCheckIndexBuildType && !isIndexIdempotent(oi.primaryIndex()) {
			return nil, oi.sourceValidationError("target index is not idempotent")
		}

		state, err := store.readIndexState(oi.sourceIndex.Name)
		if err != nil {
			return nil, err
		}
		if !state.IsScannable() {
			return nil, oi.sourceValidationError("source index is not scannable")
		}

		rangeSet := NewIndexingRangeSet(store.subspace, oi.primaryIndex())

		// Find first missing range.
		missing, err := rangeSet.FirstMissingRange(rtx.Transaction())
		if err != nil {
			return nil, err
		}
		if missing == nil {
			hasMore = false
			return nil, nil
		}

		// Convert byte boundaries to TupleRange for source index scanning.
		var rangeStart, rangeEnd tuple.Tuple
		if !bytes.Equal(missing.Begin, rangeSetFirstKey) {
			rangeStart, err = tuplefast.Unpack(missing.Begin)
			if err != nil {
				return nil, fmt.Errorf("unpack range start: %w", err)
			}
		}
		if !bytes.Equal(missing.End, rangeSetFinalKey) {
			rangeEnd, err = tuplefast.Unpack(missing.End)
			if err != nil {
				return nil, fmt.Errorf("unpack range end: %w", err)
			}
		}

		scanRange := TupleRange{
			Low:          rangeStart,
			High:         rangeEnd,
			LowEndpoint:  EndpointTypeRangeInclusive,
			HighEndpoint: EndpointTypeRangeExclusive,
		}
		if rangeStart == nil {
			scanRange.LowEndpoint = EndpointTypeTreeStart
		}
		if rangeEnd == nil {
			scanRange.HighEndpoint = EndpointTypeTreeEnd
		}

		scanProps := ForwardScan()
		scanProps.ExecuteProperties.ReturnedRowLimit = saturatingAdd(oi.limit, 1)
		if oi.allTargetIndexesIdempotent() {
			scanProps.ExecuteProperties.IsolationLevel = IsolationLevelSnapshot
		}

		cursor := store.ScanIndexRecords(oi.sourceIndex.Name, scanRange, nil, scanProps)

		maintainer, mErr := store.getIndexMaintainer(oi.primaryIndex())
		if mErr != nil {
			return nil, mErr
		}
		var scannedCount int
		var extraKey tuple.Tuple
		var reachedLimits bool // as in buildRange

		for indexedRec, iterErr := range Seq2(cursor, ctx) {
			if iterErr != nil {
				return nil, iterErr
			}

			scannedCount++

			if scannedCount > oi.limit || reachedLimits {
				extraKey = indexedRec.IndexEntry.Key
				break
			}

			rec := indexedRec.Record
			// Count ALL scanned records regardless of type filtering.
			// Matches Java's IndexingBase.handleCursorResult().
			recordsProcessed++

			if !oi.shouldIndexRecordForIndex(rec, oi.primaryIndex()) {
				continue
			}

			if oi.allTargetIndexesIdempotent() {
				if err := store.AddRecordReadConflict(rec.PrimaryKey); err != nil {
					return nil, err
				}
			}
			if err := maintainer.Update(nil, rec); err != nil {
				return nil, fmt.Errorf("index record pk=%v: %w", rec.PrimaryKey, err)
			}
			if reachedLimits, err = oi.transactionReachedLimits(rtx, started); err != nil {
				return nil, err
			}
		}

		var rangeBeginBytes, rangeEndBytes []byte
		if rangeStart != nil {
			rangeBeginBytes = rangeStart.Pack()
		}

		if extraKey != nil {
			rangeEndBytes = extraKey.Pack()
			hasMore = true
		} else {
			if rangeEnd != nil {
				rangeEndBytes = rangeEnd.Pack()
			}
			hasMore = !bytes.Equal(missing.End, rangeSetFinalKey)
		}

		err = insertIndexBuildRange(rangeSet, rtx.Transaction(), oi.primaryIndex(), rangeBeginBytes, rangeEndBytes)
		if err != nil {
			return nil, fmt.Errorf("mark range built: %w", err)
		}

		// Track progress: atomic ADD of records scanned.
		if recordsProcessed > 0 {
			store.AddBuildProgress(oi.primaryIndex(), recordsProcessed)
		}

		mergeRequests = store.GetIndexDeferredMaintenanceControl().GetMergeRequiredIndexes()
		return nil, nil
	})

	if err == nil {
		oi.mergeRequiredIndexes = mergeRequests
	}
	return recordsProcessed, hasMore, err
}

// isIndexTypeIdempotent returns true if the given index type produces idempotent
// updates. Idempotent indexes can safely use SNAPSHOT reads during online builds
// because re-applying the same operation produces the same result.
// Matches Java's IndexMaintainer.isIdempotent().
func isIndexIdempotent(index *Index) bool {
	switch canonicalIndexType(index.Type) {
	case IndexTypeValue,
		IndexTypeMinEverLong, IndexTypeMaxEverLong,
		IndexTypeMinEverTuple, IndexTypeMaxEverTuple,
		IndexTypeMaxEverVersion, IndexTypeVersion,
		IndexTypePermutedMin, IndexTypePermutedMax,
		IndexTypeText, IndexTypeBitmapValue, IndexTypeMultidimensional,
		IndexTypeVector:
		// StandardIndexMaintainer.isIdempotent's true, which these do not
		// override (StandardIndexMaintainer.java:736-738), and the atomic
		// mutations AtomicMutation.isIdempotent calls idempotent. A windowed
		// VECTOR index is its delegate's (SlidingWindowIndexMaintainer.java:364).
		return true
	case IndexTypeRank, IndexTypeTimeWindowLeaderboard:
		// RankIndexMaintainer.isIdempotent and
		// TimeWindowLeaderboardIndexMaintainer.isIdempotent: not when
		// duplicates are counted.
		return !index.GetBooleanOption(IndexOptionRankCountDuplicates, false)
	case IndexTypeCount, IndexTypeCountNotNull, IndexTypeCountUpdates, IndexTypeSum:
		return false
	default:
		// A registered factory answers for its own type (Java asks the
		// maintainer's isIdempotent).
		if f, err := lookupIndexMaintainerFactory(index); err == nil && f != nil {
			if i, ok := f.(idempotentIndexMaintainerFactory); ok {
				return i.IsIdempotent(index)
			}
		}
		// A type Go does not maintain has no maintainer, and Java no
		// isIdempotent to ask. Go's own vector_spfresh index is built as
		// non-idempotent (its generations are reconciled by
		// spfreshIndexMaintainer.UpdateWhileWriteOnly).
		return false
	}
}

// allTargetIndexesIdempotent returns true if all target indexes are idempotent.
// Matches Java's IndexMaintainer.isIdempotent() per index.
func (oi *OnlineIndexer) allTargetIndexesIdempotent() bool {
	for _, idx := range oi.targetIndexes {
		if !isIndexIdempotent(idx) {
			return false
		}
	}
	return true
}

// shouldIndexRecordForIndex checks if a record should be indexed by a specific
// index, based on record type matching.
func (oi *OnlineIndexer) shouldIndexRecordForIndex(rec *FDBStoredRecord[proto.Message], idx *Index) bool {
	if len(oi.recordTypes) > 0 {
		// Preset record types override — applies to all indexes in single-target.
		//
		// RESOLVE each configured name, exactly as indexedRecordTypes does. Both
		// read the same oi.recordTypes, which SetRecordTypes takes verbatim from
		// an exported builder, and GetRecordType accepts a SQL identifier for a
		// type stored under its escaped spelling. Comparing raw here while
		// resolving there let the two disagree about the SAME configuration: the
		// indexer would report the type as in scope and then index none of its
		// records, leaving a BUILT, READABLE, EMPTY index. That is worse than an
		// empty scan -- queries answer from it and are wrong.
		for _, t := range oi.recordTypes {
			want := t
			if rt := oi.metaData.GetRecordType(t); rt != nil {
				want = rt.Name
			}
			if rec.RecordType.Name == want {
				return true
			}
		}
		return false
	}
	// Check if the record type has this index defined.
	for _, rtIdx := range oi.metaData.GetIndexesForRecordType(rec.RecordType.Name) {
		if rtIdx.Name == idx.Name {
			return true
		}
	}
	for _, uIdx := range oi.metaData.GetUniversalIndexes() {
		if uIdx.Name == idx.Name {
			return true
		}
	}
	return false
}

// openStore opens an FDBRecordStore for the current transaction.
func (oi *OnlineIndexer) openStore(rtx *FDBRecordContext) (*FDBRecordStore, error) {
	return oi.openStoreWithPreflight(rtx, nil)
}

func (oi *OnlineIndexer) openStoreWithPreflight(rtx *FDBRecordContext, preflight func(*FDBRecordStore) error) (*FDBRecordStore, error) {
	// The format version rides along with every store this indexer opens. Java
	// threads it the same way, by reusing the caller's record-store builder
	// (IndexingCommon.getRecordStoreBuilder), so an indexer cannot silently open a
	// store at a newer format than the instance that configured it -- which would
	// defeat the format half of shouldAllowUniquePendingState.
	sb := NewStoreBuilder()
	if oi.storeTemplate != nil {
		sb = oi.storeTemplate.copyBuilder()
	}
	sb = sb.SetContext(rtx).
		SetMetaDataProvider(oi.metaData).
		SetSubspace(oi.subspace)
	// Only PASS THROUGH an explicit pin. Calling SetFormatVersion unconditionally
	// would hand the store builder an explicit 0, which it rejects.
	if oi.formatVersion != nil {
		sb = sb.SetFormatVersion(*oi.formatVersion)
	}
	sb = sb.SetIndexMaintenanceFilter(oi.maintenanceFilter)
	return sb.openWithPreflight(preflight)
}

// BlockIndex sets the block flag on the indexing stamp for all target indexes.
// A blocked stamp prevents other indexers from continuing the build.
// blockID is an optional identifier for the block reason.
// ttl is the time-to-live for the block; zero means permanent.
// Matches Java's IndexingBase.performIndexingStampOperation(BLOCK, ...).
func (oi *OnlineIndexer) BlockIndex(ctx context.Context, blockID string, ttl time.Duration) error {
	_, err := oi.run(ctx, func(rtx *FDBRecordContext) (any, error) {
		store, err := oi.openStore(rtx)
		if err != nil {
			return nil, err
		}
		for _, idx := range oi.targetIndexes {
			stamp, err := store.LoadIndexingTypeStamp(idx)
			if err != nil {
				return nil, err
			}
			if stamp == nil {
				continue
			}
			stamp.Block = proto.Bool(true)
			if blockID != "" {
				stamp.BlockID = proto.String(blockID)
			} else {
				stamp.BlockID = proto.String("")
			}
			if ttl > 0 {
				// Persisted lease-expiry: route through the context clock seam (RFC-199
				// Tier 0) so a simulation run writes a reproducible expiry. A nil env
				// (production) reads the wall clock — byte-identical to the prior time.Now().
				stamp.BlockExpireEpochMilliSeconds = proto.Uint64(uint64(rtx.Env().Now().Add(ttl).UnixMilli()))
			} else {
				stamp.BlockExpireEpochMilliSeconds = nil
			}
			if err := store.SaveIndexingTypeStamp(idx, stamp); err != nil {
				return nil, err
			}
		}
		return nil, nil
	})
	return err
}

// UnblockIndex clears the block flag on the indexing stamp for all target indexes.
// If blockID is non-empty, only unblocks stamps with a matching blockID.
// Matches Java's IndexingBase.performIndexingStampOperation(UNBLOCK, ...).
func (oi *OnlineIndexer) UnblockIndex(ctx context.Context, blockID string) error {
	_, err := oi.run(ctx, func(rtx *FDBRecordContext) (any, error) {
		store, err := oi.openStore(rtx)
		if err != nil {
			return nil, err
		}
		for _, idx := range oi.targetIndexes {
			stamp, err := store.LoadIndexingTypeStamp(idx)
			if err != nil {
				return nil, err
			}
			if stamp == nil || !stamp.GetBlock() {
				continue
			}
			if blockID != "" && stamp.GetBlockID() != blockID {
				continue // ID mismatch — don't unblock
			}
			stamp.Block = proto.Bool(false)
			if err := store.SaveIndexingTypeStamp(idx, stamp); err != nil {
				return nil, err
			}
		}
		return nil, nil
	})
	return err
}

// MarkReadableIfBuilt checks each target index and marks it READABLE if fully built.
// Returns true if all target indexes are now READABLE.
// This is an idempotent operation — safe to call repeatedly.
// Matches Java's IndexingBase.markReadableIfBuilt().
func (oi *OnlineIndexer) MarkReadableIfBuilt(ctx context.Context) (bool, error) {
	allReadable := true
	_, err := oi.run(ctx, func(rtx *FDBRecordContext) (any, error) {
		// Reset on retry — previous attempt's result is stale.
		allReadable = true
		store, err := oi.openStore(rtx)
		if err != nil {
			return nil, err
		}
		for _, idx := range oi.targetIndexes {
			state, err := store.readIndexState(idx.Name)
			if err != nil {
				return nil, err
			}
			if state == IndexStateReadable {
				continue
			}
			rangeSet := NewIndexingRangeSet(store.subspace, idx)
			missing, err := rangeSet.FirstMissingRange(rtx.Transaction())
			if err != nil {
				return nil, err
			}
			if missing != nil {
				allReadable = false
				continue
			}
			// Index is fully built — mark readable.
			if _, err := store.MarkIndexReadable(idx.Name); err != nil {
				return nil, err
			}
		}
		return nil, nil
	})
	if err != nil {
		return false, err
	}
	return allReadable, nil
}

// QueryIndexingStamps returns the indexing stamps for all target indexes.
// Returns a map of index name → stamp. Nil stamps are returned as a NONE method stamp.
// Matches Java's IndexingBase.performIndexingStampOperation(QUERY, ...).
func (oi *OnlineIndexer) QueryIndexingStamps(ctx context.Context) (map[string]*gen.IndexBuildIndexingStamp, error) {
	stamps := make(map[string]*gen.IndexBuildIndexingStamp, len(oi.targetIndexes))
	_, err := oi.run(ctx, func(rtx *FDBRecordContext) (any, error) {
		store, err := oi.openStore(rtx)
		if err != nil {
			return nil, err
		}
		for _, idx := range oi.targetIndexes {
			stamp, err := store.LoadIndexingTypeStamp(idx)
			if err != nil {
				return nil, err
			}
			if stamp == nil {
				stamp = &gen.IndexBuildIndexingStamp{
					Method: gen.IndexBuildIndexingStamp_NONE.Enum(),
				}
			}
			stamps[idx.Name] = stamp
		}
		return nil, nil
	})
	if err != nil {
		return nil, err
	}
	return stamps, nil
}
