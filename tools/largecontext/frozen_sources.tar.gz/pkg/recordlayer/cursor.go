// Portions derived from FoundationDB Record Layer (RecordCursorResult.java,
// RecordCursor.java, RecordCursorEndContinuation.java,
// RecordCursorStartContinuation.java, and others),
// Copyright 2015-2018 Apple Inc. and the FoundationDB project authors
// Licensed under the Apache License, Version 2.0; translated to Go and modified.

package recordlayer

import (
	"context"
	"fmt"
	"iter"
	"math"
)

// NoNextReason indicates why a cursor stopped producing records
type NoNextReason int

const (
	// SourceExhausted means the cursor reached the end of its data
	SourceExhausted NoNextReason = iota
	// ReturnLimitReached means the cursor hit its row limit
	ReturnLimitReached
	// ByteLimitReached means the cursor hit its byte scan limit
	ByteLimitReached
	// TimeLimitReached means the cursor hit its time limit
	TimeLimitReached
	// ScanLimitReached means the cursor hit its key-value scan limit
	ScanLimitReached
)

// IsOutOfBand returns true if this reason represents an out-of-band completion
// (not solely dependent on the records returned)
func (r NoNextReason) IsOutOfBand() bool {
	return r != SourceExhausted && r != ReturnLimitReached
}

// IsSourceExhausted returns true if there is no more data available
func (r NoNextReason) IsSourceExhausted() bool {
	return r == SourceExhausted
}

// IsLimitReached returns true if the cursor stopped due to any kind of limit
func (r NoNextReason) IsLimitReached() bool {
	return r != SourceExhausted
}

// RecordCursorContinuation represents the position of a cursor for resumption
type RecordCursorContinuation interface {
	// ToBytes serializes this continuation to a byte array.
	// Returns (nil, nil) if this is an end continuation.
	ToBytes() ([]byte, error)

	// IsEnd returns true if this represents the end of iteration
	IsEnd() bool
}

// BytesContinuation is a simple continuation that wraps a byte array
type BytesContinuation struct {
	bytes []byte
}

// NewBytesContinuation creates a BytesContinuation with the given bytes.
// A nil bytes value means end-of-cursor (IsEnd returns true).
func NewBytesContinuation(b []byte) *BytesContinuation {
	return &BytesContinuation{bytes: b}
}

// ToBytes returns the continuation bytes
func (c *BytesContinuation) ToBytes() ([]byte, error) {
	return c.bytes, nil
}

// IsEnd returns true if this is an end continuation
func (c *BytesContinuation) IsEnd() bool {
	return c.bytes == nil
}

// EndContinuation represents the end of a cursor's iteration.
// INVARIANT: Only valid when NoNextReason is SourceExhausted.
// Matches Java's RecordCursorEndContinuation.
type EndContinuation struct{}

// ToBytes always returns nil for end continuations
func (c *EndContinuation) ToBytes() ([]byte, error) {
	return nil, nil
}

// IsEnd always returns true for end continuations
func (c *EndContinuation) IsEnd() bool {
	return true
}

// StartContinuation represents the start of a cursor's iteration, or a state
// where no continuation is available for the current result. Unlike EndContinuation,
// this is NOT terminal — the cursor may have more data.
// Matches Java's RecordCursorStartContinuation.
type StartContinuation struct{}

// ToBytes returns nil (no position information available).
func (c *StartContinuation) ToBytes() ([]byte, error) {
	return nil, nil
}

// IsEnd returns false — StartContinuation is never an end state.
func (c *StartContinuation) IsEnd() bool {
	return false
}

// RecordCursorResult represents the result of a cursor's OnNext() call.
//
// Invariants (matching Java's RecordCursorResult):
//   - A result WITH a value (HasNext=true) must NOT have an EndContinuation
//   - A result with SourceExhausted MUST have an EndContinuation
//   - A result with any other NoNextReason must NOT have an EndContinuation
//
// The value is held BY VALUE, not behind a pointer, and hasNext is what
// distinguishes "has a value" — the pointer carried no information the flag does
// not. Boxing it cost one heap allocation per emitted row PER CURSOR LEVEL, and a
// plan is a stack of cursors: on a 20k-row wide scan whose plan is a projection
// over a scan, the boxes were the largest single allocator in the row path.
// GetValue still refuses to answer without a value, so the zero T a no-next
// result now carries is unreachable.
type RecordCursorResult[T any] struct {
	value        T
	continuation RecordCursorContinuation
	noNextReason NoNextReason
	hasNext      bool
}

// NewResultWithValue creates a result with a value.
// Panics if continuation is an EndContinuation OR nil — a value result
// must always carry a RESUMABLE continuation (Java's
// RecordCursorResult.withNextValue has no null arm). A nil here would
// make every parent snapshot the child as START and silently replay the
// emitted rows on resume.
func NewResultWithValue[T any](value T, continuation RecordCursorContinuation) RecordCursorResult[T] {
	if continuation == nil {
		panic("value result requires a resumable continuation, got nil")
	}
	if continuation.IsEnd() {
		panic("cannot return end continuation with next value")
	}
	return RecordCursorResult[T]{
		value:        value,
		continuation: continuation,
		hasNext:      true,
	}
}

// NewResultNoNext creates a result indicating no more records.
// Enforces invariants matching Java's RecordCursorResult.withoutNextValue():
//   - EndContinuation is only valid with SourceExhausted
//   - SourceExhausted requires an EndContinuation
func NewResultNoNext[T any](reason NoNextReason, continuation RecordCursorContinuation) RecordCursorResult[T] {
	isEnd := continuation != nil && continuation.IsEnd()
	if isEnd && !reason.IsSourceExhausted() {
		panic(fmt.Sprintf("cannot return end continuation with NoNextReason %d (only valid for SourceExhausted)", reason))
	}
	if reason.IsSourceExhausted() && !isEnd {
		panic("SourceExhausted requires an end continuation")
	}
	return RecordCursorResult[T]{
		continuation: continuation,
		noNextReason: reason,
		hasNext:      false,
	}
}

// HasNext returns true if this result contains a value
func (r RecordCursorResult[T]) HasNext() bool {
	return r.hasNext
}

// GetValue returns the value. Panics if HasNext() is false — callers must check HasNext() first.
// This matches Java's behavior of throwing IllegalResultValueAccessException.
func (r RecordCursorResult[T]) GetValue() T {
	if !r.hasNext {
		panic("GetValue called on RecordCursorResult with no value (check HasNext() first)")
	}
	return r.value
}

// GetContinuation returns the continuation for resuming the cursor
func (r RecordCursorResult[T]) GetContinuation() RecordCursorContinuation {
	return r.continuation
}

// GetNoNextReason returns the reason why there's no next record (valid when HasNext is false)
func (r RecordCursorResult[T]) GetNoNextReason() NoNextReason {
	return r.noNextReason
}

// HasStoppedBeforeEnd returns true if the cursor stopped before exhausting all records.
// This means the cursor can be resumed with the continuation to get more results.
// Matches Java's RecordCursorResult.hasStoppedBeforeEnd() which checks the continuation,
// not the reason — with the EndContinuation↔SourceExhausted invariant, these are equivalent.
func (r RecordCursorResult[T]) HasStoppedBeforeEnd() bool {
	return !r.hasNext && r.continuation != nil && !r.continuation.IsEnd()
}

// WithContinuation returns a copy of this result with a different continuation.
// Matches Java's RecordCursorResult.withContinuation().
func (r RecordCursorResult[T]) WithContinuation(continuation RecordCursorContinuation) RecordCursorResult[T] {
	r.continuation = continuation
	return r
}

// MapResult transforms a result's value using the given function.
// If the result has no value (HasNext() is false), returns a no-next result
// with the same reason and continuation. Go generics require this as a
// standalone function rather than a method.
// Matches Java's RecordCursorResult.map().
func MapResult[T, R any](result RecordCursorResult[T], fn func(T) R) RecordCursorResult[R] {
	if !result.hasNext {
		return NewResultNoNext[R](result.noNextReason, result.continuation)
	}
	mapped := fn(result.value)
	return NewResultWithValue(mapped, result.continuation)
}

// RecordCursor is a generic async iterator over records
type RecordCursor[T any] interface {
	// OnNext asynchronously returns the next result from this cursor
	OnNext(ctx context.Context) (RecordCursorResult[T], error)

	// Close releases any resources held by this cursor
	Close() error

	// IsClosed returns true if the cursor has been closed
	IsClosed() bool
}

// CursorFactory creates a cursor from an optional continuation.
// nil continuation means start from the beginning.
type CursorFactory[T any] func(continuation []byte) RecordCursor[T]

// Seq2 returns an iterator sequence over (value, error) pairs.
func Seq2[T any](cursor RecordCursor[T], ctx context.Context) iter.Seq2[T, error] {
	return func(yield func(T, error) bool) {
		defer func() { _ = cursor.Close() }()
		for {
			if err := ctx.Err(); err != nil {
				yield(*new(T), err)
				return
			}
			result, err := cursor.OnNext(ctx)
			if err != nil {
				yield(*new(T), err)
				return
			}
			if !result.HasNext() {
				// Surface an out-of-band (resource-limit) stop on the error channel
				// so a Seq2 consumer doesn't read a truncated scan as clean end-of-data
				// (RFC-106a). SourceExhausted/ReturnLimitReached → clean end.
				if e := errIfDrainTruncated(result); e != nil {
					yield(*new(T), e)
				}
				return
			}
			if !yield(result.GetValue(), nil) {
				return
			}
		}
	}
}

// emptyCursor is a cursor that immediately returns no results.
// Matches Java's RecordCursor.empty().
type emptyCursor[T any] struct{ closed bool }

// Empty returns a cursor that produces no results (source exhausted immediately).
func Empty[T any]() RecordCursor[T] {
	return &emptyCursor[T]{}
}

func (c *emptyCursor[T]) OnNext(_ context.Context) (RecordCursorResult[T], error) {
	return NewResultNoNext[T](SourceExhausted, &EndContinuation{}), nil
}

// Close/IsClosed track state like Java's EmptyCursor (close() sets a flag
// isClosed() reports) — the cursor holds no resources, but the contract is
// observable.
func (c *emptyCursor[T]) Close() error { c.closed = true; return nil }

func (c *emptyCursor[T]) IsClosed() bool { return c.closed }

// stoppedCursor is a cursor that immediately reports a no-next result with a
// caller-supplied reason and continuation — the cursor-level spelling of Java's
// RecordCursorResult.withoutNextValue(continuation, reason). It exists so a plan
// whose construction ALREADY consumed the out-of-band stop (it had to drain its
// input eagerly to decide what to flow) can still hand its parent a stop the
// parent can page on, instead of collapsing a resumable page boundary into a
// terminal error.
type stoppedCursor[T any] struct {
	reason       NoNextReason
	continuation RecordCursorContinuation
	closed       bool
}

// Stopped returns a cursor that produces no value and reports the given
// NoNextReason and continuation. reason must be a genuine stop reason and, per
// RecordCursor's contract (RecordCursor.java:212-215), anything other than
// SourceExhausted must carry a NON-end continuation so the caller can resume.
//
// The precondition is checked HERE and not left to NewResultNoNext at pull time.
// Java validates in RecordCursorResult.withoutNextValue (RecordCursorResult.java:252-258),
// where deciding the stop and reporting it are the same instant. A cursor splits
// those apart: a violation built here would otherwise surface as a panic from
// whichever parent happened to pull it, naming a stack that does not contain the
// mistake. A misbuilt stop is a programming error either way — this only decides
// whether the failure names its author.
func Stopped[T any](reason NoNextReason, continuation RecordCursorContinuation) RecordCursor[T] {
	if continuation == nil {
		panic("Stopped requires a resumable continuation, got nil")
	}
	// Delegating rather than re-deriving keeps the two checks from drifting:
	// this is the same validation the result will run on every pull.
	_ = NewResultNoNext[T](reason, continuation)
	return &stoppedCursor[T]{reason: reason, continuation: continuation}
}

func (c *stoppedCursor[T]) OnNext(_ context.Context) (RecordCursorResult[T], error) {
	return NewResultNoNext[T](c.reason, c.continuation), nil
}

func (c *stoppedCursor[T]) Close() error { c.closed = true; return nil }

func (c *stoppedCursor[T]) IsClosed() bool { return c.closed }

// errorCursor is a cursor that immediately returns an error on every OnNext call.
// Used when a cursor cannot be created (e.g., scanning a non-readable index).
type errorCursor[T any] struct {
	err error
}

func (c *errorCursor[T]) OnNext(_ context.Context) (RecordCursorResult[T], error) {
	return RecordCursorResult[T]{}, c.err
}

func (c *errorCursor[T]) Close() error { return nil }

func (c *errorCursor[T]) IsClosed() bool { return false }

// listCursor wraps a slice as a cursor. Matches Java's RecordCursor.fromList().
// Supports continuation via single-byte position encoding (up to 255 elements).
type listCursor[T any] struct {
	items  []T
	pos    int
	closed bool
}

// FromList creates a cursor from a slice. Matches Java's RecordCursor.fromList().
func FromList[T any](items []T) RecordCursor[T] {
	return &listCursor[T]{items: items}
}

// FromListWithContinuation creates a cursor from a slice, starting from a continuation.
// Matches Java's RecordCursor.fromList(list, continuation).
// Continuation format: 4-byte big-endian position (nil/empty = start from beginning).
// Java uses ByteBuffer.wrap(continuation).getInt() which reads first 4 bytes and
// throws BufferUnderflowException for continuations shorter than 4 bytes. Go returns
// an error from OnNext for invalid continuation lengths to match Java's fail-fast behavior.
func FromListWithContinuation[T any](items []T, continuation []byte) RecordCursor[T] {
	if continuation == nil {
		return &listCursor[T]{items: items, pos: 0}
	}
	// A non-nil but short (including EMPTY) continuation is malformed: Java's
	// ByteBuffer.getInt() underflows on it — only null means "start".
	if len(continuation) < 4 {
		// Java throws BufferUnderflowException. Return an error cursor.
		return &errorCursor[T]{err: fmt.Errorf("invalid list continuation: expected at least 4 bytes, got %d", len(continuation))}
	}
	// Read first 4 bytes as big-endian int (matches Java's ByteBuffer.getInt())
	start := int(continuation[0])<<24 | int(continuation[1])<<16 | int(continuation[2])<<8 | int(continuation[3])
	if start > len(items) {
		start = len(items)
	}
	return &listCursor[T]{items: items, pos: start}
}

func ListCursorContinuation(pos int) []byte {
	return []byte{byte(pos >> 24), byte(pos >> 16), byte(pos >> 8), byte(pos)}
}

func (c *listCursor[T]) OnNext(_ context.Context) (RecordCursorResult[T], error) {
	if c.closed || c.pos >= len(c.items) {
		return NewResultNoNext[T](SourceExhausted, &EndContinuation{}), nil
	}
	value := c.items[c.pos]
	c.pos++
	return NewResultWithValue(value, &BytesContinuation{bytes: ListCursorContinuation(c.pos)}), nil
}

func (c *listCursor[T]) Close() error {
	c.closed = true
	return nil
}

func (c *listCursor[T]) IsClosed() bool { return c.closed }

// saturatingAdd returns a + b, clamped to math.MaxInt on overflow.
// Both a and b must be non-negative.
func saturatingAdd(a, b int) int {
	if b > 0 && a > math.MaxInt-b {
		return math.MaxInt
	}
	return a + b
}

// Note: Most sequence utilities are available in Go 1.23+ standard library:
// - slices.Collect() for collecting sequences
// - Use range loops directly for counting, filtering, etc.
// - Many iterator utilities in the "iter" package
//
// We only provide Record Layer specific cursor transformations here.
