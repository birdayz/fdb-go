// Portions derived from FoundationDB Record Layer (
// OrderFunctionKeyExpression.java, OrderFunctionKeyExpressionFactory.java,
// TupleOrdering.java),
// Copyright 2024 Apple Inc. and the FoundationDB project authors
// Licensed under the Apache License, Version 2.0; translated to Go and modified.

package recordlayer

import (
	"fdb.dev/pkg/fdbgo/fdb/tuple"
	"google.golang.org/protobuf/proto"
)

// Order function names matching Java's OrderFunctionKeyExpressionFactory.
// Each name maps to a TupleOrdering.Direction encoding strategy.
const (
	OrderFuncAscNullsFirst  = "order_asc_nulls_first"
	OrderFuncAscNullsLast   = "order_asc_nulls_last"
	OrderFuncDescNullsFirst = "order_desc_nulls_first"
	OrderFuncDescNullsLast  = "order_desc_nulls_last"
)

func init() {
	// OrderFunctionKeyExpression.java:64-72, :88-90.
	for name, direction := range map[string]OrderDirection{
		OrderFuncAscNullsFirst:  OrderAscNullsFirst,
		OrderFuncAscNullsLast:   OrderAscNullsLast,
		OrderFuncDescNullsFirst: OrderDescNullsFirst,
		OrderFuncDescNullsLast:  OrderDescNullsLast,
	} {
		registerCoreFunction(name, FunctionSpec{Evaluator: makeOrderEvaluator(direction), MinArguments: 1, MaxArguments: 1, ColumnSize: 1})
	}
}

// isOrderFunctionName reports whether name is one of the four
// OrderFunctionKeyExpression names — the dispatch key for Java-subclass
// behaviour (createsDuplicates delegation) that Go's generic
// FunctionKeyExpression carries by name instead of by type.
func isOrderFunctionName(name string) bool {
	switch name {
	case OrderFuncAscNullsFirst, OrderFuncAscNullsLast,
		OrderFuncDescNullsFirst, OrderFuncDescNullsLast:
		return true
	default:
		return false
	}
}

// OrderFuncExpr creates a FunctionKeyExpression for ordering with the given
// direction name and arguments. Convenience wrapper matching Java's
// OrderFunctionKeyExpression constructor.
func OrderFuncExpr(direction string, arguments KeyExpression) *FunctionKeyExpression {
	return FunctionExpr(direction, arguments)
}

// makeOrderEvaluator creates a FunctionEvaluator that encodes tuple values
// according to the given order direction. Each argument tuple is packed into
// bytes using TupleOrdering encoding, which is then stored as the index key
// value (a byte string element in the FDB tuple).
//
// Matches Java's OrderFunctionKeyExpression.evaluateFunction():
//
//	return Collections.singletonList(Key.Evaluated.scalar(
//	    ZeroCopyByteString.wrap(TupleOrdering.pack(arguments.toTuple(), direction))));
func makeOrderEvaluator(dir OrderDirection) FunctionEvaluator {
	return func(_ *FDBStoredRecord[proto.Message], _ proto.Message, arguments [][]any) ([][]any, error) {
		results := make([][]any, 0, len(arguments))
		for _, args := range arguments {
			t := make(tuple.Tuple, len(args))
			for i, a := range args {
				t[i] = a
			}
			packed, err := tupleOrderingPack(t, dir)
			if err != nil {
				return nil, err
			}
			results = append(results, []any{packed})
		}
		return results, nil
	}
}
