// Portions derived from FoundationDB Record Layer (FDBRecordStore.java,
// FDBStoredRecord.java, FormatVersion.java, TupleRange.java, and others),
// Copyright 2015-2018 Apple Inc. and the FoundationDB project authors
// Copyright 2015-2025 Apple Inc. and the FoundationDB project authors
// Licensed under the Apache License, Version 2.0; translated to Go and modified.

package recordlayer

import (
	"bytes"
	"context"
	"errors"
	"fmt"
	"maps"
	"slices"
	"sync"
	"time"
	"unsafe"

	"fdb.dev/pkg/recordlayer/internal/tuplefast"

	"fdb.dev/pkg/dst"
	"fdb.dev/pkg/fdbgo/fdb"
	"fdb.dev/pkg/fdbgo/fdb/subspace"
	"fdb.dev/pkg/fdbgo/fdb/tuple"
	"google.golang.org/protobuf/encoding/protowire"
	"google.golang.org/protobuf/proto"

	"fdb.dev/gen"
)

// Record Layer format versions - should match Java FormatVersion enum.
// See FormatVersion.java for the full list.
const (
	formatVersionInfoAdded = 1 // Minimum version (INFO_ADDED in Java)
	// formatVersionRecordCountAdded (2, RECORD_COUNT_ADDED) is the version at which
	// record counts exist on disk at all. An existing store below it has no counts
	// worth trusting, so reconciliation rebuilds them unconditionally — Java's first
	// rebuildRecordCounts arm (FDBRecordStore.java:5116, via
	// RECORD_COUNT_ADDED_FORMAT_VERSION at :208).
	formatVersionRecordCountAdded = 2
	// formatVersionRecordCountKeyAdded (3, RECORD_COUNT_KEY_ADDED) is the version at
	// which the store header can carry a record-count key at all.
	formatVersionRecordCountKeyAdded = 3
	// formatVersionSaveUnsplitWithSuffix (5, SAVE_UNSPLIT_WITH_SUFFIX) is the version at
	// which every record key carries a split suffix even when split_long_records is false —
	// unless DataStoreInfo.omit_unsplit_record_suffix is true (set when a store created at an
	// earlier format version is upgraded). Below this version, unsplit records are stored at
	// the bare key recordsSubspace.pack(primaryKey) with no suffix.
	formatVersionSaveUnsplitWithSuffix = 5
	// formatVersionSaveVersionWithRecord (6, SAVE_VERSION_WITH_RECORD) is the version at which
	// record versions are stored inline adjacent to the record (recordsSubspace.pack(pk, -1))
	// rather than in the separate RecordVersionKey(8) subspace. See useOldVersionFormat().
	formatVersionSaveVersionWithRecord = 6
	// (7 = CACHEABLE_STATE; declared separately as formatVersionCacheableState below.)
	formatVersionHeaderUserFields      = 8  // User-defined key→bytes map in store header
	formatVersionReadableUniquePending = 9  // READABLE_UNIQUE_PENDING index state
	formatVersionCheckIndexBuildType   = 10 // Non-idempotent index build-from-source validation
	formatVersionRecordCountState      = 11 // RecordCountState enum (READABLE/WRITE_ONLY/DISABLED)
	formatVersionStoreLockState        = 12 // StoreLockState with FORBID_RECORD_UPDATE + FULL_STORE
	formatVersionIncarnation           = 13 // Incarnation counter for cross-cluster migration
	formatVersionFullStoreLock         = 14 // Unknown lock states prevent store opening
	formatVersionPendingWrites         = 15 // Pending index write queues
	// formatVersionMaxSupported is the highest format this binary can OPEN, and
	// it is a different question from the version a new store is BORN at.
	//
	// Java keeps the two apart deliberately — getMaximumSupportedVersion()
	// (FormatVersion.java:209) against getDefaultFormatVersion() (`:221-223`) —
	// and Go had them fused into one constant, which made the default impossible
	// to move without also moving the ceiling. Lowering a fused constant would
	// have REJECTED every store this binary had already created at 14, so "just
	// change the default" was a change that could not be made safely. Splitting
	// them is what makes it a free decision.
	//
	// Matches Java's MAX_SUPPORTED_VERSION, computed as the max enum value
	// (FormatVersion.java:188), WRITE_ONLY_WITH_QUEUE(15) at 4.14.2.0.
	formatVersionMaxSupported = formatVersionPendingWrites

	// formatVersionDefault is the version a NEW store is created at, and the
	// version an existing store is upgraded to, when the caller pins nothing.
	//
	// Java defaults to CACHEABLE_STATE(7); Go retains FULL_STORE_LOCK(14).
	// Supporting explicit queued-write format 15 must not silently enable it for
	// existing deployments. See RFC-257 and DIVERGENCES.md for this default policy.
	formatVersionDefault = formatVersionFullStoreLock

	formatVersionMinimum = formatVersionInfoAdded // Matches Java's FormatVersion.getMinimumVersion()
)

// StoreIsLockedForRecordUpdatesError is returned when attempting to modify records
// in a store with FORBID_RECORD_UPDATE lock state.
// Matches Java's com.apple.foundationdb.record.StoreIsLockedForRecordUpdates.
type StoreIsLockedForRecordUpdatesError struct {
	Reason    string
	Timestamp int64
}

func (e *StoreIsLockedForRecordUpdatesError) Error() string {
	return fmt.Sprintf("Record Store is locked for record updates: %s (timestamp: %d)", e.Reason, e.Timestamp)
}

func (*StoreIsLockedForRecordUpdatesError) JavaRecordCoreException() {}

// StoreIsFullyLockedError is returned when attempting to open a store with
// FULL_STORE lock state without providing the correct bypass reason.
// Matches Java's com.apple.foundationdb.record.StoreIsFullyLockedException.
type StoreIsFullyLockedError struct {
	Reason    string
	Timestamp int64
}

func (e *StoreIsFullyLockedError) Error() string {
	return fmt.Sprintf("Record Store is fully locked and cannot be opened: %s (timestamp: %d)", e.Reason, e.Timestamp)
}

func (*StoreIsFullyLockedError) JavaRecordCoreException() {}

// UnknownStoreLockStateError is returned when a store has an unrecognized lock state
// at FormatVersion >= FULL_STORE_LOCK (14). This prevents opening stores with
// lock states added by newer versions that we don't understand.
// Matches Java's com.apple.foundationdb.record.UnknownStoreLockStateException.
type UnknownStoreLockStateError struct {
	// LockStateValue is the state as read: UNSPECIFIED (0) for a stored
	// number the enum does not declare, which Java's parse leaves in the
	// unknown fields and reads as the default.
	LockStateValue int32
	// UnknownFields is the lock-state message's unknown fields, Java's
	// LogMessageKeys.VALUE (UnknownStoreLockStateException.java:49): an
	// undeclared state number is there.
	UnknownFields []byte
}

func (e *UnknownStoreLockStateError) Error() string {
	return fmt.Sprintf("Store has unknown lock state: %d", e.LockStateValue)
}

func (*UnknownStoreLockStateError) JavaRecordCoreException() {}

// formatVersionCacheableState is the minimum format version required for
// store state cacheability. Matches Java's FormatVersion.CACHEABLE_STATE.
const formatVersionCacheableState = 7

// StaleMetaDataVersionError is returned when the stored metadata version is
// newer than the local metadata version, meaning another instance already
// evolved the schema. Matches Java's RecordStoreStaleMetaDataVersionException.
type StaleMetaDataVersionError struct {
	LocalVersion  int
	StoredVersion int
}

func (e *StaleMetaDataVersionError) Error() string {
	return fmt.Sprintf("local meta-data has stale version: local %d, stored %d", e.LocalVersion, e.StoredVersion)
}

func (*StaleMetaDataVersionError) JavaRecordCoreException() {}

// FDBRecordStore provides record storage operations within a transaction context.
// This is the main struct for storing and retrieving records.
type FDBRecordStore struct {
	deferredMaintenance IndexDeferredMaintenanceControl
	// maintenanceFilter is Java's FDBRecordStore.indexMaintenanceFilter; nil
	// is IndexMaintenanceFilterNormal.
	maintenanceFilter IndexMaintenanceFilter
	// serializer is the TransformedRecordSerializer records are written
	// through; nil writes the bare union message (StoreBuilder.SetSerializer).
	serializer *TransformedRecordSerializer
	// goOnlyCollation is StoreBuilder.SetGoOnlyCollation: the store may hold
	// Go collation keys (GoOnlyCollationError).
	goOnlyCollation    bool
	context            *FDBRecordContext
	metaData           *RecordMetaData
	subspace           subspace.Subspace
	recordsSubspace    subspace.Subspace     // Cached subspace.Sub(RecordKey) — avoids alloc per method call
	storeHeader        *gen.DataStoreInfo    // Cached store header, loaded on Open/Create or lazily
	indexStates        map[string]IndexState // Cached index states, loaded on Open/Create or lazily
	indexRebuildPolicy IndexRebuildPolicy    // Policy for rebuilding indexes on metadata version change
	// targetFormatVersion is the format version this store opens AT — the
	// ceiling maybeUpgradeFormatVersion upgrades toward, not necessarily the
	// newest the binary knows. 0 means formatVersionDefault.
	//
	// Java's equivalent is a builder property, not a constant
	// (FDBRecordStoreBase.BaseBuilder.setFormatVersion, :2245/:2266), and its
	// javadoc spells out the reason it must be settable: during a rolling
	// upgrade you arrange "for setFormatVersion to be called with the OLD format
	// version" everywhere, so that no instance starts writing a format the
	// not-yet-upgraded instances cannot read. A store that always jumped to the
	// newest version its binary knew would make that impossible.
	targetFormatVersion int32
	storeStateCache     FDBRecordStoreStateCache // Cache for store state across transactions
	stateMu             sync.RWMutex             // protects storeHeader + indexStates
	stateLoadOnce       sync.Once                // ensures lazy store state load happens exactly once (Build() path)
	stateLoadErr        error                    // error from lazy load (nil if loaded successfully or not yet attempted)
	indexStateView      *transactionIndexStateView
	versionChanged      bool     // true if checkPossiblyRebuild detected a version change
	maintainerCache     sync.Map // string → IndexMaintainer, cached per-transaction
}

// ensureStoreStateLoaded lazily loads store state (header + index states) from
// FDB on first call. Subsequent calls are no-ops via sync.Once.
//
// Matches Java's build() + lazy preloadRecordStoreStateAsync() pattern:
// Java's Builder.build() returns immediately (zero reads), then the first
// operation that needs index state calls preloadRecordStoreStateAsync().
//
// MUST be called before acquiring stateMu to avoid deadlock.
//
// For Open/CreateOrOpen paths, storeHeader and indexStates are already populated
// during the open call — stateLoadOnce.Do returns immediately.
func (store *FDBRecordStore) ensureStoreStateLoaded() {
	store.stateLoadOnce.Do(func() {
		// Loading and publishing must be atomic with context range clears;
		// otherwise a completed clear can be undone by an older snapshot.
		store.context.indexStateMu.Lock()
		defer store.context.indexStateMu.Unlock()
		if store.indexStateView != nil {
			return // already loaded and bound (Open/CreateOrOpen path)
		}
		if store.indexStates != nil {
			// Preserve the builder's explicit assume-all-readable fast path.
			store.indexStateView = store.context.indexStateViewLocked(store.subspace, store.indexStates)
			return
		}
		state, err := loadRecordStoreState(store, ExistenceCheckNone)
		if err != nil {
			// Capture the error for callers that can propagate it.
			// Default to all readable — safe when CreateOrOpen ran at
			// startup and all indexes are known to be built.
			store.stateLoadErr = err
			store.indexStates = make(map[string]IndexState)
			return
		}
		store.storeHeader = state.StoreHeader
		store.indexStates = state.IndexStates
		store.indexStateView = store.context.indexStateViewLocked(store.subspace, store.indexStates)
	})
}

// ensureStoreStateLoadedErr calls ensureStoreStateLoaded and returns any
// error that occurred during the lazy load. For callers that can propagate
// errors (batch operations, validate, updateSecondaryIndexes).
func (store *FDBRecordStore) ensureStoreStateLoadedErr() error {
	store.ensureStoreStateLoaded()
	return store.stateLoadErr
}

// IsVersionChanged returns true if the metadata version changed during
// the most recent Open/CreateOrOpen (i.e., checkPossiblyRebuild detected
// that the stored version < current metadata version).
// Matches Java's FDBRecordStore.isVersionChanged().
func (store *FDBRecordStore) IsVersionChanged() bool {
	return store.versionChanged
}

// AsBuilder creates a new StoreBuilder with this store's configuration, in
// the same context. Matches Java's FDBRecordStore.asBuilder() (new
// Builder(this), Builder.copyFrom(FDBRecordStore)).
func (store *FDBRecordStore) AsBuilder() *StoreBuilder {
	return store.builderFrom(store.context)
}

// CopyBuilder creates a new StoreBuilder with this store's configuration
// but for a different context (transaction). Used to open the same store
// in a new transaction; the configuration copied is AsBuilder's.
func (store *FDBRecordStore) CopyBuilder(newContext *FDBRecordContext) *StoreBuilder {
	return store.builderFrom(newContext)
}

// builderFrom is Java's Builder.copyFrom(FDBRecordStore)
// (FDBRecordStore.java:5744-5757) over the settings Go has: the serializer,
// the format version, the metadata, the subspace, the index rebuild policy,
// the maintenance filter and the state cache, in ctx. The format version is
// the store's own, Java's formatVersion field: the one it was opened at,
// raised to the header's by the open's upgrade check (maybeUpgradeFormatVersion,
// as checkPossiblyRebuild sets it, :4845-4847); a store built without that
// check keeps the builder's, as Java's does. A store re-opened from this one
// therefore opens at that version, and never upgrades a header its opener
// pinned lower (which an unpinned builder, opening at the default, would).
func (store *FDBRecordStore) builderFrom(ctx *FDBRecordContext) *StoreBuilder {
	formatVersion := store.effectiveFormatVersion()
	return &StoreBuilder{
		context:            ctx,
		metaData:           store.metaData,
		subspace:           store.subspace,
		indexRebuildPolicy: store.indexRebuildPolicy,
		storeStateCache:    store.storeStateCache,
		maintenanceFilter:  store.maintenanceFilter,
		serializer:         store.serializer,
		goOnlyCollation:    store.goOnlyCollation,
		formatVersion:      &formatVersion,
	}
}

// validateRecordUpdateAllowed checks if the store allows record mutations.
// Returns StoreIsLockedForRecordUpdatesError if the store header has
// StoreLockState set to FORBID_RECORD_UPDATE.
// Goroutine-safe via stateMu (read lock).
// Matches Java's FDBRecordStore.validateRecordUpdateAllowed().
func (store *FDBRecordStore) validateRecordUpdateAllowed() error {
	if err := store.ensureStoreStateLoadedErr(); err != nil {
		return fmt.Errorf("load store state: %w", err)
	}
	store.stateMu.RLock()
	defer store.stateMu.RUnlock()
	return store.validateRecordUpdateAllowedLocked()
}

// validateRecordUpdateAllowedLocked is the same check but caller must hold stateMu.
func (store *FDBRecordStore) validateRecordUpdateAllowedLocked() error {
	if store.storeHeader == nil {
		return nil
	}
	lockState := store.storeHeader.GetStoreLockState()
	if lockState == nil {
		return nil
	}
	if lockState.GetLockState() == gen.DataStoreInfo_StoreLockState_FORBID_RECORD_UPDATE {
		return &StoreIsLockedForRecordUpdatesError{
			Reason:    lockState.GetReason(),
			Timestamp: lockState.GetTimestamp(),
		}
	}
	return nil
}

// validateStoreLockState checks lock state during store open.
// FULL_STORE prevents opening unless bypass reason matches exactly.
// At FormatVersion >= FULL_STORE_LOCK (14), unknown/unspecified states also prevent opening.
// Matches Java's FDBRecordStore.validateStoreLockState(): the bypass is
// nullable (nil = none), so a lock stored with an empty reason is
// bypassable by supplying "" — non-nil empty compares equal, exactly as
// Java's `bypassFullStoreLockReason.equals(storeLockState.getReason())`.
func validateStoreLockState(storeHeader *gen.DataStoreInfo, bypassFullStoreLockReason *string) error {
	lockState := storeHeader.GetStoreLockState()
	if lockState == nil {
		return nil
	}

	state := lockState.GetLockState()

	// FULL_STORE: blocked unless bypass reason matches exactly
	if state == gen.DataStoreInfo_StoreLockState_FULL_STORE {
		if bypassFullStoreLockReason != nil && *bypassFullStoreLockReason == lockState.GetReason() {
			return nil // bypass successful
		}
		return &StoreIsFullyLockedError{
			Reason:    lockState.GetReason(),
			Timestamp: lockState.GetTimestamp(),
		}
	}

	// At FormatVersion >= FULL_STORE_LOCK, reject unknown/unspecified states.
	// FORBID_RECORD_UPDATE is known and handled at mutation time, so skip it here.
	if storeHeader.GetFormatVersion() >= formatVersionFullStoreLock {
		if state != gen.DataStoreInfo_StoreLockState_FORBID_RECORD_UPDATE {
			return &UnknownStoreLockStateError{LockStateValue: int32(state), UnknownFields: lockState.ProtoReflect().GetUnknown()}
		}
	}

	return nil
}

// LoadRecord loads a record by its primary key.
// Handles both unsplit (suffix 0) and split (suffixes 1, 2, ...) records
// via SplitHelper, matching Java's FDBRecordStore.loadRecordAsync().
func (store *FDBRecordStore) LoadRecord(primaryKey tuple.Tuple) (*FDBStoredRecord[proto.Message], error) {
	return store.LoadRecordAsync(primaryKey, nil).Get()
}

// LoadRecordAsync sends the record's reads now, like Java's loadRecordAsync;
// Get finishes materialization. A non-nil scanState is charged when the raw
// read completes, even if its issued load is never consumed.
func (store *FDBRecordStore) LoadRecordAsync(primaryKey tuple.Tuple, scanState *ScanLimiterState) PendingRead[*FDBStoredRecord[proto.Message]] {
	issueStart := time.Now()
	load := &recordLoad{store: store, primaryKey: primaryKey}
	load.first = store.startRecordLoad(store.context.Transaction(), primaryKey)
	load.first.raw.startReadinessWithCharges(scanState)
	load.issueCost = time.Since(issueStart)
	return load
}

// pendingStoreRecordLoad adds the separate legacy version read to SplitHelper.
// Modern versions always come from the record range, even if new saves no
// longer store versions. Java loadTypedRecord only issues a separate old-format read.
type pendingStoreRecordLoad struct {
	raw        pendingRecordLoad
	oldVersion PendingRead[*FDBRecordVersion]
}

func (store *FDBRecordStore) startRecordLoad(tx fdb.ReadTransaction, primaryKey tuple.Tuple) pendingStoreRecordLoad {
	var load pendingStoreRecordLoad
	if store.useOldVersionFormat() {
		load.oldVersion = store.loadRecordVersionAsync(primaryKey, false)
	}
	load.raw = startLoadWithSplit(tx, store.recordsSubspace, primaryKey, store.metaData.IsSplitLongRecords(), store.omitUnsplitRecordSuffix(), store.context)
	return load
}

// recordLoadTimer ends at the load's completion, before a save/delete continues.
// Deferred completion covers failures; an explicit completion records success once.
type recordLoadTimer struct {
	timer *StoreTimer
	start time.Time
}

func (t *recordLoadTimer) finish() {
	if !t.start.IsZero() {
		t.timer.RecordSince(EventLoadRecord, t.start)
		t.start = time.Time{}
	}
}

// The legacy version future is observed only after successful deserialization,
// preserving Java deserializeRecord's error precedence. An inline version wins.
func (load *pendingStoreRecordLoad) finishVersion(inline *FDBRecordVersion) (*FDBRecordVersion, error) {
	if inline == nil && load.oldVersion != nil {
		return load.oldVersion.Get()
	}
	return inline, nil
}

// recordLoad is one issued LoadRecordAsync; layout and local version are fixed at issue.
type recordLoad struct {
	store      *FDBRecordStore
	primaryKey tuple.Tuple
	first      pendingStoreRecordLoad
	issueCost  time.Duration
	loadCost   time.Duration
	loaded     bool
	done       bool
	record     *FDBStoredRecord[proto.Message]
	loadErr    error
}

func (l *recordLoad) Get() (*FDBStoredRecord[proto.Message], error) {
	if !l.done {
		record, err := l.finish()
		// Release read and context state while retaining the terminal result.
		*l = recordLoad{done: true, record: record, loadErr: err}
	}
	return l.record, l.loadErr
}

func (l *recordLoad) IsReady() bool { return l.done || l.ready() }

func (l *recordLoad) ready() bool {
	if !l.first.raw.ready() {
		return false
	}
	if l.first.oldVersion == nil || l.first.oldVersion.IsReady() {
		return true
	}
	// A missing/corrupt record, or one with its own inline version, does not
	// depend on the legacy version future. Memoize decoding to check that dependency.
	l.load()
	return l.loadErr != nil || l.record == nil || l.record.Version != nil
}

func (l *recordLoad) load() {
	if !l.loaded {
		start := time.Now()
		l.record, l.loadErr = l.loadRawRecord()
		l.loadCost = time.Since(start)
		l.loaded = true
	}
}

func (l *recordLoad) loadRawRecord() (*FDBStoredRecord[proto.Message], error) {
	store, primaryKey := l.store, l.primaryKey
	var sizeInfo sizeInfo
	value, version, err := l.first.raw.finish(&sizeInfo)
	if err != nil {
		return nil, fmt.Errorf("failed to load record %v: %w", primaryKey, err)
	}
	if value == nil {
		return nil, nil // Record not found
	}

	// Discover which record type is stored by inspecting the UnionDescriptor
	recordType, protoMessage, wire, err := store.deserializeAndDiscover(value)
	if err != nil {
		return nil, &RecordDeserializationError{PrimaryKey: primaryKey, Cause: err}
	}

	stored := &FDBStoredRecord[proto.Message]{
		PrimaryKey:      primaryKey,
		RecordType:      recordType,
		Record:          protoMessage,
		wire:            wire,
		Store:           store,
		KeyCount:        sizeInfo.KeyCount,
		ValueSize:       sizeInfo.ValueSize,
		KeySize:         sizeInfo.KeySize,
		Split:           sizeInfo.IsSplit,
		VersionedInline: sizeInfo.VersionedInline,
		Version:         version,
	}

	return stored, nil
}

// The load timer counts the caller's issue and wait, not time queued behind earlier rows.
func (l *recordLoad) finish() (*FDBStoredRecord[proto.Message], error) {
	l.load()
	start := time.Now()
	defer func() {
		l.store.context.Timer().Record(EventLoadRecord, (l.issueCost + l.loadCost + time.Since(start)).Nanoseconds())
	}()
	if l.loadErr != nil || l.record == nil {
		return l.record, l.loadErr
	}
	version, err := l.first.finishVersion(l.record.Version)
	if err != nil {
		return nil, fmt.Errorf("load record version for %v: %w", l.primaryKey, err)
	}
	l.record.Version = version
	return l.record, nil
}

// SaveRecord saves a protobuf record to the store.
// Equivalent to SaveRecordWithOptions(record, RecordExistenceCheckNone).
// Java equivalent: FDBRecordStore.saveRecord(Message rec)
func (store *FDBRecordStore) SaveRecord(record proto.Message) (*FDBStoredRecord[proto.Message], error) {
	return store.SaveRecordWithOptions(record, RecordExistenceCheckNone)
}

// DeleteRecord deletes a record by its primary key, following Java's deleteRecordAsync semantics.
// Returns true if a record was deleted, false if no record existed with that key.
// Handles both split and unsplit records via SplitHelper.
// Matches Java's FDBRecordStore.deleteRecordAsync(Tuple primaryKey)
func (store *FDBRecordStore) DeleteRecord(primaryKey tuple.Tuple) (bool, error) {
	return store.deleteRecord(primaryKey, nil)
}

// deleteRecord is Java's deleteTypedRecord: typed, when not nil, is the typed
// store's serializer, through which the existing record is read.
func (store *FDBRecordStore) deleteRecord(primaryKey tuple.Tuple, typed *typedRecordSerializer) (bool, error) {
	startTime := time.Now()
	defer store.context.Timer().RecordSince(EventDeleteRecord, startTime)
	recordsSubspace := store.recordsSubspace
	splitEnabled := store.metaData.IsSplitLongRecords()

	// Load existing record to get size info and record data (for counting)
	var oldsizeInfo sizeInfo
	loadTimer := recordLoadTimer{timer: store.context.Timer(), start: time.Now()}
	defer loadTimer.finish()
	load := store.startRecordLoad(store.context.Transaction(), primaryKey)
	value, oldRecordVersion, err := load.raw.finish(&oldsizeInfo)
	if err != nil {
		return false, fmt.Errorf("failed to load record for deletion %v: %w", primaryKey, err)
	}
	if value == nil {
		return false, nil // Record not found
	}

	// Deserialize the old record first, always: Java's deleteTypedRecord loads it
	// through the serializer (loadTypedRecord, FDBRecordStore.java:1766), so a
	// record the store cannot read (encrypted under a key it lacks, or corrupt)
	// fails the delete, ahead of the lock check, and is never removed, whether or
	// not an index or the record count needs it.
	oldRecordType, oldMsg, oldWire, deserErr := store.deserializeAndDiscover(value)
	if deserErr != nil {
		return false, &RecordDeserializationError{PrimaryKey: primaryKey, Cause: deserErr}
	}
	if typed != nil {
		if err := typed.checkDeserialized(primaryKey, oldRecordType); err != nil {
			return false, err
		}
	}

	oldRecordVersion, err = load.finishVersion(oldRecordVersion)
	if err != nil {
		return false, fmt.Errorf("load old record version for deletion: %w", err)
	}

	loadTimer.finish()

	// Then the lock, before any write (validateRecordUpdateAllowed inside the
	// load's continuation, :1770-1771).
	if err := store.validateRecordUpdateAllowed(); err != nil {
		return false, err
	}

	if err := store.checkRecordWriteCollation(true, oldRecordType); err != nil {
		return false, err
	}

	// Delete all KV pairs for this record
	if _, err := deleteSplit(store.context.Transaction(), recordsSubspace, primaryKey, splitEnabled, store.omitUnsplitRecordSuffix(), &oldsizeInfo); err != nil {
		return false, err
	}

	// Clean up the record version. Matches Java's deleteTypedRecord.
	if store.metaData.IsStoreRecordVersions() || (oldRecordVersion != nil && !oldRecordVersion.IsComplete()) {
		versionKey := store.versionKey(primaryKey)
		if store.useOldVersionFormat() {
			// Legacy layout: the version lives in the separate subspace and was NOT
			// touched by deleteSplit. Clear the committed value AND drop any pending
			// same-transaction mutation / local cache entry. We must do both: if the
			// record was updated earlier in THIS transaction its committed (pre-tx)
			// version is still present in FDB while a pending incomplete SET sits in the
			// mutation queue — clearing only one of them would orphan the other. (This
			// is slightly more defensive than Java's deleteTypedRecord, whose
			// incomplete-version branch drops the mutation but leaves the prior committed
			// value behind; clearing is harmless for a pure insert and avoids a stale
			// version surviving for a deleted record.)
			store.context.Transaction().Clear(versionKey)
			store.context.RemoveVersionMutation(versionKey)
			store.context.RemoveLocalVersion(versionKey)
		} else {
			// Modern layout: deleteSplit cleared the inline FDB key; just dequeue any
			// pending incomplete version mutation + local version cache entry.
			store.context.RemoveLocalVersion(versionKey)
			store.context.RemoveVersionMutation(versionKey)
		}
	}

	oldStoredRecord := &FDBStoredRecord[proto.Message]{
		PrimaryKey: primaryKey,
		RecordType: oldRecordType,
		Record:     oldMsg,
		wire:       oldWire,
		Version:    oldRecordVersion,
		Store:      store,
	}
	// Decrement record count
	if store.metaData.GetRecordCountKey() != nil && oldMsg != nil {
		if err := store.addRecordCount(oldStoredRecord, littleEndianInt64MinusOne); err != nil {
			return false, fmt.Errorf("failed to decrement record count: %w", err)
		}
	}

	// Update secondary indexes
	if store.metaData.HasIndexes() && oldMsg != nil {
		if err := store.updateSecondaryIndexes(oldStoredRecord, nil); err != nil {
			return false, err
		}
	}

	// Record instrumentation
	timer := store.context.Timer()
	timer.Increment(CountDeleteRecordKey)
	timer.IncrementBy(CountDeleteRecordKeyBytes, int64(oldsizeInfo.KeySize))

	if err := store.context.CheckTransactionSize(); err != nil {
		return true, err
	}

	return true, nil
}

// RecordExists checks if a record exists with the given primary key.
// Handles both split and unsplit records via SplitHelper.
//
// Java equivalent: FDBRecordStore.recordExistsAsync(Tuple primaryKey, IsolationLevel isolationLevel)
func (store *FDBRecordStore) RecordExists(primaryKey tuple.Tuple, isolationLevel IsolationLevel) (bool, error) {
	recordsSubspace := store.recordsSubspace

	var tx fdb.ReadTransaction
	if isolationLevel.IsSnapshot() {
		tx = store.context.Transaction().Snapshot()
	} else {
		tx = store.context.Transaction()
	}

	return recordExistsWithSplit(tx, recordsSubspace, primaryKey, store.metaData.IsSplitLongRecords(), store.omitUnsplitRecordSuffix())
}

// SaveRecordWithOptions saves a protobuf record with existence checking and the
// default version behavior.
//
// Java equivalent: FDBRecordStoreBase.saveRecord(Message rec, RecordExistenceCheck existenceCheck)
//
// Returns:
//   - *FDBStoredRecord: The saved record with metadata
//   - error: RecordAlreadyExistsError, RecordDoesNotExistError, or RecordTypeChangedError based on existenceCheck
func (store *FDBRecordStore) SaveRecordWithOptions(
	record proto.Message,
	existenceCheck RecordExistenceCheck,
) (*FDBStoredRecord[proto.Message], error) {
	return store.saveRecordInternal(record, existenceCheck, nil, VersionstampSaveBehaviorDefault, false, nil, nil)
}

// SaveRecordWithVersion saves a record with the version behavior chooses from version (nil,
// complete, or incomplete from ClaimLocalVersion): Java's saveRecordAsync(rec, check, version, behavior).
func (store *FDBRecordStore) SaveRecordWithVersion(
	record proto.Message,
	existenceCheck RecordExistenceCheck,
	version *FDBRecordVersion,
	behavior VersionstampSaveBehavior,
) (*FDBStoredRecord[proto.Message], error) {
	return store.saveRecordInternal(record, existenceCheck, version, behavior, false, nil, nil)
}

// SaveRecordsPipelined saves records in order as SaveRecordWithOptions would
// one at a time, but sends the existing-record reads of each window of
// DefaultPipelineSize records together: Java's INSERT pipelines its saves
// (RecordQueryAbstractDataModificationPlan mapPipelined, at
// FDBRecordStore.DEFAULT_PIPELINE_SIZE). The first failing record stops the save
// and is the one reported; the reads already sent for the rest of its window
// stay in the transaction, as Java's do.
func (store *FDBRecordStore) SaveRecordsPipelined(
	records []proto.Message,
	existenceCheck RecordExistenceCheck,
) ([]*FDBStoredRecord[proto.Message], error) {
	saved := make([]*FDBStoredRecord[proto.Message], 0, len(records))
	tx := store.context.Transaction()
	for start := 0; start < len(records); start += DefaultPipelineSize {
		window := records[start:min(start+DefaultPipelineSize, len(records))]
		loads := store.startExistingRecordLoads(tx, window)
		for i, record := range window {
			stored, err := store.saveRecordInternal(record, existenceCheck, nil, VersionstampSaveBehaviorDefault, false, &loads[i], nil)
			if err != nil {
				return nil, err
			}
			saved = append(saved, stored)
		}
	}
	return saved, nil
}

// saveTarget is what a save derives from its record before reading anything.
type saveTarget struct {
	recordTypeName string
	recordType     *RecordType
	record         proto.Message // as every later load reads it
	write          proto.Message // what the save serializes
	primaryKey     tuple.Tuple
	version        *FDBRecordVersion
}

// existingRecordLoad is a save's read of the record already stored under its
// key, sent ahead of the save; without sent, the save reads for itself.
type existingRecordLoad struct {
	target  saveTarget
	err     error
	pending pendingStoreRecordLoad
	sent    bool
}

// startExistingRecordLoads sends the existing-record read of every record in
// window. A record repeating an earlier key in window is left to read at its
// save, since a read sent before the earlier save would miss it.
func (store *FDBRecordStore) startExistingRecordLoads(tx fdb.ReadTransaction, window []proto.Message) []existingRecordLoad {
	loads := make([]existingRecordLoad, len(window))
	keys := make([][]byte, 0, len(window))
	for i, record := range window {
		load := &loads[i]
		if load.target, load.err = store.saveTargetFor(record, nil, VersionstampSaveBehaviorDefault); load.err != nil {
			continue
		}
		key := load.target.primaryKey.Pack()
		if slices.ContainsFunc(keys, func(k []byte) bool { return bytes.Equal(k, key) }) {
			continue
		}
		keys = append(keys, key)
		load.pending = store.startRecordLoad(tx, load.target.primaryKey)
		load.sent = true
	}
	return loads
}

// saveTargetFor resolves the record's type, chosen version, Java form and primary key.
// Java chooses the version before evaluating the primary key against the versioned record.
func (store *FDBRecordStore) saveTargetFor(record proto.Message, version *FDBRecordVersion, behavior VersionstampSaveBehavior) (saveTarget, error) {
	if record == nil {
		return saveTarget{}, fmt.Errorf("cannot save nil record")
	}
	// Java's saveTypedRecord resolves the type by descriptor before anything
	// else (FDBRecordStore.java:552): a same-named message of another
	// descriptor is refused, untyped saves included.
	descriptor := record.ProtoReflect().Descriptor()
	recordType, err := store.metaData.GetRecordTypeForDescriptor(descriptor)
	if err != nil {
		return saveTarget{}, err
	}
	// Java chooses the save's version here, before the primary key (FDBRecordStore.java:555).
	savedVersion, err := store.recordVersionForSave(version, behavior)
	if err != nil {
		return saveTarget{}, err
	}
	recordTypeName := string(descriptor.Name())

	if recordType.PrimaryKey == nil {
		return saveTarget{}, &MetaDataError{Message: fmt.Sprintf("no primary key defined for record type: %s", recordTypeName)}
	}
	if err := store.checkPrimaryKeyCollation(recordType); err != nil {
		return saveTarget{}, err
	}
	// A closed enum field holding a number its enum does not declare is read by
	// every later load, in both engines, as unset (proto_closed_enums.go), so
	// the record is keyed, counted, indexed and written as that reading: an
	// update or delete that loads it then removes exactly the entries this save
	// writes. The caller's message is not changed. writeRecord is what the save
	// serializes (asJavaForSave: a DynamicMessage map value keeps its number,
	// which the map rewrite writes in Java's form).
	var writeRecord proto.Message
	record, writeRecord = recordType.asJavaForSave(record)

	// Extract primary key values using the flat evaluator (avoids [][]any alloc).
	// The record type is supplied to the evaluation because a record-type-prefixed
	// primary key reads its leading component off the record's own type. Java has
	// the same ordering constraint and solves it the same way: saveTypedRecord
	// builds FDBStoredRecord.newBuilder(rec).setRecordType(recordType) FIRST, then
	// evaluates the primary key against that builder (FDBRecordStore.java).
	keyValues, err := evaluateKeyFlat(recordType.PrimaryKey, &FDBStoredRecord[proto.Message]{
		RecordType: recordType,
		Record:     record,
		Version:    savedVersion,
	}, record)
	if err != nil {
		return saveTarget{}, fmt.Errorf("failed to extract primary key: %w", err)
	}
	// Reinterpret []any as tuple.Tuple without a copy; both element types are any.
	primaryKey := *(*tuple.Tuple)(unsafe.Pointer(&keyValues))
	if incomplete, _ := primaryKey.HasIncompleteVersionstamp(); incomplete {
		return saveTarget{}, &IncompleteVersionstampError{Context: "record primary key"}
	}
	return saveTarget{
		recordTypeName: recordTypeName,
		recordType:     recordType,
		record:         record,
		write:          writeRecord,
		primaryKey:     primaryKey,
		version:        savedVersion,
	}, nil
}

// saveRecordInternal reuses a preloaded target or prepares one with the requested version behavior.
// overrideLock bypasses the update lock; typed supplies a typed store's serializer.
func (store *FDBRecordStore) saveRecordInternal(
	record proto.Message,
	existenceCheck RecordExistenceCheck,
	version *FDBRecordVersion,
	behavior VersionstampSaveBehavior,
	overrideLock bool,
	load *existingRecordLoad,
	typed *typedRecordSerializer,
) (*FDBStoredRecord[proto.Message], error) {
	startTime := time.Now()
	var target saveTarget
	var err error
	if load != nil {
		target, err = load.target, load.err
	} else {
		target, err = store.saveTargetFor(record, version, behavior)
	}
	if err != nil {
		return nil, err
	}
	recordTypeName, recordType := target.recordTypeName, target.recordType
	record, writeRecord, primaryKey := target.record, target.write, target.primaryKey
	savedVersion := target.version
	defer store.context.Timer().RecordSince(EventSaveRecord, startTime)

	recordsSubspace := store.recordsSubspace
	splitEnabled := store.metaData.IsSplitLongRecords()

	// Always load the existing record (matching Java's saveRecordAsync behavior).
	// This is needed for: existence checks, record counting, and future
	// index updates / version management.
	var oldsizeInfo sizeInfo
	loadTimer := recordLoadTimer{timer: store.context.Timer(), start: time.Now()}
	defer loadTimer.finish()
	var pending pendingStoreRecordLoad
	if load != nil && load.sent {
		pending = load.pending
	} else {
		pending = store.startRecordLoad(store.context.Transaction(), primaryKey)
	}
	oldValue, oldRecordVersion, err := pending.raw.finish(&oldsizeInfo)
	if err != nil {
		return nil, fmt.Errorf("failed to load existing record: %w", err)
	}
	oldRecordExists := oldValue != nil

	// Java's saveTypedRecord loads the existing record through the serializer
	// (loadExistingRecord → loadTypedRecord, FDBRecordStore.java:561, :636-642)
	// before any existence check, so a record the store cannot read (one
	// encrypted under a key it lacks, or corrupt) fails the save with
	// RecordDeserializationException whatever the check, and is never
	// overwritten. The decoded record serves the type check and the index
	// update below.
	var cachedOldRT *RecordType
	var cachedOldMsg proto.Message
	var cachedOldWire *recordWire
	if oldRecordExists {
		var deserErr error
		cachedOldRT, cachedOldMsg, cachedOldWire, deserErr = store.deserializeAndDiscover(oldValue)
		if deserErr != nil {
			return nil, &RecordDeserializationError{PrimaryKey: primaryKey, Cause: deserErr}
		}
		if typed != nil {
			if err := typed.checkDeserialized(primaryKey, cachedOldRT); err != nil {
				return nil, err
			}
		}
	}

	if oldRecordExists {
		oldRecordVersion, err = pending.finishVersion(oldRecordVersion)
		if err != nil {
			return nil, fmt.Errorf("load old record version for save: %w", err)
		}
	}

	loadTimer.finish()

	// Perform existence checks
	if existenceCheck != RecordExistenceCheckNone {
		if existenceCheck.ErrorIfExists() && oldRecordExists {
			return nil, &RecordAlreadyExistsError{
				Message:    "record already exists",
				PrimaryKey: primaryKey,
			}
		}

		if existenceCheck.ErrorIfNotExists() && !oldRecordExists {
			return nil, &RecordDoesNotExistError{
				Message:    "record does not exist",
				PrimaryKey: primaryKey,
			}
		}

		if existenceCheck.ErrorIfTypeChanged() && oldRecordExists {
			existingTypeName := string(cachedOldMsg.ProtoReflect().Descriptor().Name())
			if existingTypeName != recordTypeName {
				return nil, &RecordTypeChangedError{
					Message:      "record type changed",
					PrimaryKey:   primaryKey,
					ActualType:   existingTypeName,
					ExpectedType: recordTypeName,
				}
			}
		}
	}

	// Check lock state AFTER load and existence checks but BEFORE write,
	// matching Java's saveRecordAsync() error precedence: existence/type
	// errors take priority over lock errors.
	if !overrideLock {
		if err := store.validateRecordUpdateAllowed(); err != nil {
			return nil, err
		}
	}

	if err := store.checkRecordWriteCollation(!oldRecordExists, recordType, cachedOldRT); err != nil {
		return nil, err
	}

	if typed != nil {
		if err := typed.checkSerialize(recordType, store.metaData.Version()); err != nil {
			return nil, err
		}
	}
	// Serialize directly into union wire format (no UnionDescriptor allocation)
	data, err := serializeUnionOver(writeRecord, recordType, priorRecordInner(cachedOldRT, cachedOldWire, recordType))
	if err != nil {
		return nil, &RecordSerializationError{Cause: err}
	}
	// The bytes stored: the serializer's transformation of the union message,
	// which the split then chunks (Java serializes, then splits).
	stored, err := store.writeStoredRecord(data, recordType, primaryKey)
	if err != nil {
		return nil, err
	}

	// Save using split helper (handles both split and unsplit data)
	var oldsizeInfoPtr *sizeInfo
	if oldRecordExists {
		oldsizeInfoPtr = &oldsizeInfo
	}

	var newsizeInfo sizeInfo
	if err := saveWithSplit(store.context,
		store.context.Transaction(),
		recordsSubspace,
		primaryKey,
		stored,
		splitEnabled,
		store.omitUnsplitRecordSuffix(),
		oldsizeInfoPtr,
		&newsizeInfo,
	); err != nil {
		return nil, fmt.Errorf("failed to save record: %w", err)
	}

	// Save the version, if any (handled separately from split helper because Go
	// FDB bindings need context-level AddVersionMutation for versionstamps).
	if savedVersion != nil {
		if err := store.saveRecordVersion(primaryKey, savedVersion, &newsizeInfo); err != nil {
			return nil, err
		}
	}

	newStoredRecord := &FDBStoredRecord[proto.Message]{
		PrimaryKey: primaryKey,
		RecordType: recordType,
		Record:     record,
		// Its map entries are indexed in the order it was written in.
		wire:            newRecordWire(recordType, unionInner(data, recordType.unionFieldNumber)),
		Version:         savedVersion,
		Store:           store,
		KeyCount:        newsizeInfo.KeyCount,
		ValueSize:       newsizeInfo.ValueSize,
		KeySize:         newsizeInfo.KeySize,
		Split:           newsizeInfo.IsSplit,
		VersionedInline: newsizeInfo.VersionedInline,
	}

	// Only increment record count for new inserts (not updates).
	if !oldRecordExists {
		if err := store.addRecordCount(newStoredRecord, littleEndianInt64One); err != nil {
			return nil, fmt.Errorf("failed to increment record count: %w", err)
		}
	}

	// Update secondary indexes
	if store.metaData.HasIndexes() {
		var oldStoredRecord *FDBStoredRecord[proto.Message]
		if oldRecordExists {
			oldStoredRecord = &FDBStoredRecord[proto.Message]{
				PrimaryKey: primaryKey,
				RecordType: cachedOldRT,
				Record:     cachedOldMsg,
				wire:       cachedOldWire,
				Version:    oldRecordVersion,
				Store:      store,
			}
		}
		if err := store.updateSecondaryIndexes(oldStoredRecord, newStoredRecord); err != nil {
			return nil, err
		}
	}

	// Record instrumentation
	timer := store.context.Timer()
	timer.Increment(CountSaveRecordKey)
	timer.IncrementBy(CountSaveRecordKeyBytes, int64(newsizeInfo.KeySize))
	timer.IncrementBy(CountSaveRecordValueBytes, int64(newsizeInfo.ValueSize))

	if err := store.context.CheckTransactionSize(); err != nil {
		return newStoredRecord, err
	}

	return newStoredRecord, nil
}

// InsertRecord saves a record and throws an error if it already exists.
// This is equivalent to SaveRecordWithOptions(record, RecordExistenceCheckErrorIfExists).
//
// Java equivalent: FDBRecordStore.insertRecordAsync(Message rec)
// Java location: fdb-record-layer-core/src/main/java/com/apple/foundationdb/record/provider/foundationdb/FDBRecordStoreBase.java:629
//
// Returns:
//   - *FDBStoredRecord: The saved record with metadata
//   - error: RecordAlreadyExistsError if a record with the same primary key already exists
func (store *FDBRecordStore) InsertRecord(record proto.Message) (*FDBStoredRecord[proto.Message], error) {
	return store.SaveRecordWithOptions(record, RecordExistenceCheckErrorIfExists)
}

// UpdateRecord saves a record and throws an error if it does not already exist or if its type has changed.
// This is equivalent to SaveRecordWithOptions(record, RecordExistenceCheckErrorIfNotExistsOrTypeChanged).
//
// Java equivalent: FDBRecordStore.updateRecordAsync(Message rec)
// Java location: fdb-record-layer-core/src/main/java/com/apple/foundationdb/record/provider/foundationdb/FDBRecordStoreBase.java:649
//
// Returns:
//   - *FDBStoredRecord: The saved record with metadata
//   - error: RecordDoesNotExistError if no record exists with this primary key
//   - error: RecordTypeChangedError if an existing record has a different type
func (store *FDBRecordStore) UpdateRecord(record proto.Message) (*FDBStoredRecord[proto.Message], error) {
	return store.SaveRecordWithOptions(record, RecordExistenceCheckErrorIfNotExistsOrTypeChanged)
}

// AddRecordReadConflict adds a read conflict range for the given primary key.
// This ensures that if another transaction modifies this record before this transaction commits,
// this transaction will fail with a conflict error.
//
// Java equivalent: FDBRecordStore.addRecordReadConflict(Tuple primaryKey)
// Java location: fdb-record-layer-core/src/main/java/com/apple/foundationdb/record/provider/foundationdb/FDBRecordStore.java:1222
func (store *FDBRecordStore) AddRecordReadConflict(primaryKey tuple.Tuple) error {
	recordRange := store.getRangeForRecord(primaryKey)
	return store.context.Transaction().AddReadConflictRange(recordRange)
}

// AddRecordWriteConflict adds a write conflict range for the given primary key.
// This ensures that if another transaction reads this record before this transaction commits,
// that transaction will fail with a conflict error.
//
// Java equivalent: FDBRecordStore.addRecordWriteConflict(Tuple primaryKey)
// Java location: fdb-record-layer-core/src/main/java/com/apple/foundationdb/record/provider/foundationdb/FDBRecordStore.java:1228
func (store *FDBRecordStore) AddRecordWriteConflict(primaryKey tuple.Tuple) error {
	recordRange := store.getRangeForRecord(primaryKey)
	return store.context.Transaction().AddWriteConflictRange(recordRange)
}

// getRangeForRecord calculates the key range that covers all possible record type variants
// for the given primary key. This matches Java's TupleRange.allOf(primaryKey).toRange(recordsSubspace())
//
// Java equivalent: TupleRange.allOf(primaryKey).toRange(recordsSubspace())
// Java location: fdb-record-layer-core/src/main/java/com/apple/foundationdb/record/TupleRange.java:371-377, 449-456
//
// Java's TupleRange.allOf() creates a range with RANGE_INCLUSIVE endpoints:
//   - Begin: recordsSubspace.pack(primaryKey)
//   - End: recordsSubspace.pack(primaryKey) + 0xFF
//
// This is different from using Sub(), which would add an extra 0x00 byte to the begin key.
// The range covers all keys that start with the primary key tuple (e.g., {orderID, UNSPLIT_RECORD}).
func (store *FDBRecordStore) getRangeForRecord(primaryKey tuple.Tuple) fdb.ExactRange {
	recordsSubspace := store.recordsSubspace

	// Pack the primary key directly (Java's TupleRange.allOf approach)
	// This gives us recordsSubspace.pack(primaryKey)
	beginKey := recordsSubspace.Pack(primaryKey)

	// For the end key, append 0xFF to create the inclusive range
	// This matches Java's RANGE_INCLUSIVE endpoint handling
	endKey := append(recordsSubspace.Pack(primaryKey), 0xFF)

	return fdb.KeyRange{
		Begin: fdb.Key(beginKey),
		End:   fdb.Key(endKey),
	}
}

// Context returns the record context this store is using
func (store *FDBRecordStore) Context() *FDBRecordContext {
	return store.context
}

// Subspace returns the subspace this store is using
func (store *FDBRecordStore) Subspace() subspace.Subspace {
	return store.subspace
}

// GetMetaData returns the metadata for this store.
// Matches Java's FDBRecordStore.getRecordMetaData().
func (store *FDBRecordStore) GetMetaData() *RecordMetaData {
	return store.metaData
}

// GetIndexMaintainer returns the index maintainer for the given index.
// Matches Java's FDBRecordStore.getIndexMaintainer().
func (store *FDBRecordStore) GetIndexMaintainer(index *Index) (IndexMaintainer, error) {
	if index == nil {
		return nil, nil
	}
	return store.getIndexMaintainer(index)
}

// DeleteIndexEntries clears all entries for the given index.
// Matches Java's StandardIndexMaintainer.deleteWhere() with no predicate.
func (store *FDBRecordStore) DeleteIndexEntries(index *Index) {
	if index == nil {
		return
	}
	indexSub := store.indexSubspace(index)
	store.context.Transaction().ClearRange(indexSub)
}

// DeleteIndexEntriesInRange clears index entries matching the given tuple prefix.
// For example, passing tuple.Tuple{"alice"} clears all entries where the first
// indexed value is "alice".
func (store *FDBRecordStore) DeleteIndexEntriesInRange(index *Index, prefix tuple.Tuple) error {
	if index == nil {
		return fmt.Errorf("index must not be nil")
	}
	// [pack, pack+ff) is the prefix's tuple range plus the key at pack itself
	// (a grouped aggregate); strinc(pack) would also clear "alice\x00…".
	prefixKey := store.indexSubspace(index).Pack(prefix)
	store.context.Transaction().ClearRange(fdb.KeyRange{Begin: prefixKey, End: append(prefixKey, 0xff)})
	return nil
}

// DeleteAllRecords deletes all records from the store.
// Clears all data subspaces except StoreInfoKey (0) and IndexStateSpaceKey (5).
// Matches Java's FDBRecordStore.deleteAllRecords() which clears everything
// from records through index state begin, then from index state end through store end.
func (store *FDBRecordStore) DeleteAllRecords() error {
	if err := store.validateRecordUpdateAllowed(); err != nil {
		return err
	}

	tx := store.context.Transaction()

	// Clear all subspaces except StoreInfoKey (0) and IndexStateSpaceKey (5).
	// Java does two range clears: [records, indexState) and (indexState, storeEnd).
	// We clear individual subspaces for clarity.
	//
	// The enumeration is the risk that trade buys: Java's second range runs to
	// the END of the store, so a keyspace added to FDBRecordStoreKeyspace is
	// cleared there automatically and has to be added HERE by hand. Every new
	// prefix must appear below, or its data survives a delete-all — which for
	// the sliding window meant the next save reading a full window over an
	// emptied graph, and evicting against a boundary naming a record that is
	// gone.
	// Use PrefixRange to include the exact prefix key — ungrouped aggregate
	// data (e.g. record counts) is stored at the subspace prefix itself,
	// which subspace.FDBRangeKeys() excludes.
	for _, key := range []int{
		RecordKey,                    // 1 - records
		IndexKey,                     // 2 - index data
		IndexSecondarySpaceKey,       // 3 - secondary index data
		RecordCountKey,               // 4 - record counts
		IndexRangeSpaceKey,           // 6 - index ranges
		IndexUniquenessViolationsKey, // 7 - uniqueness violations
		RecordVersionKey,             // 8 - record versions
		IndexBuildSpaceKey,           // 9 - index build state
		IndexSlidingWindowSpaceKey,   // 10 - sliding-window bookkeeping
	} {
		sub := store.subspace.Sub(key)
		pr, err := fdb.PrefixRange(sub.Bytes())
		if err != nil {
			return fmt.Errorf("delete all records prefix range for key %d: %w", key, err)
		}
		tx.ClearRange(pr)
	}

	// Remove pending version mutations and local version cache entries for
	// the cleared subspaces. Without this, orphaned SET_VERSIONSTAMPED_VALUE
	// mutations (for record versions) and SET_VERSIONSTAMPED_KEY mutations
	// (for VERSION index entries) would be flushed at commit, writing version
	// data for records that no longer exist.
	// Matches Java's context.clear(Range) → removeVersionMutationRange() + removeLocalVersionRange().
	for _, key := range []int{
		RecordKey,              // inline record versions live under records subspace
		IndexKey,               // VERSION index entries live under index subspace
		IndexSecondarySpaceKey, // secondary index data
		RecordVersionKey,       // explicit record version subspace
		IndexBuildSpaceKey,     // pending index queue entries
	} {
		sub := store.subspace.Sub(key)
		pr, err := fdb.PrefixRange(sub.Bytes())
		if err != nil {
			return fmt.Errorf("DeleteAllRecords: PrefixRange for subspace %d: %w", key, err)
		}
		begin, end := pr.FDBRangeKeys()
		store.context.RemoveVersionMutationsInRange(begin.FDBKey(), end.FDBKey())
		store.context.RemoveLocalVersionsInRange(begin.FDBKey(), end.FDBKey())
	}

	// Reset record count to 0. ClearRange alone doesn't override pending atomic
	// Add mutations within the same transaction, so we also explicitly Set
	// the count key to 0 to ensure reads in the same tx see the reset.
	// Skip when count state is DISABLED (no count data should exist).
	countKey := store.metaData.GetRecordCountKey()
	if countKey != nil && !store.isRecordCountDisabled() {
		countSubspace := store.subspace.Sub(RecordCountKey)
		fdbKey := countSubspace.Pack(tuple.Tuple{})
		tx.Set(fdbKey, encodeRecordCount(0))
	}

	return nil
}

// updateSecondaryIndexes updates all relevant indexes for a record change.
// oldRecord is nil for inserts, newRecord is nil for deletes.
//
// When old and new records have the same type (or one is nil), indexes are
// updated straightforwardly. When types differ (cross-type overwrite), indexes
// are partitioned into three sets: old-only (delete entries), new-only (insert
// entries), and common (update entries). Matches Java's FDBRecordStore.updateSecondaryIndexes().
func (store *FDBRecordStore) updateSecondaryIndexes(oldRecord, newRecord *FDBStoredRecord[proto.Message]) error {
	if err := store.ensureStoreStateLoadedErr(); err != nil {
		return fmt.Errorf("load store state: %w", err)
	}
	store.stateMu.RLock()
	defer store.stateMu.RUnlock()
	store.indexStateView.maintenance.RLock()
	defer store.indexStateView.maintenance.RUnlock()
	return store.updateSecondaryIndexesLocked(oldRecord, newRecord)
}

// updateSecondaryIndexesLocked is the lock-free variant for use when the caller
// already holds stateMu.RLock and the shared maintenance read lock (e.g. SaveRecordBatch).
func (store *FDBRecordStore) updateSecondaryIndexesLocked(oldRecord, newRecord *FDBStoredRecord[proto.Message]) error {
	if oldRecord == nil && newRecord == nil {
		return nil
	}
	// Validate liveness once for this record update, including the all-disabled
	// case. Per-index decisions below use cached transaction-visible state and
	// explicit conflicts; they must not allocate a GRV future for each index.
	if _, err := store.context.Transaction().GetReadVersion().Get(); err != nil {
		return err
	}

	// Fast path: same type (or one side nil) — no three-way split needed.
	sameType := oldRecord == nil || newRecord == nil || oldRecord.RecordType.Name == newRecord.RecordType.Name
	if sameType {
		var recordType *RecordType
		if newRecord != nil {
			recordType = newRecord.RecordType
		} else {
			recordType = oldRecord.RecordType
		}

		for _, index := range store.metaData.GetIndexesForRecordType(recordType.Name) {
			maintain, err := store.shouldMaintainIndex(index.Name)
			if err != nil {
				return err
			}
			if !maintain {
				continue
			}
			if err := store.updateOneIndex(index, oldRecord, newRecord); err != nil {
				return err
			}
		}
		for _, index := range store.metaData.GetUniversalIndexes() {
			maintain, err := store.shouldMaintainIndex(index.Name)
			if err != nil {
				return err
			}
			if !maintain {
				continue
			}
			if err := store.updateOneIndex(index, oldRecord, newRecord); err != nil {
				return err
			}
		}
		return nil
	}

	// Slow path: cross-type overwrite. Partition indexes into old-only,
	// new-only, and common sets. Matches Java's three-way split.
	oldIndexes, err := store.enabledIndexesForRecord(oldRecord)
	if err != nil {
		return err
	}
	newIndexes, err := store.enabledIndexesForRecord(newRecord)
	if err != nil {
		return err
	}

	commonIndexes, oldOnly, newOnly := partitionIndexes(oldIndexes, newIndexes)

	// Delete entries from indexes that only the old type had.
	for _, index := range oldOnly {
		if err := store.updateOneIndex(index, oldRecord, nil); err != nil {
			return err
		}
	}
	// Insert entries into indexes that only the new type has.
	for _, index := range newOnly {
		if err := store.updateOneIndex(index, nil, newRecord); err != nil {
			return err
		}
	}
	// Update entries in indexes shared by both types.
	for _, index := range commonIndexes {
		if err := store.updateOneIndex(index, oldRecord, newRecord); err != nil {
			return err
		}
	}

	return nil
}

// enabledIndexesForRecord returns all enabled indexes (type-specific + universal)
// that apply to the given record.
func (store *FDBRecordStore) enabledIndexesForRecord(rec *FDBStoredRecord[proto.Message]) ([]*Index, error) {
	var result []*Index
	for _, index := range store.metaData.GetIndexesForRecordType(rec.RecordType.Name) {
		maintain, err := store.shouldMaintainIndex(index.Name)
		if err != nil {
			return nil, err
		}
		if maintain {
			result = append(result, index)
		}
	}
	for _, index := range store.metaData.GetUniversalIndexes() {
		maintain, err := store.shouldMaintainIndex(index.Name)
		if err != nil {
			return nil, err
		}
		if maintain {
			result = append(result, index)
		}
	}
	return result, nil
}

// partitionIndexes splits old and new index lists into three disjoint sets:
// common (in both), oldOnly (only in old), newOnly (only in new).
// Identity is by index name.
func partitionIndexes(oldIndexes, newIndexes []*Index) (common, oldOnly, newOnly []*Index) {
	newSet := make(map[string]*Index, len(newIndexes))
	for _, idx := range newIndexes {
		newSet[idx.Name] = idx
	}

	oldSet := make(map[string]struct{}, len(oldIndexes))
	for _, idx := range oldIndexes {
		oldSet[idx.Name] = struct{}{}
		if _, ok := newSet[idx.Name]; ok {
			common = append(common, idx)
		} else {
			oldOnly = append(oldOnly, idx)
		}
	}

	for _, idx := range newIndexes {
		if _, ok := oldSet[idx.Name]; !ok {
			newOnly = append(newOnly, idx)
		}
	}
	return
}

// updateOneIndex routes to UpdateWhileWriteOnly or Update based on index state.
// Matches Java's FDBRecordStore.updateIndexes() per-index dispatch.
// updateOneIndex updates a single index. Caller must hold stateMu (read or write).
func (store *FDBRecordStore) updateOneIndex(index *Index, oldRecord, newRecord *FDBStoredRecord[proto.Message]) error {
	maintainer, err := store.getIndexMaintainer(index)
	if err != nil {
		return err
	}
	state, err := store.indexStateView.read(store.context.Transaction(), index.Name)
	if err != nil {
		return err
	}
	if state.IsDisabled() {
		return nil
	}
	// Each update is recorded in the context's index-update set for its state
	// (Java's FDBRecordStore.updateSecondaryIndexes, #4289).
	if state.IsWriteOnlyWithQueue() {
		data, err := maintainer.SerializePendingWriteQueue(oldRecord, newRecord)
		if err != nil {
			return err
		}
		if err := store.enqueuePendingIndexWrite(index, &gen.PendingWritesQueueEntry{Operation: gen.PendingWritesQueueEntry_UPDATE.Enum(), Data: data}); err != nil {
			return err
		}
		store.context.addToSessionSet(WriteOnlyWithQueueIndexesUpdated, index.Name)
		return nil
	}
	if state.IsWriteOnlyNoQueue() {
		if err := maintainer.UpdateWhileWriteOnly(oldRecord, newRecord); err != nil {
			return err
		}
		store.context.addToSessionSet(WriteOnlyIndexesUpdated, index.Name)
		return nil
	}
	if err := maintainer.Update(oldRecord, newRecord); err != nil {
		return err
	}
	store.context.addToSessionSet(ReadableIndexesUpdated, index.Name)
	return nil
}

// shouldIndexRecordForIndex checks if a record matches the given index's record types.
// Returns true if the record's type has this index defined (either per-type or universal).
func (store *FDBRecordStore) shouldIndexRecordForIndex(rec *FDBStoredRecord[proto.Message], index *Index) bool {
	for _, idx := range store.metaData.GetIndexesForRecordType(rec.RecordType.Name) {
		if idx.Name == index.Name {
			return true
		}
	}
	for _, idx := range store.metaData.GetUniversalIndexes() {
		if idx.Name == index.Name {
			return true
		}
	}
	return false
}

// indexSubspace returns the FDB subspace for a specific index.
// Layout: [storeSubspace][IndexKey=2][indexSubspaceTupleKey]
// Matches Java's FDBRecordStore.indexSubspace(Index).
func (store *FDBRecordStore) indexSubspace(index *Index) subspace.Subspace {
	return store.subspace.Sub(IndexKey, index.SubspaceTupleKey())
}

// indexSecondarySubspace returns the FDB subspace for a RANK index's secondary data (ranked sets).
// Layout: [storeSubspace][IndexSecondarySpaceKey=3][indexSubspaceTupleKey]
// Matches Java's FDBRecordStore.indexSecondarySubspace(Index).
func (store *FDBRecordStore) indexSecondarySubspace(index *Index) subspace.Subspace {
	return store.subspace.Sub(IndexSecondarySpaceKey, index.SubspaceTupleKey())
}

// indexSlidingWindowSubspace returns the FDB subspace holding a sliding-window
// index's bookkeeping (the per-partition entry list and its count/boundary
// metadata).
// Layout: [storeSubspace][IndexSlidingWindowSpaceKey=10][indexSubspaceTupleKey]
// Matches Java's FDBRecordStore.indexSlidingWindowSubspace(Index).
func (store *FDBRecordStore) indexSlidingWindowSubspace(index *Index) subspace.Subspace {
	return store.subspace.Sub(IndexSlidingWindowSpaceKey, index.SubspaceTupleKey())
}

// loadRecordForIndexMaintenance loads a record by primary key on behalf of an
// index maintainer. Matches the use Java's SlidingWindowIndexMaintainer makes of
// state.store.loadRecordAsync: a window that evicts or promotes an entry must
// hand the RECORD to the wrapped maintainer, and the entry list stores only a
// primary key.
//
// A missing record returns (nil, nil) — the caller decides what that means. For
// the sliding window it is a counted anomaly rather than an error, matching
// Java's SW_EVICTED_RECORD_MISSING / SW_PROMOTED_RECORD_MISSING arms.
func (store *FDBRecordStore) loadRecordForIndexMaintenance(primaryKey tuple.Tuple) (*FDBStoredRecord[proto.Message], error) {
	return store.LoadRecord(primaryKey)
}

// getIndexMaintainer returns the appropriate IndexMaintainer for the given index.
// Maintainers are cached for the lifetime of the store (= one transaction),
// avoiding repeated allocation of maintainer + mutation objects.
// Matches Java's FDBRecordStore.getIndexMaintainer() dispatch.
func (store *FDBRecordStore) getIndexMaintainer(index *Index) (IndexMaintainer, error) {
	if err := store.checkIndexCollation(index); err != nil {
		return nil, err
	}
	return store.getIndexMaintainerForRawAccess(index)
}

// Range deletion uses stored tuple bytes without evaluating provider-specific keys.
func (store *FDBRecordStore) getIndexMaintainerForRawAccess(index *Index) (IndexMaintainer, error) {
	if cached, ok := store.maintainerCache.Load(index.Name); ok {
		return cached.(IndexMaintainer), nil
	}

	m, err := store.createIndexMaintainer(index)
	if err != nil {
		return nil, err
	}

	store.maintainerCache.Store(index.Name, m)
	return m, nil
}

func (store *FDBRecordStore) createIndexMaintainer(index *Index) (IndexMaintainer, error) {
	idxSubspace := store.indexSubspace(index)
	tx := store.context.Transaction()
	switch canonicalIndexType(index.Type) {
	case IndexTypeValue:
		// Spelled out rather than left to the default arm. It used to BE the
		// default arm, which is what made an unknown type indistinguishable from
		// a value index — see UnknownIndexTypeError.
		return newStandardIndexMaintainer(index, idxSubspace, tx, store), nil
	case IndexTypeCount:
		return newAtomicMutationIndexMaintainer(index, idxSubspace, tx, store, &countMutation{index: index}), nil
	case IndexTypeCountNotNull:
		return newAtomicMutationIndexMaintainer(index, idxSubspace, tx, store, &countNotNullMutation{index: index}), nil
	case IndexTypeCountUpdates:
		return newAtomicMutationIndexMaintainer(index, idxSubspace, tx, store, &countUpdatesMutation{index: index}), nil
	case IndexTypeSum:
		return newAtomicMutationIndexMaintainer(index, idxSubspace, tx, store, &sumMutation{index: index}), nil
	case IndexTypeMaxEverLong:
		return newAtomicMutationIndexMaintainer(index, idxSubspace, tx, store, &minMaxEverLongMutation{index: index, isMax: true}), nil
	case IndexTypeMinEverLong:
		return newAtomicMutationIndexMaintainer(index, idxSubspace, tx, store, &minMaxEverLongMutation{index: index, isMax: false}), nil
	case IndexTypeMaxEverTuple:
		return newAtomicMutationIndexMaintainer(index, idxSubspace, tx, store, &minMaxEverTupleMutation{index: index, isMax: true}), nil
	case IndexTypeMinEverTuple:
		return newAtomicMutationIndexMaintainer(index, idxSubspace, tx, store, &minMaxEverTupleMutation{index: index, isMax: false}), nil
	case IndexTypeRank:
		secSubspace := store.indexSecondarySubspace(index)
		return newRankIndexMaintainer(index, idxSubspace, secSubspace, tx, store)
	case IndexTypeVersion:
		return newVersionIndexMaintainer(index, idxSubspace, tx, store.context, store), nil
	case IndexTypeMaxEverVersion:
		return newMaxEverVersionIndexMaintainer(index, idxSubspace, tx, store.context, store), nil
	case IndexTypePermutedMin:
		secSubspace := store.indexSecondarySubspace(index)
		return newPermutedMinMaxIndexMaintainer(index, idxSubspace, secSubspace, tx, store, false)
	case IndexTypePermutedMax:
		secSubspace := store.indexSecondarySubspace(index)
		return newPermutedMinMaxIndexMaintainer(index, idxSubspace, secSubspace, tx, store, true)
	case IndexTypeBitmapValue:
		return newBitmapValueIndexMaintainer(index, idxSubspace, tx, store)
	case IndexTypeText:
		secSubspace := store.indexSecondarySubspace(index)
		return newTextIndexMaintainerWithTimer(index, idxSubspace, secSubspace, tx, store, store.context.Timer())
	case IndexTypeTimeWindowLeaderboard:
		secSubspace := store.indexSecondarySubspace(index)
		return newTimeWindowLeaderboardIndexMaintainer(index, idxSubspace, secSubspace, tx, store)
	case IndexTypeMultidimensional:
		numDims := 2 // default; extracted from DimensionsKeyExpression at runtime
		if d := extractDimensionsExpression(index.RootExpression); d != nil {
			numDims = d.DimensionsSize
		}
		return newMultidimensionalIndexMaintainer(index, idxSubspace, store.indexSecondarySubspace(index), tx, store, numDims)
	default:
		factory, err := lookupIndexMaintainerFactory(index)
		if err != nil {
			return nil, err
		}
		if factory != nil {
			return store.newRegisteredIndexMaintainer(factory, index, idxSubspace, tx)
		}
		// FAIL CLOSED. Java's registry lookup throws MetaDataException here
		// (IndexMaintainerFactoryRegistryImpl.java:78-82) and so does this.
		//
		// The arm this replaces returned the standard (value-index) maintainer,
		// which meant an index type this build does not implement was maintained
		// as a value index — the wrong key bytes written into that index's own
		// subspace, silently, with the write succeeding. Refusing costs an
		// unmaintainable index; guessing costs the index's contents.
		return nil, &UnknownIndexTypeError{IndexName: index.Name, IndexType: index.Type}
	}
}

// newRegisteredIndexMaintainer builds a registered factory's maintainer and
// applies the sliding-window DECORATION. Java's
// IndexMaintainerFactoryRegistryImpl detects the row-number window predicate
// and wraps the factory with SlidingWindowIndexMaintainerFactory; the wrapping
// is transparent to everything downstream. Same here: the decorator implements
// IndexMaintainer and forwards the read path, so only the WRITE path changes —
// which records reach the delegate.
//
// Only IndexTypeVector is eligible (isSlidingWindowIndex), matching Java's
// SlidingWindowIndexMaintainerFactory.isSlidingWindowIndex. Go's
// IndexTypeVectorSPFresh is a Go-only extension (RFC-094) and is deliberately
// NOT decorated: keyspace 10's layout is the wire contract for Java's HNSW
// vector index, so a Go-only pairing would write bytes under prefix 10 that no
// Java engine can interpret. SPFresh also runs its own background rebalancer
// over the postings it owns, which an external evictor would be racing rather
// than cooperating with.
func (store *FDBRecordStore) newRegisteredIndexMaintainer(factory IndexMaintainerFactory, index *Index, idxSubspace subspace.Subspace, tx fdb.WritableTransaction) (IndexMaintainer, error) {
	m, err := factory.NewIndexMaintainer(IndexMaintainerState{
		Store:         store,
		Context:       store.context,
		Index:         index,
		IndexSubspace: idxSubspace,
		Transaction:   tx,
		Timer:         store.context.Timer(),
	})
	if err != nil {
		return nil, err
	}
	if !isSlidingWindowIndex(index) {
		return m, nil
	}
	return newSlidingWindowIndexMaintainer(
		index, m, store.indexSlidingWindowSubspace(index), tx, store, store.context.Timer())
}

func (store *FDBRecordStore) addUniquenessViolation(index *Index, indexKey tuple.Tuple, primaryKey tuple.Tuple, existingKey tuple.Tuple) error {
	return store.AddUniquenessViolationWithExisting(index, indexKey, primaryKey, existingKey)
}

func (store *FDBRecordStore) removeUniquenessViolations(index *Index, indexKey tuple.Tuple, primaryKey tuple.Tuple) error {
	valueSubspace := store.subspace.Sub(IndexUniquenessViolationsKey, index.SubspaceTupleKey()).Sub(indexKey...)
	store.context.Transaction().Clear(valueSubspace.Pack(primaryKey))
	// Java removes the survivor's violation when the second-last duplicate is
	// deleted. Two rows suffice to distinguish unresolved groups from a single
	// survivor; this serializable read also protects concurrent resolution.
	rows, err := store.context.Transaction().GetRange(valueSubspace, fdb.RangeOptions{Limit: 2}).GetSliceWithError()
	if err != nil {
		return err
	}
	if len(rows) == 1 {
		keyRange, err := fdb.PrefixRange(valueSubspace.Bytes())
		if err != nil {
			return err
		}
		store.context.ClearRange(keyRange)
	}
	return nil
}

// Env exposes the record context's DST environment to index maintainers.
// Nil-safe (a nil *dst.Env means production); index maintainers draw persisted
// nonces through it so a simulation run is byte-reproducible.
func (store *FDBRecordStore) Env() *dst.Env { return store.context.Env() }

// lockRegistry delegation — matches Java's LockRegistry on FDBRecordContext.

// AcquireWriteLock takes the context's exclusive lock for key.
func (store *FDBRecordStore) AcquireWriteLock(key string) { store.context.locks.WriteLock(key) }

// ReleaseWriteLock releases the exclusive lock AcquireWriteLock took for key.
func (store *FDBRecordStore) ReleaseWriteLock(key string) { store.context.locks.WriteUnlock(key) }

// AcquireReadLock takes the context's shared lock for key.
func (store *FDBRecordStore) AcquireReadLock(key string) { store.context.locks.ReadLock(key) }

// ReleaseReadLock releases the shared lock AcquireReadLock took for key.
func (store *FDBRecordStore) ReleaseReadLock(key string) { store.context.locks.ReadUnlock(key) }

func (store *FDBRecordStore) isKeyInIndexBuildRange(index *Index, primaryKey tuple.Tuple) (bool, error) {
	irs := NewIndexingRangeSet(store.subspace, index)
	return irs.ContainsKey(store.context.Transaction(), primaryKey.Pack())
}

// ScanRecords scans all records in the store, resuming after continuation's key.
// Matches Java's FDBRecordStoreBase.scanRecords(continuation, scanProperties).
func (store *FDBRecordStore) ScanRecords(continuation []byte, scanProperties ScanProperties) RecordCursor[*FDBStoredRecord[proto.Message]] {
	// EventScanRecords is recorded by ScanRecordsInRange, not here — see its
	// doc-comment for why the innermost method is the only recording site.
	return store.ScanRecordsInRange(nil, nil, EndpointTypeTreeStart, EndpointTypeTreeEnd, continuation, scanProperties)
}

// ScanRecordsByType scans records filtered to a specific record type.
// When the primary key uses RecordTypeKey() as its first component (common pattern),
// this does a prefix scan on just that type's range — O(records of this type) instead
// of O(all records). Falls back to full scan + filter if RecordTypeKey is not used.
// Matches Java's RecordQuery with RecordTypeFilter.
func (store *FDBRecordStore) ScanRecordsByType(recordTypeName string, continuation []byte, scanProperties ScanProperties) RecordCursor[*FDBStoredRecord[proto.Message]] {
	recordType := store.metaData.GetRecordType(recordTypeName)
	if recordType != nil && recordType.PrimaryKey != nil && primaryKeyHasRecordTypePrefix(recordType.PrimaryKey) {
		// Fast path: prefix scan on the record type key range.
		// RecordTypeKey is the first component, so all records of this type
		// have PK starting with (recordTypeKey, ...).
		// Use GetRecordTypeKey() to respect explicit keys from SetRecordTypeKey().
		// Matches Java's RecordType.getRecordTypeKey().
		rtk := recordType.GetRecordTypeKey()
		return store.ScanRecordsInRange(
			tuple.Tuple{rtk}, tuple.Tuple{rtk},
			EndpointTypeRangeInclusive, EndpointTypeRangeInclusive,
			continuation, scanProperties,
		)
	}
	// Slow path: full scan + filter (no RecordTypeKey prefix).
	//
	// Filter on the RESOLVED name, never on the caller's string. GetRecordType
	// accepts a SQL identifier and maps it through the protobuf escaping, so
	// `MY$TABLE` and `MY__1TABLE` both reach here for one type -- but only the
	// stored spelling is what FDBStoredRecord.RecordType.Name holds. Comparing
	// the caller's string made the fast path answer and the slow path return
	// zero rows and a nil error, which is indistinguishable from "this type has
	// no records". An unresolvable name keeps matching nothing, which is what
	// the caller-string fallback preserves.
	wantName := recordTypeName
	if recordType != nil {
		wantName = recordType.Name
	}
	inner := store.ScanRecords(continuation, scanProperties)
	return &filterCursor[*FDBStoredRecord[proto.Message]]{
		inner: inner,
		predicate: func(rec *FDBStoredRecord[proto.Message]) bool {
			return rec.RecordType.Name == wantName
		},
	}
}

// primaryKeyHasRecordTypePrefix checks if the key expression starts with RecordTypeKey().
func primaryKeyHasRecordTypePrefix(expr KeyExpression) bool {
	if _, ok := expr.(*RecordTypeKeyExpression); ok {
		return true
	}
	if concat, ok := expr.(*CompositeKeyExpression); ok && len(concat.expressions) > 0 {
		_, ok := concat.expressions[0].(*RecordTypeKeyExpression)
		return ok
	}
	return false
}

// KeyExpressionHasRecordTypePrefix is the exported form of the per-expression
// prefix check. Used by the SQL layer's covering-index pushdown to decide
// how to slice a primary-key tuple (first element is the record-type key
// when true).
func KeyExpressionHasRecordTypePrefix(expr KeyExpression) bool {
	return primaryKeyHasRecordTypePrefix(expr)
}

// ScanRecordsInRange scans records in a key range.
//
// This is the ONE place EventScanRecords is recorded, because it is the one
// method every record scan funnels through — ScanRecords, ScanRecordsByType and
// the query executor's range scans all end here. Java makes the same choice for
// the same reason: its single recording site is the innermost private
// scanTypedRecords (FDBRecordStore.java:1441), never the outer convenience
// wrappers, so no entry point can scan records without the event and none can
// record it twice. Instrumenting the outer wrapper instead left the executor's
// own scans — which enter here directly — entirely uncounted.
func (store *FDBRecordStore) ScanRecordsInRange(
	low, high tuple.Tuple,
	lowEndpoint, highEndpoint EndpointType,
	continuation []byte,
	scanProperties ScanProperties,
) RecordCursor[*FDBStoredRecord[proto.Message]] {
	cursor := store.newKeyValueCursor(low, high, lowEndpoint, highEndpoint, continuation, scanProperties)
	return instrumentCursor(store.context.Timer(), EventScanRecords, cursor)
}

func (store *FDBRecordStore) newKeyValueCursor(
	low, high tuple.Tuple,
	lowEndpoint, highEndpoint EndpointType,
	continuation []byte,
	scanProperties ScanProperties,
) *keyValueCursor {
	recordsSubspace := store.recordsSubspace
	bounds := newKVScanBounds(recordsSubspace, low, high, lowEndpoint, highEndpoint)
	props := scanProperties.ExecuteProperties
	split := store.metaData.IsSplitLongRecords()

	cursor := &keyValueCursor{
		store:           store,
		continuation:    continuation,
		scanProperties:  scanProperties,
		reverse:         scanProperties.IsReverse(),
		keyPrefixLength: len(recordsSubspace.Bytes()),
		bounds:          bounds,
		prefixLength:    bounds.prefixLength,
		scanState:       resolveScanLimiterState(props),
		// Bare-key layout applies ONLY when the store does not split long records;
		// a split-capable store always suffixes its keys even at format < 5. Matches
		// Java's scan logic, which gates the bare-key path on !isSplitLongRecords().
		omitUnsplitRecordSuffix: store.omitUnsplitRecordSuffix() && !split,
		useOldVersionFormat:     store.useOldVersionFormat(),
	}
	cursor.clock = transactionClock(store.context, props, cursor.scanState)
	if cursor.omitUnsplitRecordSuffix {
		cursor.selectorSkip = max(props.Skip, 0)
	}
	if limit := props.ReturnedRowLimit; limit > 0 && !split {
		if cursor.omitUnsplitRecordSuffix {
			cursor.innerLimit = limit
		} else {
			// Java doubles the unsplit inner limit in case records carry versions.
			cursor.innerLimit = saturatingAdd(limit, max(props.Skip, 0))
			cursor.innerLimit = saturatingAdd(cursor.innerLimit, cursor.innerLimit)
		}
	}
	return cursor
}

// CountRecords is Java's FDBRecordStore.countRecords: skip moves the range's
// selector and row and time limits are cleared. An unsplit store counts its
// key-values, inline versions included, without charging the scan limits; a
// split store counts the unsplitter's records, which charge them. A count cut
// short by a scan limit also returns ScanLimitReachedError (RFC-106a).
func (store *FDBRecordStore) CountRecords(
	ctx context.Context,
	low, high tuple.Tuple,
	lowEndpoint, highEndpoint EndpointType,
	continuation []byte,
	scanProperties ScanProperties,
) (int, error) {
	scanProperties.ExecuteProperties = scanProperties.ExecuteProperties.ClearRowAndTimeLimits()
	cursor := store.newKeyValueCursor(low, high, lowEndpoint, highEndpoint, continuation, scanProperties)
	cursor.selectorSkip = max(scanProperties.ExecuteProperties.Skip, 0)
	if err := cursor.initIterator(); err != nil {
		return 0, err
	}
	split := store.metaData.IsSplitLongRecords()
	count := 0
	for {
		if err := ctx.Err(); err != nil {
			return count, err
		}
		if !split {
			_, ok, err := cursor.nextKV()
			if err != nil || !ok {
				return count, err
			}
			count++
			continue
		}
		ok, reason, cont, err := cursor.unsplit(ctx)
		if err != nil {
			return count, err
		}
		if !ok {
			return count, errIfDrainTruncated(NewResultNoNext[*FDBStoredRecord[proto.Message]](reason, cont))
		}
		count++
	}
}

// FDBStoredRecord represents a record that has been stored in or loaded from FDB
// This is generic to match Java's FDBStoredRecord<M extends Message>
type FDBStoredRecord[M proto.Message] struct {
	// PrimaryKey is the record's primary key
	PrimaryKey tuple.Tuple

	// RecordType is the type of this record
	RecordType *RecordType

	// Record is the actual record data
	Record M

	// Version is the record's version, if loaded.
	// Matches Java's FDBStoredRecord.getVersion().
	Version *FDBRecordVersion

	// Store is the record store this record belongs to.
	// Matches Java's FDBRecord.getStore().
	Store *FDBRecordStore

	// Storage size information
	KeyCount  int
	KeySize   int
	ValueSize int

	// Whether the record is split across multiple keys
	Split bool

	// VersionedInline reports a version stored with the record and counted in its sizes.
	VersionedInline bool

	// wire is the stored bytes the record was decoded from, for a type that
	// reaches a map field (record_wire_map_order.go); nil otherwise.
	wire *recordWire
}

// HasVersion returns whether this stored record has a version.
// Matches Java's FDBStoredRecord.hasVersion().
func (r *FDBStoredRecord[M]) HasVersion() bool {
	return r.Version != nil
}

// GetFormatVersion returns the store format version.
// Goroutine-safe via stateMu (read lock).
// Matches Java's FDBRecordStore.getFormatVersion().
func (store *FDBRecordStore) GetFormatVersion() int32 {
	store.ensureStoreStateLoaded()
	store.stateMu.RLock()
	defer store.stateMu.RUnlock()
	return store.getFormatVersionLocked()
}

func (store *FDBRecordStore) getFormatVersionLocked() int32 {
	if store.storeHeader != nil && store.storeHeader.FormatVersion != nil {
		return *store.storeHeader.FormatVersion
	}
	return 0
}

// omitUnsplitRecordSuffix reports whether records are stored WITHOUT the unsplit
// record suffix (legacy layout: the value lives at the bare key
// recordsSubspace.pack(primaryKey) with no trailing suffix). This only takes
// effect when split_long_records is false; split stores always suffix their keys.
//
// Matches Java's FDBRecordStore.omitUnsplitRecordSuffix field, as initialized in
// checkVersion(): the persisted DataStoreInfo flag is authoritative once the store
// is at format version >= SAVE_UNSPLIT_WITH_SUFFIX (5); below that the records were
// necessarily saved without a suffix, so the flag is implicitly true.
func (store *FDBRecordStore) omitUnsplitRecordSuffix() bool {
	h := store.storeHeader
	if h == nil {
		// No header yet (new store being created) — current layout.
		return false
	}
	if h.GetFormatVersion() >= formatVersionSaveUnsplitWithSuffix {
		// "Note that this depends on the property that calling get on an unset
		// boolean field results in getting back false." (Java checkVersion.)
		return h.GetOmitUnsplitRecordSuffix()
	}
	return true
}

// useOldVersionFormat reports whether record versions are stored in the legacy
// separate RecordVersionKey(8) subspace (keyed by the bare primary key) rather
// than inline adjacent to the record at recordsSubspace.pack(pk, -1).
//
// Matches Java's FDBRecordStore.useOldVersionFormat():
//
//	formatVersion < SAVE_VERSION_WITH_RECORD (6) || omitUnsplitRecordSuffix
//
// The omit clause is required because a store that omits the unsplit suffix has
// no place to put the inline version key, so versions stay in the old subspace
// even after the format version is bumped past 6.
func (store *FDBRecordStore) useOldVersionFormat() bool {
	h := store.storeHeader
	if h == nil {
		return false
	}
	return h.GetFormatVersion() < formatVersionSaveVersionWithRecord || store.omitUnsplitRecordSuffix()
}

// GetUserVersion returns the user-defined store version.
// Goroutine-safe via stateMu (read lock).
// Matches Java's FDBRecordStore.getUserVersion().
func (store *FDBRecordStore) GetUserVersion() int32 {
	store.ensureStoreStateLoaded()
	store.stateMu.RLock()
	defer store.stateMu.RUnlock()
	if store.storeHeader != nil && store.storeHeader.UserVersion != nil {
		return *store.storeHeader.UserVersion
	}
	return 0
}

// SetUserVersion updates the user-defined store version and writes it to FDB.
// Goroutine-safe via stateMu (write lock).
// Matches Java's FDBRecordStore.setUserVersion().
func (store *FDBRecordStore) SetUserVersion(version int32) error {
	store.stateMu.Lock()
	defer store.stateMu.Unlock()
	if store.storeHeader == nil {
		return &RecordStoreStateNotLoadedError{}
	}
	store.storeHeader.UserVersion = &version
	return store.writeStoreHeader(store.storeHeader)
}

// GetMetaDataVersion returns the metadata version stored in the header.
// Goroutine-safe via stateMu (read lock).
func (store *FDBRecordStore) GetMetaDataVersion() int32 {
	store.ensureStoreStateLoaded()
	store.stateMu.RLock()
	defer store.stateMu.RUnlock()
	if store.storeHeader != nil && store.storeHeader.MetaDataversion != nil {
		return *store.storeHeader.MetaDataversion
	}
	return 0
}

// requireFormatVersion is Java's per-feature
// `if (!getFormatVersionEnum().isAtLeast(V)) throw` guard, applied at the WRITE
// site of every version-gated store-header feature.
//
// It reads the ACTUAL header version, not the version this process would like to
// open at, because the header is what an older instance opening the same store
// will see. Writing a v12 store lock into a header that still says 11 produces a
// lock a correctly-behaved older reader ignores — the feature silently does
// nothing, which is worse than refusing to set it.
//
// Java sites ported: FDBRecordStore.java:3222 (header user fields), :3443
// (record count state), :3478/:3494 (store lock state), :3503/:3517
// (incarnation).
//
// Callers must hold stateMu (or be inside a path that does); this only reads
// storeHeader.
func (store *FDBRecordStore) requireFormatVersion(feature string, required int32) error {
	if got := store.storeHeader.GetFormatVersion(); got < required {
		return &UnsupportedFeatureForFormatVersionError{
			Feature: feature, Version: got, RequiredVersion: required,
		}
	}
	return nil
}

// GetIncarnation returns the incarnation counter from the store header.
// Used for cross-cluster data migration versioning.
// Goroutine-safe via stateMu (read lock).
//
// GATED like Java. FDBRecordStore.getIncarnation() (`:3502-3506`) throws when the
// format version is below INCARNATION(13), and Go returned 0 — which a caller
// cannot tell apart from a store whose incarnation genuinely is 0. That is not a
// leniency, it is an AMBIGUITY: "this store has no incarnation yet" and "this
// store's format is too old to HAVE one" are different facts that were returning
// the same value. A migration keyed off incarnation reads a too-old store as a
// never-migrated one.
//
// The error is the write gate's twin (UnsupportedFeatureForFormatVersionError),
// not a new type: read and write are gated on the same version by the same
// predicate, so a caller that can write the field can read it back.
func (store *FDBRecordStore) GetIncarnation() (int32, error) {
	store.ensureStoreStateLoaded()
	store.stateMu.RLock()
	defer store.stateMu.RUnlock()
	if err := store.requireFormatVersion("incarnation", formatVersionIncarnation); err != nil {
		return 0, err
	}
	if store.storeHeader != nil {
		return store.storeHeader.GetIncarnation(), nil
	}
	return 0, nil
}

// UpdateIncarnation atomically updates the incarnation counter using the provided
// function. The new value must be strictly greater than the current value.
// Goroutine-safe via stateMu (write lock).
// Matches Java's FDBRecordStore.updateIncarnation().
func (store *FDBRecordStore) UpdateIncarnation(updater func(current int32) int32) error {
	if updater == nil {
		return fmt.Errorf("updater must not be nil")
	}
	store.stateMu.Lock()
	defer store.stateMu.Unlock()
	if store.storeHeader == nil {
		return &RecordStoreStateNotLoadedError{}
	}
	if err := store.requireFormatVersion("incarnation", formatVersionIncarnation); err != nil {
		return err
	}
	current := store.storeHeader.GetIncarnation()
	newVal := updater(current)
	if newVal <= current {
		return fmt.Errorf("incarnation must increase: current %d, new %d", current, newVal)
	}
	store.storeHeader.Incarnation = &newVal
	return store.writeStoreHeader(store.storeHeader)
}

// GetHeaderUserField returns a user-defined field from the store header, or nil
// if the field is not set.
// Goroutine-safe via stateMu (read lock).
//
// GATED like Java. getHeaderUserField() routes through
// validateCanAccessHeaderUserFields() — the SHARED validator at `:3221-3226`,
// reached from getHeaderUserField at `:3249` — which throws below
// HEADER_USER_FIELDS(8); Go returned nil, which a caller cannot tell apart from
// an unset field. Same ambiguity as GetIncarnation, and the same fix: "not set"
// and "this format cannot hold user fields at all" are different answers.
//
// SetHeaderUserField already gated on this exact version, so the pair was
// ASYMMETRIC — a write that refused loudly beside a read that answered "absent",
// which is the shape that makes a caller conclude its write silently failed to
// persist.
func (store *FDBRecordStore) GetHeaderUserField(key string) ([]byte, error) {
	store.ensureStoreStateLoaded()
	store.stateMu.RLock()
	defer store.stateMu.RUnlock()
	if err := store.requireFormatVersion("header user fields", formatVersionHeaderUserFields); err != nil {
		return nil, err
	}
	if store.storeHeader == nil {
		return nil, nil
	}
	for _, entry := range store.storeHeader.GetUserField() {
		if entry.GetKey() == key {
			return entry.GetValue(), nil
		}
	}
	return nil, nil
}

// SetHeaderUserField sets a user-defined field in the store header.
// The value is persisted immediately. Keep values small since the entire
// header is loaded on every store open.
// Goroutine-safe via stateMu (write lock).
// Matches Java's FDBRecordStore.setHeaderUserField().
func (store *FDBRecordStore) SetHeaderUserField(key string, value []byte) error {
	store.stateMu.Lock()
	defer store.stateMu.Unlock()
	if store.storeHeader == nil {
		return &RecordStoreStateNotLoadedError{}
	}
	if err := store.requireFormatVersion("header user fields", formatVersionHeaderUserFields); err != nil {
		return err
	}
	// Update existing entry or append new one
	for _, entry := range store.storeHeader.UserField {
		if entry.GetKey() == key {
			entry.Value = value
			return store.writeStoreHeader(store.storeHeader)
		}
	}
	store.storeHeader.UserField = append(store.storeHeader.UserField, &gen.DataStoreInfo_UserFieldEntry{
		Key:   &key,
		Value: value,
	})
	return store.writeStoreHeader(store.storeHeader)
}

// ClearHeaderUserField removes a user-defined field from the store header.
// Goroutine-safe via stateMu (write lock).
// Matches Java's FDBRecordStore.clearHeaderUserField().
func (store *FDBRecordStore) ClearHeaderUserField(key string) error {
	store.stateMu.Lock()
	defer store.stateMu.Unlock()
	if store.storeHeader == nil {
		return &RecordStoreStateNotLoadedError{}
	}
	if err := store.requireFormatVersion("header user fields", formatVersionHeaderUserFields); err != nil {
		return err
	}
	fields := store.storeHeader.UserField
	for i, entry := range fields {
		if entry.GetKey() == key {
			store.storeHeader.UserField = append(fields[:i], fields[i+1:]...)
			return store.writeStoreHeader(store.storeHeader)
		}
	}
	return nil // not found, no-op
}

// RecordStoreState captures the mutable state of a record store at a point in time.
// Matches Java's RecordStoreState.
type RecordStoreState struct {
	StoreHeader *gen.DataStoreInfo
	IndexStates map[string]IndexState
}

// GetRecordStoreState returns the current state of the store (header + index states).
// Goroutine-safe via stateMu (read lock).
// Matches Java's FDBRecordStore.getRecordStoreState().
func (store *FDBRecordStore) GetRecordStoreState() *RecordStoreState {
	store.ensureStoreStateLoaded()
	store.stateMu.RLock()
	defer store.stateMu.RUnlock()
	states := store.snapshotIndexStatesLocked()
	return &RecordStoreState{
		StoreHeader: store.storeHeader,
		IndexStates: states,
	}
}

// SetStoreLockState sets the store lock state in the header and persists it.
// Use FORBID_RECORD_UPDATE to prevent record mutations, or FULL_STORE to
// prevent the store from being opened entirely.
// Goroutine-safe via stateMu (write lock).
// Matches Java's FDBRecordStore.setStoreLockStateAsync().
func (store *FDBRecordStore) SetStoreLockState(state gen.DataStoreInfo_StoreLockState_State, reason string) error {
	store.stateMu.Lock()
	defer store.stateMu.Unlock()
	if store.storeHeader == nil {
		return &RecordStoreStateNotLoadedError{}
	}
	if err := store.requireFormatVersion("store lock state", formatVersionStoreLockState); err != nil {
		return err
	}
	ts := store.context.Env().Now().UnixMilli()
	store.storeHeader.StoreLockState = &gen.DataStoreInfo_StoreLockState{
		LockState: &state,
		Reason:    &reason,
		Timestamp: &ts,
	}
	return store.writeStoreHeader(store.storeHeader)
}

// ClearStoreLockState removes the lock state from the store header.
// Goroutine-safe via stateMu (write lock).
// Matches Java's FDBRecordStore.clearStoreLockStateAsync().
func (store *FDBRecordStore) ClearStoreLockState() error {
	store.stateMu.Lock()
	defer store.stateMu.Unlock()
	if store.storeHeader == nil {
		return &RecordStoreStateNotLoadedError{}
	}
	if err := store.requireFormatVersion("store lock state", formatVersionStoreLockState); err != nil {
		return err
	}
	store.storeHeader.StoreLockState = nil
	return store.writeStoreHeader(store.storeHeader)
}

// ReloadRecordStoreState forces a reload of the store state from FDB.
// Refreshes transaction-visible state, including explicit raw state mutations;
// it does not advance the transaction's read version. The loaded state is shared
// with other handles in this context.
// Matches Java's FDBRecordStore.loadRecordStoreStateAsync() force reload path.
func (store *FDBRecordStore) ReloadRecordStoreState() error {
	if err := store.ensureStoreStateLoadedErr(); err != nil {
		return err
	}
	// Reload excludes maintenance through other handles before taking the
	// lower-level registry/view locks used to publish the refreshed state.
	store.stateMu.Lock()
	defer store.stateMu.Unlock()
	store.indexStateView.maintenance.Lock()
	defer store.indexStateView.maintenance.Unlock()
	store.context.indexStateMu.Lock()
	defer store.context.indexStateMu.Unlock()
	store.indexStateView.mu.Lock()
	defer store.indexStateView.mu.Unlock()
	exists, header, err := store.checkStoreExists()
	if err != nil {
		return err
	}
	if !exists {
		return &RecordStoreDoesNotExistError{}
	}
	states, err := readIndexStates(store.context.Transaction(), store.subspace)
	if err != nil {
		return err
	}
	if !maps.Equal(store.indexStateView.states, states) {
		store.context.SetDirtyStoreState(true)
		if header.GetCacheable() {
			store.context.SetMetaDataVersionStamp()
		}
	}
	store.storeHeader = header
	store.indexStates = states
	store.indexStateView.states = maps.Clone(states)
	return nil
}

// loadStoreState loads store state via the cache or directly from FDB.
// When bypassFullStoreLockReason is set, the cache is bypassed entirely
// (matching Java's checkVersion which skips cache on lock bypass).
// Called during store Build() before concurrent access, but uses stateMu
// for consistency.
func (store *FDBRecordStore) loadStoreState(existenceCheck StoreExistenceCheck, bypassReason *string) error {
	store.stateMu.Lock()
	defer store.stateMu.Unlock()
	// Register before returning the loaded handle, and exclude clears for the
	// entire read-to-publication interval, including cache lookups.
	store.context.indexStateMu.Lock()
	defer store.context.indexStateMu.Unlock()
	if bypassReason != nil {
		// Bypass cache when using lock bypass — need fresh state to validate lock.
		state, err := loadRecordStoreState(store, existenceCheck)
		if err != nil {
			return err
		}
		store.storeHeader = state.StoreHeader
		store.indexStates = state.IndexStates
		store.indexStateView = store.context.indexStateViewLocked(store.subspace, store.indexStates)
		return nil
	}

	entry, err := store.storeStateCache.Get(store, existenceCheck)
	if err != nil {
		return err
	}

	cachedState := entry.GetRecordStoreState()
	if entry.shared {
		// Clone cached state so store mutations don't corrupt the shared cache entry.
		// Matches Java's RecordStoreState.toImmutable() which returns an unmodifiable copy.
		store.storeHeader = proto.Clone(cachedState.StoreHeader).(*gen.DataStoreInfo)
		store.indexStates = make(map[string]IndexState, len(cachedState.IndexStates))
		for k, v := range cachedState.IndexStates {
			store.indexStates[k] = v
		}
	} else {
		// Non-shared entry (e.g., PassThrough cache) — safe to use directly.
		store.storeHeader = cachedState.StoreHeader
		store.indexStates = cachedState.IndexStates
	}
	store.indexStateView = store.context.indexStateViewLocked(store.subspace, store.indexStates)
	return nil
}

// SetStateCacheability sets whether this store's state can be cached across
// transactions. When enabled, the metadata version stamp is initialized so
// cache invalidation can work. Requires FormatVersion >= CACHEABLE_STATE (7).
// Returns true if the cacheability was changed, false if already at the desired state.
// Goroutine-safe via stateMu (write lock).
// Matches Java's FDBRecordStore.setStateCacheabilityAsync().
func (store *FDBRecordStore) SetStateCacheability(cacheable bool) (bool, error) {
	store.stateMu.Lock()
	defer store.stateMu.Unlock()
	if store.storeHeader == nil {
		return false, &RecordStoreStateNotLoadedError{}
	}
	if store.storeHeader.GetFormatVersion() < formatVersionCacheableState {
		return false, fmt.Errorf("store format version %d does not support cacheability (requires >= %d)",
			store.storeHeader.GetFormatVersion(), formatVersionCacheableState)
	}
	if store.storeHeader.GetCacheable() == cacheable {
		return false, nil
	}
	header := proto.Clone(store.storeHeader).(*gen.DataStoreInfo)
	header.Cacheable = &cacheable
	if err := store.writeStoreHeader(header); err != nil {
		return false, err
	}
	store.storeHeader = header
	return true, nil
}

// IsStateCacheable returns whether this store's state is currently cacheable.
// Goroutine-safe via stateMu (read lock).
func (store *FDBRecordStore) IsStateCacheable() bool {
	store.stateMu.RLock()
	defer store.stateMu.RUnlock()
	return store.storeHeader != nil && store.storeHeader.GetCacheable()
}

// EstimateStoreSize returns the estimated byte size of the entire store subspace.
// Uses FDB's GetEstimatedRangeSizeBytes which provides an approximation.
// Matches Java's FDBRecordStore.estimateStoreSizeAsync().
func (store *FDBRecordStore) EstimateStoreSize() (int64, error) {
	begin, end := store.subspace.FDBRangeKeys()
	kr := fdb.KeyRange{Begin: begin, End: end}
	return store.context.Transaction().GetEstimatedRangeSizeBytes(kr).Get()
}

// EstimateRecordsSize returns the estimated byte size of the records subspace only.
// Matches Java's FDBRecordStore.estimateRecordsSizeAsync().
func (store *FDBRecordStore) EstimateRecordsSize() (int64, error) {
	recordsSub := store.recordsSubspace
	begin, end := recordsSub.FDBRangeKeys()
	kr := fdb.KeyRange{Begin: begin, End: end}
	return store.context.Transaction().GetEstimatedRangeSizeBytes(kr).Get()
}

// UniquenessViolation represents a recorded uniqueness violation entry.
// Matches Java's RecordIndexUniquenessViolation.
type UniquenessViolation struct {
	IndexName   string
	IndexKey    tuple.Tuple
	PrimaryKey  tuple.Tuple
	ExistingKey tuple.Tuple // Conflicting PK stored by the other side (may be nil)
}

// ScanUniquenessViolations returns all uniqueness violations recorded for the given index.
// Violations are stored in the IndexUniquenessViolationsKey (7) subspace.
// Matches Java's StandardIndexMaintainer.scanUniquenessViolations().
func (store *FDBRecordStore) ScanUniquenessViolations(index *Index) ([]UniquenessViolation, error) {
	if index == nil {
		return nil, fmt.Errorf("index must not be nil")
	}
	violationSubspace := store.subspace.Sub(IndexUniquenessViolationsKey, index.SubspaceTupleKey())
	begin, end := violationSubspace.FDBRangeKeys()
	kr := fdb.KeyRange{Begin: begin, End: end}

	kvs, err := store.context.Transaction().GetRange(kr, fdb.RangeOptions{}).GetSliceWithError()
	if err != nil {
		return nil, fmt.Errorf("scan uniqueness violations for index %q: %w", index.Name, err)
	}

	var violations []UniquenessViolation
	for _, kv := range kvs {
		t, err := tuplefast.SubspaceUnpack(kv.Key, len(violationSubspace.Bytes()))
		if err != nil {
			return nil, fmt.Errorf("unpack violation key: %w", err)
		}
		// Key format: [indexKey..., primaryKey...]
		colCount := index.RootExpression.ColumnSize()
		if len(t) > colCount {
			v := UniquenessViolation{
				IndexName:  index.Name,
				IndexKey:   tuple.Tuple(t[:colCount]),
				PrimaryKey: tuple.Tuple(t[colCount:]),
			}
			// Value contains the conflicting PK (matching Java's wire format).
			// Empty value means no cross-reference was stored.
			if len(kv.Value) > 0 {
				existingKey, err := tuplefast.Unpack(kv.Value)
				if err == nil {
					v.ExistingKey = existingKey
				}
			}
			violations = append(violations, v)
		}
	}
	return violations, nil
}

// ResolveUniquenessViolation removes a single uniqueness violation entry.
// Call this after manually resolving the conflict (e.g., deleting the duplicate record).
// This low-level utility removes only the named entry. Ordinary record deletion
// uses Java's removeUniquenessViolationsAsync algorithm, including survivor cleanup.
func (store *FDBRecordStore) ResolveUniquenessViolation(index *Index, indexKey tuple.Tuple, primaryKey tuple.Tuple) error {
	if index == nil {
		return fmt.Errorf("index must not be nil")
	}
	violationSubspace := store.subspace.Sub(IndexUniquenessViolationsKey, index.SubspaceTupleKey())
	store.context.Transaction().Clear(violationSubspace.Sub(indexKey...).Pack(primaryKey))
	return nil
}

// AddUniquenessViolation records a uniqueness violation for the given index.
// Used during WRITE_ONLY index builds when a uniqueness conflict is detected.
// Stores empty bytes as the value (no cross-reference to conflicting PK).
// Use AddUniquenessViolationWithExisting to store the conflicting PK in the value.
func (store *FDBRecordStore) AddUniquenessViolation(index *Index, indexKey tuple.Tuple, primaryKey tuple.Tuple) error {
	if index == nil {
		return fmt.Errorf("index must not be nil")
	}
	return store.AddUniquenessViolationWithExisting(index, indexKey, primaryKey, nil)
}

// AddUniquenessViolationWithExisting records a uniqueness violation with the conflicting PK.
// Matches Java's StandardIndexMaintainer.addUniquenessViolation(valueKey, primaryKey, existingKey).
// When existingKey is non-nil, its packed bytes are stored as the FDB value.
// When existingKey is nil, empty bytes are stored.
func (store *FDBRecordStore) AddUniquenessViolationWithExisting(index *Index, indexKey tuple.Tuple, primaryKey tuple.Tuple, existingKey tuple.Tuple) error {
	if index == nil {
		return fmt.Errorf("index must not be nil")
	}
	violationSubspace := store.subspace.Sub(IndexUniquenessViolationsKey, index.SubspaceTupleKey())
	// Unlike ordinary index entries, Java's uniquenessViolationKey appends the
	// full primary key, including components already present in the value key.
	key := violationSubspace.Sub(indexKey...).Pack(primaryKey)
	var value []byte
	if existingKey != nil {
		value = existingKey.Pack()
	}
	store.context.Transaction().Set(key, value)
	return nil
}

// serializeUnionOver marshals a record into the UnionDescriptor wire format
// without allocating a UnionDescriptor struct: tag(fieldNum, LEN) + varint(len)
// + innerBytes, wire-compatible with Java's UnionDescriptor serialization. The
// record replaces a stored one whose record bytes (inside the union) are
// priorInner, nil for a new record or one of another type (priorRecordInner):
// a type that reaches a map field keeps
// each map in the order priorInner stored it (marshalMapRecord,
// record_wire_map_order.go), and is never written with vtproto's MarshalVT,
// whose map order is Go's random iteration order.
func serializeUnionOver(record proto.Message, recordType *RecordType, priorInner []byte) ([]byte, error) {
	if recordType.unionFieldNumber == 0 {
		return nil, fmt.Errorf("no union field number for record type: %s", recordType.Name)
	}
	if err := recordType.checkUTF8Strings(record); err != nil {
		return nil, err
	}

	if recordType.reachesMap {
		if priorInner == nil && recordType.reachesClosedEnum && holdsUndeclared(record.ProtoReflect(), recordType.closedEnumReach) {
			// A map value holding an undeclared closed-enum number (the only
			// one asJavaForSave's write view keeps): a new record's maps go
			// through the rewrite too, which writes that entry in Java's form.
			priorInner = []byte{}
		}
		innerBytes, err := marshalMapRecord(record, priorInner, recordType.mapReach)
		if err != nil {
			return nil, err
		}
		out := make([]byte, 0, 10+len(innerBytes))
		out = protowire.AppendTag(out, recordType.unionFieldNumber, protowire.BytesType)
		return protowire.AppendBytes(out, innerBytes), nil
	}

	// Fast path: if SizeVT is available, compute size first and allocate once.
	// This avoids the intermediate MarshalVT allocation.
	type sizer interface {
		SizeVT() int
		MarshalToSizedBufferVT([]byte) (int, error)
	}
	if sv, ok := record.(sizer); ok {
		innerSize := sv.SizeVT()
		// Allocate single buffer: tag + length varint + inner bytes
		tagSize := protowire.SizeTag(recordType.unionFieldNumber)
		lenSize := protowire.SizeBytes(innerSize) - innerSize // just the varint length
		totalSize := tagSize + lenSize + innerSize
		out := make([]byte, totalSize)

		// Write tag + length prefix
		header := protowire.AppendTag(out[:0], recordType.unionFieldNumber, protowire.BytesType)
		header = protowire.AppendVarint(header, uint64(innerSize))
		headerLen := len(header)

		// Marshal directly into the remaining buffer
		_, err := sv.MarshalToSizedBufferVT(out[headerLen : headerLen+innerSize])
		if err != nil {
			return nil, err
		}
		return out[:headerLen+innerSize], nil
	}

	// Slow path: marshal first, then wrap
	var innerBytes []byte
	var err error
	if vm, ok := record.(interface{ MarshalVT() ([]byte, error) }); ok {
		innerBytes, err = vm.MarshalVT()
	} else {
		// Deterministic marshal so the persisted record bytes are BYTE-STABLE: the same record
		// value marshals to the same bytes every time, so rewriting a row whose content did not
		// change produces bytes that did not change. Generated protos take the VT paths above,
		// which emit a fixed, code-generated field order; this reflection path is hit by dynamic
		// messages (dynamicpb — SQL rows), whose default marshal iterates fields in Go map order
		// and so serializes the same row to DIFFERENT bytes across writes.
		//
		// Stability is the whole of what Deterministic:true buys — NOT a canonical encoding. It
		// selects order.LegacyFieldOrder (extensions first, then non-oneof fields before oneof
		// fields, then by field number) and sorts map entries by key; upstream explicitly
		// disclaims that this output is canonical across languages or stable across releases.
		// So this is not a claim that the bytes match what Java emits for the same record. Wire
		// compatibility does not need one: any permutation of top-level fields is a valid
		// encoding of the same message, and decoders — Java's included — are order-agnostic.
		//
		// Surfaced by the RFC-199 SQL workload's determinism oracle, which replays a seed and
		// diffs the persisted bytes.
		innerBytes, err = proto.MarshalOptions{Deterministic: true}.Marshal(record)
	}
	if err != nil {
		return nil, err
	}
	out := make([]byte, 0, 10+len(innerBytes))
	out = protowire.AppendTag(out, recordType.unionFieldNumber, protowire.BytesType)
	out = protowire.AppendBytes(out, innerBytes)
	return out, nil
}

// readStoredRecord is the union message a stored record's bytes hold: Java's
// TransformedRecordSerializer.deserialize before its inner serializer, which
// decodes the transformation prefix, decrypts and decompresses, and passes a
// bare union message through. Every store reads through it, decrypting with its
// own serializer's key manager; a store that writes with none reads every
// prefix but cannot decrypt.
func (store *FDBRecordStore) readStoredRecord(stored []byte) ([]byte, error) {
	reader := store.serializer
	if reader == nil {
		reader = plainTransformedReader
	}
	out, err := reader.untransform(stored)
	if err != nil {
		var rse *RecordSerializationError
		if errors.As(err, &rse) && rse.RetryResult == "success" && store.metaData != nil {
			rse.MetaDataVersion = store.metaData.Version()
		}
	}
	return out, err
}

// writeStoredRecord is the bytes a record's union message is stored as: the
// store's serializer's transformation, or the union message itself. A failed
// write-time validation names the record, as Java's
// RecordSerializationValidationException does.
func (store *FDBRecordStore) writeStoredRecord(union []byte, recordType *RecordType, primaryKey tuple.Tuple) ([]byte, error) {
	if store.serializer == nil {
		return union, nil
	}
	// The serialization validation deserializes what it reads back as this
	// store reads a record (Java's inner serializer).
	read := func(b []byte) (proto.Message, error) {
		_, msg, _, err := store.discoverUnion(b)
		return msg, err
	}
	stored, err := store.serializer.transformRead(union, store.Env(), read)
	var ve *RecordSerializationValidationError
	if errors.As(err, &ve) {
		ve.RecordType = recordType.Name
		ve.PrimaryKey = primaryKey
	}
	return stored, err
}

// deserializeAndDiscover reads the union wire format tag to discover the record type,
// then unmarshals the inner bytes directly into the concrete message type.
// Skips allocating/parsing a full UnionDescriptor. The returned wire keeps the
// inner bytes when the type reaches a map field (record_wire_map_order.go); a
// FDBStoredRecord built from the message carries it. data is the stored bytes,
// which readStoredRecord decodes first.
func (store *FDBRecordStore) deserializeAndDiscover(data []byte) (*RecordType, proto.Message, *recordWire, error) {
	data, err := store.readStoredRecord(data)
	if err != nil {
		return nil, nil, nil, err
	}
	return store.discoverUnion(data)
}

// discoverUnion is deserializeAndDiscover over a union message's bytes, the
// transformation already undone: the record they hold, its type and wire.
// It is Java's DynamicMessageRecordSerializer.deserializeUnion: the union must
// hold exactly one known field and no unknown one, else "Could not deserialize
// union message because there are unknown fields" (or "extra known fields",
// or "no fields"). A field the bytes repeat is one field, its occurrences
// merged, as protobuf parses them (a message field's occurrences concatenate).
func (store *FDBRecordStore) discoverUnion(data []byte) (*RecordType, proto.Message, *recordWire, error) {
	var (
		rt      *RecordType
		field   protowire.Number
		inner   []byte
		repeats bool
		known   int
		unknown int
	)
	remaining := data
	for len(remaining) > 0 {
		fieldNum, wireType, n := protowire.ConsumeTag(remaining)
		if n < 0 {
			return nil, nil, nil, fmt.Errorf("failed to read union tag")
		}
		remaining = remaining[n:]
		if t := store.metaData.fieldNumberToRecordType[fieldNum]; t != nil && wireType == protowire.BytesType {
			b, m := protowire.ConsumeBytes(remaining)
			if m < 0 {
				return nil, nil, nil, fmt.Errorf("failed to read field %d bytes", fieldNum)
			}
			remaining = remaining[m:]
			switch {
			case rt == nil:
				rt, field, inner, known = t, fieldNum, b, 1
			case fieldNum == field:
				// A repeated occurrence merges into the first.
				if !repeats {
					inner = append([]byte(nil), inner...)
					repeats = true
				}
				inner = append(inner, b...)
			default:
				known++
			}
			continue
		}
		// A field the union does not declare, or one whose wire type does
		// not match its declaration, which protobuf keeps as unknown.
		m := protowire.ConsumeFieldValue(fieldNum, wireType, remaining)
		if m < 0 {
			return nil, nil, nil, fmt.Errorf("failed to skip field %d", fieldNum)
		}
		remaining = remaining[m:]
		unknown++
	}
	switch {
	case unknown > 0:
		return nil, nil, nil, serializationError("Could not deserialize union message because there are unknown fields")
	case known > 1:
		return nil, nil, nil, serializationError("Could not deserialize union message because there are extra known fields")
	case rt == nil:
		return nil, nil, nil, serializationError("Could not deserialize union message because there are no fields")
	}
	msg, err := rt.unmarshalRecord(inner)
	if err != nil {
		return nil, nil, nil, fmt.Errorf("failed to unmarshal %s: %w", rt.Name, err)
	}
	return rt, msg, newRecordWire(rt, inner), nil
}

// priorRecordInner is the record bytes a save writes its maps over: the
// existing record's, as its decode found them (deserializeAndDiscover, which
// keeps them as the record's wire when its type reaches a map field), when the
// record is of the type being saved; nil otherwise, for which a save writes
// its maps in key order. It reads the decode every write path has already
// done, so the stored bytes are decrypted once.
func priorRecordInner(oldRT *RecordType, oldWire *recordWire, recordType *RecordType) []byte {
	if oldWire == nil || oldRT != recordType {
		return nil
	}
	return oldWire.bytes
}

// unionInner is the inner bytes of the union field numbered field in data, nil
// when data is nil or holds no such field.
func unionInner(data []byte, field protowire.Number) []byte {
	for len(data) > 0 {
		num, typ, n := protowire.ConsumeTag(data)
		if n < 0 {
			return nil
		}
		data = data[n:]
		if num == field && typ == protowire.BytesType {
			inner, m := protowire.ConsumeBytes(data)
			if m < 0 {
				return nil
			}
			return inner
		}
		m := protowire.ConsumeFieldValue(num, typ, data)
		if m < 0 {
			return nil
		}
		data = data[m:]
	}
	return nil
}

// deserializeRecord unmarshals the inner bytes of a union-wrapped record directly
// into the known record type, skipping UnionDescriptor allocation.
func (store *FDBRecordStore) deserializeRecord(data []byte, recordType *RecordType) (proto.Message, error) {
	if recordType.unionFieldNumber == 0 {
		return nil, fmt.Errorf("no union field number for record type: %s", recordType.Name)
	}
	rt, msg, _, err := store.deserializeAndDiscover(data)
	if err != nil {
		return nil, err
	}
	if rt != recordType {
		return nil, fmt.Errorf("union descriptor does not contain %s record", recordType.Name)
	}
	return msg, nil
}

// GetIndexMaintenanceFilter is Java's FDBRecordStore.getIndexMaintenanceFilter.
func (store *FDBRecordStore) GetIndexMaintenanceFilter() IndexMaintenanceFilter {
	return store.indexMaintenanceFilter()
}

func (store *FDBRecordStore) indexMaintenanceFilter() IndexMaintenanceFilter {
	if store == nil || store.maintenanceFilter == nil {
		return IndexMaintenanceFilterNormal
	}
	return store.maintenanceFilter
}
