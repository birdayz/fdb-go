// Portions derived from FoundationDB Record Layer (VersionIndexMaintainer.java,
// IndexTest.java, StandardIndexMaintainer.java, IndexScanType.java),
// Copyright 2015-2018 Apple Inc. and the FoundationDB project authors
// Copyright 2015-2026 Apple Inc. and the FoundationDB project authors
// Copyright 2021-2025 Apple Inc. and the FoundationDB project authors
// Licensed under the Apache License, Version 2.0; translated to Go and modified.

package recordlayer

import (
	"fmt"

	"fdb.dev/pkg/fdbgo/fdb"
	"fdb.dev/pkg/fdbgo/fdb/subspace"
	"fdb.dev/pkg/fdbgo/fdb/tuple"
	"google.golang.org/protobuf/proto"
)

// versionIndexMaintainer handles VERSION index maintenance.
// VERSION indexes store the record's commit version (Versionstamp) in the index key,
// enabling efficient queries by version ordering.
//
// Key difference from standardIndexMaintainer: when the entry key contains an
// incomplete versionstamp (record being saved in this transaction), the entry
// is written via SET_VERSIONSTAMPED_KEY mutation instead of a regular set.
//
// Matches Java's com.apple.foundationdb.record.provider.foundationdb.indexes.VersionIndexMaintainer.
type versionIndexMaintainer struct {
	index         *Index
	indexSubspace subspace.Subspace
	tx            fdb.WritableTransaction
	recordContext *FDBRecordContext
	store         IndexStoreContext
}

func newVersionIndexMaintainer(index *Index, indexSubspace subspace.Subspace, tx fdb.WritableTransaction, recordContext *FDBRecordContext, store IndexStoreContext) *versionIndexMaintainer {
	return &versionIndexMaintainer{
		index:         index,
		indexSubspace: indexSubspace,
		tx:            tx,
		recordContext: recordContext,
		store:         store,
	}
}

// UpdateWhileWriteOnly delegates to Update. VERSION indexes are idempotent.
func (m *versionIndexMaintainer) UpdateWhileWriteOnly(oldRecord, newRecord *FDBStoredRecord[proto.Message]) error {
	return m.Update(oldRecord, newRecord)
}

// Update handles insert (old=nil), delete (new=nil), or update (both non-nil).
// Note: uniqueness is validated at Build() time in metadata validation, so no
// runtime check is needed here.
func (m *versionIndexMaintainer) Update(oldRecord, newRecord *FDBStoredRecord[proto.Message]) error {
	var oldEntries []EvaluatedIndexEntry
	var newEntries []EvaluatedIndexEntry

	if oldRecord != nil {
		entries, err := m.FilteredIndexEntries(oldRecord)
		if err != nil {
			return fmt.Errorf("evaluate version index %q for old record: %w", m.index.Name, err)
		}
		oldEntries = entries
	}

	if newRecord != nil {
		entries, err := m.FilteredIndexEntries(newRecord)
		if err != nil {
			return fmt.Errorf("evaluate version index %q for new record: %w", m.index.Name, err)
		}
		newEntries = entries
	}

	// Skip removeCommonEntries because tuple.Pack panics on incomplete versionstamps.
	// Reusing a supplied complete version can still produce common entries.

	// Remove old entries
	for i := range oldEntries {
		entryTupleKey, err := indexEntryKey(m.index, oldEntries[i].key, oldEntries[i].primaryKey)
		if err != nil {
			return err
		}
		hasIncomplete := tupleHasIncompleteVersionstamp(entryTupleKey)
		if hasIncomplete {
			keyBytes, err := m.indexSubspace.PackWithVersionstamp(entryTupleKey)
			if err != nil {
				return fmt.Errorf("packWithVersionstamp for delete on index %q: %w", m.index.Name, err)
			}
			m.recordContext.RemoveVersionMutation(keyBytes)
		} else {
			keyBytes := m.indexSubspace.Pack(entryTupleKey)
			m.tx.ClearBytes(keyBytes)
		}
	}

	// Add new entries
	emptyValue := tuple.Tuple{}.Pack()
	for i := range newEntries {
		entryTupleKey, err := indexEntryKey(m.index, newEntries[i].key, newEntries[i].primaryKey)
		if err != nil {
			return err
		}
		hasIncomplete := tupleHasIncompleteVersionstamp(entryTupleKey)

		// For KeyWithValueExpression indexes, store the value portion in the FDB value.
		valueBytes := emptyValue
		if newEntries[i].value != nil {
			// The VALUE portion is always a vanilla pack — the versionstamp
			// mutation substitutes into the KEY only, so an incomplete
			// versionstamp here has nothing that could ever complete it. Java
			// reaches the same dead end (VersionIndexMaintainer.java:107 calls
			// value.pack() after testing only the entry KEY for incompleteness,
			// :90) and throws from Tuple.pack; Go's tuple.Pack panics, so the
			// condition is tested here and returned as Java's exception.
			//
			// The shape is `keyWithValue(concat(..., version, ...), split)` with
			// the split BEFORE the version — which Java's index generator emits
			// and Java's own DDL tests pin (IndexTest.java:897-905
			// createVersionIndexWithVersionInValue). The metadata is therefore
			// not the thing to change; only the crash is.
			if tupleHasIncompleteVersionstamp(newEntries[i].value) {
				return &IncompleteVersionstampError{
					Context: fmt.Sprintf("index %q: version column lies in the value portion of the key-with-value split", m.index.Name),
				}
			}
			valueBytes = newEntries[i].value.Pack()
		}

		if hasIncomplete {
			keyBytes, err := m.indexSubspace.PackWithVersionstamp(entryTupleKey)
			if err != nil {
				return fmt.Errorf("packWithVersionstamp for insert on index %q: %w", m.index.Name, err)
			}
			if err := checkKeyValueSizes(m.index, newEntries[i].primaryKey, keyBytes, valueBytes); err != nil {
				return err
			}
			m.recordContext.AddVersionMutation(MutationTypeSetVersionstampedKey, keyBytes, valueBytes)
		} else {
			keyBytes := m.indexSubspace.Pack(entryTupleKey)
			if err := checkKeyValueSizes(m.index, newEntries[i].primaryKey, keyBytes, valueBytes); err != nil {
				return err
			}
			m.tx.SetBytes(keyBytes, valueBytes)
		}
	}

	return nil
}

// Scan scans index entries within the given tuple range.
// VERSION indexes only support BY_VALUE scanning (same cursor as standardIndexMaintainer).
// Scan type validation (rejecting BY_RANK etc.) is handled at the store level in
// ScanIndexByType, which checks the maintainer type before dispatching. Java's
// VersionIndexMaintainer.scan(IndexScanType, ...) throws if scanType != BY_VALUE.
func (m *versionIndexMaintainer) Scan(scanRange TupleRange, continuation []byte, scanProperties ScanProperties) RecordCursor[*IndexEntry] {
	return newIndexCursor(m.index, m.indexSubspace, m.tx, scanRange, continuation, scanProperties).withContext(m.recordContext)
}

// CanDeleteWhere bounds the prefix by the index's matchable width. VERSION
// entries are a plain B-tree with no secondary structure, so the root's own
// columns are the bound.
func (m *versionIndexMaintainer) CanDeleteWhere(prefix tuple.Tuple) error {
	return checkDeleteWhereBound(m.index, prefix)
}

// DeleteWhere clears all index entries whose key starts with the given prefix.
func (m *versionIndexMaintainer) DeleteWhere(prefix tuple.Tuple) error {
	// Backstop for direct callers; DeleteRecordsWhere asks CanDeleteWhere BEFORE
	// it clears anything.
	if err := m.CanDeleteWhere(prefix); err != nil {
		return err
	}
	return deleteWhereRange(m.tx, m.indexSubspace, prefix)
}

// FilteredIndexEntries is Java's StandardIndexMaintainer.filteredIndexEntries
// over the version index's evaluated entries (see standardIndexMaintainer's).
func (m *versionIndexMaintainer) FilteredIndexEntries(record *FDBStoredRecord[proto.Message]) ([]EvaluatedIndexEntry, error) {
	values := indexValuesFor(m.store, m.index, record)
	if values == IndexValuesNone {
		return nil, nil
	}

	tuples, err := m.index.RootExpression.Evaluate(record, record.Record)
	if err != nil {
		return nil, err
	}

	kwv, isKeyWithValue := m.index.RootExpression.(*KeyWithValueExpression)
	entries := make([]EvaluatedIndexEntry, len(tuples))
	for i, values := range tuples {
		if isKeyWithValue {
			keyPart, valuePart := kwv.SplitEvaluatedKey(values)
			key := make(tuple.Tuple, len(keyPart))
			for j, v := range keyPart {
				key[j] = v
			}
			val := make(tuple.Tuple, len(valuePart))
			for j, v := range valuePart {
				val[j] = v
			}
			entries[i] = EvaluatedIndexEntry{key: key, primaryKey: record.PrimaryKey, value: val}
		} else {
			key := make(tuple.Tuple, len(values))
			for j, v := range values {
				key[j] = v
			}
			entries[i] = EvaluatedIndexEntry{key: key, primaryKey: record.PrimaryKey}
		}
	}

	return keepMaintainedEntries(m.store, m.index, record, values, entries), nil
}

// tupleHasIncompleteVersionstamp checks if any element in the tuple is an
// incomplete Versionstamp (TransactionVersion all 0xFF).
// Matches Java's Tuple.hasIncompleteVersionstamp().
func tupleHasIncompleteVersionstamp(t tuple.Tuple) bool {
	for _, elem := range t {
		if vs, ok := elem.(tuple.Versionstamp); ok {
			allFF := true
			for _, b := range vs.TransactionVersion {
				if b != 0xFF {
					allFF = false
					break
				}
			}
			if allFF {
				return true
			}
		}
	}
	return false
}
