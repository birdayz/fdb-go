set -u
emit() {
  local f=$1
  printf '\n=== FILE %s ===\n' "$f"
  if [[ -r "$f" ]]; then
    cat -- "$f" || printf 'READ_ERROR file=%s\n' "$f"
  else
    printf 'MISSING_OR_UNREADABLE file=%s\n' "$f"
  fi
}
printf 'CONTAINER_UTC='; date -u +%FT%TZ
printf 'COLLECTOR_UID=%s\n' "$EUID"
emit /proc/uptime
emit /proc/self/cgroup
for proc in /proc/[0-9]*; do
  [[ -r "$proc/comm" ]] || continue
  comm=
  read -r comm < "$proc/comm" || continue
  [[ "$comm" == fdbserver ]] || continue
  pid=${proc##*/}
  stat_line=$(cat -- "$proc/stat" 2>/dev/null) || { printf 'PID_STAT_READ_ERROR pid=%s\n' "$pid"; continue; }
  # fdbserver comm contains no spaces; stat field22 is starttime since boot.
  read -r -a fields <<< "$stat_line"
  printf '\nSERVER_ID=%s:%s\n' "$pid" "${fields[21]:-MISSING}"
  printf '=== FILE %s/stat ===\n%s\n' "$proc" "$stat_line"
  emit "$proc/io"
  emit "$proc/schedstat"
  emit "$proc/status"
done
# Docker's private cgroup namespace normally presents its own cgroup at root.
# Preserve membership/mounts; if this is not true, do NOT silently sample host root.
cg_path=$(awk -F: '$1 == "0" {print $3}' /proc/self/cgroup)
if [[ "$cg_path" == / && -f /sys/fs/cgroup/cgroup.controllers ]]; then
  printf '\nCGROUP_V2_ROOT_VERIFIED=1\n'
  for f in io.stat io.pressure cpu.stat cpu.pressure memory.current memory.stat memory.events memory.pressure; do
    emit "/sys/fs/cgroup/$f"
  done
else
  printf '\nCGROUP_V2_ROOT_UNRESOLVED path=%s; no counters substituted\n' "$cg_path"
fi
