#!/usr/bin/env bash
set -Eeuo pipefail
# PREPARED ONLY. Root invokes explicitly; Docker inspect/exec are READ ONLY.
# Never fdbcli, stop/start, database access, ptrace, flags, knobs or capabilities.
readonly runtime=/tmp/fdb-hotelbench.VxNArC
readonly session=resume-20261027-05
readonly owner=otel283-vxnar profile=fdb4-4cpu-16g-v1
readonly policy="$runtime/fdb4-config-rw1m0286"
[[ ${FDB_IO_READONLY_APPROVED:-} == yes ]] || { echo 'Explicit root read-only collector approval required' >&2; exit 1; }
: "${FDB_IO_INSTANCE:?Supply exact new session05 64-hex instance ID}"
: "${FDB_IO_OUTPUT:?Supply a NEW /tmp/fdb-hotelbench.VxNArC/io-observations-rw1m0286.UNIQUE path}"
: "${FDB_IO_SECONDS:?Supply bounded duration 15..2700 seconds}"
: "${FDB_IO_INTERVAL:?Supply exactly 5 or 10 seconds}"
[[ "$FDB_IO_INSTANCE" =~ ^[0-9a-f]{64}$ ]] || exit 1
[[ "$FDB_IO_OUTPUT" =~ ^/tmp/fdb-hotelbench\.VxNArC/io-observations-rw1m0286\.[a-zA-Z0-9_-]+$ ]] || exit 1
[[ "$FDB_IO_SECONDS" =~ ^[1-9][0-9]{0,3}$ ]] && (( FDB_IO_SECONDS >= 15 && FDB_IO_SECONDS <= 2700 )) || exit 1
[[ "$FDB_IO_INTERVAL" == 5 || "$FDB_IO_INTERVAL" == 10 ]] || exit 1
[[ $(cat "$policy/sessions/$session/instance.id") == "$FDB_IO_INSTANCE" ]] || { echo 'Session instance pin mismatch' >&2; exit 1; }
[[ ! -e "$FDB_IO_OUTPUT" ]] || { echo 'Refusing existing evidence path' >&2; exit 1; }
for tool in docker timeout sha256sum awk grep sort; do command -v "$tool" >/dev/null; done
readonly instance=$FDB_IO_INSTANCE out=$FDB_IO_OUTPUT interval=$FDB_IO_INTERVAL
readonly duration=$FDB_IO_SECONDS
mkdir "$out"
cp -- "$0" "$out/collector.source.sh"
sha256sum "$out/collector.source.sh" > "$out/collector.source.sha256"
printf 'instance=%s\nsession=%s\nowner=%s\nprofile=%s\nrun=rw1m0286\ninterval_seconds=%s\nduration_seconds=%s\nexec_user=fdb\nmode=readonly_proc_cgroup_no_db\n' \
  "$instance" "$session" "$owner" "$profile" "$interval" "$duration" > "$out/contract.txt"
readonly started=$SECONDS deadline=$((SECONDS + duration))
trap 'rc=$?; printf "%s exit=%s elapsed=%s\n" "$(date -u +%FT%TZ)" "$rc" "$((SECONDS-started))" > "$out/collector.ended"' EXIT
identity() {
  timeout --kill-after=1s 4s docker inspect --format '{{.Id}} {{.Name}} {{.State.Running}} {{.State.Paused}} {{.State.Restarting}} {{.RestartCount}} {{index .Config.Labels "otel283.owner"}} {{index .Config.Labels "otel283.profile"}} {{index .Config.Labels "otel283.session"}}' "$instance"
}
readonly expected="$instance /otel283-fdb4-vxnar true false false 0 $owner $profile $session"
initial=$(identity 2> "$out/initial.identity.stderr") || { echo 'Initial identity read failed' >&2; exit 3; }
printf '%s\n' "$initial" > "$out/initial.identity"
[[ "$initial" == "$expected" ]] || { echo 'Initial identity mismatch; no exec performed' >&2; exit 3; }
# Reading as fdb matches server UID for /proc/PID/io access. No cap additions.
read -r -d '' payload <<'PAYLOAD' || true
set -u
emit() {
  local f=$1
  printf '\n=== FILE %s ===\n' "$f"
  if [[ -r "$f" ]]; then
    cat -- "$f" || printf 'READ_ERROR file=%s\n' "$f"
  else
    printf 'MISSING_OR_UNREADABLE file=%s\n' "$f"
  fi
}
printf 'CONTAINER_UTC='; date -u +%FT%TZ
printf 'COLLECTOR_UID=%s\n' "$EUID"
emit /proc/uptime
emit /proc/self/cgroup
for proc in /proc/[0-9]*; do
  [[ -r "$proc/comm" ]] || continue
  comm=
  read -r comm < "$proc/comm" || continue
  [[ "$comm" == fdbserver ]] || continue
  pid=${proc##*/}
  stat_line=$(cat -- "$proc/stat" 2>/dev/null) || { printf 'PID_STAT_READ_ERROR pid=%s\n' "$pid"; continue; }
  # fdbserver comm contains no spaces; stat field22 is starttime since boot.
  read -r -a fields <<< "$stat_line"
  printf '\nSERVER_ID=%s:%s\n' "$pid" "${fields[21]:-MISSING}"
  printf '=== FILE %s/stat ===\n%s\n' "$proc" "$stat_line"
  emit "$proc/io"
  emit "$proc/schedstat"
  emit "$proc/status"
done
# Docker's private cgroup namespace normally presents its own cgroup at root.
# Preserve membership/mounts; if this is not true, do NOT silently sample host root.
cg_path=$(awk -F: '$1 == "0" {print $3}' /proc/self/cgroup)
if [[ "$cg_path" == / && -f /sys/fs/cgroup/cgroup.controllers ]]; then
  printf '\nCGROUP_V2_ROOT_VERIFIED=1\n'
  for f in io.stat io.pressure cpu.stat cpu.pressure memory.current memory.stat memory.events memory.pressure; do
    emit "/sys/fs/cgroup/$f"
  done
else
  printf '\nCGROUP_V2_ROOT_UNRESOLVED path=%s; no counters substituted\n' "$cg_path"
fi
PAYLOAD
printf '%s\n' "$payload" > "$out/exec-payload.sh"
# One provenance mountinfo snapshot; no flags/mount operations or DB access.
printf '%s\n' "docker exec --user fdb INSTANCE /bin/bash -c 'cat /proc/self/mountinfo'" > "$out/mountinfo.command"
timeout --kill-after=1s 4s docker exec --user fdb "$instance" /bin/bash -c 'cat /proc/self/mountinfo' \
  > "$out/container.mountinfo" 2> "$out/mountinfo.stderr" || { echo 'Initial mountinfo read failed' >&2; exit 2; }
sample=0
baseline=
while (( SECONDS < deadline )); do
  # Reserve the bounded inspect kill grace before beginning another sample.
  (( deadline - SECONDS >= 6 )) || break
  tick=$SECONDS
  sample=$((sample + 1))
  printf -v prefix '%s/sample-%06d' "$out" "$sample"
  printf 'host_utc=%s\nelapsed_seconds=%s\n' "$(date -u +%FT%TZ)" "$((SECONDS-started))" > "$prefix.time"
  current=$(identity 2> "$prefix.identity.stderr") || { echo 'Identity read failed; collector exits without service action' >&2; exit 3; }
  printf '%s\n' "$current" > "$prefix.identity"
  [[ "$current" == "$expected" ]] || { echo 'Instance stopped/identity changed; collector exits without service action' >&2; exit 3; }
  remaining=$((deadline - SECONDS))
  (( remaining > 1 )) || break
  budget=4
  (( remaining > budget )) || budget=$((remaining - 1))
  printf '%s\n' "timeout --kill-after=1s ${budget}s docker exec --user fdb $instance /bin/bash -c PAYLOAD_FROM_exec-payload.sh" > "$prefix.command"
  rc=0
  timeout --kill-after=1s "${budget}s" docker exec --user fdb "$instance" /bin/bash -c "$payload" \
    > "$prefix.stdout" 2> "$prefix.stderr" || rc=$?
  printf '%s\n' "$rc" > "$prefix.exit"
  (( rc == 0 )) || { echo 'Bounded exec read failed; raw retained, no retry/job/service action' >&2; exit 4; }
  ids=$(grep '^SERVER_ID=' "$prefix.stdout" | sort) || { echo 'No server identity census' >&2; exit 5; }
  [[ $(printf '%s\n' "$ids" | wc -l) == 4 && "$ids" != *MISSING* ]] || { echo 'Expected four fdbserver PID/starttime identities' >&2; exit 5; }
  if [[ -z "$baseline" ]]; then
    baseline=$ids
    printf '%s\n' "$baseline" > "$out/server-identity-baseline.txt"
  fi
  [[ "$ids" == "$baseline" ]] || { echo 'Server PID/starttime population changed; raw retained' >&2; exit 5; }
  grep -E 'MISSING_OR_UNREADABLE|READ_ERROR|UNRESOLVED' "$prefix.stdout" > "$prefix.accounting-warnings" || true
  # Preserve partial or unavailable observations as such; NEVER default them to 0.
  wait_seconds=$((tick + interval - SECONDS))
  remaining=$((deadline - SECONDS))
  (( wait_seconds <= remaining )) || wait_seconds=$remaining
  if (( wait_seconds > 0 )); then sleep "$wait_seconds"; fi
done
printf 'samples=%s\n' "$sample" > "$out/completed.txt"
