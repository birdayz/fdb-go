docker exec --user fdb INSTANCE /bin/bash -c 'cat /proc/self/mountinfo'
