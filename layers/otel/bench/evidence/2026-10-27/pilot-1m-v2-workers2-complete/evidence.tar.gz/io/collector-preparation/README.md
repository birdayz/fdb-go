# Prepared read-only proc/cgroup collector — run286/session05

NOT EXECUTED. Root invokes only alongside its independently authorized load. No FDBCLI/database probes, service stop/start/restart, installation, ptrace, filesystem/capability changes, workload, query or audit. Source syntax validation only (`bash -n`) passed.

Example root-only tracked job (replace instance/output and choose bounded remaining duration):

```sh
FDB_IO_READONLY_APPROVED=yes \
FDB_IO_INSTANCE=EXACT_NEW_SESSION05_64_HEX_INSTANCE \
FDB_IO_OUTPUT=/tmp/fdb-hotelbench.VxNArC/io-observations-rw1m0286.UNIQUE \
FDB_IO_SECONDS=2400 FDB_IO_INTERVAL=10 \
bash /tmp/fdb-hotelbench.VxNArC/io-collector-rw1m0286/collect.sh
```

Duration15..2700s; interval exactly5or10s. Choose duration no longer than the remaining bulk phase and root's external job lifetime. Each inspect/exec has4s timeout+1s kill grace; the loop reserves remaining deadline/grace before starting calls. Process scheduling/termination is not a hard-real-time guarantee. Root may additionally set the tracked job's wall timeout. No detached shell jobs or automatic retries/restarts.

Exact required instance must match NEXTpolicy session05/instance.id, owner/profile/session/container-name labels, running/notpaused/notrestarting, RestartCount0. Identity is checked before initial exec and before every sample. Output path must be NEW and owned runtime namespace. Any identity loss, timeout, missing/fewer/more than four servers or PID/starttime change exits without touching services. A stopping monitor/container therefore stops collection naturally; source/runtime receipts and partial output remain.

Reads run as existing image user `fdb`, matching the server UID for /proc/PID/io access, without adding capabilities. If permissions differ, missing/unreadable/io errors remain explicit raw warnings; no zero fill and no privilege escalation. Captures four servers' io/stat/schedstat/status, PID/starttime baseline, uptime, raw membership/mountinfo and cgroupv2 io.stat/io.pressure/cpu.stat/cpu.pressure/memory.current/stat/events/pressure. Counter sampling only uses /sys/fs/cgroup root when membership is `/` and cgroup.controllers exists; otherwise unresolved is recorded, never silently sampling host root. No actual FS/lsattr probe occurs in this sampler.

Every tick retains host time, exact identity result, exec command/payload, stdout/stderr/exit, accounting warnings. Source copy/hash and contract retained. Counter deltas must account for interval/PID identity and permission errors. stat CPU ticks need correct CLK_TCK; io byte counters are not all equivalent to physical-device throughput. PSI/sync trace correlation is evidence, not proof of one hardware cause. Default-priority status probes remain separate monitor evidence, not workload SLOs.

Use existing native trace output for AsyncFileKAIORead/Write/SyncLatency, StorageMetrics/fetch/DD/RedwoodMetrics/SlowTask; do not enable new tracing knobs. Read-only parent/child du must be separate invocations in the root driver; this script does not run du.
