# Prepared NEXT policy: rw1m0286 / session05

PREPARE ONLY. This isolated tree is not launched or authorized to launch. Root alone may approve capacity, resume the stopped owned container, mark readiness, declare the bounded phase and start a workload. Current OLD tree `/tmp/fdb-hotelbench.VxNArC/fdb4-config-rw1m0285` and session04 evidence remain unchanged. Run rw1m0285 was stopped by the frozen six-sample combined queue/lag gate at17:30:48Z; the loader then failed1031 after284544 ACK/167.996s. The stopped container exited0 with OOMKilled=false. Neither partial population is reused as a successful load.

## Exact identities and unchanged profile

- NEXT run: `rw1m0286`; exact NEXT session: `resume-20261027-05`.
- Container: `otel283-fdb4-vxnar`; existing owned volume: `otel283-vxnar-fdb4-redwood16-v1`.
- Owner/profile: `otel283-vxnar` / `fdb4-4cpu-16g-v1`.
- Image: `foundationdb/foundationdb@sha256:559b178a137bbe09272ad6e3752531aa04e2ddacab8ccfa4ffa86467db033bea` (7.3.77).
- 4CPU/16GiB cgroup, no extra swap; four4GiB server RSS ceilings; ports14683–14686 loopback, same process classes/cache/queue knobs/locality, single redundancy, NOT HA.
- Config hash `6b2b4e0e85fba430d99ea8710778c6776a95326246ae6e45109192327e242b1f`; seed hash `88eea690f206eac6e9d532cadc882fe4945da0c4aa0f6d6eb55e5ee1615eed3e`; cluster `otel4:otel4@127.0.0.1:14683`.

`resume.sh` checks the stopped predecessor's read-only `/etc/fdb4` bind source against literal PINNED OLD `/tmp/fdb-hotelbench.VxNArC/fdb4-config-rw1m0285`, never against NEXT here. Only the new replacement binds this NEXT directory. Existing checks retain owner/profile/image/resource/volume identity, stopped/not-paused/not-restarting state, no active volume mounts, exact cluster seed/owner marker and all four nonempty processId files. It captures receipts before metadata removal; `docker rm` has no force/volume flags. No volume initialization/adoption/deletion or `configure` is permitted. Normal resume recovery is writable; it is not read-only forensics.

Original launch/bootstrap receipts copied here are historical proof only; they are never executed. `launch.sh` and `container-entrypoint.sh` remain historical fresh-empty-volume-only helpers and MUST NOT be used on this existing volume. Never run `configure new` on the retained volume.

## Future root-only sequence (not executed)

Use only after root verifies the unchanged frozen application source revision `c7d00bf938edc6cb9a84df4c63b3bbd3ac22dc94`, binary `/tmp/fdb-hotelbench.VxNArC/otelbench-timeout-reference` SHA256 `e3d5f167aba6c671d31cd278dc16414dcdb784bb36a5f3a516d893f0668f762c`, source/input manifests, formal review, new validation and explicit capacity approval. The future driver changes ONLY source workers from4to2: count1000000, batch32, attributes8, tenants1, seed283, time order, save-mode batch, diagnostics on, 30m load timeout, 2700s bulk phase; full strict drain/audit/1600 checks retained. No server or guard change. Run namespace becomes rw1m0286; source remains frozen. This policy preparation does not start or create a workload driver.

1. Root verifies the owned session04 instance/monitor is stopped and retains all receipts; no stop action is performed by this preparation.
2. Tracked foreground-attached resume: `FDB4_SESSION=resume-20261027-05 FDB4_RESUME_APPROVED=yes FDB4_CAPACITY_GATE_APPROVED=yes FDB4_16G_APPROVED=yes bash /tmp/fdb-hotelbench.VxNArC/fdb4-config-rw1m0286/resume.sh`. Resume requires24GiB host available and200GiB disk free.
3. Root starts NEXT `monitor.sh` with exact session05, queue536870912B/lag60s/disk214748364800B. It pins exact new instance/PIDs. Startup checks resource/PID only; readiness then requires three strict samples.
4. Root explicitly invokes NEXT `readiness.sh` with `FDB4_MARK_READY_APPROVED=yes`, same session05. It preserves raw admin responses and requires three consecutive strict samples>=5s apart with queue<16MiB and lag<10s. No load before root inspects readiness proof.
5. Root invokes NEXT `declare-bulk.sh` with `FDB4_DECLARE_BULK_APPROVED=yes`, same session05, actual `FDB4_SOURCE_REVISION`40hex, `FDB4_BINARY`, `FDB4_SOURCE_MANIFEST`, and explicit `FDB4_BULK_SECONDS`1..3600. Real files are hashed. Exact run286 is generated, metadata/pin immutable; wait for exact instance/session/phase-hash monitor ACK before any ingestion. No multiple phases, wildcard runs, extensions or reused session.
6. After load terminates, root finalizes outcome receipt and invokes NEXT `drain.sh` with same session05, `FDB4_CERTIFY_DRAIN_APPROVED=yes`, `FDB4_LOAD_RECEIPT` absolute finalized receipt path. Three strict retained samples certify drain before marker completion/removal. Certificate is NOT successful ingestion/population/audit/rate evidence. No workload or audit is started automatically.

## Frozen policy and safety gates

Strict filter requires availability/quorum/current clusterfile, aggregate health true/no messages, explicit datahealthy/fully_recovered/degraded0, exact engine/log engine/counts/roles/locality/limits, empty client/process/configuration issues, finite nonnegative required default/immediateGRV/read/commit probes<5s and typed queue/lag/memory. Missing health never defaults true. Status and phase filters fatally reject multiple JSON root documents.

Only valid bounded run286/session05 phase permits sole exact `batch_priority_transaction_start_probe_timeout`, aggregate health explicitlyfalse and no contradictory successful batch probe. Summary preserves original health/exception/warning. Other warnings/failures abort. Probe read/commit priority is SYSTEM_IMMEDIATE, not a normal workload SLO proof. Deadline is checked before AND after status requests. Source revision/binary/manifest and full phase digest remain pinned.

Unchanged monitor gates: host available>=8GiB; disk>=200GiB (or reviewedhigher); cgroup<90%of16GiB; noOOM/restarts/PID changes; queue>512MiB AND lag>60s for six consecutive nominal10s valid samples abort. Monitor abort may stop only its exact labeled instance. Do not relax gates or raise server ceilings. Linux memory.used_bytes is virtual size, not RSS.

Pure `verify-drain.sh` requires exact run/session/source/phase digest/deadline, three strict lowqueue/lag raws>=5s apart and load receipt hash. Raw paths must be distinct canonical existing regular files, exact six-digit status basenames, directly inside one canonical drain-raw child. Traversal/symlink aliases rejected; equal content hashes allowed. Valid certificate returns monitor to strict even if active marker remains; removal/change of certificate fails closed.

## Future physical size sampling

The future root driver must issue parent and children in SEPARATE read-only `du` invocations: one invocation for `/var/fdb/data`, another for individual `/var/fdb/data/processes/PORT` and trace directories. Do not pass parent first together with children: du deduplication suppresses child totals. Retain each command/output/time separately; do not retroactively rewrite old boundary outputs. No du command, driver, DB read or service operation was executed while preparing this tree.

`bulk-policy-prepared.sha256` freezes the14policy files; `bootstrap-receipts.sha256` separately pins the three copied historical receipts. Independent complete pure-file validation receipts live outside the policy tree. Static validation is not service launch, live readiness, a real drain or performance verification.
