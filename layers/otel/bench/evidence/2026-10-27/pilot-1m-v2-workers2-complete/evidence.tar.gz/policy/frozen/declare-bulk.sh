#!/usr/bin/env bash
set -Eeuo pipefail
# Explicit ROOT policy declaration only; does not start ingestion or touch FDB.
readonly here=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
: "${FDB4_SESSION:?Use the new resume session}"
: "${FDB4_SOURCE_REVISION:?Supply frozen 40-hex source revision}"
: "${FDB4_BINARY:?Supply the exact frozen workload binary file}"
: "${FDB4_SOURCE_MANIFEST:?Supply the frozen source/input manifest file}"
: "${FDB4_BULK_SECONDS:?Supply explicit bounded duration, at most 3600 seconds}"
[[ ${FDB4_DECLARE_BULK_APPROVED:-} == yes ]] || exit 1
[[ "$FDB4_SESSION" == resume-20261027-05 && "$FDB4_SOURCE_REVISION" =~ ^[0-9a-f]{40}$ ]] || exit 1
[[ "$FDB4_BULK_SECONDS" =~ ^[1-9][0-9]*$ ]] && (( FDB4_BULK_SECONDS <= 3600 )) || exit 1
[[ -f "$FDB4_BINARY" && -f "$FDB4_SOURCE_MANIFEST" ]] || exit 1
readonly run_dir="$here/sessions/$FDB4_SESSION"
readonly instance=$(cat "$run_dir/instance.id")
[[ "$instance" =~ ^[0-9a-f]{64}$ ]] || exit 1
jq -e --arg instance "$instance" --arg session "$FDB4_SESSION" \
  '.instance == $instance and .session == $session and .stable_samples == 3 and .data_healthy == true and .recovery == "fully_recovered"' \
  "$run_dir/bootstrap.ready" >/dev/null
[[ ! -e "$run_dir/monitor.stopped" ]] && kill -0 "$(cat "$run_dir/monitor.pid")" || exit 1
for file in bulk-phase.json bulk-pin.json bulk-phase.completed.json drain.certificate.json; do
  [[ ! -e "$run_dir/$file" ]] || { echo "Existing phase artifact; refusing reuse: $file" >&2; exit 1; }
done
revision=$FDB4_SOURCE_REVISION
binary_hash=$(sha256sum "$FDB4_BINARY" | awk '{print $1}')
manifest_hash=$(sha256sum "$FDB4_SOURCE_MANIFEST" | awk '{print $1}')
now=$(date +%s)
deadline=$((now + FDB4_BULK_SECONDS))
phase=$(jq -cn --arg instance "$instance" --arg session "$FDB4_SESSION" --arg revision "$revision" \
  --arg binary "$binary_hash" --arg manifest "$manifest_hash" --argjson now "$now" --argjson deadline "$deadline" \
  '{schema:"otel283_bulk_monitor_v1",policy:"exact-batch-probe-warning-v1",phase:"bulk_ingest_and_drain",owner:"otel283-vxnar",profile:"fdb4-4cpu-16g-v1",instance:$instance,session:$session,run:"rw1m0286",source:{revision:$revision,binary_sha256:$binary,manifest_sha256:$manifest},started_epoch:$now,deadline_epoch:$deadline}')
printf '%s\n' "$phase" | jq -ce --arg instance "$instance" --arg session "$FDB4_SESSION" --argjson now "$now" -f "$here/bulk-phase.jq" >/dev/null
(set -o noclobber; printf '%s\n' "$phase" > "$run_dir/bulk-pin.json")
(set -o noclobber; printf 'binary=%s\nsource_manifest=%s\n' "$FDB4_BINARY" "$FDB4_SOURCE_MANIFEST" > "$run_dir/bulk-source-files.txt")
pending="$run_dir/bulk-phase.pending.$$"
(set -o noclobber; printf '%s\n' "$phase" > "$pending")
ln -- "$pending" "$run_dir/bulk-phase.json"
phase_hash=$(sha256sum "$run_dir/bulk-pin.json" | awk '{print $1}')
wait_started=$SECONDS
while :; do
  [[ ! -e "$run_dir/monitor.stopped" ]] && kill -0 "$(cat "$run_dir/monitor.pid")" || exit 1
  if [[ -f "$run_dir/bulk-policy.ack.json" ]]; then
    jq -e --arg hash "$phase_hash" --arg instance "$instance" --arg session "$FDB4_SESSION" \
      '.phase_sha256 == $hash and .instance == $instance and .session == $session' "$run_dir/bulk-policy.ack.json" >/dev/null
    break
  fi
  (( SECONDS - wait_started < 30 && $(date +%s) < deadline )) || { echo 'Policy acknowledgement deadline failed; do not start load or extend marker' >&2; exit 1; }
  sleep 1
done
echo "Declared and monitor-acknowledged bounded policy for rw1m0286 through epoch $deadline; no workload started"
