#!/usr/bin/env bash
set -Eeuo pipefail
# Explicit ROOT readiness step, not bootstrap and not a workload. No configure.
readonly here=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
: "${FDB4_SESSION:?Use the prepared resume session}"
[[ "$FDB4_SESSION" == resume-20261027-05 ]] || exit 1
[[ ${FDB4_MARK_READY_APPROVED:-} == yes ]] || { echo 'Explicit root readiness approval required' >&2; exit 1; }
readonly run_dir="$here/sessions/$FDB4_SESSION"
readonly marker="$run_dir/bootstrap.ready"
[[ -f "$run_dir/resume-receipt.txt" && -f "$run_dir/instance.id" && ! -e "$marker" ]] || exit 1
readonly instance=$(cat "$run_dir/instance.id")
[[ "$instance" =~ ^[0-9a-f]{64}$ ]] || exit 1
[[ $(docker inspect --format '{{.Id}} {{index .Config.Labels "otel283.owner"}} {{index .Config.Labels "otel283.profile"}} {{index .Config.Labels "otel283.session"}}' otel283-fdb4-vxnar) == "$instance otel283-vxnar fdb4-4cpu-16g-v1 $FDB4_SESSION" ]] || exit 1
readonly raw_dir=$(mktemp -d "$run_dir/readiness-raw.XXXXXX")
started=$SECONDS
sample=0
stable=0
while (( SECONDS - started < 300 )); do
  next_tick=$((SECONDS + 5))
  [[ -f "$run_dir/monitor.pid" && ! -e "$run_dir/monitor.stopped" ]] || { echo 'Active session monitor required' >&2; exit 1; }
  monitor_pid=$(cat "$run_dir/monitor.pid")
  [[ "$monitor_pid" =~ ^[0-9]+$ ]] && kill -0 "$monitor_pid" || { echo 'Session monitor is not alive' >&2; exit 1; }
  sample=$((sample + 1))
  printf -v raw '%s/status-%06d.json' "$raw_dir" "$sample"
  summary=
  if timeout --kill-after=1s 12s docker exec "$instance" /usr/bin/timeout --kill-after=1s 10s \
       /usr/bin/fdbcli -C /var/fdb/data/cluster/fdb.cluster --exec 'status json' \
       > "$raw" 2>> "$run_dir/readiness-errors.log"; then
    summary=$(jq -ce --argjson allow_batch_warning false -f "$here/status-check.jq" "$raw" 2>> "$run_dir/readiness-errors.log") || summary=
  fi
  if [[ -n "$summary" ]] && printf '%s\n' "$summary" | jq -e \
       '.queue_bytes < 16777216 and .durability_lag_seconds < 10' >/dev/null; then
    stable=$((stable + 1))
    jq -cn --arg timestamp "$(date -u +%FT%TZ)" --arg raw "$raw" --argjson stable "$stable" --argjson status "$summary" \
      '{timestamp:$timestamp,raw_status:$raw,stable_count:$stable,status:$status}' >> "$run_dir/readiness.jsonl"
  else
    stable=0
    jq -cn --arg timestamp "$(date -u +%FT%TZ)" --arg raw "$raw" \
      '{timestamp:$timestamp,raw_status:$raw,stable_count:0,note:"Not ready; no default-zero substitution"}' >> "$run_dir/readiness.jsonl"
  fi
  if (( stable == 3 )); then
    [[ ! -e "$run_dir/monitor.stopped" ]] && kill -0 "$monitor_pid" || exit 1
    # Atomic no-overwrite marker publication only after three strict samples.
    pending="$run_dir/bootstrap.ready.pending.$$"
    (set -o noclobber; jq -cn --arg timestamp "$(date -u +%FT%TZ)" --arg instance "$instance" --arg session "$FDB4_SESSION" \
      '{timestamp:$timestamp,instance:$instance,session:$session,stable_samples:3,nominal_interval_seconds:5,queue_strictly_below_bytes:16777216,lag_strictly_below_seconds:10,recovery:"fully_recovered",data_healthy:true}' > "$pending")
    ln -- "$pending" "$marker"
    echo "READY: $marker (no workload started)"
    exit 0
  fi
  delay=$((next_tick - SECONDS))
  if (( delay > 0 )); then sleep "$delay"; fi
done
echo 'Readiness deadline exceeded; no marker or workload published' >&2
exit 1
