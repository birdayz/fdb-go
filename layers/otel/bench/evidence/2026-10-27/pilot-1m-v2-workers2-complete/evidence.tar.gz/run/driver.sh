#!/usr/bin/env bash
set -Eeuo pipefail
export GOMAXPROCS=4 TZ=UTC
: "${FDB4_MEASUREMENT_SOURCE:?Explicit clean detached measurement source required}"
: "${FDB4_MEASUREMENT_REVISION:?Explicit committed 40-hex source revision required}"
: "${FDB4_MEASUREMENT_BINARY:?Explicit immutable built binary required}"
: "${FDB4_MEASUREMENT_BINARY_SHA256:?Explicit frozen binary digest required}"
[[ $FDB4_MEASUREMENT_REVISION =~ ^[0-9a-f]{40}$ && $FDB4_MEASUREMENT_BINARY_SHA256 =~ ^[0-9a-f]{64}$ ]]
base=/tmp/fdb-hotelbench.VxNArC
profile=$base/fdb4-config-rw1m0286
session_name=resume-20261027-05
session=$profile/sessions/$session_name
out=$base/pilot1m-v2-workers2
bin=$FDB4_MEASUREMENT_BINARY
source=$FDB4_MEASUREMENT_SOURCE
revision=$FDB4_MEASUREMENT_REVISION
container=otel283-fdb4-vxnar
cd "$source"
[[ ! -e "$out" && -f "$session/bootstrap.ready" && ! -e "$session/monitor.stopped" ]]
kill -0 "$(cat "$session/monitor.pid")"
instance=$(cat "$session/instance.id")
[[ $instance =~ ^[0-9a-f]{64}$ ]]
[[ $(docker inspect "$container" --format '{{.Id}} {{.State.Running}} {{index .Config.Labels "otel283.owner"}} {{index .Config.Labels "otel283.profile"}} {{index .Config.Labels "otel283.session"}}') == "$instance true otel283-vxnar fdb4-4cpu-16g-v1 $session_name" ]]
[[ $(git rev-parse HEAD) == "$revision" && -z $(git status --porcelain=v1) ]]
[[ $(sha256sum "$bin" | awk '{print $1}') == "$FDB4_MEASUREMENT_BINARY_SHA256" ]]
mkdir "$out"
manifest() { git ls-files --cached --others --exclude-standard -z | LC_ALL=C sort -z | xargs -0 sha256sum; }
config_manifest() { sha256sum "$profile"/{foundationdb.conf,fdb.cluster.seed,resume.sh,resume-entrypoint.sh,monitor.sh,status-check.jq,readiness.sh,bulk-phase.jq,declare-bulk.sh,drain.sh,verify-drain.sh}; }
manifest > "$out/source.before"
sha256sum "$bin" > "$out/binary.before"
config_manifest > "$out/config.before"
cp "$session/bootstrap.ready" "$out/profile-ready.json"
printf '%s\n' "$revision" > "$out/revision"
finish() {
  rc=$?
  trap - EXIT
  manifest > "$out/source.after"
  sha256sum "$bin" > "$out/binary.after"
  config_manifest > "$out/config.after"
  if ! cmp -s "$out/source.before" "$out/source.after" || ! cmp -s "$out/binary.before" "$out/binary.after" || ! cmp -s "$out/config.before" "$out/config.after" || [[ -n $(git status --porcelain=v1) ]]; then rc=4; fi
  printf 'exit=%s end=%s\n' "$rc" "$(date -u +%FT%TZ)" > "$out/status"
  exit "$rc"
}
trap finish EXIT
status() { timeout --kill-after=1s 12s docker exec "$instance" /usr/bin/timeout --kill-after=1s 10s /usr/bin/fdbcli -C /var/fdb/data/cluster/fdb.cluster --exec 'status json'; }
# Separate invocations preserve component totals rather than suppressing children.
physical() { docker exec "$instance" /bin/sh -c 'du -s -B1 /var/fdb/data; for p in /var/fdb/data/processes/* /var/fdb/data/traces; do du -s -B1 "$p"; done'; }
active() { [[ ! -e "$session/monitor.stopped" ]] && kill -0 "$(cat "$session/monitor.pid")" && [[ $(docker inspect "$container" --format '{{.Id}} {{.State.Running}}') == "$instance true" ]]; }
common=(--backend fdb --order time --cluster-file "$profile/fdb.cluster.seed" --run rw1m0286
  --seed 283 --count 1000000 --tenants 1 --attrs 8 --match-every 100 --batch 32 --save-mode batch
  --workers 2 --diagnostics --k 100 --max-candidates 2000000 --max-bytes 268435456
  --timeout 30m --revision "$revision")
printf '%q ' "$bin" "${common[@]}" --mode ingest --output "$out/ingest.json" > "$out/ingest-command.txt"
printf '\n' >> "$out/ingest-command.txt"
status > "$out/fdb.before.json"
jq -ce --argjson allow_batch_warning false -f "$profile/status-check.jq" "$out/fdb.before.json" > "$out/health.before.json"
physical > "$out/physical.before"
docker stats --no-stream --format '{{json .}}' "$instance" > "$out/container.before.jsonl"
FDB4_DECLARE_BULK_APPROVED=yes FDB4_SESSION="$session_name" FDB4_SOURCE_REVISION="$revision" \
  FDB4_BINARY="$bin" FDB4_SOURCE_MANIFEST="$out/source.before" FDB4_BULK_SECONDS=2700 \
  bash "$profile/declare-bulk.sh" | tee "$out/declare-bulk.log"
cp "$session/bulk-pin.json" "$session/bulk-policy.ack.json" "$out/"
active
rc=0
started=$(date -u +%FT%TZ)
perf stat -o "$out/perf-stat.txt" -e task-clock,cycles,instructions,context-switches,cpu-migrations,page-faults -- \
  "$bin" "${common[@]}" --mode ingest --output "$out/ingest.json" || rc=$?
ended=$(date -u +%FT%TZ)
ingest_hash=
if [[ -s "$out/ingest.json" ]]; then ingest_hash=$(sha256sum "$out/ingest.json" | awk '{print $1}'); fi
jq -cn --arg run rw1m0286 --arg instance "$instance" --arg revision "$revision" --arg start "$started" --arg end "$ended" \
  --argjson rc "$rc" --arg receipt "$out/ingest.json" --arg hash "$ingest_hash" \
  '{run:$run,instance:$instance,source_revision:$revision,started:$start,ended:$end,exit_code:$rc,ingest_receipt:$receipt,ingest_receipt_sha256:$hash,note:"Finalized load outcome only; population requires independent source audit. Sole batch-probe warning may be admitted only during the declared bounded bulk phase."}' > "$out/load-outcome.json"
physical > "$out/physical.acknowledged" 2> "$out/physical.acknowledged.stderr" || true
status > "$out/fdb.acknowledged.json" 2> "$out/fdb.acknowledged.stderr" || true
docker stats --no-stream --format '{{json .}}' "$instance" > "$out/container.acknowledged.jsonl" 2> "$out/container.acknowledged.stderr" || true
active
FDB4_CERTIFY_DRAIN_APPROVED=yes FDB4_SESSION="$session_name" FDB4_LOAD_RECEIPT="$out/load-outcome.json" \
  bash "$profile/drain.sh" | tee "$out/drain.log"
cp "$session/drain.certificate.json" "$session/drain.jsonl" "$out/"
active
physical > "$out/physical.settled"
status > "$out/fdb.settled.json"
jq -ce --argjson allow_batch_warning false -f "$profile/status-check.jq" "$out/fdb.settled.json" > "$out/health.settled.json"
if (( rc )); then
  audit_rc=0
  "$bin" "${common[@]}" --mode audit --output "$out/audit-after-failure.json" || audit_rc=$?
  printf '%s\n' "$audit_rc" > "$out/audit-after-failure.exit"
  exit "$rc"
fi
[[ -n "$ingest_hash" ]]
"$bin" "${common[@]}" --mode audit --output "$out/audit.json"
"$bin" "${common[@]}" --mode query --suite all --iterations 1600 --output "$out/all.json"
active
status > "$out/fdb.after.json"
jq -ce --argjson allow_batch_warning false -f "$profile/status-check.jq" "$out/fdb.after.json" > "$out/health.after.json"
echo '1M two-worker timeout-recovery pilot completed with strict drain, stored-source audit and explicit 16-class source-oracle checks; not 100M, production or competitive proof.'
