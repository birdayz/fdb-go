#!/usr/bin/env bash
set -Eeuo pipefail
umask 077
here=$(cd -- "$(dirname -- "$0")" && pwd -P)
readonly here name=otel283-ch16-vxnar volume=otel283-vxnar-ch16-v1 owner=otel283-vxnar profile=ch16-4cpu-16g-v1 image='clickhouse/clickhouse-server@sha256:b2bfa4d8399ee9973868cc5c1754cb506a6f4b86fbddc41010cc090beb55c85e'
[[ ${CH16_APPROVED:-} == yes && ${CH16_FDB_STOP_CONFIRMED:-} == yes ]] || { echo 'Explicit approval and stopped-FDB confirmation required' >&2; exit 1; }
exec 9>"$here/launch.lock"; flock -n 9 || { echo 'Launch already active' >&2; exit 1; }
[[ ! -e "$here/instance.id" && ! -e "$here/launch-receipt.txt" ]] || { echo 'Existing receipt: refusing reuse' >&2; exit 1; }
timeout 10 docker info >/dev/null
if docker inspect "$name" >/dev/null 2>&1; then echo 'Container exists; refusing reuse' >&2; exit 1; fi
if docker volume inspect "$volume" >/dev/null 2>&1; then echo 'Volume exists; refusing reuse' >&2; exit 1; fi
# Hard sequential policy: never stop or touch FDB here. Owner must stop it first.
if [[ $(docker inspect --format '{{.State.Running}}' otel283-fdb4-vxnar 2>/dev/null || printf missing) != false ]]; then echo 'Expected owned FDB must exist and be stopped' >&2; exit 1; fi
[[ $(docker inspect --format '{{index .Config.Labels "otel283.owner"}} {{index .Config.Labels "otel283.profile"}}' otel283-fdb4-vxnar) == 'otel283-vxnar fdb4-4cpu-16g-v1' ]] || { echo 'FDB owner/profile mismatch' >&2; exit 1; }
for port in 18125 19005; do if ss -H -ltn "sport = :$port" | grep -q .; then echo "Port occupied: $port" >&2; exit 1; fi; done
timeout 10 docker image inspect "$image" >/dev/null
"$here/resources.sh"
# Monitor must already run in a separate tracked foreground job.
[[ -f "$here/monitor.heartbeat" ]] && (( $(date +%s) - $(stat -c %Y "$here/monitor.heartbeat") < 10 )) || { echo 'Start monitor first; no fresh heartbeat' >&2; exit 1; }
[[ $(docker volume create --label "otel283.owner=$owner" --label "otel283.profile=$profile" --label 'otel283.role=ch16-data' "$volume") == "$volume" ]]
[[ $(docker volume inspect --format '{{index .Labels "otel283.owner"}} {{index .Labels "otel283.profile"}}' "$volume") == "$owner $profile" ]]
id=$(docker create --name "$name" --pull never --restart no --network host --cpus 4 --memory 16g --memory-swap 16g \
  --label "otel283.owner=$owner" --label "otel283.profile=$profile" --label 'otel283.role=ch16-server' \
  --mount "type=volume,source=$volume,target=/var/lib/clickhouse,volume-nocopy" \
  --mount "type=bind,source=$here/server.xml,target=/etc/clickhouse-server/config.d/otel283.xml,readonly" \
  --mount "type=bind,source=$here/profile.xml,target=/etc/clickhouse-server/users.d/otel283.xml,readonly" \
  --env CLICKHOUSE_SKIP_USER_SETUP=1 "$image")
[[ $id =~ ^[0-9a-f]{64}$ ]] || { echo 'Unexpected container ID' >&2; exit 1; }
printf '%s\n' "$id" > "$here/instance.id"
printf 'container=%s\nvolume=%s\ninstance=%s\nowner=%s\nprofile=%s\nimage=%s\n' "$name" "$volume" "$id" "$owner" "$profile" "$image" > "$here/launch-receipt.txt"
stop_owned() {
  [[ $(docker inspect --format '{{.Id}} {{index .Config.Labels "otel283.owner"}} {{index .Config.Labels "otel283.profile"}}' "$name" 2>/dev/null || :) == "$id $owner $profile" ]] && timeout 20 docker stop -t 10 "$id" >/dev/null || :
}
trap stop_owned EXIT INT TERM
# The foreground runtime job stays attached. The monitor independently enforces
# resources and its own deadline; no cleanup deletes the owned volume.
timeout --foreground --signal=TERM --kill-after=20s 3600s docker start --attach "$id"
