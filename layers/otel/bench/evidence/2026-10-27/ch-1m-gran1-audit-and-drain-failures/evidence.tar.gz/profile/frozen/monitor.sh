#!/usr/bin/env bash
set -Eeuo pipefail
umask 077
here=$(cd -- "$(dirname -- "$0")" && pwd -P)
readonly here name=otel283-ch16-vxnar owner=otel283-vxnar profile=ch16-4cpu-16g-v1
exec 9>"$here/monitor.lock"; flock -n 9 || { echo 'Monitor already active' >&2; exit 1; }
[[ ! -e "$here/instance.id" ]] || { echo 'Refusing existing instance' >&2; exit 1; }
stop_owned() {
  rm -f "$here/monitor.heartbeat"
  if [[ -f "$here/instance.id" ]]; then
    id=$(cat "$here/instance.id")
    if [[ $id =~ ^[0-9a-f]{64}$ ]] && [[ $(timeout 10 docker inspect --format '{{.Id}} {{index .Config.Labels "otel283.owner"}} {{index .Config.Labels "otel283.profile"}}' "$name" 2>/dev/null || :) == "$id $owner $profile" ]]; then timeout 20 docker stop -t 10 "$id" >/dev/null || :; fi
  fi
}
trap stop_owned EXIT INT TERM
started=$SECONDS; running_seen=no
while (( SECONDS-started < 3600 )); do
  "$here/resources.sh"
  if [[ -f "$here/instance.id" ]]; then
    id=$(cat "$here/instance.id")
    [[ $id =~ ^[0-9a-f]{64}$ ]] || exit 1
    [[ $(timeout 10 docker inspect --format '{{.Id}} {{index .Config.Labels "otel283.owner"}} {{index .Config.Labels "otel283.profile"}}' "$name") == "$id $owner $profile" ]] || { echo 'Ownership mismatch' >&2; exit 1; }
    read -r running pid < <(docker inspect --format '{{.State.Running}} {{.State.Pid}}' "$id")
    if [[ $running == true ]]; then
      running_seen=yes
      [[ $pid =~ ^[1-9][0-9]*$ ]] || exit 1
      cg=$(awk -F: '$1=="0" {print $3}' "/proc/$pid/cgroup")
      [[ -n $cg && -f "/sys/fs/cgroup$cg/memory.current" && -f "/sys/fs/cgroup$cg/memory.max" ]] || { echo 'Cannot resolve cgroup v2 memory' >&2; exit 1; }
      current=$(cat "/sys/fs/cgroup$cg/memory.current"); max=$(cat "/sys/fs/cgroup$cg/memory.max")
      [[ $current =~ ^[0-9]+$ && $max == 17179869184 ]] && (( current*10 < max*9 )) || { echo 'Container memory guard failed' >&2; exit 1; }
      printf '%s memory_current=%s memory_max=%s\n' "$(date -u +%FT%TZ)" "$current" "$max"
    elif [[ $running_seen == yes ]] || (( SECONDS-started > 120 )); then echo 'Container is not running' >&2; exit 1; fi
  elif (( SECONDS-started > 120 )); then echo 'Launch did not appear' >&2; exit 1; fi
  touch "$here/monitor.heartbeat"
  sleep 5
done
echo 'CH16 monitor TTL expired' >&2
exit 1
