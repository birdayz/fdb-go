#!/usr/bin/env bash
set -Eeuo pipefail
export GOMAXPROCS=4 TZ=UTC
base=/tmp/fdb-hotelbench.VxNArC
source=$base/granularity-measurement-src
bin=$base/otelbench-granularity-reference
profile=$base/ch16-config
out=$base/ch1m-gran1-30m
revision=9244882a5914e0f897b0216866ca77d2bd4b6910
cd "$source"
[[ ! -e "$out" && $(git rev-parse HEAD) == "$revision" && -z $(git status --porcelain=v1) ]]
sha256sum --check "$base/granularity-binary.sha256"
instance=$(cat "$profile/instance.id")
[[ $(docker inspect --format '{{.Id}} {{.State.Running}} {{.State.OOMKilled}} {{.RestartCount}} {{index .Config.Labels "otel283.owner"}} {{index .Config.Labels "otel283.profile"}}' otel283-ch16-vxnar) == "$instance true false 0 otel283-vxnar ch16-4cpu-16g-v1" ]]
mkdir "$out"
manifest() { git ls-files --cached --others --exclude-standard -z | LC_ALL=C sort -z | xargs -0 sha256sum; }
manifest > "$out/source.before"
sha256sum "$bin" > "$out/binary.before"
sha256sum "$profile"/{server.xml,profile.xml,launch.sh,monitor.sh,resources.sh,resources-policy.sh,readiness.sh} > "$out/config.before"
finish() {
  rc=$?
  trap - EXIT
  manifest > "$out/source.after"
  sha256sum "$bin" > "$out/binary.after"
  sha256sum "$profile"/{server.xml,profile.xml,launch.sh,monitor.sh,resources.sh,resources-policy.sh,readiness.sh} > "$out/config.after"
  if ! cmp -s "$out/source.before" "$out/source.after" || ! cmp -s "$out/binary.before" "$out/binary.after" || ! cmp -s "$out/config.before" "$out/config.after" || [[ -n $(git status --porcelain=v1) ]]; then rc=4; fi
  printf 'exit=%s end=%s\n' "$rc" "$(date -u +%FT%TZ)" > "$out/status"
  exit "$rc"
}
trap finish EXIT
admin() { curl --noproxy '*' --fail --silent --show-error --max-time 15 --data-binary "$1" http://127.0.0.1:18125/; }
admin "SELECT count() FROM system.processes WHERE startsWith(query,'INSERT INTO otel_ch1m_g1_0287.spans') FORMAT TabSeparated" > "$out/prior-active-inserts.txt"
[[ $(cat "$out/prior-active-inserts.txt") == 0 ]]
common=(--backend ch-attrs --order time --ch-url http://127.0.0.1:18125 --seed 283
  --run ch1m_g1_30m_0288 --ch-index-granularity 1 --count 1000000 --tenants 1 --attrs 8
  --match-every 100 --k 100 --ch-batch 8192 --ch-batch-bytes 8388608 --batch 32 --save-mode batch
  --workers 2 --max-candidates 2000000 --max-bytes 268435456 --timeout 30m --revision "$revision")
printf '%q ' "$bin" "${common[@]}" --mode ingest > "$out/ingest.command"
printf '\n' >> "$out/ingest.command"
"$bin" "${common[@]}" --mode ingest --output "$out/ingest.json"
"$bin" "${common[@]}" --mode audit --output "$out/audit.json"
jq -e '.error == null and .stats.rows == 1000000 and .stats.attributes == 8000000' "$out/audit.json" >/dev/null
echo 'Fresh granularity-1 arm completed with the FDB-matched 30m whole-command budget. Earlier 10m deadline failure remains failed; no query verdict yet.'
