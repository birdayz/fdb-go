#!/usr/bin/env bash
set -Eeuo pipefail
# PREPARED ONLY. Root must approve the capacity gate and fast-lane result first.
# Run under the runtime's tracked background job mechanism, not nohup/shell '&'.
readonly here=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
readonly image='foundationdb/foundationdb@sha256:559b178a137bbe09272ad6e3752531aa04e2ddacab8ccfa4ffa86467db033bea'
readonly container=otel283-fdb4-vxnar
readonly owner=otel283-vxnar
readonly profile=fdb4-4cpu-16g-v1
readonly min_available=$((8 * 1024 * 1024 * 1024))
[[ ${FDB4_CAPACITY_GATE_APPROVED:-} == yes && ${FDB4_16G_APPROVED:-} == yes ]] || {
  echo 'Require explicit FDB4_CAPACITY_GATE_APPROVED=yes and FDB4_16G_APPROVED=yes' >&2; exit 1;
}
: "${FDB4_VOLUME:?Supply a NEW unique name beginning otel283-vxnar-fdb4-}"
case "$FDB4_VOLUME" in
  otel283-vxnar-fdb4-*) ;;
  *) echo 'Refusing volume outside the new profile namespace' >&2; exit 1 ;;
esac
[[ "$FDB4_VOLUME" =~ ^[a-zA-Z0-9][a-zA-Z0-9_.-]+$ ]] || { echo 'Invalid volume name' >&2; exit 1; }
if docker inspect "$container" >/dev/null 2>&1; then
  echo "Container already exists; refusing reuse: $container" >&2; exit 1
fi
if docker volume inspect "$FDB4_VOLUME" >/dev/null 2>&1; then
  echo "Volume already exists; refusing attachment: $FDB4_VOLUME" >&2; exit 1
fi
available=$(awk '/^MemAvailable:/ {printf "%.0f\n", $2 * 1024}' /proc/meminfo)
(( available >= min_available )) || { echo 'Host headroom is below 8 GiB; launch refused' >&2; exit 1; }
docker image inspect "$image" >/dev/null
# Read-only capacity evidence; approval above must account for all old volumes,
# the 16-GiB CH comparator, logs/backups, and a separate disk abort threshold.
docker info --format 'DockerRootDir={{.DockerRootDir}}'
df -B1 --output=source,size,used,avail,target "$(docker info --format '{{.DockerRootDir}}')"
for port in 14683 14684 14685 14686; do
  if ss -H -ltn "sport = :$port" | grep -q .; then
    echo "Port is already listening; launch refused: $port" >&2; exit 1
  fi
done
volume=$(docker volume create \
  --label "otel283.owner=$owner" --label "otel283.profile=$profile" \
  --label 'otel283.role=fdb4-data' "$FDB4_VOLUME")
[[ "$volume" == "$FDB4_VOLUME" ]] || { echo 'Unexpected new volume name' >&2; exit 1; }
# Retain identity before run; failures never auto-delete the volume/container.
printf 'container=%s\nvolume=%s\nowner=%s\nprofile=%s\nimage=%s\n' \
  "$container" "$volume" "$owner" "$profile" "$image" > "$here/launch-receipt.txt"
printf 'Start monitor.sh separately in a tracked job as soon as container exists.\n' >&2
# Foreground container attachment; inside, foreground Tini -> bash -> fdbmonitor.
# No stock fdb.bash, no configure/bootstrap, no old-volume reference, no auto-restart.
exec docker run --name "$container" --pull never --restart no \
  --cpus 4 --memory 16g --memory-swap 16g \
  --label "otel283.owner=$owner" --label "otel283.profile=$profile" \
  --label 'otel283.role=fdb4-server' \
  --mount "type=volume,source=$volume,target=/var/fdb/data,volume-nocopy" \
  --mount "type=bind,source=$here,target=/etc/fdb4,readonly" \
  --publish 127.0.0.1:14683:14683 --publish 127.0.0.1:14684:14684 \
  --publish 127.0.0.1:14685:14685 --publish 127.0.0.1:14686:14686 \
  --env FDB4_OWNER="$owner" --env FDB_CLUSTER_FILE=/var/fdb/data/cluster/fdb.cluster \
  --entrypoint /usr/bin/tini "$image" -g -- /bin/bash /etc/fdb4/container-entrypoint.sh
