#!/usr/bin/env bash
set -Eeuo pipefail
# Explicit ROOT strict-drain observation. No load, audit, configure or DB writes.
readonly here=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
: "${FDB4_SESSION:?Use the active new resume session}"
: "${FDB4_LOAD_RECEIPT:?Supply the finalized preserved load outcome receipt}"
[[ ${FDB4_CERTIFY_DRAIN_APPROVED:-} == yes && "$FDB4_SESSION" == resume-20261027-04 ]] || exit 1
readonly run_dir="$here/sessions/$FDB4_SESSION"
readonly instance=$(cat "$run_dir/instance.id")
readonly phase_file="$run_dir/bulk-phase.json"
[[ -f "$phase_file" && ! -e "$run_dir/drain.certificate.json" && ! -e "$run_dir/bulk-phase.completed.json" ]] || exit 1
cmp -- "$phase_file" "$run_dir/bulk-pin.json" || exit 1
readonly phase_hash=$(sha256sum "$phase_file" | awk '{print $1}')
readonly receipt=$(readlink -f "$FDB4_LOAD_RECEIPT")
[[ -s "$receipt" ]] || exit 1
readonly receipt_hash=$(sha256sum "$receipt" | awk '{print $1}')
readonly raw_dir=$(mktemp -d "$run_dir/drain-raw.XXXXXX")
samples='[]'
sample=0
while :; do
  sample_epoch=$(date +%s)
  jq -ce --arg instance "$instance" --arg session "$FDB4_SESSION" --argjson now "$sample_epoch" -f "$here/bulk-phase.jq" "$phase_file" >/dev/null || { echo 'Bulk deadline/metadata invalid; no certificate' >&2; exit 1; }
  [[ $(sha256sum "$phase_file" | awk '{print $1}') == "$phase_hash" && ! -e "$run_dir/monitor.stopped" ]] || exit 1
  kill -0 "$(cat "$run_dir/monitor.pid")" || exit 1
  sample=$((sample + 1))
  printf -v raw '%s/status-%06d.json' "$raw_dir" "$sample"
  summary=
  if timeout --kill-after=1s 12s docker exec "$instance" /usr/bin/timeout --kill-after=1s 10s \
       /usr/bin/fdbcli -C /var/fdb/data/cluster/fdb.cluster --exec 'status json' \
       > "$raw" 2>> "$run_dir/drain-errors.log"; then
    summary=$(jq -ce --argjson allow_batch_warning false -f "$here/status-check.jq" "$raw" 2>> "$run_dir/drain-errors.log") || summary=
  fi
  if [[ -n "$summary" ]] && printf '%s\n' "$summary" | jq -e '.aggregate_healthy_original == true and .health_exception_used == false and .queue_bytes < 16777216 and .durability_lag_seconds < 10' >/dev/null; then
    raw_hash=$(sha256sum "$raw" | awk '{print $1}')
    samples=$(printf '%s\n' "$samples" | jq -c --arg raw "$raw" --arg hash "$raw_hash" --argjson epoch "$sample_epoch" '. + [{raw_path:$raw,sha256:$hash,epoch:$epoch}]')
    jq -cn --argjson status "$summary" --arg raw "$raw" --argjson count "$(printf '%s\n' "$samples" | jq length)" \
      '{raw_status:$raw,strict_status:$status,stable_count:$count}' >> "$run_dir/drain.jsonl"
  else
    samples='[]'
    jq -cn --arg raw "$raw" '{raw_status:$raw,stable_count:0,note:"Not strictly drained; raw preserved"}' >> "$run_dir/drain.jsonl"
  fi
  if [[ $(printf '%s\n' "$samples" | jq length) == 3 ]]; then
    completed=$(date +%s)
    deadline=$(jq -er '.deadline_epoch' "$phase_file")
    (( completed < deadline )) || exit 1
    [[ ! -e "$run_dir/monitor.stopped" ]] && kill -0 "$(cat "$run_dir/monitor.pid")" || exit 1
    [[ $(sha256sum "$receipt" | awk '{print $1}') == "$receipt_hash" ]] || exit 1
    pending="$run_dir/drain.certificate.pending.$$"
    (set -o noclobber; jq -cn --arg instance "$instance" --arg session "$FDB4_SESSION" --arg hash "$phase_hash" \
      --arg receipt "$receipt" --arg receipt_hash "$receipt_hash" --argjson completed "$completed" \
      --argjson samples "$samples" --slurpfile phase "$phase_file" \
      '{schema:"otel283_strict_drain_v1",instance:$instance,session:$session,run:"rw1m0285",source:$phase[0].source,phase_sha256:$hash,completed_epoch:$completed,samples:$samples,load_receipt:$receipt,load_receipt_sha256:$receipt_hash}' > "$pending")
    ln -- "$pending" "$run_dir/drain.certificate.json"
    bash "$here/verify-drain.sh" "$run_dir" "$instance" "$FDB4_SESSION" "$phase_hash"
    # Certificate now exists and verifies BEFORE removal of the active marker.
    (set -o noclobber; cat "$phase_file" > "$run_dir/bulk-phase.completed.json")
    rm -- "$phase_file"
    echo 'Strict drain certified; monitor returns to strict normal policy. Certificate does not certify load population/audit success.'
    exit 0
  fi
  # Keep strict samples at least five seconds apart even with clock rounding.
  sleep 5
done
