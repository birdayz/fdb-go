#!/usr/bin/env bash
set -Eeuo pipefail
# Existing owned data only. No initialization, seed overwrite, chmod or chown.
readonly data=/var/fdb/data
readonly config_hash=6b2b4e0e85fba430d99ea8710778c6776a95326246ae6e45109192327e242b1f
[[ ${FDB4_OWNER:-} == otel283-vxnar && ${FDB4_MODE:-} == resume ]] || exit 1
[[ $(sha256sum /etc/fdb4/foundationdb.conf | awk '{print $1}') == "$config_hash" ]] || { echo 'Config pin mismatch' >&2; exit 1; }
[[ -f "$data/.otel283-owner" && $(cat "$data/.otel283-owner") == otel283-vxnar ]] || { echo 'Existing volume ownership marker mismatch' >&2; exit 1; }
[[ -f "$data/cluster/fdb.cluster" ]] || { echo 'Existing cluster file absent' >&2; exit 1; }
[[ $(sha256sum "$data/cluster/fdb.cluster" | awk '{print $1}') == $(sha256sum /etc/fdb4/fdb.cluster.seed | awk '{print $1}') ]] || { echo 'Existing cluster seed changed; explicit recovery review required' >&2; exit 1; }
for port in 14683 14684 14685 14686; do
  [[ -d "$data/processes/$port" && -s "$data/processes/$port/processId" && -d "$data/traces/$port" ]] || {
    echo "Missing existing process identity/directory: $port" >&2; exit 1;
  }
done
# fdbmonitor drops child privileges according to the unchanged pinned config.
# Recovery is writable; do not treat this as read-only forensic inspection.
exec /usr/bin/fdbmonitor --conffile /etc/fdb4/foundationdb.conf --lockfile /var/run/otel283-fdb4-monitor.pid
