#!/usr/bin/env bash
set -Eeuo pipefail
# PREPARED ONLY. Explicit owned resume; never configure/bootstrap a database.
readonly here=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
# The stopped predecessor must bind the frozen OLD tree; replacement binds here.
readonly old_policy_root=/tmp/fdb-hotelbench.VxNArC/fdb4-config
readonly container=otel283-fdb4-vxnar
readonly volume=otel283-vxnar-fdb4-redwood16-v1
readonly owner=otel283-vxnar
readonly profile=fdb4-4cpu-16g-v1
readonly image='foundationdb/foundationdb@sha256:559b178a137bbe09272ad6e3752531aa04e2ddacab8ccfa4ffa86467db033bea'
[[ ${FDB4_RESUME_APPROVED:-} == yes && ${FDB4_CAPACITY_GATE_APPROVED:-} == yes && ${FDB4_16G_APPROVED:-} == yes ]] || {
  echo 'Require explicit resume, capacity and 16-GiB approval' >&2; exit 1;
}
: "${FDB4_SESSION:?Supply a NEW session name, e.g. resume-20261027-01}"
[[ "$FDB4_SESSION" == resume-20261027-04 ]] || exit 1
readonly session="$here/sessions/$FDB4_SESSION"
[[ ! -e "$session" ]] || { echo 'Session exists; refusing to overwrite evidence' >&2; exit 1; }
readonly config_hash=6b2b4e0e85fba430d99ea8710778c6776a95326246ae6e45109192327e242b1f
readonly seed_hash=88eea690f206eac6e9d532cadc882fe4945da0c4aa0f6d6eb55e5ee1615eed3e
[[ $(sha256sum "$here/foundationdb.conf" | awk '{print $1}') == "$config_hash" ]] || exit 1
[[ $(sha256sum "$here/fdb.cluster.seed" | awk '{print $1}') == "$seed_hash" ]] || exit 1
for line in "container=$container" "volume=$volume" "owner=$owner" "profile=$profile" "image=$image"; do
  grep -Fx -- "$line" "$here/launch-receipt.txt" >/dev/null || { echo 'Original launch receipt mismatch' >&2; exit 1; }
done
grep -Fx 'Database created' "$here/bootstrap.log" >/dev/null || { echo 'Missing original successful bootstrap receipt' >&2; exit 1; }
grep -F 'configure new single ssd-redwood-1' "$here/bootstrap-command.txt" >/dev/null || exit 1
available=$(awk '/^MemAvailable:/ {printf "%.0f\n", $2 * 1024}' /proc/meminfo)
[[ "$available" =~ ^[0-9]+$ ]] && (( available >= 24 * 1024 * 1024 * 1024 )) || { echo 'Need 16-GiB incremental reservation plus 8-GiB host reserve' >&2; exit 1; }
docker_root=$(docker info --format '{{.DockerRootDir}}')
disk=$(df -B1 --output=avail "$docker_root" | tail -1 | tr -d ' ')
[[ "$disk" =~ ^[0-9]+$ ]] && (( disk >= 200 * 1024 * 1024 * 1024 )) || { echo 'Need at least 200 GiB Docker-filesystem free' >&2; exit 1; }
mkdir -p "$here/sessions"
mkdir "$session"
# Capture before any container removal. Any failure leaves evidence and volume.
docker inspect "$container" > "$session/original-container.inspect.json"
docker volume inspect "$volume" > "$session/volume.inspect.json"
docker image inspect "$image" > "$session/image.inspect.json"
docker logs --timestamps "$container" > "$session/original-container.stdout.log" 2> "$session/original-container.stderr.log"
image_id=$(jq -er '.[0].Id' "$session/image.inspect.json")
jq -e --arg owner "$owner" --arg profile "$profile" --arg volume "$volume" --arg image "$image" --arg id "$image_id" --arg old_here "$old_policy_root" '
  length == 1 and (.[0] |
    .State.Status == "exited" and .State.Running == false and .State.Paused == false and .State.Restarting == false
    and .Config.Labels["otel283.owner"] == $owner and .Config.Labels["otel283.profile"] == $profile
    and .Config.Image == $image and .Image == $id
    and .HostConfig.NanoCpus == 4000000000 and .HostConfig.Memory == 17179869184
    and .HostConfig.MemorySwap == 17179869184
    and ([.Mounts[] | select(.Destination == "/var/fdb/data" and .Type == "volume" and .Name == $volume)] | length == 1)
    and ([.Mounts[] | select(.Destination == "/etc/fdb4" and .Type == "bind" and .Source == $old_here and .RW == false)] | length == 1))
' "$session/original-container.inspect.json" >/dev/null || { echo 'Stopped container identity/config/mount mismatch' >&2; exit 1; }
jq -e --arg owner "$owner" --arg profile "$profile" --arg volume "$volume" '
  length == 1 and (.[0] | .Name == $volume and .Labels["otel283.owner"] == $owner and .Labels["otel283.profile"] == $profile)
' "$session/volume.inspect.json" >/dev/null || exit 1
# No active container, including any differently named instance, may mount data.
active=$(docker ps -q --filter "volume=$volume")
if [[ -n "$active" ]]; then
  docker inspect $active > "$session/active-containers.inspect.json"
  jq -e --arg volume "$volume" '[.[] | .Mounts[]? | select(.Type == "volume" and .Name == $volume)] | length == 0' \
    "$session/active-containers.inspect.json" >/dev/null || { echo 'Data volume mounted by an active container' >&2; exit 1; }
fi
# Docker cp reads stopped-container files without starting it or mounting data anew.
docker cp "$container:/var/fdb/data/.otel283-owner" "$session/existing.owner"
docker cp "$container:/var/fdb/data/cluster/fdb.cluster" "$session/existing.cluster"
[[ $(cat "$session/existing.owner") == "$owner" ]] || exit 1
cmp -- "$session/existing.cluster" "$here/fdb.cluster.seed" || { echo 'Preserved cluster differs from pinned seed; review required, never overwrite' >&2; exit 1; }
for port in 14683 14684 14685 14686; do
  docker cp "$container:/var/fdb/data/processes/$port/processId" "$session/process-$port.processId"
  [[ -s "$session/process-$port.processId" ]] || exit 1
  if ss -H -ltn "sport = :$port" | grep -q .; then echo "Port in use: $port" >&2; exit 1; fi
done
cp -p "$here/launch-receipt.txt" "$here/bootstrap-command.txt" "$here/bootstrap.log" "$session/"
sha256sum "$here/foundationdb.conf" "$here/fdb.cluster.seed" "$here/resume.sh" "$here/resume-entrypoint.sh" \
  "$here/monitor.sh" "$here/status-check.jq" "$here/readiness.sh" > "$session/resume-source.sha256"
printf 'container=%s\nvolume=%s\nowner=%s\nprofile=%s\nimage=%s\nsession=%s\nmode=resume\n' \
  "$container" "$volume" "$owner" "$profile" "$image" "$FDB4_SESSION" > "$session/resume-receipt.txt"
# Recheck immediately before metadata replacement. No force or volume-delete flag.
[[ $(docker inspect --format '{{.Id}} {{.State.Running}}' "$container") == "$(jq -r '.[0].Id' "$session/original-container.inspect.json") false" ]] || exit 1
docker rm "$container" > "$session/original-container.removed.txt"
# Create first, persist its exact ID, then foreground attach/start. This lets the
# session monitor distinguish the old stopped instance from the new created one.
new_id=$(docker create --name "$container" --pull never --restart no \
  --cpus 4 --memory 16g --memory-swap 16g \
  --label "otel283.owner=$owner" --label "otel283.profile=$profile" --label 'otel283.role=fdb4-server' \
  --label "otel283.session=$FDB4_SESSION" \
  --mount "type=volume,source=$volume,target=/var/fdb/data,volume-nocopy" \
  --mount "type=bind,source=$here,target=/etc/fdb4,readonly" \
  --publish 127.0.0.1:14683:14683 --publish 127.0.0.1:14684:14684 \
  --publish 127.0.0.1:14685:14685 --publish 127.0.0.1:14686:14686 \
  --env FDB4_OWNER="$owner" --env FDB4_MODE=resume --env FDB_CLUSTER_FILE=/var/fdb/data/cluster/fdb.cluster \
  --entrypoint /usr/bin/tini "$image" -g -- /bin/bash /etc/fdb4/resume-entrypoint.sh)
[[ "$new_id" =~ ^[0-9a-f]{64}$ ]] || exit 1
printf '%s\n' "$new_id" > "$session/instance.id"
docker inspect "$new_id" > "$session/resumed-container.created.inspect.json"
printf 'Start monitor with FDB4_SESSION=%s; readiness is a separate explicit root step.\n' "$FDB4_SESSION" >&2
exec docker start --attach "$new_id"
