#!/usr/bin/env bash
set -Eeuo pipefail
# Executed only by a later, approved launch. Does NOT bootstrap a database.
readonly data=/var/fdb/data
readonly owner=otel283-vxnar
[[ ${FDB4_OWNER:-} == "$owner" ]] || { echo 'Missing owned-launch token' >&2; exit 1; }
# Refuse every populated volume, including a previously initialized FDB4 volume.
# A future resume needs a separate reviewed path; never adopt retained old data.
[[ -d "$data" ]] || { echo 'Missing dedicated data volume' >&2; exit 1; }
[[ -z $(find "$data" -mindepth 1 -maxdepth 1 -print -quit) ]] || {
  echo 'Refusing nonempty data volume; no writes performed' >&2; exit 1;
}
mkdir -p "$data/cluster"
for port in 14683 14684 14685 14686; do
  mkdir -p "$data/processes/$port" "$data/traces/$port"
done
cp /etc/fdb4/fdb.cluster.seed "$data/cluster/fdb.cluster"
printf '%s\n' "$owner" > "$data/.otel283-owner"
chown -R fdb:fdb "$data"
# This is foreground fdbmonitor, not --daemonize. Tini remains PID 1.
exec /usr/bin/fdbmonitor --conffile /etc/fdb4/foundationdb.conf --lockfile /var/run/otel283-fdb4-monitor.pid
