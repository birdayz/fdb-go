# NEXT policy285 preparation

Prepared only: /tmp/fdb-hotelbench.VxNArC/fdb4-config-rw1m0285. Exact run rw1m0285 and session resume-20261027-04. All original fdb4-config source/evidence unchanged, old session03 service untouched. Root alone owns later stop/resume/readiness/declaration/workload. New workload revision/binary/source-input hashes are NOT yet pinned; declare-bulk flags require actual later values.

GREEN249/249: original241 complete tests plus8 tests (oldrun284 rejection; oldsession03 rejection even when supplied matching argument; six predecessor/replacement mount identity tests).48successes/201expected rejections. Nonempty15retained raws:14healthy positives,11belowdrain thresholds, solewarning raw015. Nine shell scripts syntaxchecked; no operational helper invoked except PURE FILE verify-drain. All command argv/expected/actual exits/stdout/stderr retained. Synthetic valid certificate uses distinct canonical retained files with equalcontent hashes.

Frozen source consists14policy files plus separately pinned three original historical bootstrap/launch receipts. Exact source copied under policy-at-validation. Resume's predecessor predicate parsed directly from new resume.sh and tested against retained session03 original-container.inspect.json: OLDread-only bind accepted; NEW/wrong/writable binds and running state rejected. New create command statically asserts source=$here (NEXT). Session04 hardpins added to resume/monitor/readiness/declaration/drain and phase; verify-drain uses exact phase/session/run. Profile/image/volume/config/seed/resources/ports/processchecks/gates unchanged. No existingvolume configuration.

Future du requirement is documented in NEXTREADME: parent and child sizing must be separate read-only invocations, retaining outputs separately; old outputs not rewritten. No performance driver was executed or changed.

No Docker/DB/service/stop/launch/workload actions. No repository source/library/mainREADME/TODO writes. No old policy edits. This static pass is NOT launch approval or live readiness/drain/performance evidence.
