# rw1m0284 timeout diagnosis (read-only)

## Outcome and evidence population

Finalized failed load: 114,720 acknowledged rows / 3,585 acknowledged batches, 47.583190245s, first reported error `batch starting 114720: transaction_timed_out (1031)`, ended 2026-10-27 16:29:22Z. Diagnostics: 3,589 source Runs/closure entries, zero source replays; four Runs lack acknowledged success. The first worker error cancels sibling workers; this does NOT prove four independent timeouts or the exact physical population. No population audit was requested or performed. No sustainable ingestion-rate claim.

Analyzed nine retained monitor raws 000001–000009, monitor timestamps 16:28:34–16:29:54Z: five at/before load end, four afterward; plus the three existing certified strict-drain raws. These are coarse status snapshots, not traces of the failed transaction. Monitor timestamps precede completion of admin requests (the batch probe can wait five seconds); rates/probe observations have different windows. Complete numeric extraction: metrics.tsv / metrics.json. Raw paths and hashes: source-and-provenance-command.json.

## Corroborated backpressure, not a proven timeout stage

| Monitor time | Default GRV s | Commit probe s | Worst storage queue B | Durability lag s | Log queue B | Default TPS limit / released |
|---|---:|---:|---:|---:|---:|---:|
|16:28:44|0.000229|0.005197|623482435|6.786|170291497|275.62 / 118.79|
|16:28:55|0.000327|0.006491|901412940|15.057|239141118|274.83 / 74.40|
|16:29:04|0.457146|0.008050|1055500247|29.447|273068309|24.34 / 25.80|
|16:29:15|0.090677|0.702300|1000386405|35.573|272979477|232.48 / 67.14|
|16:29:24 (post-end)|0.002207|0.185384|937647435|39.563|273662004|4455.77 / 29.76|

At 16:29:04, both default and batch limiting reasons explicitly name `storage_server_write_queue_size`, server ID 8452c6420620447c (14683). Batch TPS limit was already 15.68 at 16:28:55. Raw000004 aggregate healthy=false with the sole batch-start timeout; it was admitted by the bounded exception, NOT healthy=true. Other selected raws are aggregate healthy=true; all nine report available/data healthy/fully_recovered, degraded=0 and empty client/process messages. Ratekeeper source computes queue-derived TPS constraints from smoothed durable/input rates (Ratekeeper.actor.cpp:860–904).

Storage/log rates are reported role `hz` values, not device throughput. At16:28:44 storage14683 input/durable=65.59/28.33 MB/s, storage14686=33.89/20.97; log=17.31/6.24. At16:29:04 they are6.40/22.01,24.26/0.0038,1.66/5.43 MB/s respectively; at16:29:15 they are8.46/15.99,17.49/28.15,5.05/3.58. Uneven storage durability/queue buildup and explicit RK limits corroborate backpressure; no single bottleneck mechanism is proven.

Sampled total server CPU before load end peaks1.765 cores (individual storage approximately0.75 each at16:29:04) under4CPU cap. App perf reports28.391s task-clock /47.592s elapsed (~0.60 cores). These do not prove absence of transient CPU scheduling/throttling. Process disk counters/busy are all zero in these status samples and cannot establish an idle device or diagnose disk latency. PIDs stable; sampled RSS below4GiB/process; peak cgroup6.435GB, host available minimum33.436GB, disk free minimum431.473GB. No evidence here of a resource gate or monitor termination.

Commit/read status probes use SYSTEM_IMMEDIATE priority (Status.actor.cpp:1359–1363,1416–1421); successful probes and their <5s validation do NOT establish a normal workload transaction's1500ms budget was met. Recorded aggregate phase totals (manifest67.200s,open17.181s,save28.751s,successful commits71.287s) overlap across four workers and do not identify the failed stage; successful-only commit timer omits failed commits.

## Exact pinned C++ semantics and application timing

Upstream source HEAD3ea44ce1d9003ad095e408039e1f755c319c4dfb (7.3.77):

- error_definitions.h:58 defines1031 as transaction_timed_out, operation aborted because transaction timed out.
- ReadYourWrites.actor.cpp:1550–1553,1567–1578,2570–2573 anchors timeout to creationTime+configured duration, not time of SetTimeout. Timebomb poisons pending/future operations. API>=610 retains timeout across successful onError retries; explicit reset establishes a fresh creationTime (2735–2754). Options documentation291–294 agrees.
- NativeAPI.actor.cpp:7743–7779 does NOT list1031 among onError-retryable codes; it returns the original error. RYW onError1499–1533 also propagates an already-poisoned resetPromise. A fresh application-level transaction retry is distinct from changing FDB's onError classification.
- A timeout during commit does NOT prove noncommit: RYW commit races resetPromise against native commit (1381,1405), diagnostic code labels1031 `Maybe committed` (1454–1459), and options311 explicitly warns a timed-out commit may already have succeeded or may succeed later. In-flight simulation1337–1349 deliberately exercises later commit after timeout. This is a supported possibility, NOT evidence this particular failed batch committed.

Pinned app revision692a42505133f7f42030bc9ba91c65f8d7828d14 reads manifest before b.open in saveIngestBatch (ingest.go:144–152); b.open sets1500ms timeout (fdb.go:88–95). Pinned Go stateSetTimeout likewise anchors to creationTime (transaction.go:2578–2584). Manifest/GRV wait can therefore consume the creation-relative budget before the timeout is armed, leaving little/no time at open/save/commit. This is source-backed exposure, not proof of the actual failed stage. Merely moving SetTimeout earlier bounds manifest wait consistently; it does not enlarge the1500ms budget or remove backpressure.

## Implications for proposed app work (not implemented)

Bounded, cancelable, backoff-controlled fresh-Run retries for1031 are an application policy worth testing, not a core client bug fix. Preserve FDB1031 terminal onError behavior and all server/resource/size/time guards. Configure timeout before manifest, for every new transaction. Reuse immutable batch payloads but reopen/reread current record state and perform the normal safe old/new index maintenance each fresh transaction; do not replay a captured stale mutation set, add non-idempotent increments, double-count ACKs or mark loading ready after exhaustion. A timed-out previous commit may have succeeded or still be in flight, so semantic duplicate replay safety and conflict coverage need explicit tests. Current receipts do not prove that safety automatically.

Existing strict-drain certificate completed16:30:47Z, with strict samples16:30:37/42/47: queue1414544/269565/203276B, lag9.58839/5.25791/5.18328s, aggregate/data healthy=true and no messages. This proves the recorded drain conditions, NOT successful ingestion or exact population.

Only new analysis files were written. No source/policy/service modifications, Docker/DB actions, new workload, audit, query, build or test job occurred.
