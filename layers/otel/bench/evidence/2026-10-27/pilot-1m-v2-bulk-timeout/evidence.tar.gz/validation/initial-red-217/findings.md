# Static validation findings

No policy edits and no Docker/server/DB actions occurred. The frozen prepared manifest verified both before and after the 217-test run. 213 expectations matched; all four mismatches are additional adversarial certificate/document-contract checks.

1. Two concatenated valid healthy JSON objects produce two accepted summaries with exit 0 from both strict and bulk jq invocations. These are tests status-two-json-documents-strict and status-two-json-documents-bulk. A jq filter normally streams all top-level JSON values. Monitor/readiness/drain use the same non-slurping invocation, although later --argjson use may incidentally abort on multiple summaries. No live script was run to claim end-to-end behavior.
2. verify-drain.sh accepts one raw file referred to by all three samples, with different certificate epochs. It checks length and spacing but not distinct paths (lines 16–23,27–34). Actual drain.sh generates unique increasing raw filenames; the finding is acceptance of a forged/replayed certificate rather than evidence that the producer does this.
3. verify-drain.sh accepts a sample raw path containing drain-raw.fixture/../status-outside.json (exit 0). The lexical shell glob at line 29 does not canonicalize paths. The escaped file remains inside this synthetic run directory; this demonstrates violation of drain-raw containment. Actual drain.sh-generated paths do not contain dot-dot.

Complete results and exact command paths: summary.json and commands-results.jsonl. No patch was made to turn these tests green. Root decision required before any policy revision.

Source-hash scope: bulk-phase.jq checks source hash/revision syntax; a different valid hexadecimal source hash is intentionally format-valid. The separate byte-for-byte phase-pin digest guard rejects changed bytes. The pure verifier also rejects source/pin/hash mutations in certificate tests. These synthetic files do not constitute ingestion success, real-time DB observations, or a real strict drain.
