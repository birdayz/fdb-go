# Validate the exact separately identified bulk-monitor arm. No wildcard phase.
# Call with --arg instance --arg session --argjson now; returns original metadata.
def uint: type == "number" and . >= 0 and floor == . and . < 1e15;
# A pinned phase is exactly one document, not a stream of candidate phases.
if ([limit(1; inputs)] | length) != 0 then error("Expected exactly one bulk phase document") else . end |
if (type == "object"
    and .schema == "otel283_bulk_monitor_v1"
    and .policy == "exact-batch-probe-warning-v1"
    and .phase == "bulk_ingest_and_drain"
    and .owner == "otel283-vxnar"
    and .profile == "fdb4-4cpu-16g-v1"
    and .instance == $instance and (.instance | test("^[0-9a-f]{64}$"))
    and .session == $session
    and .run == "rw1m0284"
    and (.source.revision | type == "string" and test("^[0-9a-f]{40}$"))
    and (.source.binary_sha256 | type == "string" and test("^[0-9a-f]{64}$"))
    and (.source.manifest_sha256 | type == "string" and test("^[0-9a-f]{64}$"))
    and (.started_epoch | uint) and (.deadline_epoch | uint)
    and .started_epoch <= $now and .deadline_epoch > $now
    and .deadline_epoch > .started_epoch
    and .deadline_epoch - .started_epoch <= 3600)
then . else error("Invalid/expired instance/session/run/source/deadline bulk phase") end
