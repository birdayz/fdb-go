# Owned FDB4 runtime profile and explicit resume — prepared for root review

## Actual state and preserved first stop

The fresh four-process, 4-CPU/16-GiB Redwood database was launched and bootstrapped successfully. At the FIRST stop no dataset had been loaded: initial readiness was too early, with `cluster.data.state` still `initializing` and no `healthy` boolean. That strict stop remains valid. Later resume session02 reached strict readiness, then its 1M pilot was stopped externally by the monitor on the sole batch-priority start-probe warning after 143,264 acknowledged rows. That partial loading run `rw1m0283` and all receipts remain preserved; no DB crash or successful 1M/sustained-rate claim follows. A NEW separately identified `exact-batch-probe-warning-v1` monitor-policy arm is now prepared for new run **`rw1m0284`** in new session03, with unchanged server/resource/backlog settings. No automatic ingestion resume is implemented.

All original files remain, including the original root-level `bootstrap.ready`, logs, JSONL, readiness status, bootstrap receipt and source manifest. BEFORE this policy amendment, the exact monitor/filter/readiness source used at session02 abort was copied without overwrite to `sessions/resume-20261027-02/code-at-abort/`; its raw status files and all session02 receipts remain untouched. A separate immutable-by-convention copy of the complete pre-amendment file population is in **`initial-stop-20261027T151321Z/`**. Do not overwrite/delete either population. Initial raw invalid monitor status was not retained by the old monitor; root's `readiness.json` documents initialization. New monitor/readiness code preserves every raw result before validation, even empty, malformed or timed-out output.

Current stopped container: `otel283-fdb4-vxnar`.
Existing owned volume: **`otel283-vxnar-fdb4-redwood16-v1`**.
Owner/profile labels: `otel283.owner=otel283-vxnar`, `otel283.profile=fdb4-4cpu-16g-v1`.
The old 4-GiB SQLite pilot and its retained-volume holder are separate and must never be adopted, reconfigured or removed by this workflow. Root may archive and then explicitly drop only the owned partial `rw1m0283` application run after approved recovery; these runtime helpers do NOT drop or resume it.

Only files were prepared/archived during this amendment. No Docker action, configure command, launch, validation job or test was run by its author. Root will statically review and validate before executing any future command below.

## Frozen source and resource envelope

- Image: `foundationdb/foundationdb@sha256:559b178a137bbe09272ad6e3752531aa04e2ddacab8ccfa4ffa86467db033bea`.
- Matching local source: `/home/birdy/.local/share/fdb-perf/fdbsrc`, commit `3ea44ce1d9003ad095e408039e1f755c319c4dfb` (FoundationDB 7.3.77).
- Unchanged config SHA-256: `6b2b4e0e85fba430d99ea8710778c6776a95326246ae6e45109192327e242b1f`.
- Unchanged seed SHA-256: `88eea690f206eac6e9d532cadc882fe4945da0c4aa0f6d6eb55e5ee1615eed3e`.
- Cluster identity/seed: `otel4:otel4@127.0.0.1:14683`.
- Four aggregate CPU quota, 16-GiB container memory, no additional swap allowance; 4-GiB per-server RSS ceilings. Default queue knobs, NOT earlier experimental reduced queues.
- Storage caches 2 GiB each; transaction/stateless caches 64 MiB each. RSS kill ceilings are not allocations/reservations; process sums do not guarantee cgroup headroom.

| Port | Class / expected recruited roles | Preserved process directory | Cache |
|---|---|---|---|
| 14683 | storage + coordinator | `/var/fdb/data/processes/14683` | 2 GiB |
| 14684 | transaction / log | `/var/fdb/data/processes/14684` | 64 MiB |
| 14685 | stateless / commit proxy, GRV proxy, resolver, master, controller | `/var/fdb/data/processes/14685` | 64 MiB |
| 14686 | storage | `/var/fdb/data/processes/14686` | 2 GiB |

All four ports are mapped loopback-to-same-loopback port. All data and separate `/var/fdb/data/traces/PORT` directories are on this named volume. Same machine/zone locality is deliberate: one host/disk/failure domain, single redundancy, **not HA**. The process classes are recruitment preferences, so readiness checks actual roles.

Redwood is the FIRST fresh scale-profile engine. Exact source `experimental-features.rst` classifies Redwood as production-ready in 7.3; `ManagementAPI.actor.cpp:269–274` accepts `ssd-redwood-1` and still selects SQLite for log spill. This is not a claim of measured performance, capacity or production suitability. Old 4-GiB SQLite versus new 16-GiB Redwood is not an engine-only comparison. A later engine A/B requires separate fresh owned volumes and matched envelopes.

Upstream `configuration.rst:180–318` supports foreground fdbmonitor sections, `$ID`/`$PID`, distinct data directories and memory/cache settings. `fdbserver.actor.cpp` implements the supported arguments. Default queue thresholds are in `ServerKnobs.cpp:839–890`. Raw status fields/role names come from matching `Schemas.cpp` and preserved real receipts. No server config or fresh entrypoint was changed for resume.

## Capacity and comparison gates

Before resume, root must approve the frozen source, validation result and capacity gate. `resume.sh` requires **at least 24 GiB current host MemAvailable** for the 16-GiB incremental envelope plus 8-GiB reserve, and **at least 200 GiB free on the Docker filesystem**. The continuous monitor retains the 8-GiB host floor and disk floor. A 16-GiB cap is not a reservation or a fit proof.

The approximately 38.7-GiB available-memory observation allowed that initial reservation, subject to a fresh check. Old CH approximately 0.3-GiB residency under its old 4-GiB cap is already reflected in available memory and is not a comparative arm. Matched CH/FDB 4-CPU/16-GiB services will run **sequentially**, not concurrently. Root may run CH100M first, explicitly clean up only owned CH data, then attempt retained FDB100M. Logical KV bytes are not physical allocated size. Include protected old volumes, transaction logs, trace files, engine allocation and maintenance growth; the 200-GiB pilot floor does not prove 100M fits.

## Explicit owned resume (no bootstrap)

The original `launch.sh` and `container-entrypoint.sh` remain fresh-only and must NOT be used on this populated volume. The new `resume.sh` / `resume-entrypoint.sh` provide a separate reviewed path:

1. Require `FDB4_RESUME_APPROVED=yes`, `FDB4_CAPACITY_GATE_APPROVED=yes`, `FDB4_16G_APPROVED=yes` and a NEW safe `FDB4_SESSION` name. Refuse an existing session directory.
2. Verify original launch and successful bootstrap receipts, pinned config/seed/image, stopped container labels/image/resource envelope/config mount, named volume labels, and no active container mounting that volume.
3. Capture stopped-container inspect, image/volume inspect and stdout/stderr before metadata removal. Read the owner marker, existing cluster file and all four nonempty `processId` files via Docker cp from the stopped container; preserve copies in the new session. Existing cluster must match the pinned identity; changes fail closed for explicit review, never seed overwrite.
4. After checks, remove ONLY the stopped container's metadata using `docker rm` **without force or volume flags**. Never create, initialize or delete a volume. Named volume remains intact even if recreation fails. Snapshot receipts preserve the original container identity.
5. Create a replacement with the same name, exact existing volume, pinned image/config, same ports/resources/locality, plus `otel283.session=SESSION`. Persist its exact `instance.id` before foreground `docker start --attach`.
6. The resume entrypoint verifies owner/cluster/config and every existing process/trace directory, then runs foreground Tini → fdbmonitor. It contains **no configure, mkdir, seed overwrite, chmod or chown** of existing data. Normal FDB recovery is writable and can alter files; this is not read-only forensics.

Any failed check leaves artifacts and data retained. If removal succeeds but replacement creation fails, there is no implicit fallback to fresh launch: root reviews the saved receipt and a recovery-specific recreation. Do not rerun blindly. There is no auto-remove option. Preserve required forensic snapshots before any writable recovery if that is a new obligation.

Future explicit root command, under the runtime's tracked background mechanism (not shell `&`/nohup):

```sh
FDB4_RESUME_APPROVED=yes FDB4_CAPACITY_GATE_APPROVED=yes FDB4_16G_APPROVED=yes \
  FDB4_SESSION=resume-UNIQUE_NEW_SESSION \
  bash /tmp/fdb-hotelbench.VxNArC/fdb4-config/resume.sh
```

**NEVER run `configure new` on this existing volume.** Original bootstrap receipts are historical evidence only. Engine migration or old-volume adoption is not part of resume.

## Session monitor and raw evidence

All new output goes to `sessions/SESSION/`; original root-level monitor files and ready marker are ignored and retained unchanged. Each session has an independent PID baseline, raw status sequence and new ready marker. `monitor.sh` requires the prepared session receipt and refuses an existing monitor PID file or session marker. It waits for the session's exact `instance.id`; this prevents mistaking the old stopped container for the resumed one. A created-but-not-started new instance has bounded startup grace.

Start a new monitor immediately with resume, before readiness/workload:

```sh
FDB4_SESSION=resume-UNIQUE_NEW_SESSION \
  FDB4_MIN_DISK_AVAILABLE_BYTES=214748364800 \
  MAX_STORAGE_QUEUE_BYTES=536870912 MAX_DURABILITY_LAG_SECONDS=60 \
  bash /tmp/fdb-hotelbench.VxNArC/fdb4-config/monitor.sh
```

Always-active gates: host available below 8 GiB; disk free below 200 GiB (or reviewed higher threshold); cgroup charged memory at least 90% of 16 GiB; OOM/container restarts; fdbserver process/PID change after initial census; invalid resource accounting. Monitor abort may stop ONLY the exact session instance with verified labels; never removes data. It has a 60-second graceful stop timeout. Sampling is an abort aid, not an instantaneous resource guarantee.

Before the new `sessions/SESSION/bootstrap.ready`, monitor performs resource/PID checks only, not admin status. After it appears, each nominal-ten-second admin sample uses a ten-second fdbcli timeout plus bounded exec transport. **Stdout is written to `monitor-raw/status-NNNNNN.json` before parsing**; errors/timeouts preserve empty or truncated output too. `status-errors.log`, `monitor.log` and compact `monitor.jsonl` are session-local. JSONL includes raw-file path, validated queue/lag, process roles/memory, resource measurements and streak. Monitor PID/exit evidence is session-local; never reset a failed session to hide a stop.

`status-check.jq` is a pure fail-closed validator/projection, STRICT by default. Readiness explicitly passes `allow_batch_warning=false`. It requires client availability/quorum/up-to-date cluster file; empty client/process/configuration issues; cluster availability; **`cluster.data.state.healthy == true`**; **`cluster.recovery_state.name == fully_recovered`**; zero degraded processes; exact single/Redwood/SQLite-log configuration/counts; four expected addresses/classes/locality/4-GiB limits and actual role placement; finite successful default/immediate-GRV/read/commit probes; and typed queue/lag/RSS values. Missing health is NOT true. Normally aggregate health must be true and cluster messages empty. The ONLY exception is the separately declared bounded bulk arm below; no unknown/additional warning is accepted. Optional configuration-message absence follows the exact upstream aggregate semantics, not a default-zero health conversion.

Backlog gates are unchanged: worst storage queue strictly above **536,870,912 bytes** AND worst durability lag strictly above **60 seconds**, for **six consecutive valid nominal-ten-second samples**, cause abort. Either falling to/below its threshold resets the streak. These maxima may describe different storage processes. No zero substitutions, no queue-knob changes, no relaxation to tolerate initialization after readiness. Changing thresholds requires a separately reviewed profile.

## Explicit root readiness and end-load drain

`readiness.sh` is a separate admin-read-only root step, not bootstrap or workload. It requires an active session monitor and explicit `FDB4_MARK_READY_APPROVED=yes`. Over at most 300 seconds, it captures every raw result before validation and waits for **three consecutive nominal-five-second samples** satisfying the full strict status/role/recovery validator AND worst queue **strictly below 16 MiB** AND worst lag **strictly below 10 seconds**. Initialization/unhealthy/malformed results reset the readiness streak and remain preserved; they do not become successful missing-data defaults.

```sh
FDB4_SESSION=resume-UNIQUE_NEW_SESSION FDB4_MARK_READY_APPROVED=yes \
  bash /tmp/fdb-hotelbench.VxNArC/fdb4-config/readiness.sh
```

Only after those three valid samples does the helper atomically publish a new **session-local** `bootstrap.ready` containing instance/session and readiness contract. Root must inspect its receipts before permitting any workload. Neither marker creation nor the helper starts a workload. A failed readiness attempt publishes no marker and retains evidence; a later explicit attempt uses a new unique raw directory. The original root-level prematurely published marker is historical and never reused.

After load, the declared bulk arm must complete `drain.sh` below: three STRICT healthy/recovered/role-correct samples below 16 MiB/10 seconds, with a verifiable raw-status certificate, before the bulk marker is removed or the phase completes. Keep the session `bootstrap.ready` marker throughout; removing/recreating it is still a monitor abort. The bulk-warning allowance remains bounded during drain observation so expected low-priority starvation cannot prevent observing recovery, but it cannot certify the final drain. Without strict initial readiness, completed population audit and strict end drain, measurements are profiling only, not sustained-throughput/capacity claims. A larger ceiling does not excuse queue growth.

## NEW bounded bulk-warning policy arm (server settings unchanged)

Exact 7.3.77 source separates availability from aggregate health. `Status.actor.cpp:1371–1453` does not attach the availability flag to the batch GRV probe; its five-second timeout adds `batch_priority_transaction_start_probe_timeout`. `StatusClient.actor.cpp:460–496` marks aggregate healthy false for ANY cluster message. GRV prioritization serves system/default before batch (`GrvProxyServer.actor.cpp:922–946`). This justifies classifying ONLY that warning during a bounded load/drain operation, not ignoring health generally. Read/commit status probes use system-immediate priority, so their success is not a default query/commit SLA proof.

The monitor never rewrites raw or summary health to true. Summary records `aggregate_healthy_original`, `health_exception_used`, exact `warning_names`, queue/lag, default/batch limiting reasons and probe values. Monitor JSONL records declared phase/source/hash and cumulative warning samples / bulk-status samples / fraction. One warning sample remains operational evidence of backpressure, not a successful capacity measurement.

The sole warning is accepted only when ALL ordinary structural checks above pass, aggregate healthy is explicitly false, the sole cluster message name is exactly the batch-probe timeout, no batch-success result contradicts that timeout, client/process/configuration issue lists are empty, and the four required nonbatch probe results are finite, nonnegative and below the source five-second timeout. Healthy samples must have aggregate healthy true and no cluster messages. Unknown/additional messages, default/immediate/read/commit failures, incomplete recovery, missing health, degraded processes, role/PID/resource changes and malformed data still abort. Server queues and 4-GiB ceilings remain unchanged.

### Declare once, only after strict readiness

Root must explicitly approve a new session03 operation and supply the frozen source revision, exact workload binary, source/input manifest and bounded duration. `declare-bulk.sh` hashes the two real files and binds them into `source`; revision is the explicit root-provided 40-hex source pin. Root remains responsible for validating that source manifest and before/after source freeze. This helper does not invoke the workload or touch FDB.

```sh
FDB4_SESSION=resume-20261027-03 FDB4_DECLARE_BULK_APPROVED=yes \
  FDB4_SOURCE_REVISION=ROOT_FROZEN_40_HEX_REVISION \
  FDB4_BINARY=/absolute/path/to/frozen/workload-binary \
  FDB4_SOURCE_MANIFEST=/absolute/path/to/frozen/source-input-manifest \
  FDB4_BULK_SECONDS=ROOT_APPROVED_POSITIVE_INTEGER_AT_MOST_3600 \
  bash /tmp/fdb-hotelbench.VxNArC/fdb4-config/declare-bulk.sh
```

The operation is fixed to run **`rw1m0284`** and policy `exact-batch-probe-warning-v1`. Root must use that exact run/source/binary for ingestion; no normal audit/query benchmark is allowed during this phase. The marker schema includes `schema=otel283_bulk_monitor_v1`, `phase=bulk_ingest_and_drain`, exact owner/profile/instance/session/run, source revision plus binary/manifest SHA-256, start epoch and hard deadline. Duration is explicitly supplied and at most one hour; no extension, in-place edit or reuse is allowed. `bulk-phase.jq` validates it. `bulk-pin.json` preserves the original metadata; monitor pins its full byte digest and rejects changes/removal without a verified certificate. A pending file is linked atomically to `bulk-phase.json` only after pin publication.

`declare-bulk.sh` waits up to 30 seconds for the monitor's instance/session/phase-hash acknowledgement before returning. Root must wait for that successful return before starting ingestion; it is not enough to notice the file exists. This avoids starting the load while the monitor is still processing a pre-declaration strict sample. A failed declaration leaves evidence and starts no workload; never extend its deadline to retry until green.

No marker means strict normal policy. A bulk declaration before session readiness aborts. During a valid active marker, monitor may enable the exact warning filter, including while observing drain. It rechecks metadata/deadline BEFORE and AFTER each potentially ten-second status request. Expiry fails closed, even if the next status is otherwise healthy; it does not silently extend or end the operation. Resource gates and six-sample **512-MiB queue AND 60-second lag** gate continue unchanged.

### Strict final-drain certificate, then normal strict phases

After the workload terminates, root inspects and finalizes its outcome receipt. Invoke `drain.sh` explicitly, pointing to that immutable receipt. The receipt can document failure; a drain certificate proves only strict drain, NOT successful 1M ingestion, audit, completeness, sustainable rate or 100M capacity.

```sh
FDB4_SESSION=resume-20261027-03 FDB4_CERTIFY_DRAIN_APPROVED=yes \
  FDB4_LOAD_RECEIPT=/absolute/path/to/finalized/load-outcome-receipt \
  bash /tmp/fdb-hotelbench.VxNArC/fdb4-config/drain.sh
```

The helper is admin-read-only with respect to FDB. It retains every raw response, uses `allow_batch_warning=false`, and requires three consecutive strict samples at least five seconds apart with worst queue <16 MiB and lag <10 seconds. Warnings/invalid samples reset its streak; it cannot outlive the declared deadline. Monitor stays active with the narrowly permitted warning during this observation. If the deadline or another gate fails, preserve the failed arm rather than extending until green.

`drain.certificate.json` binds the exact phase hash/instance/session/run/source, completion epoch before deadline, the three raw-file paths and byte hashes/observation epochs, and the finalized load receipt path/hash. `verify-drain.sh` is PURE FILE validation: it revalidates the phase at certificate time, all raw hashes and strict filter outcomes, sample spacing/low queue-lag, and receipt hash. No certificate can accept the warning or merely assert health without retained raw proof.

The helper publishes and verifies the certificate BEFORE preserving the active marker as `bulk-phase.completed.json` and removing only `bulk-phase.json`. The monitor independently verifies the certificate before accepting removal; as soon as a valid certificate exists the monitor returns to strict policy even if the active marker has not yet been removed. Certificate changes/removal fail closed. `bootstrap.ready` is never removed. Audit/query/other normal phases remain strict; no second bulk phase is permitted in the same session. Run failure receipts and all status artifacts remain immutable evidence.

### Memory interpretation and failure classification

Keep 4-GiB per-process ceilings for this isolated policy arm. Linux `memory.used_bytes` is sourced from virtual address-space size (`Platform.actor.cpp:361–376`); the RSS kill monitor uses resident bytes (`SystemMonitor.cpp:462–474`). Used bytes near 4 GiB did not cause session02's external monitor stop. No process restart/OOM or DB crash is established. Increasing every ceiling would be a separate changed baseline, not a fix for the batch warning. No successful rate is inferred from partial ACK rows before the external stop.

## Review/validation boundary

These scripts/filter are prepared source, not executed validation. Root owns shell/filter fixture checks, resource gate, resume launch and monitoring. The initial initializing status should FAIL the strict shared filter; do not mutate that evidence to make it pass. Test fixtures may be new files under a new session or separate runtime review directory, not edits to original receipts. Keep old stopped services/holders and their receipts untouched.
