#!/usr/bin/env bash
set -Eeuo pipefail
# PURE FILE verification; no Docker or FDB operations. Used by monitor/helper.
readonly here=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
[[ $# == 4 ]] || exit 1
readonly run_dir=$1 instance=$2 session=$3 phase_hash=$4
readonly cert="$run_dir/drain.certificate.json"
[[ $(sha256sum "$run_dir/bulk-pin.json" | awk '{print $1}') == "$phase_hash" ]] || exit 1
completed=$(jq -er '.completed_epoch' "$cert")
jq -ce --arg instance "$instance" --arg session "$session" --argjson now "$completed" -f "$here/bulk-phase.jq" "$run_dir/bulk-pin.json" >/dev/null
jq -e --arg instance "$instance" --arg session "$session" --arg hash "$phase_hash" --slurpfile phase "$run_dir/bulk-pin.json" '
  .schema == "otel283_strict_drain_v1" and .instance == $instance and .session == $session
  and .run == "rw1m0284" and .phase_sha256 == $hash and .source == $phase[0].source
  and (.completed_epoch | type == "number" and floor == .)
  and .completed_epoch >= $phase[0].started_epoch and .completed_epoch < $phase[0].deadline_epoch
  and (.samples | type == "array" and length == 3)
  and all(.samples[];
    (.epoch | type == "number" and floor == .) and .epoch >= $phase[0].started_epoch
    and (.raw_path | type == "string" and length > 0)
    and (.sha256 | type == "string" and test("^[0-9a-f]{64}$")))
  and .samples[1].epoch - .samples[0].epoch >= 5
  and .samples[2].epoch - .samples[1].epoch >= 5
  and .samples[2].epoch <= .completed_epoch
  and (.load_receipt | type == "string" and length > 0)
  and (.load_receipt_sha256 | type == "string" and test("^[0-9a-f]{64}$"))
' "$cert" >/dev/null
for i in 0 1 2; do
  raw=$(jq -er --argjson i "$i" '.samples[$i].raw_path' "$cert")
  case "$raw" in "$run_dir"/drain-raw.*/status-*.json) ;; *) exit 1 ;; esac
  expected=$(jq -er --argjson i "$i" '.samples[$i].sha256' "$cert")
  [[ $(sha256sum "$raw" | awk '{print $1}') == "$expected" ]] || exit 1
  jq -ce --argjson allow_batch_warning false -f "$here/status-check.jq" "$raw" |
    jq -e '.aggregate_healthy_original == true and .health_exception_used == false and .queue_bytes < 16777216 and .durability_lag_seconds < 10' >/dev/null
 done
receipt=$(jq -er '.load_receipt' "$cert")
[[ $(sha256sum "$receipt" | awk '{print $1}') == "$(jq -er '.load_receipt_sha256' "$cert")" ]] || exit 1
jq -c '{phase_sha256,instance,session,run,source,completed_epoch,strict_samples:(.samples|length),load_receipt_sha256}' "$cert"
