# Post-run tool notes

First receipt-freezing script attempted to import node:crypto, rejected by the script sandbox with ERR_NO_CRYPTO before any file effects. A subsequent explicit test confirmed policy-at-validation did not exist. No validation was rerun.

The follow-up shell accidentally invoked sha256sum -c with an absolute manifest path from the repository working directory rather than the policy working directory. As expected, its relative paths found repository README.md (mismatch) and could not find the 13 policy files. This is not a policy mutation result. Correct cwd manifest checks passed inside the validation harness both before and after tests; post-run-source-inspection.json records another correct-cwd check.
