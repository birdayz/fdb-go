# Pure-file policy validation receipt

No Docker/server/database action was executed. Approved policy corrections preceded this independent run; frozen policy source was not edited during it. `validate.mjs` generates isolated fixtures, records every external command and output, and executes only bash syntax checks, jq validators, literal SHA equality guards, SHA-256 commands and the pure-file verify-drain helper.

Input provenance and nonempty retained populations are in `provenance.json`. Complete argv/working directory/expected and actual exits/output paths are in `commands-results.jsonl`; commands are also listed in `commands.sh`. `commands.sh` is a command receipt, not a set-e replay script: many commands intentionally return nonzero. Reproduction starts with `node validate.mjs` in a NEW empty directory holding a copy of the harness; it refuses existing fixture directories.

Synthetic certificates do not prove any ingestion success or real-time DB observations. Different valid source hashes are format-valid declarations; the separate byte-digest guard rejects mutation relative to an already pinned phase. Additional adversarial cases test repeated raw-file references and lexical path traversal, beyond actual helper-produced certificates.

Summary: 241 tests; 241 matched expectations; 0 mismatches. See `summary.json` for exact failures.
