import fs from 'node:fs';
import path from 'node:path';
import {spawnSync} from 'node:child_process';

const out=path.dirname(new URL(import.meta.url).pathname);
const policy='/tmp/fdb-hotelbench.VxNArC/fdb4-config';
const retained=policy+'/sessions/resume-20261027-02/monitor-raw';
for(const sub of ['results','status-fixtures','phase-fixtures','cert-fixtures'])fs.mkdirSync(out+'/'+sub);
const records=[];let sequence=0;
const quote=s=>"'"+String(s).replaceAll("'","'\\''")+"'";
const clone=x=>JSON.parse(JSON.stringify(x));
const save=(file,data)=>{fs.writeFileSync(file,typeof data==='string'?data:JSON.stringify(data,null,2)+'\n');return file;};
function command(kind,name,exe,args,expected=null,extra=null){
  if(!['bash','jq','sha256sum'].includes(exe))throw Error('Forbidden validation executable '+exe);
  if(exe==='bash'&&args[0]!=='-n'&&args[0]!=='-c'&&args[0]!==policy+'/verify-drain.sh')throw Error('Forbidden policy execution');
  const n=++sequence;const id=String(n).padStart(4,'0')+'-'+name.replace(/[^a-zA-Z0-9_-]/g,'_');
  const r=spawnSync(exe,args,{cwd:policy,encoding:'utf8',timeout:20000,maxBuffer:16*1024*1024});
  const stdout=r.stdout??'',stderr=r.stderr??'';
  save(out+'/results/'+id+'.stdout',stdout);save(out+'/results/'+id+'.stderr',stderr);
  let met=expected===null?null:(expected?r.status===0:r.status!==0);
  let assertion=null;
  if(extra&&r.status===0){try{assertion=extra(stdout);if(!assertion)met=false;}catch(e){assertion=String(e);met=false;}}
  const row={sequence:n,kind,name,cwd:policy,command:[exe,...args],shell_command:'cd '+quote(policy)+' && '+[exe,...args].map(quote).join(' '),expected_success:expected,exit_code:r.status,signal:r.signal,error:r.error?String(r.error):null,expectation_met:met,extra_assertion:assertion,stdout_file:'results/'+id+'.stdout',stderr_file:'results/'+id+'.stderr'};
  records.push(row);fs.appendFileSync(out+'/commands-results.jsonl',JSON.stringify(row)+'\n');
  fs.appendFileSync(out+'/commands.sh',row.shell_command+'\n');
  return {row,stdout,stderr,code:r.status};
}
function sha(file){const r=command('setup','sha256-'+path.basename(file),'sha256sum',[file]);if(r.code!==0)throw Error('Hash failed '+file);return r.stdout.split(/\s/)[0];}
function status(name,obj,allow,expected,assertion=null){
  const file=save(out+'/status-fixtures/'+name+'.json',obj);
  const args=['-ce'];if(allow!==undefined)args.push('--argjson','allow_batch_warning',JSON.stringify(allow));args.push('-f',policy+'/status-check.jq',file);
  return command('test','status-'+name,'jq',args,expected,assertion);
}
function statusBoth(name,obj){status(name+'-strict',obj,false,false);status(name+'-bulk',obj,true,false);}

command('test','frozen-manifest-before','sha256sum',['-c',policy+'/bulk-policy-prepared.sha256'],true);
for(const file of fs.readdirSync(policy).filter(x=>x.endsWith('.sh')).sort())command('test','bash-n-'+file,'bash',['-n',policy+'/'+file],true);
const originals=fs.readdirSync(retained).filter(x=>/^status-\d+\.json$/.test(x)).sort().map(file=>({file:retained+'/'+file,json:JSON.parse(fs.readFileSync(retained+'/'+file,'utf8'))}));
const healthy=originals.filter(x=>x.json.client?.database_status?.healthy===true&&x.json.cluster?.data?.state?.healthy===true);
const low=healthy.filter(x=>x.json.cluster.qos.worst_queue_bytes_storage_server<16777216&&x.json.cluster.qos.worst_durability_lag_storage_server.seconds<10);
const warning=originals.find(x=>x.json.cluster?.messages?.length===1&&x.json.cluster.messages[0].name==='batch_priority_transaction_start_probe_timeout');
if(!healthy.length||!low.length||!warning)throw Error('Vacuous retained positive population');
const provenance={retained_status_count:originals.length,healthy_positive_count:healthy.length,strict_low_queue_lag_count:low.length,warning_source:warning.file,healthy_source:low[0].file,input_sha256:{}};
for(const x of originals)provenance.input_sha256[x.file]=sha(x.file);
save(out+'/provenance.json',provenance);
for(const x of healthy){const name='retained-'+path.basename(x.file,'.json');status(name+'-strict',x.json,false,true,s=>{const x=JSON.parse(s);return x.aggregate_healthy_original===true&&x.health_exception_used===false&&x.warning_names.length===0;});status(name+'-bulk',x.json,true,true);}
status('sole-warning-default-strict',warning.json,undefined,false);
status('sole-warning-explicit-strict',warning.json,false,false);
status('sole-warning-explicit-bulk',warning.json,true,true,s=>{const x=JSON.parse(s);return x.aggregate_healthy_original===false&&x.health_exception_used===true&&x.warning_names.length===1&&x.warning_names[0]==='batch_priority_transaction_start_probe_timeout'&&x.queue_bytes===warning.json.cluster.qos.worst_queue_bytes_storage_server;});
const base=clone(low[0].json),warn=clone(warning.json);
statusBoth('malformed','{');statusBoth('empty','');statusBoth('array',[]);
statusBoth('two-json-documents',JSON.stringify(base)+'\n'+JSON.stringify(base)+'\n');
for(const [name,mutate] of [
 ['missing-data-health',x=>delete x.cluster.data.state.healthy],['unhealthy-data',x=>x.cluster.data.state.healthy=false],
 ['missing-recovery',x=>delete x.cluster.recovery_state],['incomplete-recovery',x=>x.cluster.recovery_state.name='accepting_commits'],
 ['client-unavailable',x=>x.client.database_status.available=false],['cluster-unavailable',x=>x.cluster.database_available=false],
 ['missing-client-health',x=>delete x.client.database_status.healthy],['missing-quorum',x=>delete x.client.coordinators.quorum_reachable],
 ['stale-cluster-file',x=>x.client.cluster_file.up_to_date=false],['client-issue',x=>x.client.messages=[{name:'status_incomplete_cluster'}]],
 ['process-issue',x=>Object.values(x.cluster.processes)[0].messages=[{name:'test_issue'}]],
 ['missing-process-messages',x=>delete Object.values(x.cluster.processes)[0].messages],
 ['configuration-issue',x=>{x.client.configuration={messages:[{name:'test_issue'}]};}],
 ['extra-cluster-message',x=>x.cluster.messages.push({name:'read_probe_timeout'})],
 ['other-only-warning',x=>x.cluster.messages=[{name:'transaction_start_probe_timeout'}]],
 ['contradictory-healthy-warning',x=>x.client.database_status.healthy=true],
 ['batch-success-and-timeout',x=>x.cluster.latency_probe.batch_priority_transaction_start_seconds=0.01],
 ['degraded',x=>x.cluster.degraded_processes=1],['missing-degraded',x=>delete x.cluster.degraded_processes],
 ['missing-queue',x=>delete x.cluster.qos.worst_queue_bytes_storage_server],['string-queue',x=>x.cluster.qos.worst_queue_bytes_storage_server='0'],
 ['negative-queue',x=>x.cluster.qos.worst_queue_bytes_storage_server=-1],['fractional-queue',x=>x.cluster.qos.worst_queue_bytes_storage_server=0.5],
 ['missing-lag',x=>delete x.cluster.qos.worst_durability_lag_storage_server.seconds],['string-lag',x=>x.cluster.qos.worst_durability_lag_storage_server.seconds='0'],
 ['missing-limiting-reason',x=>delete x.cluster.qos.performance_limited_by],
 ['missing-rss',x=>delete Object.values(x.cluster.processes)[0].memory.rss_bytes],
 ['missing-used-memory',x=>delete Object.values(x.cluster.processes)[0].memory.used_bytes],
 ['wrong-memory-limit',x=>Object.values(x.cluster.processes)[0].memory.limit_bytes=8589934592],
 ['wrong-role-class',x=>Object.values(x.cluster.processes)[0].class_type='unset'],
 ['missing-role',x=>Object.values(x.cluster.processes)[0].roles=[]],
 ['wrong-address',x=>Object.values(x.cluster.processes)[0].address='127.0.0.1:19999'],
 ['wrong-engine',x=>x.cluster.configuration.storage_engine='ssd-2'],
 ['wrong-log-count',x=>x.cluster.configuration.logs=2],
 ]){const x=clone(warn);mutate(x);statusBoth(name,x);}
for(const probe of ['transaction_start_seconds','immediate_priority_transaction_start_seconds','read_seconds','commit_seconds']){
 for(const [suffix,change] of [['missing',x=>delete x.cluster.latency_probe[probe]],['null',x=>x.cluster.latency_probe[probe]=null],['string',x=>x.cluster.latency_probe[probe]='0.1'],['timeout-boundary',x=>x.cluster.latency_probe[probe]=5]]){const x=clone(warn);change(x);statusBoth('probe-'+probe+'-'+suffix,x);}
}
{const x=clone(base);x.client.database_status.healthy=false;statusBoth('unexplained-false-aggregate',x);}
status('wrong-allow-argument-type',warn,'true',false);
statusBoth('infinite-queue',JSON.stringify(warn).replace('"worst_queue_bytes_storage_server":1025994869','"worst_queue_bytes_storage_server":1e9999'));

const instance='a'.repeat(64),session='synthetic-static-validation';
const phase={schema:'otel283_bulk_monitor_v1',policy:'exact-batch-probe-warning-v1',phase:'bulk_ingest_and_drain',owner:'otel283-vxnar',profile:'fdb4-4cpu-16g-v1',instance,session,run:'rw1m0284',source:{revision:'b'.repeat(40),binary_sha256:'c'.repeat(64),manifest_sha256:'d'.repeat(64)},started_epoch:1000,deadline_epoch:2000};
function phaseTest(name,p,expected,now=1010,inst=instance,sess=session){const file=save(out+'/phase-fixtures/'+name+'.json',p);return command('test','phase-'+name,'jq',['-ce','--arg','instance',inst,'--arg','session',sess,'--argjson','now',JSON.stringify(now),'-f',policy+'/bulk-phase.jq',file],expected);}
phaseTest('matching',phase,true);phaseTest('at-start',phase,true,1000);phaseTest('expired',phase,false,2001);phaseTest('exact-deadline',phase,false,2000);phaseTest('wrong-instance',phase,false,1010,'f'.repeat(64));phaseTest('wrong-session',phase,false,1010,instance,'other');
for(const [name,change]of [
 ['wrong-schema',p=>p.schema='other'],['wrong-policy',p=>p.policy='ignore-health'],['wrong-phase',p=>p.phase='audit'],['wrong-owner',p=>p.owner='other'],['wrong-profile',p=>p.profile='other'],['wrong-run',p=>p.run='rw1m0283'],
 ['future-start',p=>p.started_epoch=1020],['negative-start',p=>p.started_epoch=-1],['fractional-start',p=>p.started_epoch=1000.5],['missing-start',p=>delete p.started_epoch],['missing-deadline',p=>delete p.deadline_epoch],['fractional-deadline',p=>p.deadline_epoch=2000.5],['overlong-duration',p=>p.deadline_epoch=4601],['deadline-before-start',p=>p.deadline_epoch=999],
 ['missing-revision',p=>delete p.source.revision],['bad-revision',p=>p.source.revision='xyz'],['missing-binary-hash',p=>delete p.source.binary_sha256],['bad-binary-hash',p=>p.source.binary_sha256='c'.repeat(63)],['uppercase-binary-hash',p=>p.source.binary_sha256='C'.repeat(64)],['missing-manifest-hash',p=>delete p.source.manifest_sha256],['bad-manifest-hash',p=>p.source.manifest_sha256='not-a-hash']]){const x=clone(phase);change(x);phaseTest(name,x,false);}
{const x=clone(phase);x.deadline_epoch=4600;phaseTest('max-duration',x,true);}
const pin=save(out+'/phase-fixtures/pin.json',phase);
const changed=clone(phase);changed.source.binary_sha256='e'.repeat(64);
const changedFile=save(out+'/phase-fixtures/changed-valid-source.json',changed);
phaseTest('different-valid-source-is-format-valid',changed,true);
const guard='set -euo pipefail; [[ "$(sha256sum "$1" | awk \'{print $1}\')" == "$(sha256sum "$2" | awk \'{print $1}\')" ]]';
command('test','phase-source-pin-match','bash',['-c',guard,'phase-hash-guard',pin,pin],true);
command('test','phase-source-pin-mismatch','bash',['-c',guard,'phase-hash-guard',changedFile,pin],false);

function certFixture(name,mutate=null){
 const dir=out+'/cert-fixtures/'+name;fs.mkdirSync(dir);const rawDir=dir+'/drain-raw.fixture';fs.mkdirSync(rawDir);
 const pinFile=save(dir+'/bulk-pin.json',phase);const phaseHash=sha(pinFile);
 const receipt=save(dir+'/load-receipt.json',{run:'rw1m0284',fixture:true,note:'SYNTHETIC; no workload or DB action occurred'});
 const samples=[];for(let i=0;i<3;i++){const raw=save(rawDir+'/status-'+String(i+1).padStart(6,'0')+'.json',base);samples.push({raw_path:raw,sha256:sha(raw),epoch:1010+i*5});}
 const cert={schema:'otel283_strict_drain_v1',instance,session,run:'rw1m0284',source:clone(phase.source),phase_sha256:phaseHash,completed_epoch:1040,samples,load_receipt:receipt,load_receipt_sha256:sha(receipt)};
 let expectedHash=phaseHash;
 if(mutate){const result=mutate({dir,rawDir,pinFile,receipt,samples,cert,phaseHash});if(result?.expectedHash)expectedHash=result.expectedHash;}
 const certFile=dir+'/drain.certificate.json';if(!cert.__missing){delete cert.__missing;save(certFile,cert);}
 return {dir,expectedHash};
}
function certTest(name,change,expected,extra=null){const f=certFixture(name,change);return command('test','drain-'+name,'bash',[policy+'/verify-drain.sh',f.dir,instance,session,f.expectedHash],expected,extra);}
certTest('valid',null,true,s=>{const x=JSON.parse(s);return x.strict_samples===3&&x.run==='rw1m0284';});
certTest('tampered-raw',f=>fs.appendFileSync(f.samples[0].raw_path,' '),false);
certTest('tampered-receipt',f=>fs.appendFileSync(f.receipt,' '),false);
certTest('missing-raw',f=>fs.unlinkSync(f.samples[0].raw_path),false);
certTest('missing-receipt',f=>fs.unlinkSync(f.receipt),false);
certTest('missing-certificate',f=>f.cert.__missing=true,false);
certTest('missing-phase-pin',f=>fs.unlinkSync(f.pinFile),false);
for(const [name,change]of [
 ['short-gap',f=>f.cert.samples[1].epoch=1014],['reversed-gap',f=>f.cert.samples[1].epoch=1009],['sample-before-start',f=>f.cert.samples[0].epoch=999],['fractional-sample-time',f=>f.cert.samples[0].epoch=1010.5],['sample-after-completion',f=>f.cert.completed_epoch=1019],
 ['two-samples',f=>f.cert.samples.pop()],['four-samples',f=>f.cert.samples.push(clone(f.cert.samples[2]))],
 ['completed-at-deadline',f=>f.cert.completed_epoch=2000],['completed-before-start',f=>f.cert.completed_epoch=999],
 ['wrong-instance',f=>f.cert.instance='e'.repeat(64)],['wrong-session',f=>f.cert.session='other'],['wrong-run',f=>f.cert.run='rw1m0283'],['source-mismatch',f=>f.cert.source.binary_sha256='e'.repeat(64)],['phase-hash-mismatch',f=>f.cert.phase_sha256='e'.repeat(64)]])certTest(name,change,false);
function replaceRaw(f,obj){save(f.samples[0].raw_path,obj);f.cert.samples[0].sha256=sha(f.samples[0].raw_path);}
certTest('warning-not-strict',f=>replaceRaw(f,warn),false);
certTest('missing-health-with-correct-hash',f=>{const x=clone(base);delete x.cluster.data.state.healthy;replaceRaw(f,x);},false);
certTest('malformed-with-correct-hash',f=>replaceRaw(f,'{'),false);
certTest('queue-at-drain-limit',f=>{const x=clone(base);x.cluster.qos.worst_queue_bytes_storage_server=16777216;replaceRaw(f,x);},false);
certTest('lag-at-drain-limit',f=>{const x=clone(base);x.cluster.qos.worst_durability_lag_storage_server.seconds=10;replaceRaw(f,x);},false);
certTest('phase-pin-tampered',f=>{const p=clone(phase);p.source.manifest_sha256='f'.repeat(64);save(f.pinFile,p);},false);
certTest('phase-policy-wrong-with-refreshed-hashes',f=>{const p=clone(phase);p.policy='ignore-health';save(f.pinFile,p);const h=sha(f.pinFile);f.cert.phase_sha256=h;return {expectedHash:h};},false);
certTest('raw-outside-approved-directory',f=>{const p=save(f.dir+'/outside.json',base);f.cert.samples[0].raw_path=p;f.cert.samples[0].sha256=sha(p);},false);
// Additional adversarial certificate-contract checks, not an actual-helper run.
certTest('same-raw-file-reused-three-times',f=>{for(let i=1;i<3;i++){f.cert.samples[i].raw_path=f.cert.samples[0].raw_path;f.cert.samples[i].sha256=f.cert.samples[0].sha256;}},false);
certTest('raw-path-dotdot-escape',f=>{const p=save(f.dir+'/status-outside.json',base);f.cert.samples[0].raw_path=f.rawDir+'/../status-outside.json';f.cert.samples[0].sha256=sha(p);},false);

command('test','frozen-manifest-after','sha256sum',['-c',policy+'/bulk-policy-prepared.sha256'],true);
const tests=records.filter(r=>r.kind==='test');const failures=tests.filter(r=>!r.expectation_met);
const summary={validation_scope:'PURE FILE/static only; no Docker/server/DB actions; production policy not edited',policy_manifest:policy+'/bulk-policy-prepared.sha256',provenance,commands:records.length,tests:tests.length,expected_success:tests.filter(r=>r.expected_success).length,expected_rejection:tests.filter(r=>r.expected_success===false).length,passed:tests.length-failures.length,failed:failures.length,failures:failures.map(r=>({name:r.name,expected_success:r.expected_success,exit_code:r.exit_code,extra_assertion:r.extra_assertion,stdout_file:r.stdout_file,stderr_file:r.stderr_file,command:r.shell_command}))};
save(out+'/summary.json',summary);
save(out+'/README.md','# Pure-file policy validation receipt\n\nNo Docker/server/database action was executed. Frozen policy source was not edited. `validate.mjs` generates isolated fixtures, records every external command and output, and executes only bash syntax checks, jq validators, literal SHA equality guards, SHA-256 commands and the pure-file verify-drain helper.\n\nInput provenance and nonempty retained populations are in `provenance.json`. Complete argv/working directory/expected and actual exits/output paths are in `commands-results.jsonl`; commands are also listed in `commands.sh`. `commands.sh` is a command receipt, not a set-e replay script: many commands intentionally return nonzero. Reproduction starts with `node validate.mjs` in a NEW empty directory holding a copy of the harness; it refuses existing fixture directories.\n\nSynthetic certificates do not prove any ingestion success or real-time DB observations. Different valid source hashes are format-valid declarations; the separate byte-digest guard rejects mutation relative to an already pinned phase. Additional adversarial cases test repeated raw-file references and lexical path traversal, beyond actual helper-produced certificates.\n\nSummary: '+summary.tests+' tests; '+summary.passed+' matched expectations; '+summary.failed+' mismatches. See `summary.json` for exact failures.\n');
console.log(JSON.stringify(summary,null,2));
process.exitCode=failures.length?1:0;
