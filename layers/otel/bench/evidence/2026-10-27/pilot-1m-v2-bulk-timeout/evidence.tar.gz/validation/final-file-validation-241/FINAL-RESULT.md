# Final pure-file policy validation

GREEN: 241/241 expectations matched (46 successful positives, 195 expected rejections), 475 recorded subprocess commands. All nine policy shell scripts pass bash -n. Nonempty retained positives: 14 real healthy statuses each pass strict and bulk; 11 are below strict drain queue/lag thresholds. Real raw015 sole-warning is rejected strictly, accepted only under explicit bulk allowance, and preserves original false health in its summary. Synthetic valid drain certificate passes with three distinct raw paths and IDENTICAL content hashes.

Both filters use a bounded one-extra-input guard with fatal halt_error(1), rejecting 2/3/5 top-level documents while leaving valid fields untouched. Ordinary error() was found insufficient because jq may resume at a later root and return success; that intermediate RED run is preserved separately.

Pure verifier now requires canonical existing run dir and canonical existing regular raw files, three distinct paths, exact six-digit status basenames, direct children of one allowed drain-raw subtree. It rejects dot-dot/dot aliases, symlink file or directory aliases, noncanonical/nested/mixed subtrees, missing/directory files and wrong basenames. Content hash uniqueness is deliberately NOT required.

Original RED: /tmp/fdb-hotelbench.VxNArC/policy-static-validation-JdoW2S (217/213; four mismatches), receipt manifest SHA256 6fb585ef78e5764dcae06795e8025bec38c52ab92f3742222be6b33b5fb63d3e.
Intermediate RED: /tmp/fdb-hotelbench.VxNArC/policy-static-validation-green-20261027 (name predates result; 238/235; three 3-document mismatches), receipt manifest SHA256 74fee896091194ed7ebbdad0a0ca039077819b28559d9dcc8c838e947c666dd1.

Final prepared policy manifest: /tmp/fdb-hotelbench.VxNArC/fdb4-config/bulk-policy-prepared.sha256, SHA256 9ff068247e532573f65c6884c791ae503b9fa7649f295c052c7f09737b8d21fa. Copied exact source and manifest are under policy-at-validation/. Complete commands/outputs and fixture provenance: commands-results.jsonl, commands.sh, results/, provenance.json. Symlink fixture metadata: fixture-symlinks.json.

No Docker/server/database actions were performed. Policy edits were root-approved before the independent final run, and policy manifest checks passed before/after. This is file/static validation only, not a real drain, workload run, launch authorization, or capacity/performance claim.
