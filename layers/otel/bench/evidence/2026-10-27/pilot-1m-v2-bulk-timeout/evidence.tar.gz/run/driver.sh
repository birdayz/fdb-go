#!/usr/bin/env bash
set -Eeuo pipefail
export GOMAXPROCS=4 TZ=UTC
base=/tmp/fdb-hotelbench.VxNArC
profile=$base/fdb4-config
session_name=resume-20261027-03
session=$profile/sessions/$session_name
out=$base/pilot1m-v2-bulkbounded
bin=$base/otelbench-v2-reference
source=$base/v2-measurement-src
revision=692a42505133f7f42030bc9ba91c65f8d7828d14
container=otel283-fdb4-vxnar
cd "$source"
[[ ! -e "$out" && -f "$session/bootstrap.ready" && ! -e "$session/monitor.stopped" ]]
kill -0 "$(cat "$session/monitor.pid")"
instance=$(cat "$session/instance.id")
[[ $(docker inspect "$container" --format '{{.Id}} {{.State.Running}}') == "$instance true" ]]
[[ $(git rev-parse HEAD) == "$revision" && -z $(git status --porcelain=v1) ]]
sha256sum --check "$base/v2-binary.sha256"
mkdir "$out"
manifest() { git ls-files --cached --others --exclude-standard -z | LC_ALL=C sort -z | xargs -0 sha256sum; }
config_manifest() { sha256sum "$profile"/{foundationdb.conf,fdb.cluster.seed,resume.sh,resume-entrypoint.sh,monitor.sh,status-check.jq,readiness.sh,bulk-phase.jq,declare-bulk.sh,drain.sh,verify-drain.sh}; }
manifest > "$out/source.before"
sha256sum "$bin" > "$out/binary.before"
config_manifest > "$out/config.before"
cp "$session/bootstrap.ready" "$out/profile-ready.json"
printf '%s\n' "$revision" > "$out/revision"
finish() {
  rc=$?
  trap - EXIT
  manifest > "$out/source.after"
  sha256sum "$bin" > "$out/binary.after"
  config_manifest > "$out/config.after"
  if ! cmp -s "$out/source.before" "$out/source.after" || ! cmp -s "$out/binary.before" "$out/binary.after" || ! cmp -s "$out/config.before" "$out/config.after" || [[ -n $(git status --porcelain=v1) ]]; then rc=4; fi
  printf 'exit=%s end=%s\n' "$rc" "$(date -u +%FT%TZ)" > "$out/status"
  exit "$rc"
}
trap finish EXIT
status() { timeout --kill-after=1s 12s docker exec "$instance" /usr/bin/timeout --kill-after=1s 10s /usr/bin/fdbcli -C /var/fdb/data/cluster/fdb.cluster --exec 'status json'; }
physical() { docker exec "$instance" /bin/sh -c 'du -s -B1 /var/fdb/data /var/fdb/data/processes/* /var/fdb/data/traces'; }
active() { [[ ! -e "$session/monitor.stopped" ]] && kill -0 "$(cat "$session/monitor.pid")" && [[ $(docker inspect "$container" --format '{{.Id}} {{.State.Running}}') == "$instance true" ]]; }
common=(--backend fdb --order time --cluster-file "$profile/fdb.cluster.seed" --run rw1m0284
  --count 1000000 --tenants 1 --attrs 8 --match-every 100 --batch 32 --save-mode batch
  --workers 4 --diagnostics --k 100 --max-candidates 2000000 --max-bytes 268435456
  --timeout 30m --revision "$revision")
printf '%q ' "$bin" "${common[@]}" --mode ingest --output "$out/ingest.json" > "$out/ingest-command.txt"
printf '\n' >> "$out/ingest-command.txt"
status > "$out/fdb.before.json"
jq -ce --argjson allow_batch_warning false -f "$profile/status-check.jq" "$out/fdb.before.json" > "$out/health.before.json"
physical > "$out/physical.before"
docker stats --no-stream --format '{{json .}}' "$instance" > "$out/container.before.jsonl"
FDB4_DECLARE_BULK_APPROVED=yes FDB4_SESSION="$session_name" FDB4_SOURCE_REVISION="$revision" \
  FDB4_BINARY="$bin" FDB4_SOURCE_MANIFEST="$out/source.before" FDB4_BULK_SECONDS=2700 \
  bash "$profile/declare-bulk.sh" | tee "$out/declare-bulk.log"
cp "$session/bulk-pin.json" "$session/bulk-policy.ack.json" "$out/"
active
rc=0
started=$(date -u +%FT%TZ)
perf stat -o "$out/perf-stat.txt" -e task-clock,cycles,instructions,context-switches,cpu-migrations,page-faults -- \
  "$bin" "${common[@]}" --mode ingest --output "$out/ingest.json" || rc=$?
ended=$(date -u +%FT%TZ)
ingest_hash=$(sha256sum "$out/ingest.json" | awk '{print $1}')
jq -cn --arg run rw1m0284 --arg instance "$instance" --arg revision "$revision" --arg start "$started" --arg end "$ended" \
  --argjson rc "$rc" --arg receipt "$out/ingest.json" --arg hash "$ingest_hash" \
  '{run:$run,instance:$instance,source_revision:$revision,started:$start,ended:$end,exit_code:$rc,ingest_receipt:$receipt,ingest_receipt_sha256:$hash,note:"Finalized load outcome only; population requires independent source audit. Sole batch-probe warning may be admitted only during the declared bounded bulk phase."}' > "$out/load-outcome.json"
physical > "$out/physical.acknowledged" 2> "$out/physical.acknowledged.stderr" || true
status > "$out/fdb.acknowledged.json" 2> "$out/fdb.acknowledged.stderr" || true
docker stats --no-stream --format '{{json .}}' "$instance" > "$out/container.acknowledged.jsonl" 2> "$out/container.acknowledged.stderr" || true
active
FDB4_CERTIFY_DRAIN_APPROVED=yes FDB4_SESSION="$session_name" FDB4_LOAD_RECEIPT="$out/load-outcome.json" \
  bash "$profile/drain.sh" | tee "$out/drain.log"
cp "$session/drain.certificate.json" "$session/drain.jsonl" "$out/"
active
physical > "$out/physical.settled"
status > "$out/fdb.settled.json"
jq -ce --argjson allow_batch_warning false -f "$profile/status-check.jq" "$out/fdb.settled.json" > "$out/health.settled.json"
if (( rc )); then exit "$rc"; fi
"$bin" "${common[@]}" --mode audit --output "$out/audit.json"
# The known selective/custom_varying selector defect is NOT exercised by all:
# these are the 16 explicit trace/span/GenAI/time cases. No selective claim.
"$bin" "${common[@]}" --mode query --suite all --iterations 1600 --output "$out/all.json"
active
status > "$out/fdb.after.json"
jq -ce --argjson allow_batch_warning false -f "$profile/status-check.jq" "$out/fdb.after.json" > "$out/health.after.json"
echo '1M V2 bounded-policy pilot completed with strict final drain, stored-source audit and explicit all-suite oracle checks; not 100M, production or competitive proof.'
