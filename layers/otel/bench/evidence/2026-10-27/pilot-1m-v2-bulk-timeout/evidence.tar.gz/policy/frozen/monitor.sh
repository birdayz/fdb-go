#!/usr/bin/env bash
set -Eeuo pipefail
# Explicit session: original stop artifacts and marker are never overwritten.
readonly container=otel283-fdb4-vxnar owner=otel283-vxnar profile=fdb4-4cpu-16g-v1
readonly here=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
: "${FDB4_SESSION:?Use the NEW resume session name}"
[[ "$FDB4_SESSION" =~ ^[a-zA-Z0-9][a-zA-Z0-9_.-]*$ ]] || exit 1
readonly run_dir="$here/sessions/$FDB4_SESSION"
readonly bootstrap_marker="$run_dir/bootstrap.ready"
[[ -f "$run_dir/resume-receipt.txt" && ! -e "$bootstrap_marker" && ! -e "$run_dir/monitor.pid" ]] || {
  echo 'Require prepared new resume session, no ready marker and no prior monitor' >&2; exit 1;
}
readonly min_host=$((8 * 1024 * 1024 * 1024))
readonly min_disk_floor=$((200 * 1024 * 1024 * 1024))
readonly max_cgroup=$((16 * 1024 * 1024 * 1024 * 90 / 100))
readonly max_queue=${MAX_STORAGE_QUEUE_BYTES:-536870912}
readonly max_lag=${MAX_DURABILITY_LAG_SECONDS:-60}
readonly min_disk=${FDB4_MIN_DISK_AVAILABLE_BYTES:-214748364800}
[[ "$max_queue" =~ ^[1-9][0-9]*$ && "$max_lag" =~ ^[1-9][0-9]*$ && "$min_disk" =~ ^[1-9][0-9]*$ ]] || exit 1
(( min_disk >= min_disk_floor )) || exit 1
command -v jq >/dev/null
command -v timeout >/dev/null
readonly docker_root=$(docker info --format '{{.DockerRootDir}}')
mkdir "$run_dir/monitor-raw"
(set -o noclobber; printf '%s\n' "$$" > "$run_dir/monitor.pid")
trap 'date -u +%FT%TZ > "$run_dir/monitor.stopped"' EXIT
log() { printf '%s %s\n' "$(date -u +%FT%TZ)" "$*" | tee -a "$run_dir/monitor.log"; }
expected_id=
check_owner() {
  [[ -n "$expected_id" ]] && [[ $(docker inspect --format '{{.Id}} {{index .Config.Labels "otel283.owner"}} {{index .Config.Labels "otel283.profile"}} {{index .Config.Labels "otel283.session"}}' "$container") == "$expected_id $owner $profile $FDB4_SESSION" ]]
}
abort() {
  log "ABORT: $*"
  jq -cn --arg timestamp "$(date -u +%FT%TZ)" --arg reason "$*" \
    '{type:"abort",timestamp:$timestamp,reason:$reason}' >> "$run_dir/monitor.jsonl"
  if [[ -n "$expected_id" ]] && docker inspect "$expected_id" >/dev/null 2>&1; then
    check_owner || { log 'Instance/label mismatch: refusing stop'; exit 1; }
    docker stop --timeout 60 "$expected_id" >> "$run_dir/monitor.log" 2>&1 || true
  fi
  exit 1
}
# Only an exact, pinned, bounded bulk phase can select the warning exception.
phase_hash=
phase_metadata=null
phase_seen=false
final_drain_hash=
allow_batch_warning=false
bulk_samples=0
warning_samples=0
resolve_bulk_policy() {
  allow_batch_warning=false
  local phase="$run_dir/bulk-phase.json" pin="$run_dir/bulk-pin.json" cert="$run_dir/drain.certificate.json" current active now result pending
  if [[ ! -f "$phase" && ! -f "$cert" && "$phase_seen" == false ]]; then return; fi
  [[ -f "$bootstrap_marker" && -f "$pin" ]] || abort 'Bulk declaration without strict readiness/source pin'
  current=$(sha256sum "$pin" | awk '{print $1}') || abort 'Cannot read bulk source pin'
  if [[ "$phase_seen" == false ]]; then
    phase_hash=$current
    phase_metadata=$(cat "$pin") || abort 'Cannot retain phase metadata'
    phase_seen=true
  fi
  [[ "$current" == "$phase_hash" ]] || abort 'Bulk source pin changed'
  if [[ -f "$cert" ]]; then
    current=$(sha256sum "$cert" | awk '{print $1}') || abort 'Cannot read drain certificate'
    if [[ -z "$final_drain_hash" ]]; then
      result=$(bash "$here/verify-drain.sh" "$run_dir" "$expected_id" "$FDB4_SESSION" "$phase_hash") || abort 'Invalid strict final-drain certificate'
      final_drain_hash=$current
      log "Strict final drain verified; exception ended: $result"
    fi
    [[ "$current" == "$final_drain_hash" ]] || abort 'Final-drain certificate changed'
    return
  fi
  [[ -z "$final_drain_hash" && -f "$phase" ]] || abort 'Bulk marker/certificate removed without strict final drain'
  if ! active=$(sha256sum "$phase" | awk '{print $1}'); then
    # Completion can atomically publish a certificate then remove the marker.
    if [[ -f "$cert" ]]; then resolve_bulk_policy; return; fi
    abort 'Cannot read active bulk marker'
  fi
  [[ "$active" == "$phase_hash" ]] || abort 'Bulk metadata/deadline changed in place'
  now=$(date +%s)
  jq -ce --arg instance "$expected_id" --arg session "$FDB4_SESSION" --argjson now "$now" -f "$here/bulk-phase.jq" "$pin" >/dev/null || abort 'Bulk instance/session/run/source/deadline invalid or expired'
  allow_batch_warning=true
  if [[ ! -f "$run_dir/bulk-policy.ack.json" ]]; then
    pending="$run_dir/bulk-policy.ack.pending.$$"
    (set -o noclobber; jq -cn --arg hash "$phase_hash" --arg instance "$expected_id" --arg session "$FDB4_SESSION" \
      '{phase_sha256:$hash,instance:$instance,session:$session}' > "$pending")
    ln -- "$pending" "$run_dir/bulk-policy.ack.json" || abort 'Cannot publish policy acknowledgement'
    log "Acknowledged bulk policy arm exact-batch-probe-warning-v1 phase_sha256=$phase_hash"
  fi
}
started=$SECONDS
initial_pids=
bootstrap_seen=false
running_seen=false
backlog_streak=0
sample=0
log "session=$FDB4_SESSION policy_arm=exact-batch-probe-warning-v1(strict unless declared) queue>$max_queue AND lag>$max_lag for 6 nominal-10s samples; min_disk=$min_disk; marker=$bootstrap_marker"
while :; do
  next_tick=$((SECONDS + 10))
  available=$(awk '/^MemAvailable:/ {printf "%.0f\n", $2 * 1024}' /proc/meminfo)
  [[ "$available" =~ ^[0-9]+$ ]] || abort 'Invalid host memory accounting'
  (( available >= min_host )) || abort "Host available=$available below 8 GiB"
  disk=$(df -B1 --output=avail "$docker_root" | tail -1 | tr -d ' ')
  [[ "$disk" =~ ^[0-9]+$ ]] || abort 'Invalid disk accounting'
  (( disk >= min_disk )) || abort "Disk available=$disk below $min_disk"
  if [[ -z "$expected_id" ]]; then
    if [[ -f "$run_dir/instance.id" ]]; then
      expected_id=$(cat "$run_dir/instance.id")
      [[ "$expected_id" =~ ^[0-9a-f]{64}$ ]] || abort 'Invalid expected container ID'
    else
      (( SECONDS - started < 300 )) || abort 'New container ID not published within 300s'
      sleep 2; continue
    fi
  fi
  check_owner || { log 'Instance/label mismatch: refusing monitor/stop'; exit 1; }
  state=$(docker inspect --format '{{.State.Status}} {{.State.Running}} {{.State.OOMKilled}} {{.RestartCount}} {{.State.ExitCode}}' "$expected_id")
  read -r status_name running oom restarts code <<< "$state"
  [[ "$oom" == false && "$restarts" == 0 ]] || abort "OOM/restart state: $state"
  if [[ "$running" != true ]]; then
    if [[ "$status_name" == created && "$running_seen" == false ]] && (( SECONDS - started < 300 )); then
      sleep 2; continue
    fi
    if [[ "$running_seen" == false ]]; then abort "Container exited before observed running: $state"; fi
    log "Container stopped; exit=$code; data retained"
    [[ "$code" == 0 ]] && exit 0 || exit 1
  fi
  running_seen=true
  usage=$(docker exec "$expected_id" /bin/sh -c 'if test -r /sys/fs/cgroup/memory.current; then cat /sys/fs/cgroup/memory.current; else cat /sys/fs/cgroup/memory/memory.usage_in_bytes; fi') || abort 'Cannot read cgroup memory'
  [[ "$usage" =~ ^[0-9]+$ ]] || abort 'Invalid cgroup memory'
  (( usage < max_cgroup )) || abort "Cgroup usage=$usage reaches 90% of 16 GiB"
  pids=$(docker exec "$expected_id" /bin/sh -c 'pgrep -x fdbserver | sort -n | tr "\n" ","') || abort 'Cannot census processes'
  count=$(printf '%s' "$pids" | tr -cd ',' | wc -c | tr -d ' ')
  if [[ -z "$initial_pids" ]]; then
    if [[ "$count" == 4 ]]; then initial_pids=$pids
    else (( SECONDS - started < 300 )) || abort "Expected four processes; saw $count"; fi
  elif [[ "$pids" != "$initial_pids" ]]; then
    abort "Server process loss/change: initial=$initial_pids current=$pids"
  fi
  timestamp=$(date -u +%FT%TZ)
  resources=$(jq -cn --argjson host "$available" --argjson disk "$disk" --argjson cgroup "$usage" --arg pids "$pids" \
    '{host_available_bytes:$host,disk_available_bytes:$disk,cgroup_bytes:$cgroup,server_pids:$pids}')
  if [[ -f "$bootstrap_marker" ]]; then
    bootstrap_seen=true
    [[ "$count" == 4 ]] || abort 'Ready marker without four processes'
    resolve_bulk_policy
    sample=$((sample + 1))
    printf -v raw '%s/monitor-raw/status-%06d.json' "$run_dir" "$sample"
    # Persist stdout BEFORE validation, including empty/truncated/invalid status.
    timeout --kill-after=1s 12s docker exec "$expected_id" /usr/bin/timeout --kill-after=1s 10s \
      /usr/bin/fdbcli -C /var/fdb/data/cluster/fdb.cluster --exec 'status json' \
      > "$raw" 2>> "$run_dir/status-errors.log" || abort "Status command failed/timed out; raw=$raw"
    # Recheck deadline/completion after a potentially ten-second admin request.
    resolve_bulk_policy
    summary=$(jq -ce --argjson allow_batch_warning "$allow_batch_warning" -f "$here/status-check.jq" "$raw" 2>> "$run_dir/status-errors.log") || abort "Status validation failed; preserved raw=$raw"
    if [[ "$allow_batch_warning" == true ]]; then bulk_samples=$((bulk_samples + 1)); fi
    if [[ $(printf '%s\n' "$summary" | jq -r '.health_exception_used') == true ]]; then warning_samples=$((warning_samples + 1)); fi
    if printf '%s\n' "$summary" | jq -e --argjson q "$max_queue" --argjson lag "$max_lag" \
      '.queue_bytes > $q and .durability_lag_seconds > $lag' >/dev/null; then
      backlog_streak=$((backlog_streak + 1))
    else backlog_streak=0; fi
    jq -cn --arg timestamp "$timestamp" --arg raw "$raw" --argjson resources "$resources" --argjson status "$summary" --argjson streak "$backlog_streak" \
      --argjson exception_allowed "$allow_batch_warning" --argjson phase "$phase_metadata" --arg phase_hash "$phase_hash" \
      --argjson bulk_samples "$bulk_samples" --argjson warnings "$warning_samples" \
      '{type:"status",timestamp:$timestamp,raw_status:$raw,resources:$resources,status:$status,backlog_streak:$streak,
        bulk_exception_allowed:$exception_allowed,bulk_phase:$phase,bulk_phase_sha256:$phase_hash,
        warning_frequency:{warning_samples:$warnings,bulk_status_samples:$bulk_samples,fraction:(if $bulk_samples>0 then $warnings/$bulk_samples else null end)}}' >> "$run_dir/monitor.jsonl"
    (( backlog_streak < 6 )) || abort 'Queue and lag exceeded frozen gates for six consecutive samples'
  else
    [[ "$bootstrap_seen" == false ]] || abort 'Session-ready marker removed'
    [[ ! -e "$run_dir/bulk-phase.json" && ! -e "$run_dir/drain.certificate.json" ]] || abort 'Bulk policy artifacts before strict readiness'
    jq -cn --arg timestamp "$timestamp" --argjson resources "$resources" \
      '{type:"prereadiness_resources",timestamp:$timestamp,resources:$resources}' >> "$run_dir/monitor.jsonl"
  fi
  delay=$((next_tick - SECONDS))
  if (( delay > 0 )); then sleep "$delay"; fi
done
