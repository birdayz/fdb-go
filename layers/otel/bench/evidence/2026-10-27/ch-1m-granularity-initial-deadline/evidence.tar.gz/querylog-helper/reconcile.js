#!/usr/bin/env node
'use strict';
const fs=require('node:fs'), http=require('node:http'), crypto=require('node:crypto'), path=require('node:path'), {execFileSync}=require('node:child_process');
const policy=require('./policy');
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const endpoint='http://127.0.0.1:18125/'; // fixed loopback only, no credentials or redirects
const maxResponse=32*1024*1024, pageSize=256, maxRows=1024, waitMs=120000;
function request(sql) {
  return new Promise((resolve,reject)=>{
    const req=http.request(endpoint,{method:'POST',headers:{'content-type':'text/plain'},timeout:10000},res=>{
      if(res.statusCode!==200){res.resume();reject(Error(`HTTP status ${res.statusCode}`));return;}
      let size=0, chunks=[]; res.on('data',c=>{size+=c.length;if(size>maxResponse){req.destroy(Error('response exceeded 32 MiB'));return;}chunks.push(c);});
      res.on('end',()=>resolve(Buffer.concat(chunks).toString('utf8'))); res.on('error',reject);
    });
    req.on('timeout',()=>req.destroy(Error('request timeout'))); req.on('error',reject); req.end(sql);
  });
}
function rows(text) { return text.trim() ? text.trim().split('\n').map(JSON.parse) : []; }
function save(file, value) { fs.writeFileSync(file,value,{flag:'wx',mode:0o600}); }
async function main() {
  const args=process.argv.slice(2);
  if(args.length<2 || args.length>3 || (args[2] && args[2]!=='--flush')) throw Error('usage: node reconcile.js EVIDENCE_JSON NEW_OUTPUT_DIR [--flush]');
  const [inputFile,out,flag]=args;
  const inputBytes=fs.readFileSync(inputFile), e=JSON.parse(inputBytes), meta=policy.input(e);
  fs.mkdirSync(out,{mode:0o700}); // exclusive: never overwrite an old reconciliation
  const raw=[]; let describe=[], report=[], failure=''; const start=Date.now();
  try {
    const id=fs.readFileSync('/tmp/fdb-hotelbench.VxNArC/ch16-config/instance.id','utf8').trim();
    if(!/^[0-9a-f]{64}$/.test(id)) throw Error('invalid owned instance ID');
    const fmt='{{.Id}} {{index .Config.Labels "otel283.owner"}} {{index .Config.Labels "otel283.profile"}} {{.State.Running}}';
    const inspect=execFileSync('docker',['inspect','--format',fmt,'otel283-ch16-vxnar'],{encoding:'utf8',timeout:10000}).trim();
    if(inspect!==`${id} otel283-vxnar ch16-4cpu-16g-v1 true`) throw Error('CH16 ownership/running mismatch');
    if((await request('SELECT version() FORMAT TabSeparated')).trim()!=='26.10.2.103') throw Error('unexpected ClickHouse server version');
    // Explicit DESCRIBE: retain only column name/type, never defaults or comments.
    describe=rows(await request('DESCRIBE TABLE system.query_log FORMAT JSONEachRow')).map(x=>({name:x.name,type:x.type}));
    const cols=new Set(describe.map(x=>x.name));
    for(const col of ['query_id','type','read_rows','read_bytes','query_duration_ms','databases','is_initial_query']) if(!cols.has(col)) throw Error(`query_log missing required column ${col}`);
    const extra=[];
    if(cols.has('tables')) extra.push('tables');
    if(cols.has('projections')) extra.push('projections');
    if(cols.has('Settings')) for(const k of ['max_threads','max_memory_usage','use_query_cache']) extra.push(`Settings['${k}'] AS setting_${k}`);
    if(flag==='--flush') await request('SYSTEM FLUSH LOGS');
    let pending=meta.ids;
    while(pending.length) {
      if(Date.now()-start>waitMs) break;
      const found=new Set();
      for(let i=0;i<pending.length;i+=pageSize) {
        if(Date.now()-start>waitMs) break;
        const ids=pending.slice(i,i+pageSize); // all validated hex before SQL construction
        const literals=ids.map(x=>`'${x}'`).join(',');
        const selected=['query_id','toString(type) AS type','read_rows','read_bytes','query_duration_ms','databases',...extra].join(',');
        const sql=`SELECT ${selected} FROM system.query_log WHERE is_initial_query=1 AND query_id IN (${literals}) AND type IN ('QueryFinish','ExceptionBeforeStart','ExceptionWhileProcessing') LIMIT ${maxRows+1} FORMAT JSONEachRow`;
        const batch=rows(await request(sql));
        if(batch.length>maxRows) throw Error('query-log page row cap exceeded');
        const subset=new Set(ids);
        for(const row of batch) {if(!subset.has(row.query_id)) throw Error('unexpected query ID in response'); raw.push(row); found.add(row.query_id);}
      }
      pending=pending.filter(x=>!found.has(x));
      if(pending.length && Date.now()-start<waitMs) await new Promise(r=>setTimeout(r,1000));
    }
    report=policy.reconcile(meta,raw);
    if(report.some(x=>x.status!=='ok')) failure='unreconciled query IDs; see report';
  } catch(err) { failure=String(err.message || err); report=policy.reconcile(meta,raw); }
  const schema=Buffer.from(JSON.stringify(describe,null,2)+'\n');
  const rawBytes=Buffer.from(raw.map(x=>JSON.stringify(x)).join('\n')+(raw.length?'\n':''));
  const result=Buffer.from(JSON.stringify(report,null,2)+'\n');
  save(path.join(out,'schema.json'),schema); save(path.join(out,'query-log.jsonl'),rawBytes); save(path.join(out,'reconciliation.json'),result);
  const provenance={schema:'otel_querylog_reconciliation_v1',created_utc:new Date().toISOString(),endpoint,flush_opt_in:flag==='--flush',source_sha256:sha(inputBytes),source_basename:path.basename(inputFile),helper_sha256:sha(fs.readFileSync(__filename)),policy_sha256:sha(fs.readFileSync(path.join(__dirname,'policy.js'))),run:meta.run,backend:meta.backend,corpus_fingerprint:meta.corpus,owned_database:meta.db,sample_count:meta.ids.length,page_size:pageSize,response_cap_bytes:maxResponse,wait_ms:waitMs,elapsed_ms:Date.now()-start,failed:!!failure,failure,artifacts:{'schema.json':sha(schema),'query-log.jsonl':sha(rawBytes),'reconciliation.json':sha(result)},note:'Separate from timed receipt; zero query_duration_ms means <1ms at integer-ms resolution. Missing/duplicates/errors are not zero.'};
  const provenanceBytes=Buffer.from(JSON.stringify(provenance,null,2)+'\n');
  save(path.join(out,'provenance.json'),provenanceBytes);
  save(path.join(out,'provenance.sha256'),sha(provenanceBytes)+'  provenance.json\n');
  if(failure){console.error(failure);process.exitCode=1;} else console.log(`reconciled ${report.length} IDs; output ${out}`);
}
main().catch(err=>{console.error(String(err.message || err));process.exitCode=1;});
