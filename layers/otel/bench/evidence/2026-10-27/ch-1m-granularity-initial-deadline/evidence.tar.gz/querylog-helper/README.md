# CH16 query-log reconciliation — prepared only

No ClickHouse or Docker request was made in preparation. This standalone helper does not edit or enrich the input evidence or native metric fields. After timed queries and owner authorization only:

```
node /tmp/fdb-hotelbench.VxNArC/ch-querylog-reconcile/reconcile.js EVIDENCE_JSON NEW_OUTPUT_DIR
```

The output directory must not exist. The endpoint is fixed to HTTP `127.0.0.1:18125` with no credentials, and the helper checks the recorded CH16 container ID, exact owner/profile labels, running state and server version. Host loopback is shared with other local users and host-network containers and is not an authentication boundary. Use only on the approved isolated host. It does not verify that no other process can impersonate the endpoint; owner must verify listener ownership as part of CH16 readiness.

By default, polling is read-only, up to 120 seconds, with 10-second request timeout. To flush logs, root may separately run `SYSTEM FLUSH LOGS` **after** the timed run, or append `--flush` to explicitly opt into that operation. Never run during timed work. DESCRIBE TABLE system.query_log precedes queries; absent required columns fail closed, and projections/settings are selected only if present. Missing database scope information is a scope mismatch, not presumed ownership.

Each request includes at most 256 validated unique receipt IDs; each response is capped at 32 MiB and at most 1024 terminal rows (overflow is an error). Each output contains a source receipt hash, helper/policy hashes, receipt run/backend/corpus, and hashes of filtered schema, raw selected query-log fields and reconciliation report. The raw output contains only IDs, terminal type, metrics, databases/tables, optional projections and whitelisted query settings—never SQL query text or arbitrary settings. Error, missing, duplicate, scope mismatch or malformed metrics are explicit failures, not zeros; `query_duration_ms=0` is below 1ms at integer-ms resolution. Raw output and hashes are sensitive operational metadata; restrict access.

Pure offline check: `node policy-test.js`. It covers IDs, duplicate/missing/exception/scope, invalid metrics and the millisecond floor. It does not validate SQL, ClickHouse compatibility, actual query-log flushing, listener ownership, resource usage or service behavior; these remain launch-time checks. No 100M authorization.
