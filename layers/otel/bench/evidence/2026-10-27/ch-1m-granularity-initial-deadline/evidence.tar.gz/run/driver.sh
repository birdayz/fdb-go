#!/usr/bin/env bash
set -Eeuo pipefail
export GOMAXPROCS=4 TZ=UTC
base=/tmp/fdb-hotelbench.VxNArC
source=$base/granularity-measurement-src
bin=$base/otelbench-granularity-reference
profile=$base/ch16-config
out=$base/ch1m-tune
revision=9244882a5914e0f897b0216866ca77d2bd4b6910
cd "$source"
[[ ! -e "$out" && $(git rev-parse HEAD) == "$revision" && -z $(git status --porcelain=v1) ]]
sha256sum --check "$base/granularity-binary.sha256"
[[ -s "$profile/readiness-02.log" ]]
instance=$(cat "$profile/instance.id")
mkdir "$out"
manifest() { git ls-files --cached --others --exclude-standard -z | LC_ALL=C sort -z | xargs -0 sha256sum; }
config_manifest() { sha256sum "$profile"/{server.xml,profile.xml,launch.sh,monitor.sh,resources.sh,resources-policy.sh,readiness.sh}; }
manifest > "$out/source.before"
sha256sum "$bin" > "$out/binary.before"
config_manifest > "$out/config.before"
printf '%s\n' "$revision" > "$out/revision"
cp "$profile/readiness-02.log" "$out/profile-ready.txt"
started=$SECONDS
finish() {
  rc=$?
  trap - EXIT
  manifest > "$out/source.after"
  sha256sum "$bin" > "$out/binary.after"
  config_manifest > "$out/config.after"
  if ! cmp -s "$out/source.before" "$out/source.after" || ! cmp -s "$out/binary.before" "$out/binary.after" || ! cmp -s "$out/config.before" "$out/config.after" || [[ -n $(git status --porcelain=v1) ]]; then rc=4; fi
  printf 'exit=%s end=%s elapsed_seconds=%s\n' "$rc" "$(date -u +%FT%TZ)" "$((SECONDS-started))" > "$out/status"
  exit "$rc"
}
trap finish EXIT
active() {
  (( SECONDS-started < 3000 ))
  [[ $(docker inspect --format '{{.Id}} {{.State.Running}} {{.State.OOMKilled}} {{.RestartCount}} {{index .Config.Labels "otel283.owner"}} {{index .Config.Labels "otel283.profile"}}' otel283-ch16-vxnar) == "$instance true false 0 otel283-vxnar ch16-4cpu-16g-v1" ]]
  [[ -e "$profile/monitor.heartbeat" ]] && (( $(date +%s)-$(stat -c %Y "$profile/monitor.heartbeat") < 15 ))
}
admin() { curl --noproxy '*' --fail --silent --show-error --max-time 15 --data-binary "$1" http://127.0.0.1:18125/; }
common=(--backend ch-attrs --order time --ch-url http://127.0.0.1:18125 --seed 283
  --count 1000000 --tenants 1 --attrs 8 --match-every 100 --k 100
  --ch-batch 8192 --ch-batch-bytes 8388608 --batch 32 --save-mode batch --workers 2
  --max-candidates 2000000 --max-bytes 268435456 --timeout 10m --revision "$revision")
physical() { docker exec "$instance" /bin/bash -c 'du -s -B1 /var/lib/clickhouse; du -s -B1 /var/lib/clickhouse/store /var/lib/clickhouse/tmp'; }
active
physical > "$out/physical.before"
docker stats --no-stream --format '{{json .}}' "$instance" > "$out/container.before.jsonl"
# Fresh independent namespaces; the granularity-1 extreme is explicitly exploratory.
for granularity in 8192 512 64 1; do
  active
  run="ch1m_g${granularity}_0287"
  args=("${common[@]}" --run "$run" --ch-index-granularity "$granularity")
  printf '%q ' "$bin" "${args[@]}" --mode ingest > "$out/ingest-g${granularity}.command"
  printf '\n' >> "$out/ingest-g${granularity}.command"
  "$bin" "${args[@]}" --mode ingest --output "$out/ingest-g${granularity}.json"
  "$bin" "${args[@]}" --mode audit --output "$out/audit-g${granularity}.json"
  jq -e '.error == null and .stats.rows == 1000000 and .stats.attributes == 8000000' "$out/audit-g${granularity}.json" >/dev/null
  physical > "$out/physical-after-g${granularity}"
  docker stats --no-stream --format '{{json .}}' "$instance" > "$out/container-after-g${granularity}.jsonl"
done
# Merge drain is untimed, bounded, and requires three zero-active samples.
settled=0
for sample in $(seq 1 60); do
  active
  n=$(admin "SELECT count() FROM system.merges WHERE database IN ('otel_ch1m_g8192_0287','otel_ch1m_g512_0287','otel_ch1m_g64_0287','otel_ch1m_g1_0287') FORMAT TabSeparated")
  [[ "$n" =~ ^[0-9]+$ ]]
  printf '%s active_merges=%s\n' "$(date -u +%FT%TZ)" "$n" >> "$out/merge-drain.txt"
  if [[ "$n" == 0 ]]; then settled=$((settled+1)); else settled=0; fi
  (( settled < 3 )) || break
  sleep 5
done
(( settled >= 3 )) || { echo 'CH merge drain did not complete; no tuning verdict' >&2; exit 6; }
for round in 1 2 3; do
  case "$round" in 1) order=(8192 64 512 1);; 2) order=(512 1 8192 64);; 3) order=(1 512 64 8192);; esac
  ordinal=0
  for granularity in "${order[@]}"; do
    active
    run="ch1m_g${granularity}_0287"
    if (( (round+ordinal)%2 )); then transports=(native http); else transports=(http native); fi
    for transport in "${transports[@]}"; do
      active
      args=("${common[@]}" --run "$run" --ch-index-granularity "$granularity" --ch-query-transport "$transport")
      if [[ "$transport" == native ]]; then args+=(--ch-native-addr 127.0.0.1:19005); fi
      "$bin" "${args[@]}" --mode query --suite all --iterations 1600 --output "$out/query-g${granularity}-${transport}-r${round}.json"
      jq -e '.failures == 0 and (.samples|length) == 1600 and (.histograms|length) == 16 and all(.histograms[]; .population == 100)' "$out/query-g${granularity}-${transport}-r${round}.json" >/dev/null
    done
    ordinal=$((ordinal+1))
  done
done
active
physical > "$out/physical.after"
admin "SELECT database,table,sum(rows) AS rows,sum(bytes_on_disk) AS bytes,sum(marks) AS marks FROM system.parts WHERE active AND database LIKE 'otel_ch1m_g%_0287' GROUP BY database,table FORMAT JSONEachRow" > "$out/parts.after.jsonl"
echo 'Four fresh 1M CH attribute/time layouts audited; rotated 3-round HTTP/native tuning matrix has 38400 exact source-oracle answers. Best-tested choice and confirmation are a separate step; not a 100M/production or global-optimality claim.'
