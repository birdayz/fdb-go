#!/usr/bin/env bash
set -Eeuo pipefail
export GOMAXPROCS=4 TZ=UTC
base=/tmp/fdb-hotelbench.VxNArC
source=$base/timeout-measurement-src
bin=$base/otelbench-timeout-reference
profile=$base/fdb4-config-rw1m0286
session=$profile/sessions/resume-20261027-05
out=$base/query1m-fdb-warm
revision=c7d00bf938edc6cb9a84df4c63b3bbd3ac22dc94
cd "$source"
[[ ! -e "$out" && $(git rev-parse HEAD) == "$revision" && -z $(git status --porcelain=v1) ]]
[[ -f "$session/drain.certificate.json" && ! -e "$session/bulk-phase.json" && ! -e "$session/monitor.stopped" ]]
[[ $(cat "$base/pilot1m-v2-workers2/status") == exit=0* ]]
instance=$(cat "$session/instance.id")
kill -0 "$(cat "$session/monitor.pid")"
sha256sum --check "$base/timeout-binary.sha256"
mkdir "$out"
manifest() { git ls-files --cached --others --exclude-standard -z | LC_ALL=C sort -z | xargs -0 sha256sum; }
manifest > "$out/source.before"
sha256sum "$bin" > "$out/binary.before"
printf '%s\n' "$revision" > "$out/revision"
finish() {
  rc=$?
  trap - EXIT
  manifest > "$out/source.after"
  sha256sum "$bin" > "$out/binary.after"
  if ! cmp -s "$out/source.before" "$out/source.after" || ! cmp -s "$out/binary.before" "$out/binary.after" || [[ -n $(git status --porcelain=v1) ]]; then rc=4; fi
  printf 'exit=%s end=%s\n' "$rc" "$(date -u +%FT%TZ)" > "$out/status"
  exit "$rc"
}
trap finish EXIT
status() {
  [[ ! -e "$session/monitor.stopped" ]] && kill -0 "$(cat "$session/monitor.pid")"
  [[ $(docker inspect otel283-fdb4-vxnar --format '{{.Id}} {{.State.Running}} {{index .Config.Labels "otel283.session"}}') == "$instance true resume-20261027-05" ]]
  timeout --kill-after=1s 12s docker exec "$instance" /usr/bin/timeout --kill-after=1s 10s /usr/bin/fdbcli -C /var/fdb/data/cluster/fdb.cluster --exec 'status json'
}
common=(--backend fdb --order time --cluster-file "$profile/fdb.cluster.seed" --run rw1m0286
  --seed 283 --count 1000000 --tenants 1 --attrs 8 --match-every 100 --batch 32 --save-mode batch
  --workers 2 --diagnostics --k 100 --max-candidates 2000000 --max-bytes 268435456
  --timeout 20m --revision "$revision" --mode query --suite all --iterations 16000)
for round in 1 2 3; do
  status > "$out/fdb-before-${round}.json"
  jq -ce --argjson allow_batch_warning false -f "$profile/status-check.jq" "$out/fdb-before-${round}.json" > "$out/health-before-${round}.json"
  "$bin" "${common[@]}" --output "$out/all-${round}.json"
  jq -e '.failures == 0 and (.samples | length) == 16000 and (.histograms | length) == 16 and all(.histograms[]; .population == 1000)' "$out/all-${round}.json" >/dev/null
  status > "$out/fdb-after-${round}.json"
  jq -ce --argjson allow_batch_warning false -f "$profile/status-check.jq" "$out/fdb-after-${round}.json" > "$out/health-after-${round}.json"
done
echo 'Three completed warm/local FDB rounds, 48000 source-oracle-checked answers; 1M only, not a CH/100M/HA/SLO comparison.'
