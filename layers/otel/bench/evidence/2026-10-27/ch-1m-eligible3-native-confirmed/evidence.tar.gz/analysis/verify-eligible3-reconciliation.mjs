import fs from 'node:fs';
import crypto from 'node:crypto';
let base = '/tmp/fdb-hotelbench.VxNArC', output;
for (let i=2;i<process.argv.length;i+=2) {
  const key=process.argv[i], value=process.argv[i+1];
  if (!value || !['--root','--output'].includes(key)) throw Error('usage: [--root INPUTROOT] [--output NEWFILE]');
  if (key==='--root') base=value; else output=value;
}
const root = `${base}/ch1m-eligible3-querylog-resume03`;
const read = p => fs.readFileSync(p);
const json = p => JSON.parse(read(p));
const sha = p => crypto.createHash('sha256').update(read(p)).digest('hex');
const check = (v, why) => { if (!v) throw Error(why); };
const metric = v => {
  check((typeof v === 'number' && Number.isSafeInteger(v) && v >= 0) ||
    (typeof v === 'string' && /^(0|[1-9][0-9]*)$/.test(v) && Number.isSafeInteger(Number(v))), 'bad read/duration metrics');
  return Number(v);
};
check(read(`${root}/status`).toString().trim() === '21 reconciliations completed', 'missing completed status');
const dirs = fs.readdirSync(root, {withFileTypes: true}).filter(d => d.isDirectory()).map(d => d.name).sort();
check(dirs.length === 21, 'wrong reconciliation population');
const allIDs = new Set(), outputs = [];
let matrixIDs = 0, confirmationIDs = 0;
for (const dir of dirs) {
  const m = /^(?:g(8192|512|64)-(native|http)-r([123])|confirm-native-r([123]))$/.exec(dir);
  check(m, `unexpected reconciliation ${dir}`);
  const confirmed = !!m[4];
  const source = confirmed ? `${base}/ch1m-eligible3-confirmation/native-${m[4]}.json` : `${base}/ch1m-eligible3-query-matrix/query-g${m[1]}-${m[2]}-r${m[3]}.json`;
  const d = `${root}/${dir}`, e = json(source), provenance = json(`${d}/provenance.json`), reconciled = json(`${d}/reconciliation.json`);
  const logs = read(`${d}/query-log.jsonl`).toString().trim().split('\n').filter(Boolean).map(JSON.parse);
  const count = confirmed ? 16000 : 1600;
  check(e.failures === 0 && e.error == null && e.samples.length === count, 'bad source population');
  check(provenance.failed === false && provenance.failure === '' && provenance.session === 'resume03' && provenance.source_sha256 === sha(source) && provenance.sample_count === count, 'provenance mismatch');
  for (const [file, hash] of Object.entries(provenance.artifacts)) check(sha(`${d}/${file}`) === hash, 'artifact hash mismatch');
  check(logs.length === count && reconciled.length === count, 'terminal-row/report population mismatch');
  const report = new Map(reconciled.map(r => [r.query_id, r]));
  const byID = new Map(logs.map(r => [r.query_id, r]));
  check(report.size === count && byID.size === count, 'duplicate IDs');
  const classes = {};
  for (const sample of e.samples) {
    const id = sample.query_id, row = byID.get(id), r = report.get(id);
    check(/^otel_[0-9a-f]{32}$/.test(id) && !allIDs.has(id), 'missing/duplicate global ID');
    allIDs.add(id);
    check(r?.status === 'ok' && r.observed_terminal_rows === 1 && row?.type === 'QueryFinish' && row.databases.includes(`otel_${e.config.run}`), 'error, missing or wrong-scope terminal row');
    check(row.setting_max_threads === '4' && row.setting_max_memory_usage === '8589934592' && row.setting_use_query_cache === '0', 'observed query settings changed');
    const values = [row.read_rows, row.read_bytes, row.query_duration_ms].map(metric);
    (classes[sample.class] ??= []).push(values);
  }
  check(Object.keys(classes).length === 16 && Object.values(classes).every(v => v.length === count/16), 'class census invalid');
  const summary = {};
  for (const [name, values] of Object.entries(classes)) {
    summary[name] = {population: values.length};
    for (const [i, metric] of ['read_rows', 'read_bytes', 'query_duration_ms'].entries()) {
      const v = values.map(a => a[i]).sort((a, b) => a-b);
      summary[name][metric] = {min: v[0], p50: v[Math.ceil(v.length*.5)-1], p99: v[Math.ceil(v.length*.99)-1], max: v.at(-1)};
    }
  }
  if (confirmed) confirmationIDs += count; else matrixIDs += count;
  outputs.push({dir, source_sha256: sha(source), provenance_sha256: sha(`${d}/provenance.json`), data_query_count: count, classes: summary});
}
check(matrixIDs === 28800 && confirmationIDs === 48000 && allIDs.size === 76800, 'overall ID population mismatch');
const result = {schema: 'otelbench_independent_data_query_census_v1', reconciliation_count: dirs.length, unique_data_query_ids: allIDs.size, matrix_query_ids: matrixIDs, confirmation_query_ids: confirmationIDs, errors_missing_duplicates: 0, observed_max_threads: 4, observed_max_memory_usage: 8589934592, observed_use_query_cache: 0, outputs, boundary: 'Data-request-only server query_log work. Separate ownership requests and client decoding/network are excluded, while original timed ns includes them. Integer query_duration_ms=0 means below1ms, never zero engine work. No FDB-equivalent work or isolated-engine-speedup claim.'};
output ??= `${base}/ch1m-eligible3-data-work.json`;
fs.writeFileSync(output, JSON.stringify(result, null, 2) + '\n', {flag: 'wx', mode: 0o600});
console.log(`21 reconciliations independently verified: ${matrixIDs}+${confirmationIDs} unique data IDs; zero errors/missing/duplicates; settings4threads/8GiB/cacheoff.`);
for (const o of outputs.filter(o => o.dir.startsWith('confirm-'))) console.log(o.dir, Object.fromEntries(['trace', 'span', 'genai_response', 'time_narrow'].map(c => [c, o.classes[c].query_duration_ms])));
