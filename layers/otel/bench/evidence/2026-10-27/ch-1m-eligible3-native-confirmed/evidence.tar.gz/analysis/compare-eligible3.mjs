import fs from 'node:fs';
import crypto from 'node:crypto';
import {createRequire} from 'node:module';
const require = createRequire(import.meta.url);
const p = require('./ch1m-select-confirm-eligible3-resume03/policy.js');
let base = '/tmp/fdb-hotelbench.VxNArC', output;
for (let i=2;i<process.argv.length;i+=2) {
  const key=process.argv[i], value=process.argv[i+1];
  if (!value || !['--root','--output'].includes(key)) throw Error('usage: [--root INPUTROOT] [--output NEWFILE]');
  if (key==='--root') base=value; else output=value;
}
const fdbRevision = 'c7d00bf938edc6cb9a84df4c63b3bbd3ac22dc94';
const chRevision = '9244882a5914e0f897b0216866ca77d2bd4b6910';
const corpus = 'f81921380a3919e7eae1cfd847c68cf6a4911ab1230aa751fa18fbc40ebb84d3';
const read = path => fs.readFileSync(path);
const json = path => JSON.parse(read(path));
const sha = path => crypto.createHash('sha256').update(read(path)).digest('hex');
const assert = (value, message) => { if (!value) throw Error(message); };
for (const name of ['query1m-fdb-warm', 'ch1m-eligible3-confirmation']) {
  assert(/^exit=0(?:\s|$)/.test(read(`${base}/${name}/status`).toString()), `${name} incomplete`);
  for (const kind of ['source', 'binary']) assert(read(`${base}/${name}/${kind}.before`).equals(read(`${base}/${name}/${kind}.after`)), `${name} ${kind} changed`);
}
assert(/^exit=0 state=passed commands=18 attempts=28800 failed_commands=0(?:\s|$)/.test(read(`${base}/ch1m-eligible3-query-matrix/status`).toString()), 'tuning matrix incomplete');
const selected = json(`${base}/ch1m-eligible3-confirmation/selection.json`);
assert(selected.winner === 8192 && selected.matrix_failures === 0 && selected.excluded.length === 1 && selected.excluded[0].granularity === 1 && selected.excluded[0].timed_population === 0, 'selection/exclusion differs');
const rounds = {fdb: [], clickhouse_native: []};
const hashes = {};
let oracle;
for (let round = 1; round <= 3; round++) {
  for (const engine of ['fdb', 'clickhouse_native']) {
    const file = engine === 'fdb' ? `${base}/query1m-fdb-warm/all-${round}.json` : `${base}/ch1m-eligible3-confirmation/native-${round}.json`;
    const e = json(file);
    assert(e.config?.diagnostics === (engine === 'fdb'), `${engine} diagnostics setting changed`);
    const identity = engine === 'fdb' ? {backend: 'fdb', revision: fdbRevision, corpus, run: 'rw1m0286'} : {backend: 'ch-attrs', revision: chRevision, corpus, run: 'ch1m_g8192_0287', transport: 'native', granularity: 8192};
    p.validate(e, 16000, identity, oracle);
    if (!oracle) oracle = e.samples;
    const classes = {};
    for (const name of p.classes) {
      const values = e.samples.filter(s => s.class === name).map(s => s.ns).sort((a, b) => a-b);
      assert(values.length === 1000, `${name} empty or wrong population`);
      const q = fraction => values[Math.ceil(fraction * values.length) - 1];
      classes[name] = {...e.histograms[name], p999_ns: q(0.999)};
    }
    rounds[engine].push({round, go: e.go, start_utc: e.start_utc, wall_ns: e.wall_ns, first_sample: e.samples[0], classes});
    hashes[file] = sha(file);
  }
}
const range = values => [Math.min(...values), Math.max(...values)];
const comparison = {};
for (const name of p.classes) {
  const f = rounds.fdb.map(r => r.classes[name]), c = rounds.clickhouse_native.map(r => r.classes[name]);
  const f50 = range(f.map(h => h.p50_ns)), c50 = range(c.map(h => h.p50_ns));
  comparison[name] = {population_per_engine: 3000, fdb_p50_ns_range: f50, ch_p50_ns_range: c50, fdb_p99_ns_range: range(f.map(h => h.p99_ns)), ch_p99_ns_range: range(c.map(h => h.p99_ns)), fdb_max_ns: Math.max(...f.map(h => h.max_ns)), ch_max_ns: Math.max(...c.map(h => h.max_ns)), descriptive_ch_over_fdb_p50_ratio_range: [c50[0]/f50[1], c50[1]/f50[0]]};
}
output ??= `${base}/ch1m-eligible3-comparison.json`;
const result = {schema: 'otelbench_1m_eligible3_comparison_v1', selection_rule: selected.selection, winner: selected.winner, excluded: selected.excluded, corpus, fdb_revision: fdbRevision, ch_revision: chRevision, fdb_binary_sha256: selected.fdb_binary_sha256, ch_binary_sha256: selected.ch_binary_sha256, source_manifest_sha256: selected.source_manifest_sha256, compiler_versions: [...new Set([...rounds.fdb, ...rounds.clickhouse_native].map(r => r.go))], query_population: {fdb: 48000, clickhouse_confirmation: 48000, clickhouse_tuning: 28800, classes: 16, each_class_each_round: 1000, failures: 0}, inputs: {...hashes, [`${base}/ch1m-eligible3-confirmation/selection.json`]: sha(`${base}/ch1m-eligible3-confirmation/selection.json`)}, comparison, rounds, boundary: 'Sequential local immutable 1M corpora, 4CPU/16GiB profiles, not 100M or HA/production/SLO proof. Best-tested passing configuration only; granularity1 failed full EXPLAIN audits and was not timed. FDB command timeout20m diagnostics on vs CH10m diagnostics off/server2s; no matched deadline or durability claim. Source/oracle preparation excluded from sample ns. CH confirmation followed a clean server restart; all first samples and tails retained, no hidden warmup. Ratios are descriptive cross-round bounds, not causal or independent-trial estimates. p999 is empirical nearest rank index998 at n1000, not a production SLO. Query-log work is separate data-request-only evidence.'};
fs.writeFileSync(output, JSON.stringify(result, null, 2) + '\n', {flag: 'wx', mode: 0o600});
for (const name of p.targets) {
  const r = comparison[name];
  console.log(`${name}: FDB p50=${r.fdb_p50_ns_range.map(n => (n/1e6).toFixed(3)).join('..')}ms CH=${r.ch_p50_ns_range.map(n => (n/1e6).toFixed(3)).join('..')}ms ratio=${r.descriptive_ch_over_fdb_p50_ratio_range.map(n => n.toFixed(2)).join('..')}x`);
}
console.log(`compiler=${result.compiler_versions.join(',')} 48000+48000 checked; ${output}`);
