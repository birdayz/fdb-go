import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';
import assert from 'node:assert/strict';
const src='/tmp/fdb-hotelbench.VxNArC', testroot=fs.mkdtempSync(path.join(os.tmpdir(),'otel-census-owned-'));
fs.chmodSync(testroot,0o700);
function copy(from,to) {
  const st=fs.lstatSync(from); assert(!st.isSymbolicLink(),`refusing symlink ${from}`);
  if(st.isDirectory()){fs.mkdirSync(to,{recursive:true});for(const n of fs.readdirSync(from))copy(path.join(from,n),path.join(to,n));}
  else {assert(st.isFile(),`refusing non-file ${from}`);fs.copyFileSync(from,to,fs.constants.COPYFILE_EXCL);}
}
for(const n of ['query1m-fdb-warm','ch1m-eligible3-confirmation','ch1m-eligible3-querylog-resume03','ch1m-eligible3-query-matrix'])copy(path.join(src,n),path.join(testroot,n));
const comparison=path.join(src,'compare-eligible3.mjs'), verifier=path.join(src,'verify-eligible3-reconciliation.mjs');
let n=0;
function execute(helper,success,label) {
 const output=path.join(testroot,`result-${++n}.json`);
 const r=spawnSync(process.execPath,[helper,'--root',testroot,'--output',output],{encoding:'utf8',maxBuffer:1024*1024});
 assert.equal(r.status===0,success,`${label}: status=${r.status} stderr=${r.stderr}`);
 if(success)assert(fs.existsSync(output),`${label}: missing output`); else assert(!fs.existsSync(output),`${label}: unexpected output`);
 return success?JSON.parse(fs.readFileSync(output,'utf8')):null;
}
function mutation(label,helper,fn) {
 const saved=new Map();
 const save=file=>{if(!saved.has(file))saved.set(file,fs.readFileSync(file));};
 const write=(file,v)=>{save(file);fs.writeFileSync(file,typeof v==='string'?v:JSON.stringify(v)+'\n');};
 const j=file=>JSON.parse(fs.readFileSync(file));
 const hash=file=>crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
 const rehash=(dir,...names)=>{const f=path.join(dir,'provenance.json'),o=j(f);for(const name of names)o.artifacts[name]=hash(path.join(dir,name));write(f,o);};
 try {fn({save,write,j,hash,rehash});execute(helper,false,label);} finally {for(const [file,buf] of saved)fs.writeFileSync(file,buf);}
}
const compare=execute(comparison,true,'comparison positive 16 classes/96k samples');
assert.equal(compare.query_population.fdb,48000);assert.equal(compare.query_population.clickhouse_confirmation,48000);assert.equal(Object.keys(compare.comparison).length,16);
const work=execute(verifier,true,'reconciliation positive 21/76800');assert.equal(work.reconciliation_count,21);assert.equal(work.unique_data_query_ids,76800);assert.equal(work.matrix_query_ids,28800);assert.equal(work.confirmation_query_ids,48000);
const fdb=path.join(testroot,'query1m-fdb-warm'), confirm=path.join(testroot,'ch1m-eligible3-confirmation'), tuning=path.join(testroot,'ch1m-eligible3-query-matrix'), logs=path.join(testroot,'ch1m-eligible3-querylog-resume03');
const f1=path.join(fdb,'all-1.json'), c1=path.join(confirm,'native-1.json'), selection=path.join(confirm,'selection.json'), rd=path.join(logs,'confirm-native-r1'), raw=path.join(rd,'query-log.jsonl'), report=path.join(rd,'reconciliation.json'), prov=path.join(rd,'provenance.json');
for(const [label,file,text] of [['missing fdb status',path.join(fdb,'status'),''],['incomplete fdb status',path.join(fdb,'status'),'exit=1\n'],['changed source',path.join(fdb,'source.after'),'different'],['changed binary',path.join(confirm,'binary.after'),'different'],['incomplete matrix status',path.join(tuning,'status'),'exit=10\n']]) mutation(label,comparison,x=>x.write(file,text));
mutation('wrong winner',comparison,x=>{const e=x.j(selection);e.winner=64;x.write(selection,e);});
mutation('g1 exclusion vacuity',comparison,x=>{const e=x.j(selection);e.excluded=[];x.write(selection,e);});
mutation('wrong selection failure count',comparison,x=>{const e=x.j(selection);e.matrix_failures=1;x.write(selection,e);});
mutation('partial compare population',comparison,x=>{const e=x.j(f1);e.samples.pop();x.write(f1,e);});
mutation('empty compare population',comparison,x=>{const e=x.j(f1);e.samples=[];x.write(f1,e);});
mutation('comparison sample error',comparison,x=>{const e=x.j(f1);e.samples[0].error='bad';x.write(f1,e);});
mutation('comparison changed class',comparison,x=>{const e=x.j(f1);e.samples[0].class='span';x.write(f1,e);});
mutation('comparison histogram mismatch',comparison,x=>{const e=x.j(f1);e.histograms.trace.p99_ns++;x.write(f1,e);});
mutation('comparison oracle mismatch',comparison,x=>{const e=x.j(c1);e.samples[0].result_digest='0'.repeat(64);x.write(c1,e);});
mutation('comparison wrong identity',comparison,x=>{const e=x.j(c1);e.config.ch_index_granularity=64;x.write(c1,e);});
mutation('FDB diagnostics false',comparison,x=>{const e=x.j(f1);e.config.diagnostics=false;x.write(f1,e);});
mutation('FDB diagnostics missing',comparison,x=>{const e=x.j(f1);delete e.config.diagnostics;x.write(f1,e);});
mutation('CH diagnostics true',comparison,x=>{const e=x.j(c1);e.config.diagnostics=true;x.write(c1,e);});
mutation('CH diagnostics missing',comparison,x=>{const e=x.j(c1);delete e.config.diagnostics;x.write(c1,e);});
// Positive nearest-rank check changes only timing/histogram inside the owned copy.
{
 const original=fs.readFileSync(f1), e=JSON.parse(original), chosen=e.samples.filter(s=>s.class==='trace');
 chosen.forEach((s,i)=>s.ns=i+1);e.histograms.trace={population:1000,min_ns:1,p50_ns:500,p95_ns:950,p99_ns:990,max_ns:1000};
 fs.writeFileSync(f1,JSON.stringify(e));try{const o=execute(comparison,true,'nearest-rank boundaries');const h=o.rounds.fdb[0].classes.trace;assert.equal(h.p50_ns,500);assert.equal(h.p95_ns,950);assert.equal(h.p99_ns,990);assert.equal(h.p999_ns,999);assert.equal(h.max_ns,1000);}finally{fs.writeFileSync(f1,original);}
}
mutation('missing log completion status',verifier,x=>x.write(path.join(logs,'status'),''));
{
 const target=path.join(logs,'unexpected-directory');fs.mkdirSync(target);try{execute(verifier,false,'wrong directory population');}finally{fs.rmdirSync(target);}
 const from=path.join(logs,'g64-http-r1'),to=path.join(logs,'unexpected-name');fs.renameSync(from,to);try{execute(verifier,false,'unexpected directory name');}finally{fs.renameSync(to,from);}
}
mutation('bad source sha',verifier,x=>{const e=x.j(prov);e.source_sha256='0'.repeat(64);x.write(prov,e);});
mutation('failed provenance',verifier,x=>{const e=x.j(prov);e.failed=true;x.write(prov,e);});
mutation('wrong session',verifier,x=>{const e=x.j(prov);e.session='resume02';x.write(prov,e);});
mutation('artifact SHA changed',verifier,x=>{const e=x.j(prov);e.artifacts['query-log.jsonl']='0'.repeat(64);x.write(prov,e);});
mutation('empty report',verifier,x=>{x.write(report,[]);x.rehash(rd,'reconciliation.json');});
mutation('empty raw log',verifier,x=>{x.write(raw,'');x.rehash(rd,'query-log.jsonl');});
function editRaw(x,fn){const rows=fs.readFileSync(raw,'utf8').trim().split('\n').map(JSON.parse);fn(rows);x.write(raw,rows.map(JSON.stringify).join('\n')+'\n');x.rehash(rd,'query-log.jsonl');}
{
 const original=fs.readFileSync(raw), originalProv=fs.readFileSync(prov);
 const rows=original.toString().trim().split('\n').map(JSON.parse);rows[0].query_duration_ms='0';rows[0].read_rows=0;
 fs.writeFileSync(raw,rows.map(JSON.stringify).join('\n')+'\n');const v=JSON.parse(originalProv);v.artifacts['query-log.jsonl']=crypto.createHash('sha256').update(fs.readFileSync(raw)).digest('hex');fs.writeFileSync(prov,JSON.stringify(v));
 try{const result=execute(verifier,true,'zero-duration reporting positive');assert.match(result.boundary,/below1ms/);assert(result.outputs.find(o=>o.dir==='confirm-native-r1').classes.trace.query_duration_ms.min===0);}finally{fs.writeFileSync(raw,original);fs.writeFileSync(prov,originalProv);}
}
mutation('duplicate log ID',verifier,x=>editRaw(x,rows=>rows[1].query_id=rows[0].query_id));
mutation('terminal error',verifier,x=>editRaw(x,rows=>rows[0].type='ExceptionWhileProcessing'));
mutation('wrong database scope',verifier,x=>editRaw(x,rows=>rows[0].databases=['unowned']));
mutation('query settings mismatch',verifier,x=>editRaw(x,rows=>rows[0].setting_max_threads='8'));
mutation('cache setting mismatch',verifier,x=>editRaw(x,rows=>rows[0].setting_use_query_cache='1'));
mutation('memory setting mismatch',verifier,x=>editRaw(x,rows=>rows[0].setting_max_memory_usage='1'));
mutation('invalid metrics',verifier,x=>editRaw(x,rows=>rows[0].read_bytes='not-a-number'));
for(const [label,value] of [['null',null],['empty',''],['boolean',false],['object',{}],['array',[]],['noncanonical','00'],['signed string','-1'],['whitespace',' 1'],['unsafe string','9007199254740992'],['unsafe number',9007199254740992]]) mutation(`invalid metric ${label}`,verifier,x=>editRaw(x,rows=>rows[0].read_rows=value));
mutation('missing metric',verifier,x=>editRaw(x,rows=>delete rows[0].read_rows));
mutation('report error',verifier,x=>{const r=x.j(report);r[0].status='error';x.write(report,r);x.rehash(rd,'reconciliation.json');});
mutation('duplicate report ID',verifier,x=>{const r=x.j(report);r[1].query_id=r[0].query_id;x.write(report,r);x.rehash(rd,'reconciliation.json');});
mutation('source sample missing ID',verifier,x=>{const e=x.j(c1);delete e.samples[0].query_id;x.write(c1,e);const v=x.j(prov);v.source_sha256=x.hash(c1);x.write(prov,v);});
mutation('source duplicate ID',verifier,x=>{const e=x.j(c1);e.samples[1].query_id=e.samples[0].query_id;x.write(c1,e);const v=x.j(prov);v.source_sha256=x.hash(c1);x.write(prov,v);});
mutation('source empty sample census',verifier,x=>{const e=x.j(c1);e.samples=[];x.write(c1,e);const v=x.j(prov);v.source_sha256=x.hash(c1);x.write(prov,v);});
mutation('source failed population',verifier,x=>{const e=x.j(c1);e.failures=1;x.write(c1,e);const v=x.j(prov);v.source_sha256=x.hash(c1);x.write(prov,v);});
mutation('source error present',verifier,x=>{const e=x.j(c1);e.error='error';x.write(c1,e);const v=x.j(prov);v.source_sha256=x.hash(c1);x.write(prov,v);});
mutation('report observed rows mismatch',verifier,x=>{const r=x.j(report);r[0].observed_terminal_rows=0;x.write(report,r);x.rehash(rd,'reconciliation.json');});
mutation('provenance population mismatch',verifier,x=>{const v=x.j(prov);v.sample_count=0;x.write(prov,v);});
mutation('provenance nonempty failure',verifier,x=>{const v=x.j(prov);v.failure='bad';x.write(prov,v);});
mutation('negative read metric',verifier,x=>editRaw(x,rows=>rows[0].read_rows=-1));
mutation('fractional duration',verifier,x=>editRaw(x,rows=>rows[0].query_duration_ms=0.5));
mutation('missing terminal row',verifier,x=>editRaw(x,rows=>rows.pop()));
mutation('sample count mismatch',verifier,x=>{const e=x.j(c1);e.samples.pop();x.write(c1,e);const v=x.j(prov);v.source_sha256=x.hash(c1);x.write(prov,v);});
mutation('class population skew',verifier,x=>{const e=x.j(c1);e.samples[0].class='span';x.write(c1,e);const v=x.j(prov);v.source_sha256=x.hash(c1);x.write(prov,v);});
const exists=path.join(testroot,'already-exists.json');fs.writeFileSync(exists,'untouched');const r=spawnSync(process.execPath,[comparison,'--root',testroot,'--output',exists],{encoding:'utf8'});assert.notEqual(r.status,0);assert.equal(fs.readFileSync(exists,'utf8'),'untouched');n++;
console.log(`PASS ${n} helper executions; includes 4 positive controls, nearest-rank and zero-duration boundaries, and existing-output refusal; fixtures retained at ${testroot}`);
