'use strict';
const classes=['trace','trace_absent','span','span_absent','genai_response','genai_scope_resource','genai_scope_scope','genai_type','genai_absent','genai_operation','genai_provider','genai_model','time_narrow','time_empty','time_absent','time_broad'];
const targets=['trace','span','genai_response','time_narrow'];
function validate(e,count,identity,oracle,allowFailures=false) {
  if(!e || !e.config || e.tool!=='otelbench-v2' || e.mode!=='query' || e.suite!=='all' || e.backend!==identity.backend || e.revision!==identity.revision || e.corpus_fingerprint!==identity.corpus || e.config.run!==identity.run || e.config.backend!==identity.backend || !Number.isSafeInteger(e.failures) || e.failures<0 || e.failures>count) throw Error('receipt identity or failure');
  if(e.failures===0 ? e.error!=null : (!allowFailures || e.error!==`otel oracle measure queries: ${e.failures}/${count} queries failed; raw samples include failures; histograms are successful-only`)) throw Error('receipt failure status');
  const c=e.config;
  for(const [k,v] of Object.entries({seed:283,count:1000000,tenants:1,attributes:8,match_every:100,k:100,batch:32,save_mode:'batch',workers:2,max_candidates:2000000,max_bytes:268435456,hash_bytes:32,order:'time',tenant:0,iterations:count})) if(c[k]!==v) throw Error('config mismatch '+k);
  if(identity.backend==='ch-attrs' && (c.ch_query_transport!==identity.transport || c.ch_index_granularity!==identity.granularity || c.ch_batch!==8192 || c.ch_batch_bytes!==8388608)) throw Error('CH configuration mismatch');
  if(!Array.isArray(e.samples) || e.samples.length!==count || count%16) throw Error('sample count mismatch');
  const grouped=Object.fromEntries(classes.map(x=>[x,[]])), ids=new Set(); let failures=0;
  for(let i=0;i<count;i++) {
    const s=e.samples[i];
    if(!s || s.iteration!==i || s.class!==classes[i%16] || !Number.isSafeInteger(s.ns) || s.ns<=0 || !Number.isSafeInteger(s.results) || s.results<0 || !/^[0-9a-f]{64}$/.test(s.result_digest || '') || (s.error!==undefined && (typeof s.error!=='string' || !s.error))) throw Error('bad sample '+i);
    const failed=!!s.error; if(failed) failures++;
    if(!failed && oracle && (s.class!==oracle[i].class || s.result_digest!==oracle[i].result_digest || s.results!==oracle[i].results)) throw Error('cross-engine oracle mismatch '+i);
    if(identity.backend==='ch-attrs') { const id=s.query_id || ''; if((!failed && !id) || (id && (!/^otel_[0-9a-f]{32}$/.test(id) || ids.has(id) || s.query_transport!==identity.transport))) throw Error('bad CH query id/transport'); if(id)ids.add(id); }
    if(!failed) grouped[s.class].push(s.ns);
  }
  if(failures!==e.failures) throw Error('failure population mismatch');
  const hist={};
  for(const cls of classes) {
    const v=grouped[cls].sort((a,b)=>a-b);
    if(!v.length) {if(e.histograms?.[cls]!==undefined)throw Error('empty class histogram'); continue;}
    const q=p=>v[Math.ceil(v.length*p/100)-1], h={population:v.length,min_ns:v[0],p50_ns:q(50),p95_ns:q(95),p99_ns:q(99),max_ns:v[v.length-1]};
    if(JSON.stringify(e.histograms?.[cls])!==JSON.stringify(h)) throw Error('histogram mismatch '+cls);
    hist[cls]=h;
  }
  if(Object.keys(e.histograms||{}).length!==Object.keys(hist).length) throw Error('extra/missing histogram');
  return {hist,failures};
}
function choose(rounds) {
  const scores=[]; for(const g of [64,512,8192]) {
    if(!rounds[g] || !Array.isArray(rounds[g].native) || !Array.isArray(rounds[g].http) || rounds[g].native.length!==3 || rounds[g].http.length!==3) throw Error('missing rounds');
    if([...rounds[g].native,...rounds[g].http].some(r=>r.failures!==0)) continue;
    const values=rounds[g].native.flatMap(r=>targets.map(c=>r.hist[c].p50_ns));
    if(values.length!==12 || values.some(x=>!Number.isFinite(x)||x<=0)) throw Error('invalid score');
    scores.push({granularity:g,score_ns:Math.exp(values.reduce((a,v)=>a+Math.log(v),0)/12)});
  }
  if(!scores.length) throw Error('no eligible granularity');
  scores.sort((a,b)=>a.score_ns-b.score_ns || a.granularity-b.granularity); return scores;
}
module.exports={classes,targets,validate,choose};
