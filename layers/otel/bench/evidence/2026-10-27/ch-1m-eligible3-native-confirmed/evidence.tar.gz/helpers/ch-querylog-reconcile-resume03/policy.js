'use strict';
const ID = /^otel_[0-9a-f]{32}$/;
function input(e) {
  if (!e || !e.config || !/^ch-(attrs|map)$/.test(e.backend) || e.config.backend !== e.backend || !/^[a-z0-9_]{8,48}$/.test(e.config.run || '') || !/^[0-9a-f]{64}$/.test(e.corpus_fingerprint || '')) throw Error('invalid receipt identity');
  if (!Array.isArray(e.samples) || !e.samples.length || e.samples.length > 100000) throw Error('invalid sample population');
  const ids = new Set();
  for (const s of e.samples) {
    if (!s || !ID.test(s.query_id || '')) throw Error('invalid sample query_id');
    if (ids.has(s.query_id)) throw Error('duplicate sample query_id');
    ids.add(s.query_id);
  }
  return {run:e.config.run, backend:e.backend, corpus:e.corpus_fingerprint, db:'otel_'+e.config.run, ids:[...ids]};
}
function reconcile(meta, rows) {
  const wanted = new Set(meta.ids), groups = new Map(meta.ids.map(id=>[id,[]]));
  for (const row of rows) {
    if (!wanted.has(row.query_id)) throw Error('query log returned unrequested ID');
    groups.get(row.query_id).push(row);
  }
  const result = [];
  for (const id of meta.ids) {
    const matches=groups.get(id);
    let status='ok';
    if (!matches.length) status='missing';
    else if (matches.length !== 1) status='duplicate';
    else if (matches[0].type !== 'QueryFinish') status='error';
    else if (!Array.isArray(matches[0].databases) || !matches[0].databases.includes(meta.db)) status='scope_mismatch';
    const row=matches.length===1 ? matches[0] : undefined;
    if (status==='ok') {
      for (const key of ['read_rows','read_bytes','query_duration_ms']) if (!/^(0|[1-9][0-9]*)$/.test(String(row[key]))) status='invalid_metrics';
    }
    result.push({query_id:id,status, ...(row && status==='ok' ? {duration_interpretation: String(row.query_duration_ms)==='0' ? '0ms at integer-millisecond resolution (<1ms)' : 'integer milliseconds'} : {}), observed_terminal_rows:matches.length});
  }
  return result;
}
function owner(line,id,approved,deadline,now,heartbeatAge) {
  if(approved!=='yes' || !/^[0-9a-f]{64}$/.test(id || '') || !Number.isSafeInteger(deadline) || !Number.isSafeInteger(now) || !Number.isSafeInteger(heartbeatAge) || heartbeatAge<0 || heartbeatAge>=15 || deadline-now<15 || deadline-now>3600) throw Error('resume03 approval/deadline/heartbeat invalid');
  const expected=`${id} otel283-vxnar ch16-4cpu-16g-v1 resume03 true false 0 sha256:b2bfa4d8399ee9973868cc5c1754cb506a6f4b86fbddc41010cc090beb55c85e host 4000000000 17179869184 17179869184 otel283-vxnar-ch16-v1`;
  if(line!==expected) throw Error('resume03 owner/profile/limits/mount mismatch');
}
module.exports={input,reconcile,owner};
