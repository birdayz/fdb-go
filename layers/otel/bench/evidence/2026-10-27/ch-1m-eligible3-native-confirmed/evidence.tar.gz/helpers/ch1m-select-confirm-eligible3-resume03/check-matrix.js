'use strict';
const fs=require('node:fs'), p=require('./policy');
try {
  const [file,gs,transport,rcs]=process.argv.slice(2),g=Number(gs),rc=Number(rcs);
  if(process.argv.length!==6 || ![64,512,8192].includes(g) || !['http','native'].includes(transport) || ![0,1].includes(rc)) throw Error('invalid check arguments/command exit');
  const e=JSON.parse(fs.readFileSync(file)); const run=`ch1m_g${g}_0287`;
  const v=p.validate(e,1600,{backend:'ch-attrs',revision:'9244882a5914e0f897b0216866ca77d2bd4b6910',corpus:'f81921380a3919e7eae1cfd847c68cf6a4911ab1230aa751fa18fbc40ebb84d3',run,granularity:g,transport},undefined,true);
  if(rc!==(v.failures?1:0)) throw Error('command exit/failures mismatch');
  console.log(v.failures);
}catch(e){console.error(e.message);process.exitCode=1;}
