#!/usr/bin/env bash
set -Eeuo pipefail
umask 077
base=/tmp/fdb-hotelbench.VxNArC
matrix=$base/ch1m-eligible3-query-matrix
confirmation=$base/ch1m-eligible3-confirmation
out=$base/ch1m-eligible3-querylog-resume03
helper=$base/ch-querylog-reconcile-resume03
profile=$base/ch16-config-resume03
[[ ${CH03_RECONCILE_APPROVED:-} == yes ]] || { echo 'Explicit post-timing reconciliation approval required' >&2; exit 1; }
status=$(cat "$matrix/status")
[[ $(cat "$confirmation/status") == exit=0* ]] && [[ $status == 'exit=0 state=passed commands=18 attempts=28800 '* || $status == 'exit=10 state=complete-with-failures commands=18 attempts=28800 '* ]] || { echo 'Timing matrix or confirmation incomplete' >&2; exit 1; }
(cd "$helper" && sha256sum -c SHA256SUMS >/dev/null)
(cd "$confirmation" && sha256sum -c confirmation.sha256 && sha256sum -c selection.sha256)
node "$helper/preflight.js"
[[ ! -e "$out" ]] || { echo 'Output exists: inspect and continue manually in fresh directories' >&2; exit 1; }
deadline=$(cat "$profile/deadline.epoch"); [[ $deadline =~ ^[0-9]+$ ]] && (( deadline-$(date +%s)<=3600 )) || exit 1
deadline_hash=$(sha256sum "$profile/deadline.epoch" | cut -d' ' -f1)
mkdir "$out"
first=yes
run_one() {
  local file=$1 dir=$2
  [[ $(sha256sum "$profile/deadline.epoch" | cut -d' ' -f1) == "$deadline_hash" ]] && (( deadline-$(date +%s) >= 130 )) || { echo 'Deadline changed or insufficient TTL; defer remaining receipts' >&2; return 1; }
  [[ -f "$profile/monitor.heartbeat" ]] && (( $(date +%s)-$(stat -c %Y "$profile/monitor.heartbeat") < 15 )) || return 1
  "$profile/resources.sh"
  local opts=(); if [[ $first == yes ]]; then opts=(--flush); first=no; fi
  timeout --foreground --kill-after=5s 125s node "$helper/reconcile.js" "$file" "$dir" "${opts[@]}"
}
for g in 8192 512 64; do for t in native http; do for r in 1 2 3; do
  run_one "$matrix/query-g${g}-${t}-r${r}.json" "$out/g${g}-${t}-r${r}"
done; done; done
for r in 1 2 3; do run_one "$confirmation/native-$r.json" "$out/confirm-native-r$r"; done
printf '21 reconciliations completed\n' > "$out/status"
