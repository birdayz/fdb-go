'use strict';
const fs=require('node:fs'), crypto=require('node:crypto'), p=require('./policy');
try {
 const base='/tmp/fdb-hotelbench.VxNArC', matrix=base+'/ch1m-eligible3-query-matrix', confirm=base+'/ch1m-eligible3-confirmation';
 const s=JSON.parse(fs.readFileSync(confirm+'/selection.json'));
 if(s.schema!=='ch1m_selection_v1' || ![64,512,8192].includes(s.winner)) throw Error('bad selection');
 let count=0; const seen=new Set();
 const add=ids=>{for(const id of ids){if(seen.has(id))throw Error('query ID reused across receipts');seen.add(id);}};
 for(const g of [8192,512,64])for(const t of ['native','http'])for(let r=1;r<=3;r++) {
  const f=`${matrix}/query-g${g}-${t}-r${r}.json`, bytes=fs.readFileSync(f), sum=crypto.createHash('sha256').update(bytes).digest('hex');
  if(s.inputs[f]!==sum) throw Error('matrix receipt SHA mismatch');
  const e=JSON.parse(bytes),meta=p.input(e); if(meta.ids.length!==1600 || meta.run!==`ch1m_g${g}_0287` || e.config.ch_query_transport!==t || e.config.ch_index_granularity!==g) throw Error('matrix identity/sample count'); add(meta.ids); count++;
 }
 for(let r=1;r<=3;r++){const e=JSON.parse(fs.readFileSync(`${confirm}/native-${r}.json`)),meta=p.input(e);if(meta.ids.length!==16000 || meta.run!==`ch1m_g${s.winner}_0287` || e.config.ch_query_transport!=='native' || e.config.ch_index_granularity!==s.winner) throw Error('confirmation identity/sample count');add(meta.ids);count++;}
 if(count!==21)throw Error('receipt census');
 console.log('21 receipts have nonempty unique query IDs and 18 matrix hashes match selection');
}catch(e){console.error(e.message);process.exitCode=1;}
