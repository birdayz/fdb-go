#!/usr/bin/env node
'use strict';
const fs=require('node:fs'), path=require('node:path'), crypto=require('node:crypto'), cp=require('node:child_process');
const p=require('./policy');
const base='/tmp/fdb-hotelbench.VxNArC', matrix=base+'/ch1m-eligible3-query-matrix', fdb=base+'/query1m-fdb-warm', proof=base+'/pilot1m-v2-workers2';
const chRev='9244882a5914e0f897b0216866ca77d2bd4b6910', fdbRev='c7d00bf938edc6cb9a84df4c63b3bbd3ac22dc94';
const chBin='ffdb0e4ff43e12fa2605b7c61bf3a2695ab464c8c518cd21c5ff136a46f1a515', fdbBin='e3d5f167aba6c671d31cd278dc16414dcdb784bb36a5f3a516d893f0668f762c';
const sha=b=>crypto.createHash('sha256').update(b).digest('hex'), read=f=>fs.readFileSync(f), json=f=>JSON.parse(read(f));
function check(v,msg){if(!v)throw Error(msg);}
function clean(s,rev,manifest) {
  check(cp.execFileSync('git',['rev-parse','HEAD'],{cwd:s,encoding:'utf8'}).trim()===rev,'source revision mismatch');
  check(!cp.execFileSync('git',['status','--porcelain=v1'],{cwd:s,encoding:'utf8'}).trim(),'source dirty');
  cp.execFileSync('sha256sum',['-c',manifest],{cwd:s,stdio:'ignore'});
}
function same(a,b){check(read(a).equals(read(b)),'frozen evidence mismatch: '+a);}
function audit(file,backend,run,corpus,gran,rev) {
  const a=json(file), c=a.config;
  check(a.tool==='otelbench-v2' && a.mode==='audit' && a.error==null && a.failures===0 && a.backend===backend && a.revision===rev && c.run===run && c.backend===backend && a.corpus_fingerprint===corpus && a.stats.rows===1000000 && a.stats.attributes===8000000,'invalid audit '+file);
  for(const [k,v] of Object.entries({seed:283,count:1000000,tenants:1,attributes:8,match_every:100,order:'time',hash_bytes:32})) check(c[k]===v,'audit config mismatch '+k);
  if(gran!==null){check(c.ch_index_granularity===gran && a.stats.details?.ch_index_granularity_requested===String(gran) && a.stats.details?.server_version==='26.10.2.103','audit granularity/version'); for(const t of ['spans','attr_lookup']) check(new RegExp(`index_granularity\\s*=\\s*${gran}(?![0-9])`).test(a.stats.details?.[t+'_show_create']||''),'missing physical DDL '+t);}
  return sha(read(file));
}
function main(){
  const out=process.argv[2]; check(process.argv.length===3 && out,'usage: node analyze.js NEW_SELECTION_JSON');
  const matrixStatus=read(matrix+'/status').toString();
  check((/^exit=0 state=passed commands=18 attempts=28800 failed_commands=0(?:\s|$)/.test(matrixStatus) || /^exit=10 state=complete-with-failures commands=18 attempts=28800 failed_commands=[1-9][0-9]*(?:\s|$)/.test(matrixStatus)) && /^exit=0(?:\s|$)/.test(read(fdb+'/status').toString()) && /^exit=0(?:\s|$)/.test(read(proof+'/status').toString()),'incomplete matrix/FDB status');
  for(const d of [matrix,fdb,proof]) for(const n of ['source','binary']) same(`${d}/${n}.before`,`${d}/${n}.after`);
  same(matrix+'/config.before',matrix+'/config.after'); same(matrix+'/driver.before',matrix+'/driver.after');
  cp.execFileSync('sha256sum',['-c',matrix+'/driver.before'],{stdio:'ignore'});
  clean(base+'/granularity-measurement-src',chRev,matrix+'/source.before'); clean(base+'/timeout-measurement-src',fdbRev,fdb+'/source.before');
  check(sha(read(base+'/otelbench-granularity-reference'))===chBin && sha(read(base+'/otelbench-timeout-reference'))===fdbBin,'binary SHA mismatch');
  cp.execFileSync('sha256sum',['-c',matrix+'/config.before'],{stdio:'ignore'});
  const corpus='f81921380a3919e7eae1cfd847c68cf6a4911ab1230aa751fa18fbc40ebb84d3';
  cp.execFileSync('sha256sum',['-c',path.join(__dirname,'frozen-failures.sha256')],{stdio:'ignore'});
  const hashes={}, fdbRounds=[]; const proofAudit=proof+'/audit.json'; hashes[proofAudit]=audit(proofAudit,'fdb','rw1m0286',corpus,null,fdbRev);
  let oracle;
  for(let r=1;r<=3;r++){const file=`${fdb}/all-${r}.json`, e=json(file); const h=p.validate(e,16000,{backend:'fdb',revision:fdbRev,corpus,run:'rw1m0286'},oracle); if(!oracle) oracle=e.samples; fdbRounds.push(h); hashes[file]=sha(read(file));}
  const rounds={}; let totalFailures=0, failedCommands=0;
  const original=base+'/ch1m-gran1-30m', failedWindow=base+'/ch1m-gran1-postdrain-audit', failedWindow2=base+'/ch1m-gran1-postdrain-resume02-audit', post=base+'/ch1m-gran1-after-maintenance-audit';
  check(/^exit=1(?:\s|$)/.test(read(original+'/status').toString()) && /^exit=6(?:\s|$)/.test(read(failedWindow+'/status').toString()) && /^exit=6(?:\s|$)/.test(read(failedWindow2+'/status').toString()) && /^exit=1(?:\s|$)/.test(read(post+'/status').toString()),'g1 failure statuses changed');
  check(!fs.existsSync(failedWindow+'/audit.json') && !fs.existsSync(failedWindow2+'/audit.json'),'failed drain unexpectedly audited');
  for(const family of ['source','binary','config','predecessor']) same(`${post}/${family}.before`,`${post}/${family}.after`);
  cp.execFileSync('sha256sum',['-c',post+'/predecessor.before'],{stdio:'ignore'});
  same(post+'/source.before',matrix+'/source.before'); same(post+'/binary.before',matrix+'/binary.before'); same(post+'/config.before',matrix+'/config.before');
  const ingest=json(original+'/ingest.json'), failed=json(original+'/audit.json'), failedAfter=json(post+'/audit.json');
  check(ingest.mode==='ingest' && ingest.error==null && ingest.stats.rows===1000000 && ingest.stats.attributes===8000000 && ingest.revision===chRev && ingest.corpus_fingerprint===corpus && ingest.backend==='ch-attrs' && ingest.config.run==='ch1m_g1_30m_0288' && ingest.config.ch_index_granularity===1,'original g1 ingest not proven');
  for(const a of [failed,failedAfter]) check(a.mode==='audit' && typeof a.error==='string' && a.error.includes('TIMEOUT_EXCEEDED') && a.stats.rows===1000000 && a.stats.attributes===8000000 && JSON.stringify(a.config)===JSON.stringify(ingest.config),'g1 timeout evidence invalid');
  const drain=read(post+'/merge-drain.txt').toString().trim().split('\n');
  check(drain.length>=3 && drain.slice(-3).every(x=>/active_merges=0$/.test(x)),'g1 after-maintenance lacks three zero observations');
  for(const file of [original+'/status',original+'/ingest.json',original+'/audit.json',failedWindow+'/status',failedWindow+'/merge-drain.txt',failedWindow2+'/status',failedWindow2+'/merge-drain.txt',post+'/status',post+'/audit.json',post+'/merge-drain.txt',post+'/predecessor.before']) hashes[file]=sha(read(file));
  for(const g of [8192,512,64]){
    const run=`ch1m_g${g}_0287`, auditFile=`${base}/ch1m-tune/audit-g${g}.json`;
    hashes[auditFile]=audit(auditFile,'ch-attrs',run,corpus,g,chRev);
    rounds[g]={native:[],http:[]};
    for(const t of ['native','http']) for(let r=1;r<=3;r++){
      const file=`${matrix}/query-g${g}-${t}-r${r}.json`,e=json(file);
      const result=p.validate(e,1600,{backend:'ch-attrs',revision:chRev,corpus,run,granularity:g,transport:t},oracle,true);
      const rcFile=file.replace(/\.json$/,'.rc'); const rc=read(rcFile).toString().trim();
      check(rc===String(result.failures?1:0),'command exit/failure mismatch '+file);
      for(const position of ['before','after']) {const mergeFile=file.replace(/\.json$/,`-merges-${position}.txt`); check(/^active_merges=0\s*$/.test(read(mergeFile).toString()),'missing quiescent boundary '+mergeFile); hashes[mergeFile]=sha(read(mergeFile));}
      totalFailures+=result.failures; if(result.failures)failedCommands++; hashes[file]=sha(read(file)); hashes[rcFile]=sha(read(rcFile)); rounds[g][t].push(result);
    }
  }
  check(Number((matrixStatus.match(/failed_commands=([0-9]+)/)||[])[1])===failedCommands && ((totalFailures===0 && /^exit=0 state=passed/.test(matrixStatus)) || (totalFailures>0 && /^exit=10 state=complete-with-failures/.test(matrixStatus))),'matrix status/failure census mismatch');
  const scores=p.choose(rounds);
  const result={schema:'ch1m_selection_v1',selection:'geometric mean of 12 native per-round class medians; trace, span, genai_response, time_narrow; exact score tie chooses numerically smallest granularity',winner:scores[0].granularity,scores,ineligible:[64,512,8192].filter(g=>!scores.some(s=>s.granularity===g)),excluded:[{granularity:1,reason:'full audit exceeded fixed 2s limit in initial and quiescent windows; native g1 was not timed',timed_population:0}],matrix_failures:totalFailures,corpus,fdb_revision:fdbRev,ch_revision:chRev,fdb_binary_sha256:fdbBin,ch_binary_sha256:chBin,source_manifest_sha256:{fdb:sha(read(fdb+'/source.before')),ch:sha(read(matrix+'/source.before'))},matrix_config_sha256:sha(read(matrix+'/config.before')),inputs:hashes,fdb_rounds:fdbRounds,ch_rounds:rounds,created_utc:new Date().toISOString(),boundary:'1M local immutable data; FDB command timeout 20m and diagnostics on vs CH 10m, diagnostics off and 2s server limit: not matched deadlines or SLO evidence; not 100M, durability equivalence or production proof'};
  fs.writeFileSync(out,JSON.stringify(result,null,2)+'\n',{flag:'wx',mode:0o600}); console.log(`selected ${result.winner}; ${out}`);
}
try{main()}catch(e){console.error(e.message);process.exitCode=1;}
