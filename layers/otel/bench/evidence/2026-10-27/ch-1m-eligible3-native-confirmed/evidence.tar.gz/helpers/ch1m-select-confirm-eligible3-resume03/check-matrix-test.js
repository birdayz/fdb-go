'use strict';
const fs=require('node:fs'),os=require('node:os'),path=require('node:path'),cp=require('node:child_process'),assert=require('node:assert/strict'),p=require('./policy');
const dir=fs.mkdtempSync(path.join(os.tmpdir(),'ch1m-policy-')); try {
  const histograms=Object.fromEntries(p.classes.map((k,i)=>[k,{population:100,min_ns:i+1,p50_ns:i+1,p95_ns:i+1,p99_ns:i+1,max_ns:i+1}]));
  const samples=Array.from({length:1600},(_,i)=>({iteration:i,class:p.classes[i%16],ns:i%16+1,results:1,result_digest:'a'.repeat(64),query_id:'otel_'+i.toString(16).padStart(32,'0'),query_transport:'native'}));
  const config={backend:'ch-attrs',run:'ch1m_g64_0287',seed:283,count:1000000,tenants:1,attributes:8,match_every:100,k:100,batch:32,save_mode:'batch',workers:2,max_candidates:2000000,max_bytes:268435456,hash_bytes:32,order:'time',tenant:0,iterations:1600,ch_query_transport:'native',ch_index_granularity:64,ch_batch:8192,ch_batch_bytes:8388608};
  const e={tool:'otelbench-v2',mode:'query',suite:'all',backend:'ch-attrs',revision:'9244882a5914e0f897b0216866ca77d2bd4b6910',corpus_fingerprint:'f81921380a3919e7eae1cfd847c68cf6a4911ab1230aa751fa18fbc40ebb84d3',config,failures:0,error:null,samples,histograms};
  const file=path.join(dir,'receipt.json'), helper=path.join(__dirname,'check-matrix.js');
  const run=(obj,rc)=>{fs.writeFileSync(file,JSON.stringify(obj));return cp.spawnSync(process.execPath,[helper,file,'64','native',String(rc)],{encoding:'utf8'});};
  assert.equal(run(e,0).status,0); assert.notEqual(run(e,1).status,0);
  const failed=structuredClone(e); failed.samples[0].error='timeout'; delete failed.samples[0].query_id; failed.failures=1; failed.error='otel oracle measure queries: 1/1600 queries failed; raw samples include failures; histograms are successful-only'; failed.histograms.trace.population=99;
  assert.equal(run(failed,1).status,0); assert.notEqual(run(failed,0).status,0);
  const partial=structuredClone(failed); partial.samples.pop(); assert.notEqual(run(partial,1).status,0);
  const wrong=structuredClone(failed); wrong.samples[1].class='trace'; assert.notEqual(run(wrong,1).status,0);
  const empty=structuredClone(e); empty.samples=[]; assert.notEqual(run(empty,0).status,0);
  console.log('offline 1600-attempt command receipt fixtures passed');
}finally{fs.rmSync(dir,{recursive:true,force:true});}
