#!/usr/bin/env bash
set -Eeuo pipefail
umask 077
base=/tmp/fdb-hotelbench.VxNArC
matrix=$base/ch1m-eligible3-query-matrix
confirmation=$base/ch1m-eligible3-confirmation
out=$base/ch1m-eligible3-querylog-after
helper=$base/ch-querylog-reconcile/reconcile.js
profile=$base/ch16-config-resume02
# Never extend the new monitor's fixed deadline.
raw_deadline=$(cat "$profile/deadline.epoch")
[[ $raw_deadline =~ ^[0-9]+$ ]] && (( raw_deadline-$(date +%s)<=3600 )) || exit 1
deadline=$((raw_deadline-60))
deadline_hash=$(sha256sum "$profile/deadline.epoch" | cut -d' ' -f1)
export CH16_RECONCILE_SESSION=resume02
[[ ${CH1M_RECONCILE_APPROVED:-} == yes ]] || { echo 'Explicit post-confirmation approval required' >&2; exit 1; }
matrix_status=$(cat "$matrix/status")
[[ $(cat "$confirmation/status") == exit=0* ]] && [[ $matrix_status == 'exit=0 state=passed commands=18 attempts=28800 '* || $matrix_status == 'exit=10 state=complete-with-failures commands=18 attempts=28800 '* ]] || { echo 'Timing matrix or confirmation incomplete' >&2; exit 1; }
(cd "$confirmation" && sha256sum -c confirmation.sha256 && sha256sum -c selection.sha256)
[[ ! -e "$out" ]] || { echo 'Output exists: inspect/continue manually in fresh directories' >&2; exit 1; }
mkdir "$out"
flush=()
[[ ${CH1M_RECONCILE_FLUSH:-no} != yes ]] || flush=(--flush)
for g in 8192 512 64; do for transport in native http; do for r in 1 2 3; do
  [[ $(sha256sum "$profile/deadline.epoch" | cut -d' ' -f1) == "$deadline_hash" ]] && (( deadline-$(date +%s) >= 130 )) || { echo 'Deadline changed or insufficient TTL: defer remaining reconciliations' >&2; exit 1; }
  [[ -f "$profile/monitor.heartbeat" ]] && (( $(date +%s)-$(stat -c %Y "$profile/monitor.heartbeat") < 15 )) || exit 1
  file="$matrix/query-g${g}-${transport}-r${r}.json"
  timeout --foreground --kill-after=5s 125s node "$helper" "$file" "$out/g${g}-${transport}-r${r}" "${flush[@]}"
  flush=()
done; done; done
for r in 1 2 3; do
  [[ $(sha256sum "$profile/deadline.epoch" | cut -d' ' -f1) == "$deadline_hash" ]] && (( deadline-$(date +%s) >= 130 )) || { echo 'Deadline changed or insufficient TTL: defer remaining reconciliations' >&2; exit 1; }
  [[ -f "$profile/monitor.heartbeat" ]] && (( $(date +%s)-$(stat -c %Y "$profile/monitor.heartbeat") < 15 )) || exit 1
  timeout --foreground --kill-after=5s 125s node "$helper" "$confirmation/native-$r.json" "$out/confirm-native-r$r" "${flush[@]}"
  flush=()
done
printf '21 reconciliations completed\n' > "$out/status"
