'use strict';
const fs=require('node:fs'), p=require('./policy');
try {
  const [selection,file]=process.argv.slice(2); if(!selection||!file||process.argv.length!==4) throw Error('usage: node check-confirm.js selection.json confirmation.json');
  const s=JSON.parse(fs.readFileSync(selection)),e=JSON.parse(fs.readFileSync(file)),f=JSON.parse(fs.readFileSync('/tmp/fdb-hotelbench.VxNArC/query1m-fdb-warm/all-1.json'));
  if(s.schema!=='ch1m_selection_v1'||![64,512,8192].includes(s.winner)||s.ch_revision!=='9244882a5914e0f897b0216866ca77d2bd4b6910'||s.fdb_revision!=='c7d00bf938edc6cb9a84df4c63b3bbd3ac22dc94') throw Error('invalid selection');
  const g=s.winner,run=`ch1m_g${g}_0287`;
  p.validate(e,16000,{backend:'ch-attrs',revision:s.ch_revision,corpus:s.corpus,run,granularity:g,transport:'native'},f.samples);
  console.log('confirmation sample/oracle validation passed');
}catch(e){console.error(e.message);process.exitCode=1;}
