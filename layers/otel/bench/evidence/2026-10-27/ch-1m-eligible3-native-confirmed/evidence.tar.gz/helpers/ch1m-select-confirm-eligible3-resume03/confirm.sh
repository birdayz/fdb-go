#!/usr/bin/env bash
set -Eeuo pipefail
umask 077
export GOMAXPROCS=4 TZ=UTC
base=/tmp/fdb-hotelbench.VxNArC
here=$base/ch1m-select-confirm-eligible3-resume03
source=$base/granularity-measurement-src
bin=$base/otelbench-granularity-reference
profile=$base/ch16-config-resume03
out=$base/ch1m-eligible3-confirmation
revision=9244882a5914e0f897b0216866ca77d2bd4b6910
# Resume monitor's fixed one-hour deadline, with one-minute margin; never extend it.
raw_deadline=$(cat "$profile/deadline.epoch")
[[ $raw_deadline =~ ^[0-9]+$ ]] && (( raw_deadline-$(date +%s)<=3600 )) || { echo 'Invalid resume deadline' >&2; exit 1; }
deadline=$((raw_deadline-60))
deadline_hash=$(sha256sum "$profile/deadline.epoch" | cut -d' ' -f1)
[[ ${CH1M_CONFIRM_APPROVED:-} == yes ]] || { echo 'Explicit approval required' >&2; exit 1; }
remaining() { [[ $(sha256sum "$profile/deadline.epoch" | cut -d' ' -f1) == "$deadline_hash" ]] && (( deadline-$(date +%s) >= $1 )) || { echo 'Changed deadline or insufficient monitor lifetime: defer' >&2; exit 1; }; }
# Three 10-minute query timeouts + 3-minute guard/health margin.
remaining 1980
[[ ! -e "$out" ]] || { echo 'Existing confirmation output; refusing reuse' >&2; exit 1; }
mkdir "$out"
cd "$source"
manifest() { git ls-files --cached --others --exclude-standard -z | LC_ALL=C sort -z | xargs -0 sha256sum; }
manifest > "$out/source.before"
sha256sum "$bin" > "$out/binary.before"
sha256sum "$profile"/{server.xml,profile.xml,launch.sh,monitor.sh,resources.sh,resources-policy.sh,readiness.sh} > "$out/config.before"
finish() {
  rc=$?; trap - EXIT
  manifest > "$out/source.after" || rc=4
  sha256sum "$bin" > "$out/binary.after" || rc=4
  sha256sum "$profile"/{server.xml,profile.xml,launch.sh,monitor.sh,resources.sh,resources-policy.sh,readiness.sh} > "$out/config.after" || rc=4
  if ! cmp -s "$out/source.before" "$out/source.after" || ! cmp -s "$out/binary.before" "$out/binary.after" || ! cmp -s "$out/config.before" "$out/config.after" || [[ -n $(git status --porcelain=v1) ]]; then rc=4; fi
  printf 'exit=%s end=%s\n' "$rc" "$(date -u +%FT%TZ)" > "$out/status"
  exit "$rc"
}
trap finish EXIT
node "$here/analyze.js" "$out/selection.json"
sha256sum "$out/selection.json" > "$out/selection.sha256"
g=$(jq -er '.winner | select(.==8192 or .==512 or .==64)' "$out/selection.json")
run="ch1m_g${g}_0287"
instance=$(cat "$profile/instance.id")
active() {
  remaining 1
  [[ $(docker inspect --format '{{.Id}} {{.State.Running}} {{.State.OOMKilled}} {{.RestartCount}} {{index .Config.Labels "otel283.owner"}} {{index .Config.Labels "otel283.profile"}} {{index .Config.Labels "otel283.session"}}' otel283-ch16-resume03) == "$instance true false 0 otel283-vxnar ch16-4cpu-16g-v1 resume03" ]]
  [[ -e "$profile/monitor.heartbeat" ]] && (( $(date +%s)-$(stat -c %Y "$profile/monitor.heartbeat") < 15 ))
  "$profile/resources.sh"
}
admin() { curl --noproxy '*' --fail --silent --show-error --max-time 15 --data-binary "$1" http://127.0.0.1:18125/; }
health() {
  local label=$1 merges
  active
  "$profile/readiness.sh" > "$out/readiness-$label.txt"
  docker stats --no-stream --format '{{json .}}' "$instance" > "$out/container-$label.jsonl"
  admin "SELECT database,table,elapsed,progress FROM system.merges WHERE database IN ('otel_ch1m_g8192_0287','otel_ch1m_g512_0287','otel_ch1m_g64_0287','otel_ch1m_g1_0287','otel_ch1m_g1_30m_0288') FORMAT JSONEachRow" > "$out/merges-$label.jsonl"
  merges=$(admin "SELECT count() FROM system.merges WHERE database IN ('otel_ch1m_g8192_0287','otel_ch1m_g512_0287','otel_ch1m_g64_0287','otel_ch1m_g1_0287','otel_ch1m_g1_30m_0288') FORMAT TabSeparated")
  [[ "$merges" == 0 ]] || { echo "Active merge at $label; stop confirmation" >&2; return 1; }
  admin "SELECT database,table,sum(rows) AS rows,sum(bytes_on_disk) AS bytes,sum(marks) AS marks FROM system.parts WHERE active AND database='otel_${run}' GROUP BY database,table FORMAT JSONEachRow" > "$out/parts-$label.jsonl"
  active
}
common=(--backend ch-attrs --order time --ch-url http://127.0.0.1:18125 --seed 283
  --count 1000000 --tenants 1 --attrs 8 --match-every 100 --k 100
  --ch-batch 8192 --ch-batch-bytes 8388608 --batch 32 --save-mode batch --workers 2
  --max-candidates 2000000 --max-bytes 268435456 --timeout 10m --revision "$revision"
  --run "$run" --ch-index-granularity "$g" --ch-query-transport native --ch-native-addr 127.0.0.1:19005
  --mode query --suite all --iterations 16000)
for round in 1 2 3; do
  remaining $(( (4-round)*660 ))
  health "before-$round"
  remaining $(( (4-round)*660 ))
  timeout --foreground --kill-after=5s 10m "$bin" "${common[@]}" --output "$out/native-$round.json"
  node "$here/check-confirm.js" "$out/selection.json" "$out/native-$round.json"
  health "after-$round"
done
sha256sum "$out"/native-{1,2,3}.json > "$out/confirmation.sha256"
echo 'Three 1M local confirmation rounds complete; query-log reconciliation remains separate and untimed.'
