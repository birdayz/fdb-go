#!/usr/bin/env bash
set -Eeuo pipefail
export GOMAXPROCS=4 TZ=UTC
base=/tmp/fdb-hotelbench.VxNArC
source=$base/granularity-measurement-src
bin=$base/otelbench-granularity-reference
profile=$base/ch16-config-resume02
out=$base/ch1m-gran1-after-maintenance-audit
revision=9244882a5914e0f897b0216866ca77d2bd4b6910
cd "$source"
[[ ! -e "$out" && $(git rev-parse HEAD) == "$revision" && -z $(git status --porcelain=v1) ]]
[[ ${CH1M_AFTER_MAINTENANCE_APPROVED:-} == yes ]] || { echo 'Explicit separate after-maintenance census approval required' >&2; exit 1; }
[[ $(cat "$base/ch1m-gran1-postdrain-resume02-audit/status") == exit=6* && ! -e "$base/ch1m-gran1-postdrain-resume02-audit/audit.json" ]]
[[ $(cat "$base/ch1m-gran1-30m/status") == exit=1* && $(cat "$base/ch1m-gran1-postdrain-audit/status") == exit=6* && ! -e "$base/ch1m-gran1-postdrain-audit/audit.json" ]]
(cd "$profile" && sha256sum -c frozen-failures.sha256 >/dev/null)
deadline=$(cat "$profile/deadline.epoch"); [[ $deadline =~ ^[0-9]+$ ]] && (( deadline-$(date +%s) >= 1320 && deadline-$(date +%s)<=3600 )) || { echo 'Insufficient fixed resume TTL for 10m drain + 10m audit + margin' >&2; exit 1; }
deadline_hash=$(sha256sum "$profile/deadline.epoch" | cut -d' ' -f1)
jq -e '.error == null and .stats.rows == 1000000 and .stats.attributes == 8000000' "$base/ch1m-gran1-30m/ingest.json" >/dev/null
jq -e '.error != null and (.error | contains("TIMEOUT_EXCEEDED"))' "$base/ch1m-gran1-30m/audit.json" >/dev/null
sha256sum --check "$base/granularity-binary.sha256"
instance=$(cat "$profile/instance.id")
mkdir "$out"
printf '%s\n' 'Distinct observed after-maintenance census window on existing ready ch1m_g1_30m_0288. Original first audit failed; the five-minute and resumed ten-minute drain windows both expired without audits and remain failed. The latter ended with only two zero-merge samples, not its required three. No new ingest, altered query budget, ownership adoption, hidden retry or source/config change.' > "$out/scope.txt"
manifest() { git ls-files --cached --others --exclude-standard -z | LC_ALL=C sort -z | xargs -0 sha256sum; }
manifest > "$out/source.before"
sha256sum "$bin" > "$out/binary.before"
sha256sum "$profile"/{server.xml,profile.xml,launch.sh,monitor.sh,resources.sh,resources-policy.sh,readiness.sh} > "$out/config.before"
sha256sum "$base/ch1m-gran1-30m"/{status,ingest.json,audit.json} "$base/ch1m-gran1-postdrain-audit"/{status,merge-drain.txt,predecessor.before,predecessor.after,scope.txt} "$base/ch1m-gran1-postdrain-resume02-audit"/{status,merge-drain.txt,predecessor.before,predecessor.after,scope.txt} > "$out/predecessor.before"
finish() {
  rc=$?
  trap - EXIT
  manifest > "$out/source.after"
  sha256sum "$bin" > "$out/binary.after"
  sha256sum "$profile"/{server.xml,profile.xml,launch.sh,monitor.sh,resources.sh,resources-policy.sh,readiness.sh} > "$out/config.after"
  sha256sum "$base/ch1m-gran1-30m"/{status,ingest.json,audit.json} "$base/ch1m-gran1-postdrain-audit"/{status,merge-drain.txt,predecessor.before,predecessor.after,scope.txt} "$base/ch1m-gran1-postdrain-resume02-audit"/{status,merge-drain.txt,predecessor.before,predecessor.after,scope.txt} > "$out/predecessor.after"
  for family in source binary config predecessor; do cmp -s "$out/$family.before" "$out/$family.after" || rc=4; done
  [[ -z $(git status --porcelain=v1) ]] || rc=4
  printf 'exit=%s end=%s\n' "$rc" "$(date -u +%FT%TZ)" > "$out/status"
  exit "$rc"
}
trap finish EXIT
active() {
  [[ $(sha256sum "$profile/deadline.epoch" | cut -d' ' -f1) == "$deadline_hash" ]] && (( $(date +%s)+60 < deadline ))
  [[ $(docker inspect --format '{{.Id}} {{.State.Running}} {{.State.OOMKilled}} {{.RestartCount}} {{index .Config.Labels "otel283.owner"}} {{index .Config.Labels "otel283.profile"}} {{index .Config.Labels "otel283.session"}}' otel283-ch16-resume02) == "$instance true false 0 otel283-vxnar ch16-4cpu-16g-v1 resume02" ]]
  [[ -e "$profile/monitor.heartbeat" ]] && (( $(date +%s)-$(stat -c %Y "$profile/monitor.heartbeat") < 15 ))
}
admin() { curl --noproxy '*' --fail --silent --show-error --max-time 15 --data-binary "$1" http://127.0.0.1:18125/; }
active
"$profile/readiness.sh" > "$out/profile-before.txt"
settled=0
for sample in $(seq 1 120); do
  active
  n=$(admin "SELECT count() FROM system.merges WHERE database IN ('otel_ch1m_g8192_0287','otel_ch1m_g512_0287','otel_ch1m_g64_0287','otel_ch1m_g1_0287','otel_ch1m_g1_30m_0288') FORMAT TabSeparated")
  [[ "$n" =~ ^[0-9]+$ ]]
  printf '%s active_merges=%s\n' "$(date -u +%FT%TZ)" "$n" >> "$out/merge-drain.txt"
  if [[ "$n" == 0 ]]; then settled=$((settled+1)); else settled=0; fi
  (( settled < 3 )) || break
  sleep 5
done
(( settled >= 3 )) || { echo 'Distinct post-merge validation window did not drain; no retry of failed audit' >&2; exit 6; }
(( deadline-$(date +%s) >= 660 )) || { echo 'Insufficient resume TTL for full 10m audit budget' >&2; exit 1; }
args=(--backend ch-attrs --order time --ch-url http://127.0.0.1:18125 --seed 283 --run ch1m_g1_30m_0288 --ch-index-granularity 1 --count 1000000 --tenants 1 --attrs 8 --match-every 100 --k 100 --ch-batch 8192 --ch-batch-bytes 8388608 --batch 32 --save-mode batch --workers 2 --max-candidates 2000000 --max-bytes 268435456 --timeout 10m --revision "$revision")
printf '%q ' "$bin" "${args[@]}" --mode audit > "$out/audit.command"
printf '\n' >> "$out/audit.command"
"$bin" "${args[@]}" --mode audit --output "$out/audit.json"
jq -e '.error == null and .stats.rows == 1000000 and .stats.attributes == 8000000' "$out/audit.json" >/dev/null
active
"$profile/readiness.sh" > "$out/profile-after.txt"
echo 'Separate after-maintenance census passed unchanged query budgets; original audit and both earlier drain-window failures remain failed.'
