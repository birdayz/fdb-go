#!/usr/bin/env bash
set -Eeuo pipefail
umask 077
here=$(cd -- "$(dirname -- "$0")" && pwd -P)
old=/tmp/fdb-hotelbench.VxNArC/ch16-config-resume02
readonly here old name=otel283-ch16-resume03 owner=otel283-vxnar profile=ch16-4cpu-16g-v1 predecessor=7df4e34f3c11cd4a751c492194d6221accebec302afe993493446e1574c66762
[[ ${CH16_RESUME03_APPROVED:-} == yes && ${CH16_FAST_GATE_CONFIRMED:-} == yes ]] || { echo 'Resume approval and completed fast-gate confirmation required' >&2; exit 1; }
status=$(cat /tmp/fdb-hotelbench.VxNArC/ch1m-eligible3-query-matrix/status)
[[ $status == 'exit=0 state=passed commands=18 attempts=28800 '* || $status == 'exit=10 state=complete-with-failures commands=18 attempts=28800 '* ]] || { echo 'Eligible3 matrix incomplete' >&2; exit 1; }
(cd /tmp/fdb-hotelbench.VxNArC/ch1m-select-confirm-eligible3 && sha256sum -c SHA256SUMS >/dev/null && sha256sum -c frozen-failures.sha256 >/dev/null)
exec 9>"$here/monitor.lock"; flock -n 9 || { echo 'Resume monitor already active' >&2; exit 1; }
# Hold predecessor monitor lock for this whole session; never stop or signal it.
exec 8>"$old/monitor.lock"; flock -n 8 || { echo 'Predecessor monitor still active' >&2; exit 1; }
[[ ! -e "$here/instance.id" && ! -e "$here/deadline.epoch" ]] || { echo 'Existing resume session; refusing reuse' >&2; exit 1; }
[[ $(cat "$old/instance.id") == "$predecessor" ]] || exit 1
[[ $(timeout 10 docker inspect --format '{{.Id}} {{.State.Running}} {{index .Config.Labels "otel283.owner"}} {{index .Config.Labels "otel283.profile"}} {{index .Config.Labels "otel283.session"}}' otel283-ch16-resume02) == "$predecessor false $owner $profile resume02" ]] || { echo 'Predecessor must be owned and stopped' >&2; exit 1; }
[[ ! -e "$old/monitor.heartbeat" || $(( $(date +%s)-$(stat -c %Y "$old/monitor.heartbeat") )) -ge 15 ]] || { echo 'Old heartbeat still fresh' >&2; exit 1; }
node /tmp/fdb-hotelbench.VxNArC/ch1m-select-confirm-eligible3/analyze.js "$here/matrix-validation.json"
sha256sum "$here/matrix-validation.json" > "$here/matrix-validation.sha256"
stop_owned() {
  rm -f "$here/monitor.heartbeat"
  if [[ -f "$here/instance.id" ]]; then
    id=$(cat "$here/instance.id")
    if [[ $id =~ ^[0-9a-f]{64}$ ]] && [[ $(timeout 10 docker inspect --format '{{.Id}} {{index .Config.Labels "otel283.owner"}} {{index .Config.Labels "otel283.profile"}} {{index .Config.Labels "otel283.session"}}' "$name" 2>/dev/null || :) == "$id $owner $profile resume03" ]]; then timeout 20 docker stop -t 10 "$id" >/dev/null || :; fi
  fi
}
trap stop_owned EXIT INT TERM
started=$SECONDS; deadline=$(( $(date +%s)+3600 )); (set -o noclobber; printf '%s\n' "$deadline" > "$here/deadline.epoch")
running_seen=no
while (( SECONDS-started < 3600 )) && (( $(date +%s) < deadline )); do
  [[ $(cat "$here/deadline.epoch") == "$deadline" ]] || { echo 'Deadline changed' >&2; exit 1; }
  "$here/resources.sh"
  if [[ -f "$here/instance.id" ]]; then
    id=$(cat "$here/instance.id"); [[ $id =~ ^[0-9a-f]{64}$ ]] || exit 1
    [[ $(timeout 10 docker inspect --format '{{.Id}} {{index .Config.Labels "otel283.owner"}} {{index .Config.Labels "otel283.profile"}} {{index .Config.Labels "otel283.session"}}' "$name") == "$id $owner $profile resume03" ]] || exit 1
    read -r running pid < <(docker inspect --format '{{.State.Running}} {{.State.Pid}}' "$id")
    if [[ $running == true ]]; then
      running_seen=yes; [[ $pid =~ ^[1-9][0-9]*$ ]] || exit 1
      cg=$(awk -F: '$1=="0" {print $3}' "/proc/$pid/cgroup")
      [[ -n $cg && -f "/sys/fs/cgroup$cg/memory.current" && -f "/sys/fs/cgroup$cg/memory.max" ]] || exit 1
      current=$(cat "/sys/fs/cgroup$cg/memory.current"); max=$(cat "/sys/fs/cgroup$cg/memory.max")
      [[ $current =~ ^[0-9]+$ && $max == 17179869184 ]] && (( current*10 < max*9 )) || { echo 'Container memory guard failed' >&2; exit 1; }
      printf '%s memory_current=%s memory_max=%s\n' "$(date -u +%FT%TZ)" "$current" "$max"
    elif [[ $running_seen == yes ]] || (( SECONDS-started > 120 )); then echo 'Resume container not running' >&2; exit 1; fi
  elif (( SECONDS-started > 120 )); then echo 'Resume launch did not appear' >&2; exit 1; fi
  touch "$here/monitor.heartbeat"; sleep 5
done
echo 'Resume monitor TTL expired' >&2; exit 1
