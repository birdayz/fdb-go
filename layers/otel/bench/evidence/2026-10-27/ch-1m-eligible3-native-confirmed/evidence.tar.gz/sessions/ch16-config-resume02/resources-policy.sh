#!/usr/bin/env bash
set -Eeuo pipefail
[[ $# == 4 ]] || { echo 'Expected total, available, Docker free and runtime /tmp free in bytes' >&2; exit 1; }
for value in "$@"; do
  [[ $value =~ ^(0|[1-9][0-9]{0,15})$ ]] || { echo 'Invalid resource value' >&2; exit 1; }
done
total=$1 available=$2 docker_free=$3 tmp_free=$4
(( total > 0 && available <= total && available >= 8*1024*1024*1024 && available >= (total+9)/10 )) || { echo 'Host memory reserve/90% guard failed' >&2; exit 1; }
(( docker_free >= 200*1024*1024*1024 )) || { echo 'Docker-root disk reserve failed' >&2; exit 1; }
(( tmp_free >= 2*1024*1024*1024 )) || { echo 'Runtime /tmp reserve failed' >&2; exit 1; }
