#!/usr/bin/env bash
set -Eeuo pipefail
umask 077
here=$(cd -- "$(dirname -- "$0")" && pwd -P)
old=/tmp/fdb-hotelbench.VxNArC/ch16-config-resume02
readonly here old name=otel283-ch16-resume03 predecessor=7df4e34f3c11cd4a751c492194d6221accebec302afe993493446e1574c66762 volume=otel283-vxnar-ch16-v1 owner=otel283-vxnar profile=ch16-4cpu-16g-v1 image='clickhouse/clickhouse-server@sha256:b2bfa4d8399ee9973868cc5c1754cb506a6f4b86fbddc41010cc090beb55c85e'
[[ ${CH16_RESUME03_APPROVED:-} == yes && ${CH16_FDB_STOP_CONFIRMED:-} == yes && ${CH16_FAST_GATE_CONFIRMED:-} == yes ]] || { echo 'Resume/FDB-stop/fast-gate explicit confirmation required' >&2; exit 1; }
status=$(cat /tmp/fdb-hotelbench.VxNArC/ch1m-eligible3-query-matrix/status)
[[ $status == 'exit=0 state=passed commands=18 attempts=28800 '* || $status == 'exit=10 state=complete-with-failures commands=18 attempts=28800 '* ]] || { echo 'Eligible3 matrix incomplete' >&2; exit 1; }
sha256sum -c "$here/matrix-validation.sha256" >/dev/null
(cd /tmp/fdb-hotelbench.VxNArC/ch1m-select-confirm-eligible3 && sha256sum -c SHA256SUMS >/dev/null && sha256sum -c frozen-failures.sha256 >/dev/null)
exec 9>"$here/launch.lock"; flock -n 9 || exit 1
[[ ! -e "$here/instance.id" && ! -e "$here/launch-receipt.txt" ]] || { echo 'Existing resume receipt' >&2; exit 1; }
timeout 10 docker info >/dev/null
if docker inspect "$name" >/dev/null 2>&1; then echo 'Resume container exists' >&2; exit 1; fi
[[ $(cat "$old/instance.id") == "$predecessor" ]] || exit 1
[[ $(docker inspect --format '{{.State.Running}} {{index .Config.Labels "otel283.owner"}} {{index .Config.Labels "otel283.profile"}}' otel283-fdb4-vxnar) == 'false otel283-vxnar fdb4-4cpu-16g-v1' ]] || { echo 'Owned FDB must be stopped' >&2; exit 1; }
# Inspect predecessor without printing environment or credentials; no modification.
timeout 10 docker inspect "$predecessor" | jq -e --arg id "$predecessor" --arg old "$old" --arg volume "$volume" --arg image "$image" '
  length==1 and (.[0] | .Id==$id and .Name=="/otel283-ch16-resume02" and .Config.Labels["otel283.session"]=="resume02" and .State.Running==false and .Image=="sha256:b2bfa4d8399ee9973868cc5c1754cb506a6f4b86fbddc41010cc090beb55c85e" and .Config.Image==$image and .Config.Labels["otel283.owner"]=="otel283-vxnar" and .Config.Labels["otel283.profile"]=="ch16-4cpu-16g-v1" and .HostConfig.NetworkMode=="host" and .HostConfig.NanoCpus==4000000000 and .HostConfig.Memory==17179869184 and .HostConfig.MemorySwap==17179869184 and .HostConfig.RestartPolicy.Name=="no" and ([.Mounts[]|select(.Destination=="/var/lib/clickhouse" and .Type=="volume" and .Name==$volume)]|length)==1 and ([.Mounts[]|select(.Destination=="/etc/clickhouse-server/config.d/otel283.xml" and .Source==($old+"/server.xml") and .RW==false)]|length)==1 and ([.Mounts[]|select(.Destination=="/etc/clickhouse-server/users.d/otel283.xml" and .Source==($old+"/profile.xml") and .RW==false)]|length)==1)' >/dev/null
[[ $(docker volume inspect --format '{{index .Labels "otel283.owner"}} {{index .Labels "otel283.profile"}} {{index .Labels "otel283.role"}}' "$volume") == "$owner $profile ch16-data" ]] || { echo 'Volume owner mismatch' >&2; exit 1; }
for f in server.xml profile.xml resources.sh resources-policy.sh; do cmp -s "$old/$f" "$here/$f" || { echo "Config changed: $f" >&2; exit 1; }; done
(cd "$here" && sha256sum -c frozen-config.sha256 >/dev/null)
for port in 18125 19005; do if ss -H -ltn "sport = :$port" | grep -q .; then echo "Port occupied: $port" >&2; exit 1; fi; done
"$here/resources.sh"
[[ -f "$here/monitor.heartbeat" && -f "$here/deadline.epoch" ]] && (( $(date +%s)-$(stat -c %Y "$here/monitor.heartbeat") < 10 )) || { echo 'Start resume monitor first' >&2; exit 1; }
deadline=$(cat "$here/deadline.epoch"); [[ $deadline =~ ^[0-9]+$ ]] && (( deadline>$(date +%s) && deadline-$(date +%s)<=3600 )) || exit 1
id=$(docker create --name "$name" --pull never --restart no --network host --cpus 4 --memory 16g --memory-swap 16g \
  --label "otel283.owner=$owner" --label "otel283.profile=$profile" --label 'otel283.role=ch16-server' --label 'otel283.session=resume03' \
  --mount "type=volume,source=$volume,target=/var/lib/clickhouse,volume-nocopy" \
  --mount "type=bind,source=$here/server.xml,target=/etc/clickhouse-server/config.d/otel283.xml,readonly" \
  --mount "type=bind,source=$here/profile.xml,target=/etc/clickhouse-server/users.d/otel283.xml,readonly" \
  --env CLICKHOUSE_SKIP_USER_SETUP=1 "$image")
[[ $id =~ ^[0-9a-f]{64}$ ]] || exit 1
printf '%s\n' "$id" > "$here/instance.id"
printf 'container=%s\nvolume=%s\ninstance=%s\npredecessor=%s\nowner=%s\nprofile=%s\nsession=resume03\nimage=%s\n' "$name" "$volume" "$id" "$predecessor" "$owner" "$profile" "$image" > "$here/launch-receipt.txt"
stop_owned() {
  [[ $(docker inspect --format '{{.Id}} {{index .Config.Labels "otel283.owner"}} {{index .Config.Labels "otel283.profile"}} {{index .Config.Labels "otel283.session"}}' "$name" 2>/dev/null || :) == "$id $owner $profile resume03" ]] && timeout 20 docker stop -t 10 "$id" >/dev/null || :
}
trap stop_owned EXIT INT TERM
remaining=$(( deadline-$(date +%s) )); (( remaining>0 )) || exit 1
timeout --foreground --signal=TERM --kill-after=20s "${remaining}s" docker start --attach "$id"
