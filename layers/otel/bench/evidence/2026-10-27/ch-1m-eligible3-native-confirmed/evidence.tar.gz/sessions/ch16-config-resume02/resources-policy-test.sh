#!/usr/bin/env bash
set -Eeuo pipefail
here=$(cd -- "$(dirname -- "$0")" && pwd -P)
p="$here/resources-policy.sh"
g=$((1024*1024*1024))
pass() { if ! "$p" "$@" >/dev/null 2>&1; then echo "Expected pass: $*" >&2; exit 1; fi; }
reject() { if "$p" "$@" >/dev/null 2>&1; then echo "Expected reject: $*" >&2; exit 1; fi; }
# Current 32 GiB tmpfs, 20 GiB free, is not required to contain CH data.
pass $((64*g)) $((20*g)) $((201*g)) $((20*g))
pass $((80*g)) $((8*g)) $((200*g)) $((2*g))
reject $((64*g)) $((8*g-1)) $((201*g)) $((20*g))
reject $((100*g)) $((9*g)) $((201*g)) $((20*g))
reject $((64*g)) $((20*g)) $((200*g-1)) $((20*g))
reject $((64*g)) $((20*g)) $((201*g)) $((2*g-1))
reject $((64*g)) $((65*g)) $((201*g)) $((20*g))
reject 0 0 $((201*g)) $((20*g))
reject malformed $((20*g)) $((201*g)) $((20*g))
reject 010 $((20*g)) $((201*g)) $((20*g))
echo 'resource policy fixture cases passed (10 cases)'
