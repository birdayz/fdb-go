#!/usr/bin/env bash
set -Eeuo pipefail
here=$(cd -- "$(dirname -- "$0")" && pwd -P)
readonly here name=otel283-ch16-resume02 owner=otel283-vxnar profile=ch16-4cpu-16g-v1
[[ -f "$here/instance.id" && -f "$here/monitor.heartbeat" ]] || { echo 'No instance or active monitor' >&2; exit 1; }
id=$(cat "$here/instance.id"); [[ $id =~ ^[0-9a-f]{64}$ ]] || exit 1
for ((i=0;i<60;i++)); do
  [[ -f "$here/monitor.heartbeat" ]] && (( $(date +%s) - $(stat -c %Y "$here/monitor.heartbeat") < 15 )) || { echo 'Monitor heartbeat stale' >&2; exit 1; }
  [[ $(timeout 10 docker inspect --format '{{.Id}} {{index .Config.Labels "otel283.owner"}} {{index .Config.Labels "otel283.profile"}} {{index .Config.Labels "otel283.session"}} {{.State.Running}}' "$name") == "$id $owner $profile resume02 true" ]] || { echo 'Identity/running check failed' >&2; exit 1; }
  deadline=$(cat "$here/deadline.epoch"); [[ $deadline =~ ^[0-9]+$ ]] && (( $(date +%s)<deadline )) || { echo 'Resume monitor deadline expired' >&2; exit 1; }
  http=$(curl --noproxy '*' -fsS --max-time 2 'http://127.0.0.1:18125/?query=SELECT%20version%28%29' 2>/dev/null || :)
  native=$(timeout 3 docker exec "$id" clickhouse-client --host 127.0.0.1 --port 19005 --query 'SELECT version()' 2>/dev/null || :)
  if [[ $http == 26.10.2.103 && $native == 26.10.2.103 ]]; then
    settings=$(timeout 5 docker exec "$id" clickhouse-client --host 127.0.0.1 --port 19005 --query "SELECT getSetting('max_threads'),getSetting('max_memory_usage'),toUInt8(getSetting('use_query_cache')) FORMAT TSV")
    [[ $settings == $'4\t8589934592\t0' ]] || { echo 'Unexpected query settings' >&2; exit 1; }
    limit=$(timeout 5 docker exec "$id" clickhouse-client --host 127.0.0.1 --port 19005 --query "SELECT value FROM system.server_settings WHERE name='max_server_memory_usage' FORMAT TSV")
    [[ $limit == 12884901888 ]] || { echo 'Unexpected or unavailable server memory setting' >&2; exit 1; }
    temp_setting=$(timeout 5 docker exec "$id" clickhouse-client --host 127.0.0.1 --port 19005 --query "SELECT value FROM system.server_settings WHERE name='tmp_path' FORMAT TSV")
    [[ $temp_setting == /var/lib/clickhouse/tmp/ ]] || { echo 'Unexpected or unavailable server tmp_path' >&2; exit 1; }
    [[ $(timeout 5 docker exec "$id" readlink -f /var/lib/clickhouse/tmp) == /var/lib/clickhouse/tmp ]] || { echo 'Server temp path is missing or redirected' >&2; exit 1; }
    [[ $(docker inspect --format '{{range .Mounts}}{{if eq .Destination "/var/lib/clickhouse"}}{{.Type}} {{.Name}}{{end}}{{end}}' "$id") == 'volume otel283-vxnar-ch16-v1' ]] || { echo 'Unexpected data volume mount' >&2; exit 1; }
    "$here/resources.sh"
    printf 'ready instance=%s version=%s native_and_http=ok\n' "$id" "$http"
    exit 0
  fi
  sleep 2
done
echo 'Readiness timed out' >&2; exit 1
