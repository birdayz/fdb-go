#!/usr/bin/env bash
set -Eeuo pipefail
read -r total avail < <(awk '/^MemTotal:/ {t=$2*1024} /^MemAvailable:/ {a=$2*1024} END {printf "%.0f %.0f\n",t,a}' /proc/meminfo)
(( total > 0 && avail >= 8*1024*1024*1024 && avail*10 >= total )) || { echo 'Host memory reserve/90% guard failed' >&2; exit 1; }
root=$(timeout 10 docker info --format '{{.DockerRootDir}}')
[[ -n "$root" && -d "$root" ]] || { echo 'Docker root unavailable' >&2; exit 1; }
docker_free=$(df -PB1 "$root" | awk 'NR==2 {print $4}')
tmp_free=$(df -PB1 /tmp | awk 'NR==2 {print $4}')
here=$(cd -- "$(dirname -- "$0")" && pwd -P)
"$here/resources-policy.sh" "$total" "$avail" "$docker_free" "$tmp_free"
