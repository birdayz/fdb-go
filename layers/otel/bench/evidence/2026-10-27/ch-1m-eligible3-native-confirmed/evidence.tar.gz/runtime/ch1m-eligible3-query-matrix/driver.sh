#!/usr/bin/env bash
set -Eeuo pipefail
export GOMAXPROCS=4 TZ=UTC
base=/tmp/fdb-hotelbench.VxNArC
source=$base/granularity-measurement-src
bin=$base/otelbench-granularity-reference
profile=$base/ch16-config-resume02
out=$base/ch1m-eligible3-query-matrix
revision=9244882a5914e0f897b0216866ca77d2bd4b6910
[[ ${CH1M_ELIGIBLE3_APPROVED:-} == yes ]] || { echo 'Explicit approval of 3-arm campaign and excluded granularity 1 required' >&2; exit 1; }
cd "$source"
[[ ! -e "$out" && $(git rev-parse HEAD) == "$revision" && -z $(git status --porcelain=v1) ]]
for g in 8192 512 64; do jq -e '.error == null and .stats.rows == 1000000 and .stats.attributes == 8000000' "$base/ch1m-tune/audit-g${g}.json" >/dev/null; done
jq -e '.error == null and .stats.rows == 1000000 and .stats.attributes == 8000000' "$base/ch1m-gran1-30m/ingest.json" >/dev/null
[[ $(cat "$base/ch1m-gran1-30m/status") == exit=1* ]]
jq -e '.error != null and (.error | contains("TIMEOUT_EXCEEDED"))' "$base/ch1m-gran1-30m/audit.json" >/dev/null
[[ $(cat "$base/ch1m-gran1-postdrain-audit/status") == exit=6* && ! -e "$base/ch1m-gran1-postdrain-audit/audit.json" && $(cat "$base/ch1m-gran1-postdrain-resume02-audit/status") == exit=6* && ! -e "$base/ch1m-gran1-postdrain-resume02-audit/audit.json" ]]
(cd "$profile" && sha256sum -c frozen-failures.sha256 >/dev/null)
(cd "$base/ch1m-select-confirm-eligible3" && sha256sum -c frozen-failures.sha256 >/dev/null)
[[ $(cat "$base/ch1m-gran1-after-maintenance-audit/status") == exit=1* ]]
jq -e '.error != null and (.error | contains("TIMEOUT_EXCEEDED")) and .stats.rows == 1000000 and .stats.attributes == 8000000' "$base/ch1m-gran1-after-maintenance-audit/audit.json" >/dev/null
for family in source binary config predecessor; do cmp -s "$base/ch1m-gran1-after-maintenance-audit/$family.before" "$base/ch1m-gran1-after-maintenance-audit/$family.after"; done
sha256sum -c "$base/ch1m-gran1-after-maintenance-audit/predecessor.before" >/dev/null
sha256sum -c "$base/ch1m-gran1-after-maintenance-audit/binary.before" >/dev/null
sha256sum -c "$base/ch1m-gran1-after-maintenance-audit/config.before" >/dev/null
sha256sum -c "$base/ch1m-gran1-after-maintenance-audit/source.before" >/dev/null
[[ $(tail -n 3 "$base/ch1m-gran1-after-maintenance-audit/merge-drain.txt" | grep -Ec 'active_merges=0$') == 3 && -s "$base/ch1m-gran1-after-maintenance-audit/profile-before.txt" ]] || { echo 'Missing quiescent failure evidence/readiness' >&2; exit 1; }
deadline=$(cat "$profile/deadline.epoch"); [[ $deadline =~ ^[0-9]+$ ]] && (( deadline-$(date +%s)<=3600 && deadline>$(date +%s)+60 )) || exit 1
deadline_hash=$(sha256sum "$profile/deadline.epoch" | cut -d' ' -f1)
sha256sum --check "$base/granularity-binary.sha256"
(cd "$base/ch1m-select-confirm-eligible3" && sha256sum -c SHA256SUMS >/dev/null)
instance=$(cat "$profile/instance.id")
mkdir "$out"
manifest() { git ls-files --cached --others --exclude-standard -z | LC_ALL=C sort -z | xargs -0 sha256sum; }
manifest > "$out/source.before"
sha256sum "$bin" > "$out/binary.before"
sha256sum "$profile"/{server.xml,profile.xml,launch.sh,monitor.sh,resources.sh,resources-policy.sh,readiness.sh} > "$out/config.before"
sha256sum "$base/ch1m-eligible3-query-matrix.sh" "$base/ch1m-select-confirm-eligible3/policy.js" "$base/ch1m-select-confirm-eligible3/check-matrix.js" > "$out/driver.before"
complete=0
failed_commands=0
finish() {
  rc=$?
  trap - EXIT
  manifest > "$out/source.after"
  sha256sum "$bin" > "$out/binary.after"
  sha256sum "$profile"/{server.xml,profile.xml,launch.sh,monitor.sh,resources.sh,resources-policy.sh,readiness.sh} > "$out/config.after"
  sha256sum "$base/ch1m-eligible3-query-matrix.sh" "$base/ch1m-select-confirm-eligible3/policy.js" "$base/ch1m-select-confirm-eligible3/check-matrix.js" > "$out/driver.after"
  if ! cmp -s "$out/source.before" "$out/source.after" || ! cmp -s "$out/binary.before" "$out/binary.after" || ! cmp -s "$out/config.before" "$out/config.after" || ! cmp -s "$out/driver.before" "$out/driver.after" || [[ -n $(git status --porcelain=v1) ]]; then rc=4; fi
  state=incomplete
  if [[ $complete == 18 && $rc == 0 && $failed_commands == 0 ]]; then state=passed; fi
  if [[ $complete == 18 && $rc == 10 && $failed_commands -gt 0 ]]; then state=complete-with-failures; fi
  printf 'exit=%s state=%s commands=%s attempts=%s failed_commands=%s end=%s\n' "$rc" "$state" "$complete" "$((complete*1600))" "$failed_commands" "$(date -u +%FT%TZ)" > "$out/status"
  exit "$rc"
}
trap finish EXIT
active() {
  [[ $(sha256sum "$profile/deadline.epoch" | cut -d' ' -f1) == "$deadline_hash" ]] && (( $(date +%s)+60 < deadline ))
  [[ $(docker inspect --format '{{.Id}} {{.State.Running}} {{.State.OOMKilled}} {{.RestartCount}} {{index .Config.Labels "otel283.owner"}} {{index .Config.Labels "otel283.profile"}} {{index .Config.Labels "otel283.session"}}' otel283-ch16-resume02) == "$instance true false 0 otel283-vxnar ch16-4cpu-16g-v1 resume02" ]]
  [[ -e "$profile/monitor.heartbeat" ]] && (( $(date +%s)-$(stat -c %Y "$profile/monitor.heartbeat") < 15 ))
}
admin() { curl --noproxy '*' --fail --silent --show-error --max-time 15 --data-binary "$1" http://127.0.0.1:18125/; }
merges_boundary() {
  local file=$1 n
  active
  n=$(admin "SELECT count() FROM system.merges WHERE database IN ('otel_ch1m_g8192_0287','otel_ch1m_g512_0287','otel_ch1m_g64_0287','otel_ch1m_g1_0287','otel_ch1m_g1_30m_0288') FORMAT TabSeparated")
  [[ "$n" =~ ^[0-9]+$ ]] || { echo 'Invalid merge observation' >&2; return 1; }
  printf 'active_merges=%s\n' "$n" > "$file"
  [[ "$n" == 0 ]] || { echo 'Active merge at timed-command boundary; matrix incomplete' >&2; return 1; }
}
settled=0
for sample in $(seq 1 60); do
  active
  n=$(admin "SELECT count() FROM system.merges WHERE database IN ('otel_ch1m_g8192_0287','otel_ch1m_g512_0287','otel_ch1m_g64_0287','otel_ch1m_g1_0287','otel_ch1m_g1_30m_0288') FORMAT TabSeparated")
  [[ "$n" =~ ^[0-9]+$ ]]
  printf '%s active_merges=%s\n' "$(date -u +%FT%TZ)" "$n" >> "$out/merge-drain.txt"
  if [[ "$n" == 0 ]]; then settled=$((settled+1)); else settled=0; fi
  (( settled < 3 )) || break
  sleep 5
done
(( settled >= 3 )) || { echo 'CH merge drain did not complete; no query-tuning verdict' >&2; exit 6; }
common=(--backend ch-attrs --order time --ch-url http://127.0.0.1:18125 --seed 283
  --count 1000000 --tenants 1 --attrs 8 --match-every 100 --k 100
  --ch-batch 8192 --ch-batch-bytes 8388608 --batch 32 --save-mode batch --workers 2
  --max-candidates 2000000 --max-bytes 268435456 --timeout 10m --revision "$revision")
for round in 1 2 3; do
  case "$round" in 1) order=(8192 64 512);; 2) order=(512 8192 64);; 3) order=(64 512 8192);; esac
  ordinal=0
  for granularity in "${order[@]}"; do
    run="ch1m_g${granularity}_0287"
    if (( (round+ordinal)%2 )); then transports=(native http); else transports=(http native); fi
    for transport in "${transports[@]}"; do
      active
      args=("${common[@]}" --run "$run" --ch-index-granularity "$granularity" --ch-query-transport "$transport")
      if [[ "$transport" == native ]]; then args+=(--ch-native-addr 127.0.0.1:19005); fi
      (( deadline-$(date +%s) >= 660 )) || { echo 'Insufficient TTL for 10m command; matrix incomplete' >&2; exit 1; }
      receipt="$out/query-g${granularity}-${transport}-r${round}.json"
      merges_boundary "${receipt%.json}-merges-before.txt"
      if "$bin" "${args[@]}" --mode query --suite all --iterations 1600 --output "$receipt"; then rc=0; else rc=$?; fi
      printf '%s\n' "$rc" > "${receipt%.json}.rc"
      merges_boundary "${receipt%.json}-merges-after.txt"
      failures=$(node "$base/ch1m-select-confirm-eligible3/check-matrix.js" "$receipt" "$granularity" "$transport" "$rc")
      [[ $failures =~ ^[0-9]+$ ]] || { echo 'Invalid sample-failure count' >&2; exit 1; }
      if (( failures > 0 )); then failed_commands=$((failed_commands+1)); fi
      complete=$((complete+1))
    done
    ordinal=$((ordinal+1))
  done
done
active
admin "SELECT database,table,sum(rows) AS rows,sum(bytes_on_disk) AS bytes,sum(marks) AS marks FROM system.parts WHERE active AND database IN ('otel_ch1m_g8192_0287','otel_ch1m_g512_0287','otel_ch1m_g64_0287','otel_ch1m_g1_30m_0288') GROUP BY database,table FORMAT JSONEachRow" > "$out/parts.after.jsonl"
[[ $complete == 18 ]] || { echo 'Matrix command census incomplete' >&2; exit 1; }
if (( failed_commands > 0 )); then
  echo "Complete eligible3 matrix: 28800 attempts, $failed_commands receipts include sample failures; selection must exclude their profiles."
  exit 10
fi
echo 'Completed eligible3 rotated HTTP/native query matrix: 28800 source-oracle answers on three audited 1M layouts; g1 excluded after audit failures; selection and 1000/class confirmation remain separate.'
